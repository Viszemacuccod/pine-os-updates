#!/usr/bin/python3
"""Notes: quick notes that save themselves, in Pine's look (same frame as Pine Settings).
Each note is a plain text file in ~/.local/share/pine-notes/ (open them with any editor).
Usage: pine-notes
"""
import glob
import os
import sys
import time

_HERE = os.path.dirname(os.path.abspath(__file__))
for _p in ("/usr/lib/pine-settings", os.path.join(_HERE, "..", "pine-settings")):
    if os.path.isdir(_p):
        sys.path.insert(0, _p)

import gi  # noqa: E402
gi.require_version("Gtk", "4.0")
gi.require_version("Adw", "1")
from gi.repository import Adw, Gdk, Gio, GLib, Gtk  # noqa: E402

import look  # noqa: E402

try:
    from common import _
except Exception:  # pragma: no cover
    def _(t):
        return t

DIR = os.path.join(GLib.get_user_data_dir(), "pine-notes")


def read(path):
    try:
        with open(path, encoding="utf-8") as f:
            return f.read()
    except OSError:
        return ""


class Window(Adw.ApplicationWindow):
    def __init__(self, app):
        super().__init__(application=app, title=_("Notes"))
        self.set_default_size(900, 640)
        self.set_size_request(360, 400)
        look.apply()
        os.makedirs(DIR, exist_ok=True)
        self.cur, self.pending, self.text = None, 0, ""
        self.toasts = Adw.ToastOverlay()
        self.split = Adw.NavigationSplitView()
        self.split.set_min_sidebar_width(260)
        self.split.set_max_sidebar_width(320)
        bp = Adw.Breakpoint.new(Adw.BreakpointCondition.parse("max-width: 640sp"))
        bp.add_setter(self.split, "collapsed", True)
        self.add_breakpoint(bp)
        self.toasts.set_child(self.split)
        self.set_content(self.toasts)

        # sidebar: New note, search, the notes
        box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=6, margin_start=10, margin_end=10, margin_bottom=10)
        new = Gtk.Button(label=_("New note"))
        new.add_css_class("suggested-action")
        new.connect("clicked", lambda _b: self.new_note())
        box.append(new)
        self.search = Gtk.SearchEntry(placeholder_text=_("Search notes"))
        self.search.connect("search-changed", lambda _e: self.list.invalidate_filter())
        box.append(self.search)
        self.list = Gtk.ListBox()
        self.list.add_css_class("navigation-sidebar")
        self.list.set_filter_func(self._filter)
        self.list.connect("row-selected", lambda _l, r: r and self.open_note(r.path))
        sc = Gtk.ScrolledWindow(vexpand=True, hscrollbar_policy=Gtk.PolicyType.NEVER, child=self.list)
        box.append(sc)
        side = Adw.ToolbarView()
        side.add_top_bar(Adw.HeaderBar())
        side.set_content(box)
        self.split.set_sidebar(Adw.NavigationPage(title=_("Notes"), child=side))

        # the note
        self.view = Gtk.TextView(wrap_mode=Gtk.WrapMode.WORD_CHAR, top_margin=16, bottom_margin=16,
                                 left_margin=20, right_margin=20)
        self.view.set_sensitive(False)
        self.buf = self.view.get_buffer()
        self.buf.connect("changed", self._changed)
        card = Gtk.ScrolledWindow(child=self.view, vexpand=True, margin_start=12, margin_end=12, margin_bottom=12)
        card.add_css_class("card")
        self.empty = Adw.StatusPage(icon_name="document-edit-symbolic", title=_("No note selected"),
                                    description=_("Pick a note on the left or start a new one."))
        self.pages = Gtk.Stack()
        self.pages.add_named(self.empty, "empty")
        self.pages.add_named(card, "note")
        header = Adw.HeaderBar()
        self.del_btn = Gtk.Button(icon_name="user-trash-symbolic", tooltip_text=_("Delete note"))
        self.del_btn.add_css_class("flat")
        self.del_btn.connect("clicked", lambda _b: self.delete())
        header.pack_end(self.del_btn)
        tv = Adw.ToolbarView()
        tv.add_top_bar(header)
        tv.set_content(self.pages)
        self.content = Adw.NavigationPage(title=_("Notes"), child=tv)
        self.split.set_content(self.content)
        self.reload()
        if not self.list.get_first_child():
            self.new_note()
        else:
            self.list.select_row(self.list.get_row_at_index(0))

    # ---- list
    def _filter(self, row):
        q = self.search.get_text().strip().lower()
        return not q or q in row.text.lower()

    def reload(self, select=None):
        while self.list.get_first_child():
            self.list.remove(self.list.get_first_child())
        files = sorted(glob.glob(os.path.join(DIR, "*.txt")), key=os.path.getmtime, reverse=True)
        for p in files:
            text = read(p)
            lines = [ln for ln in text.splitlines() if ln.strip()]
            row = Gtk.ListBoxRow()
            row.path, row.text = p, text
            box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, margin_top=6, margin_bottom=6, margin_start=6)
            t = Gtk.Label(label=lines[0] if lines else _("New note"), xalign=0, ellipsize=3)
            t.add_css_class("heading")
            when = time.strftime("%Y-%m-%d %H:%M", time.localtime(os.path.getmtime(p)))
            s = Gtk.Label(label=f"{when}  {lines[1] if len(lines) > 1 else ''}", xalign=0, ellipsize=3)
            s.add_css_class("dim-label")
            s.add_css_class("caption")
            box.append(t)
            box.append(s)
            row.set_child(box)
            self.list.append(row)
            if p == (select or self.cur):
                self.list.select_row(row)

    def new_note(self):
        self.save()
        p = os.path.join(DIR, f"{time.time_ns()}.txt")
        open(p, "w").close()
        self.reload(select=p)
        self.view.grab_focus()

    def open_note(self, path):
        if path == self.cur:
            return
        self.save()
        self.cur = path
        self.text = read(path)
        self.buf.handler_block_by_func(self._changed)
        self.buf.set_text(self.text)
        self.buf.handler_unblock_by_func(self._changed)
        self.view.set_sensitive(True)
        self.pages.set_visible_child_name("note")
        self.split.set_show_content(True)

    # ---- saving (a moment after you stop typing)
    def _changed(self, _buf):
        if self.pending:
            GLib.source_remove(self.pending)
        self.pending = GLib.timeout_add(600, self._autosave)

    def _autosave(self):
        self.pending = 0
        self.save()
        self.reload()
        return False

    def save(self):
        if self.pending:
            GLib.source_remove(self.pending)
            self.pending = 0
        if not self.cur or not os.path.exists(self.cur):
            return
        text = self.buf.get_text(self.buf.get_start_iter(), self.buf.get_end_iter(), False)
        if text != self.text:
            try:
                with open(self.cur, "w", encoding="utf-8") as f:
                    f.write(text)
                self.text = text
            except OSError as e:
                self.toasts.add_toast(Adw.Toast.new(str(e)))

    def delete(self):
        if not self.cur:
            return
        try:
            Gio.File.new_for_path(self.cur).trash(None)     # to the Recycle Bin, not for good
        except GLib.Error as e:
            self.toasts.add_toast(Adw.Toast.new(e.message))
            return
        self.cur = None
        self.buf.set_text("")
        self.view.set_sensitive(False)
        self.pages.set_visible_child_name("empty")
        self.reload()
        if self.list.get_first_child():
            self.list.select_row(self.list.get_row_at_index(0))


class App(Adw.Application):
    def __init__(self):
        super().__init__(application_id="org.pineos.Notes", flags=Gio.ApplicationFlags.FLAGS_NONE)

    def do_activate(self):
        win = self.props.active_window or Window(self)
        win.present()

    def do_shutdown(self):
        win = self.props.active_window
        if win:
            win.save()
        Adw.Application.do_shutdown(self)


if __name__ == "__main__":
    sys.exit(App().run(sys.argv))
