#!/usr/bin/python3
"""Pine Files: the file manager of Pine OS, laid out like the Windows 11 File Explorer.

Usage: pine-files [folder ...]      each folder opens in its own tab
Tabs on top; back / forward / up / refresh, a path bar (click empty space to type a path) and
search; a command bar (New, cut, copy, paste, rename, delete, Sort, View, Details); on the left
Home, Quick access (Desktop, Downloads, Documents, Pictures, Music, Videos) and This PC (drives,
file system, Recycle Bin); a details pane on the right and a status bar.
Files are copied and moved with cp / mv, deleted to the Recycle Bin (Shift+Delete: for good).
"""
import os
import re
import subprocess
import sys
import threading

_HERE = os.path.dirname(os.path.abspath(__file__))
for _p in ("/usr/lib/pine-settings", os.path.join(_HERE, "..", "pine-settings")):
    if os.path.isdir(_p):
        sys.path.insert(0, _p)

import gi  # noqa: E402
gi.require_version("Gtk", "4.0")
gi.require_version("Adw", "1")
from gi.repository import Adw, Gdk, Gio, GLib, GObject, Gtk  # noqa: E402

import look  # noqa: E402

try:
    from common import _  # the user's language (untranslated text stays English)
except Exception:  # pragma: no cover
    def _(text):
        return text

APP_ID = "org.pineos.Files"
ATTRS = ",".join(["standard::name", "standard::display-name", "standard::icon", "standard::content-type",
                  "standard::size", "standard::type", "standard::is-hidden", "standard::is-backup",
                  "time::modified", "thumbnail::path", "thumbnail::is-valid"])
FOLDER = Gio.FileType.DIRECTORY
HOME = os.path.expanduser("~")


# ---------------------------------------------------------------- helpers
def fmt_size(n):
    n = float(n)
    for unit in ("bytes", "KB", "MB", "GB", "TB"):
        if n < 1024 or unit == "TB":
            return f"{n:.0f} {unit}" if unit in ("bytes", "KB") or n >= 100 else f"{n:.1f} {unit}"
        n /= 1024


def file_of(info):
    return info.get_attribute_object("standard::file")


def is_dir(info):
    return info.get_file_type() == FOLDER


def type_text(info):
    return _("File folder") if is_dir(info) else (Gio.content_type_get_description(info.get_content_type() or "") or "")


def modified(info):
    dt = info.get_modification_date_time()
    return dt.to_local().format("%Y-%m-%d %H:%M") if dt else ""


def natural(s):
    return [int(t) if t.isdigit() else t for t in re.split(r"(\d+)", s.casefold())]


SORT_KEYS = {
    "name": lambda i: natural(i.get_display_name()),
    "date": lambda i: (i.get_modification_date_time().to_unix() if i.get_modification_date_time() else 0),
    "type": lambda i: type_text(i).casefold(),
    "size": lambda i: 0 if is_dir(i) else i.get_size(),
}


def sorter_for(kind):
    key = SORT_KEYS[kind]

    def cmp(a, b, _d):
        if is_dir(a) != is_dir(b):                       # folders first, like Explorer
            return -1 if is_dir(a) else 1
        x, y = key(a), key(b)
        return (x > y) - (x < y)
    return Gtk.CustomSorter.new(cmp, None)


def unique(folder, name, folder_item=False):
    base, ext = (name, "") if folder_item else os.path.splitext(name)
    cand, n = name, 2
    while folder.get_child(cand).query_exists():
        cand, n = f"{base} ({n}){ext}", n + 1
    return cand


def quick_places():
    out = [(_("Desktop"), GLib.UserDirectory.DIRECTORY_DESKTOP, "user-desktop"),
           (_("Downloads"), GLib.UserDirectory.DIRECTORY_DOWNLOAD, "folder-download"),
           (_("Documents"), GLib.UserDirectory.DIRECTORY_DOCUMENTS, "folder-documents"),
           (_("Pictures"), GLib.UserDirectory.DIRECTORY_PICTURES, "folder-pictures"),
           (_("Music"), GLib.UserDirectory.DIRECTORY_MUSIC, "folder-music"),
           (_("Videos"), GLib.UserDirectory.DIRECTORY_VIDEOS, "folder-videos")]
    res = []
    for label, d, icon in out:
        p = GLib.get_user_special_dir(d)
        if p and os.path.isdir(p) and p != HOME:
            res.append((label, Gio.File.new_for_path(p), icon))
    return res


# ---------------------------------------------------------------- one tab
class FilesView(Gtk.Box):
    """The folder shown in one tab: details list or icons, its history, its details pane."""

    def __init__(self, win):
        super().__init__()
        self.win = win
        self.loc = None
        self.back_stack, self.fwd_stack = [], []
        self.show_hidden, self.text, self.mode = False, "", "details"
        self.dl = None
        self.hs = {}
        self.flt = Gtk.CustomFilter.new(self._match)
        self.sort_model = Gtk.SortListModel.new(None, None)
        self.sel = Gtk.MultiSelection.new(self.sort_model)
        self.sel.connect("selection-changed", lambda *_a: self._selection_changed())

        self.cols = {}
        self.list = Gtk.ColumnView(model=self.sel)
        self.list.add_css_class("fm-list")
        self.list.set_show_row_separators(False)
        for cid, title, width in (("name", _("Name"), 0), ("date", _("Date modified"), 170),
                                  ("type", _("Type"), 160), ("size", _("Size"), 100)):
            col = Gtk.ColumnViewColumn.new(title, self._cell(cid))
            col.set_sorter(sorter_for(cid))
            col.set_resizable(True)
            if width:
                col.set_fixed_width(width)
            else:
                col.set_expand(True)
            self.list.append_column(col)
            self.cols[cid] = col
        self.sort_model.set_sorter(self.list.get_sorter())
        self.list.sort_by_column(self.cols["name"], Gtk.SortType.ASCENDING)     # like Explorer: A-Z, folders first
        self.list.connect("activate", lambda _v, pos: self.open_pos(pos))

        self.grid = Gtk.GridView(model=self.sel, factory=self._grid_cell(), max_columns=20)
        self.grid.add_css_class("fm-grid")
        self.grid.connect("activate", lambda _v, pos: self.open_pos(pos))

        self.views = Gtk.Stack(hexpand=True, vexpand=True)
        self.views.add_named(Gtk.ScrolledWindow(child=self.list), "details")
        self.views.add_named(Gtk.ScrolledWindow(child=self.grid), "icons")
        for v in (self.list, self.grid):
            g = Gtk.GestureClick(button=3)
            g.connect("pressed", self._context, v)
            v.add_controller(g)

        self.empty = Gtk.Label(label=_("This folder is empty."))
        self.empty.add_css_class("dim-label")
        self.empty.set_visible(False)
        overlay = Gtk.Overlay(child=self.views)
        overlay.add_overlay(self.empty)
        self.empty.set_can_target(False)

        # details pane
        self.pane = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=6)
        self.pane.add_css_class("fm-pane")
        self.pane.set_size_request(290, -1)
        self.p_pic = Gtk.Picture(content_fit=Gtk.ContentFit.SCALE_DOWN, height_request=150)
        self.p_img = Gtk.Image(pixel_size=96, height_request=150)
        self.p_title = Gtk.Label(xalign=0, wrap=True, selectable=True)
        self.p_title.add_css_class("title-3")
        self.p_info = Gtk.Label(xalign=0, wrap=True, selectable=True)
        self.p_info.add_css_class("dim-label")
        for w in (self.p_img, self.p_pic, self.p_title, self.p_info):
            self.pane.append(w)
        self.revealer = Gtk.Revealer(child=self.pane, transition_type=Gtk.RevealerTransitionType.SLIDE_LEFT,
                                     reveal_child=win.show_pane)
        self.append(overlay)
        self.append(Gtk.Separator(orientation=Gtk.Orientation.VERTICAL))
        self.append(self.revealer)

    # ---- model
    def _match(self, info):
        if not self.show_hidden and (info.get_is_hidden() or info.get_is_backup()):
            return False
        return self.text in info.get_display_name().lower()

    def go(self, f, push=True):
        if f is None:
            return
        if push and self.loc is not None and not f.equal(self.loc):
            self.back_stack.append(self.loc)
            self.fwd_stack.clear()
        self.loc = f
        self.dl = Gtk.DirectoryList.new(ATTRS, f)
        self.dl.set_monitored(True)
        self.dl.connect("notify::loading", lambda *_a: self._status())
        filt = Gtk.FilterListModel.new(self.dl, self.flt)
        filt.connect("items-changed", lambda *_a: self._status())
        self.sort_model.set_model(filt)
        self.text = ""
        self.win.location_changed(self)
        self._status()

    def back(self):
        if self.back_stack:
            self.fwd_stack.append(self.loc)
            self.go(self.back_stack.pop(), push=False)

    def forward(self):
        if self.fwd_stack:
            self.back_stack.append(self.loc)
            self.go(self.fwd_stack.pop(), push=False)

    def up(self):
        p = self.loc.get_parent() if self.loc else None
        if p:
            self.go(p)

    def reload(self):
        self.go(self.loc, push=False)

    def refilter(self):
        self.flt.changed(Gtk.FilterChange.DIFFERENT)
        self._status()

    def set_mode(self, mode):
        self.mode = mode
        self.views.set_visible_child_name(mode)

    def sort_by(self, kind, descending):
        col = self.cols[kind]
        self.list.sort_by_column(col, Gtk.SortType.DESCENDING if descending else Gtk.SortType.ASCENDING)

    # ---- selection
    def selected(self):
        bs, out = self.sel.get_selection(), []
        if bs.get_size():
            for i in range(self.sel.get_n_items()):
                if bs.contains(i):
                    out.append(self.sel.get_item(i))
        return out

    def selected_files(self):
        return [file_of(i) for i in self.selected()]

    def select_all(self):
        self.sel.select_all()

    def open_pos(self, pos):
        info = self.sel.get_item(pos)
        if info is not None:
            self.open_info(info)

    def open_info(self, info):
        f = file_of(info)
        if is_dir(info):
            self.go(f)
        else:
            try:
                Gio.AppInfo.launch_default_for_uri(f.get_uri(), None)
            except GLib.Error as e:
                self.win.toast(e.message)

    def _selection_changed(self):
        self._status()
        self.win.selection_changed(self)

    def _status(self):
        n = self.sel.get_n_items()
        self.empty.set_visible(n == 0 and not (self.dl and self.dl.get_loading()))
        sel = self.selected()
        if sel:
            size = sum(i.get_size() for i in sel if not is_dir(i))
            text = _("%d items selected") % len(sel) if len(sel) > 1 else _("1 item selected")
            if size:
                text += "   " + fmt_size(size)
        else:
            text = _("%d items") % n if n != 1 else _("1 item")
        if self.win.current() is self:
            self.win.status.set_label(text)
        self._pane(sel, n)

    def _pane(self, sel, n):
        self.p_pic.set_visible(False)
        self.p_img.set_visible(True)
        if len(sel) == 1:
            i = sel[0]
            self.p_title.set_label(i.get_display_name())
            lines = [type_text(i), modified(i)]
            if not is_dir(i):
                lines.insert(1, fmt_size(i.get_size()))
            self.p_info.set_label("\n".join(x for x in lines if x))
            tp = i.get_attribute_byte_string("thumbnail::path")
            if tp and os.path.exists(tp):
                self.p_pic.set_filename(tp)
                self.p_pic.set_visible(True)
                self.p_img.set_visible(False)
            elif i.get_icon():
                self.p_img.set_from_gicon(i.get_icon())
        elif sel:
            self.p_img.set_from_icon_name("edit-select-all-symbolic")
            self.p_title.set_label(_("%d items selected") % len(sel))
            self.p_info.set_label("")
        else:
            self.p_img.set_from_icon_name("folder")
            self.p_title.set_label(self.loc.get_basename() if self.loc and self.loc.get_basename() else "/")
            self.p_info.set_label(_("%d items") % n)

    # ---- context menu
    def _context(self, gesture, _n, x, y, view):
        w = view.pick(x, y, Gtk.PickFlags.DEFAULT)
        while w is not None and not hasattr(w, "_pos"):
            w = w.get_parent()
        if w is not None and not self.sel.is_selected(w._pos):
            self.sel.select_item(w._pos, True)
        elif w is None:
            self.sel.unselect_all()
        pop = Gtk.PopoverMenu.new_from_model(self.win.menu_for(bool(self.selected())))
        pop.set_parent(view)
        r = Gdk.Rectangle()
        r.x, r.y, r.width, r.height = int(x), int(y), 1, 1
        pop.set_pointing_to(r)
        pop.set_has_arrow(False)
        pop.connect("closed", lambda p: GLib.idle_add(p.unparent))
        pop.popup()

    # ---- cells
    def _cell(self, cid):
        f = Gtk.SignalListItemFactory()

        def setup(_f, li):
            lb = Gtk.Label(xalign=0 if cid in ("name", "type", "date") else 1, ellipsize=3, hexpand=True)
            if cid == "name":
                box = Gtk.Box(spacing=10)
                box.append(Gtk.Image(pixel_size=22))
                box.append(lb)
                box.add_css_class("fm-cell")
                li.set_child(box)
            else:
                lb.add_css_class("fm-cell")
                lb.add_css_class("dim-label")
                li.set_child(lb)

        def bind(_f, li):
            info, w = li.get_item(), li.get_child()
            w._pos = li.get_position()
            if cid == "name":
                lb = w.get_last_child()
                lb._pos = w._pos
                if info.get_icon():
                    w.get_first_child().set_from_gicon(info.get_icon())
                lb.set_label(info.get_display_name())
            elif cid == "date":
                w.set_label(modified(info))
            elif cid == "type":
                w.set_label(type_text(info))
            else:
                w.set_label("" if is_dir(info) else fmt_size(info.get_size()))

        f.connect("setup", setup)
        f.connect("bind", bind)
        return f

    def _grid_cell(self):
        f = Gtk.SignalListItemFactory()

        def setup(_f, li):
            box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=4, width_request=104)
            box.add_css_class("fm-cell")
            box.append(Gtk.Image(pixel_size=64))
            box.append(Gtk.Label(wrap=True, wrap_mode=2, lines=2, ellipsize=3, justify=Gtk.Justification.CENTER,
                                 max_width_chars=12))
            li.set_child(box)

        def bind(_f, li):
            info, box = li.get_item(), li.get_child()
            box._pos = li.get_position()
            if info.get_icon():
                box.get_first_child().set_from_gicon(info.get_icon())
            box.get_last_child().set_label(info.get_display_name())

        f.connect("setup", setup)
        f.connect("bind", bind)
        return f


# ---------------------------------------------------------------- window
class Window(Adw.ApplicationWindow):
    def __init__(self, app):
        super().__init__(application=app, title=_("Files"))
        self.set_default_size(1180, 760)
        self.set_size_request(560, 420)
        _mode, acc = look.saved_look()
        look.apply()
        css = Gtk.CssProvider()
        css.load_from_string(f"""
.fm-cell {{ padding: 6px 8px; }}
.fm-list > listview > row {{ padding: 0 4px; border-radius: 5px; }}
.fm-grid > child {{ padding: 6px; border-radius: 5px; }}
.navigation-sidebar > row.fm-head {{ min-height: 30px; opacity: 0.65; }}
.fm-path {{ background-color: color-mix(in srgb, currentColor 7%, transparent); border-radius: 5px; padding: 0 4px; min-height: 32px; }}
.fm-path button {{ min-height: 24px; padding: 0 8px; }}
.fm-pane {{ padding: 16px; }}
.fm-cmd {{ padding: 2px 8px 6px 8px; }}
""")
        Gtk.StyleContext.add_provider_for_display(Gdk.Display.get_default(), css,
                                                  Gtk.STYLE_PROVIDER_PRIORITY_USER + 2)
        self.show_pane, self.show_hidden, self.clip, self.clip_cut = False, False, [], False
        self.toasts = Adw.ToastOverlay()
        self.tabview = Adw.TabView()
        self._actions()

        # same frame as Pine Settings: sidebar page + content page, plain header bars
        self.split = Adw.NavigationSplitView()
        self.split.set_min_sidebar_width(260)
        self.split.set_max_sidebar_width(300)
        bp = Adw.Breakpoint.new(Adw.BreakpointCondition.parse("max-width: 640sp"))
        bp.add_setter(self.split, "collapsed", True)
        self.add_breakpoint(bp)

        tabs = Adw.TabBar(view=self.tabview, autohide=False, expand_tabs=False)
        plus = Gtk.Button(icon_name="list-add-symbolic", tooltip_text=_("New tab (Ctrl+T)"))
        plus.add_css_class("flat")
        plus.connect("clicked", lambda _b: self.new_tab(Gio.File.new_for_path(HOME)))
        tabs.set_start_action_widget(plus)
        self.status = Gtk.Label(xalign=0, margin_start=14, margin_top=4, margin_bottom=4)
        self.status.add_css_class("dim-label")
        tb = Adw.ToolbarView()
        tb.add_top_bar(self._header())
        tb.add_top_bar(tabs)
        tb.add_top_bar(self._cmdbar())
        tb.set_content(self.tabview)
        tb.add_bottom_bar(self.status)
        self.content = Adw.NavigationPage(title=_("Files"), child=tb)
        self.split.set_content(self.content)
        self.split.set_sidebar(self._sidebar())
        self.toasts.set_child(self.split)
        self.set_content(self.toasts)
        self.tabview.connect("notify::selected-page", lambda *_a: self._tab_changed())
        self.tabview.connect("notify::n-pages", lambda *_a: self.close() if self.tabview.get_n_pages() == 0 else None)
        self._mounts = Gio.VolumeMonitor.get()
        for sig in ("mount-added", "mount-removed", "mount-changed", "volume-added", "volume-removed"):
            self._mounts.connect(sig, lambda *_a: self._fill_sidebar())
        self._fill_sidebar()

    # ---- actions
    def _actions(self):
        def add(name, cb, state=None, ptype=None):
            if state is None:
                a = Gio.SimpleAction.new(name, None)
                a.connect("activate", lambda _a, _p: cb())
            else:
                a = Gio.SimpleAction.new_stateful(name, ptype, state)
                a.connect("activate", cb)
            self.add_action(a)
            return a
        self.act = {}
        for name, cb in (("back", lambda: self.cur().back()), ("forward", lambda: self.cur().forward()),
                         ("up", lambda: self.cur().up()), ("refresh", lambda: self.cur().reload()),
                         ("newtab", lambda: self.new_tab(self.cur().loc)), ("closetab", self.close_tab),
                         ("focuspath", self.focus_path), ("open", self.open_selected),
                         ("opentab", self.open_in_tab), ("cut", lambda: self.clip_set(True)),
                         ("copy", lambda: self.clip_set(False)), ("paste", self.paste),
                         ("rename", self.rename), ("delete", lambda: self.delete(False)),
                         ("deleteperm", lambda: self.delete(True)), ("newfolder", self.new_folder),
                         ("newfile", self.new_file), ("selectall", self.select_all),
                         ("terminal", self.terminal), ("hiddenfiles", self.toggle_hidden)):
            self.act[name] = add(name, cb)
        add("sort", self._sort_chosen, GLib.Variant.new_string("name"), GLib.VariantType.new("s"))
        add("sortdir", self._sort_chosen, GLib.Variant.new_string("asc"), GLib.VariantType.new("s"))
        add("view", self._view_chosen, GLib.Variant.new_string("details"), GLib.VariantType.new("s"))
        add("details", self._pane_toggled, GLib.Variant.new_boolean(False))
        app = self.get_application()
        for name, keys in (("back", "<Alt>Left"), ("forward", "<Alt>Right"), ("up", "<Alt>Up"),
                           ("refresh", "F5"), ("newtab", "<Control>t"), ("closetab", "<Control>w"),
                           ("focuspath", "<Control>l"), ("cut", "<Control>x"), ("copy", "<Control>c"),
                           ("paste", "<Control>v"), ("rename", "F2"), ("delete", "Delete"),
                           ("deleteperm", "<Shift>Delete"), ("newfolder", "<Control><Shift>n"),
                           ("selectall", "<Control>a"), ("hiddenfiles", "<Control>h")):
            app.set_accels_for_action(f"win.{name}", [keys])

    def _edit(self, kind, _x):
        """Ctrl+C / X / V while typing in a text box belong to the text box."""
        self.get_focus().emit(kind + "-clipboard")

    def _in_text(self):
        return isinstance(self.get_focus(), Gtk.Text)

    def select_all(self):
        if self._in_text():
            self.get_focus().select_region(0, -1)
        else:
            self.cur().select_all()

    def _sort_chosen(self, action, value):
        action.set_state(value)
        v = self.cur()
        v.sort_by(self.lookup_action("sort").get_state().get_string(),
                  self.lookup_action("sortdir").get_state().get_string() == "desc")

    def _view_chosen(self, action, value):
        action.set_state(value)
        for i in range(self.tabview.get_n_pages()):
            self.tabview.get_nth_page(i).get_child().set_mode(value.get_string())

    def _pane_toggled(self, action, _v=None):
        self.show_pane = not action.get_state().get_boolean()
        action.set_state(GLib.Variant.new_boolean(self.show_pane))
        for i in range(self.tabview.get_n_pages()):
            self.tabview.get_nth_page(i).get_child().revealer.set_reveal_child(self.show_pane)

    # ---- bars
    def _header(self):
        bar = Adw.HeaderBar()
        for icon, act, tip in (("go-previous-symbolic", "win.back", _("Back (Alt+Left)")),
                               ("go-next-symbolic", "win.forward", _("Forward (Alt+Right)")),
                               ("go-up-symbolic", "win.up", _("Up (Alt+Up)")),
                               ("view-refresh-symbolic", "win.refresh", _("Refresh (F5)"))):
            b = Gtk.Button(icon_name=icon, action_name=act, tooltip_text=tip)
            b.add_css_class("flat")
            bar.pack_start(b)
        self.pathstack = Gtk.Stack(hexpand=True)
        self.crumbs = Gtk.Box()
        scroll = Gtk.ScrolledWindow(child=self.crumbs, hscrollbar_policy=Gtk.PolicyType.EXTERNAL,
                                    vscrollbar_policy=Gtk.PolicyType.NEVER)
        self.crumb_scroll = scroll
        self.pathstack.add_named(scroll, "crumbs")
        self.pathentry = Gtk.Entry(hexpand=True)
        self.pathentry.connect("activate", self._path_entered)
        keys = Gtk.EventControllerKey()
        keys.connect("key-pressed", lambda _c, kv, *_a: (self._path_mode(False), True)[1] if kv == Gdk.KEY_Escape else False)
        self.pathentry.add_controller(keys)
        foc = Gtk.EventControllerFocus()
        foc.connect("leave", lambda *_a: self._path_mode(False))
        self.pathentry.add_controller(foc)
        self.pathstack.add_named(self.pathentry, "entry")
        self.pathstack.add_css_class("fm-path")
        self.pathstack.set_size_request(320, -1)
        bar.set_title_widget(self.pathstack)
        self.search = Gtk.SearchEntry(width_chars=18)
        self.search.connect("search-changed", self._search)
        bar.pack_end(self.search)
        return bar

    def _cmdbar(self):
        bar = Gtk.Box(spacing=2, margin_start=8, margin_end=8, margin_bottom=6)
        bar.add_css_class("fm-cmd")
        new = Gio.Menu()
        new.append(_("Folder"), "win.newfolder")
        new.append(_("Text document"), "win.newfile")
        mb = Gtk.MenuButton(menu_model=new, tooltip_text=_("New"))
        mb.set_child(self._lbl(_("New"), "list-add-symbolic"))
        mb.add_css_class("flat")
        bar.append(mb)
        bar.append(Gtk.Separator(orientation=Gtk.Orientation.VERTICAL, margin_start=4, margin_end=4))
        for icon, act, tip in (("edit-cut-symbolic", "win.cut", _("Cut (Ctrl+X)")),
                               ("edit-copy-symbolic", "win.copy", _("Copy (Ctrl+C)")),
                               ("edit-paste-symbolic", "win.paste", _("Paste (Ctrl+V)")),
                               ("document-edit-symbolic", "win.rename", _("Rename (F2)")),
                               ("user-trash-symbolic", "win.delete", _("Delete (Del)"))):
            b = Gtk.Button(icon_name=icon, action_name=act, tooltip_text=tip)
            b.add_css_class("flat")
            bar.append(b)
        bar.append(Gtk.Separator(orientation=Gtk.Orientation.VERTICAL, margin_start=4, margin_end=4))
        sm = Gio.Menu()
        for label, key in ((_("Name"), "name"), (_("Date modified"), "date"), (_("Type"), "type"), (_("Size"), "size")):
            sm.append(label, f"win.sort::{key}")
        order = Gio.Menu()
        order.append(_("Ascending"), "win.sortdir::asc")
        order.append(_("Descending"), "win.sortdir::desc")
        sm.append_section(None, order)
        sb = Gtk.MenuButton(menu_model=sm)
        sb.set_child(self._lbl(_("Sort"), "view-sort-ascending-symbolic"))
        sb.add_css_class("flat")
        bar.append(sb)
        vm = Gio.Menu()
        vm.append(_("Details"), "win.view::details")
        vm.append(_("Icons"), "win.view::icons")
        hid = Gio.Menu()
        hid.append(_("Hidden files"), "win.hiddenfiles")
        vm.append_section(None, hid)
        vb = Gtk.MenuButton(menu_model=vm)
        vb.set_child(self._lbl(_("View"), "view-grid-symbolic"))
        vb.add_css_class("flat")
        bar.append(vb)
        bar.append(Gtk.Box(hexpand=True))
        d = Gtk.ToggleButton(action_name="win.details")
        d.set_child(self._lbl(_("Details"), "sidebar-show-right-symbolic"))
        d.add_css_class("flat")
        bar.append(d)
        return bar

    @staticmethod
    def _lbl(text, icon):
        box = Gtk.Box(spacing=6)
        box.append(Gtk.Image.new_from_icon_name(icon))
        box.append(Gtk.Label(label=text))
        return box

    def menu_for(self, has_selection):
        m = Gio.Menu()
        if has_selection:
            a = Gio.Menu()
            a.append(_("Open"), "win.open")
            a.append(_("Open in new tab"), "win.opentab")
            m.append_section(None, a)
            b = Gio.Menu()
            for label, act in ((_("Cut"), "cut"), (_("Copy"), "copy"), (_("Paste"), "paste"),
                               (_("Rename"), "rename"), (_("Delete"), "delete")):
                b.append(label, f"win.{act}")
            m.append_section(None, b)
        else:
            a = Gio.Menu()
            a.append(_("New folder"), "win.newfolder")
            a.append(_("New text document"), "win.newfile")
            a.append(_("Paste"), "win.paste")
            a.append(_("Select all"), "win.selectall")
            m.append_section(None, a)
        c = Gio.Menu()
        c.append(_("Open in Terminal"), "win.terminal")
        c.append(_("Refresh"), "win.refresh")
        m.append_section(None, c)
        return m

    # ---- sidebar
    def _sidebar(self):
        """Same structure as Pine Settings' sidebar: a card on top, then the navigation list."""
        box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=6)
        box.set_margin_start(10)
        box.set_margin_end(10)
        box.set_margin_bottom(10)
        card = Gtk.Button()
        card.add_css_class("flat")
        card.add_css_class("pine-usercard")
        inner = Gtk.Box(spacing=12)
        badge = Gtk.Image.new_from_icon_name("folder-symbolic")
        badge.set_pixel_size(24)
        badge.add_css_class("pine-badge")
        inner.append(badge)
        texts = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, valign=Gtk.Align.CENTER)
        name = Gtk.Label(label=_("Files"), xalign=0)
        name.add_css_class("heading")
        texts.append(name)
        free = ""
        try:
            fs = Gio.File.new_for_path(HOME).query_filesystem_info("filesystem::free", None)
            free = _("%s free") % fmt_size(fs.get_attribute_uint64("filesystem::free"))
        except GLib.Error:
            pass
        sub = Gtk.Label(label=free, xalign=0)
        sub.add_css_class("dim-label")
        sub.add_css_class("caption")
        texts.append(sub)
        inner.append(texts)
        card.set_child(inner)
        card.connect("clicked", lambda *_a: self.cur().go(Gio.File.new_for_path(HOME)))
        box.append(card)

        self.side = Gtk.ListBox(selection_mode=Gtk.SelectionMode.SINGLE)
        self.side.add_css_class("navigation-sidebar")
        self.side.set_activate_on_single_click(True)
        self.side.connect("row-activated", self._side_activated)
        self.side_items = []
        sc = Gtk.ScrolledWindow(vexpand=True, hscrollbar_policy=Gtk.PolicyType.NEVER)
        sc.set_child(self.side)
        box.append(sc)
        tv = Adw.ToolbarView()
        tv.add_top_bar(Adw.HeaderBar())
        tv.set_content(box)
        return Adw.NavigationPage(title=_("Files"), child=tv)

    def _side_row(self, label, icon, target, head=False):
        box = Gtk.Box(spacing=12, margin_start=6)
        if icon:
            img = Gtk.Image.new_from_gicon(icon) if isinstance(icon, Gio.Icon) else Gtk.Image.new_from_icon_name(icon)
            box.append(img)
        lb = Gtk.Label(label=label, xalign=0, hexpand=True, ellipsize=3)
        if head:
            lb.add_css_class("caption-heading")
        box.append(lb)
        row = Gtk.ListBoxRow(child=box, selectable=not head, activatable=not head)
        if head:
            row.add_css_class("fm-head")
        self.side.append(row)
        self.side_items.append(target)

    def _fill_sidebar(self):
        self.side.remove_all()
        self.side_items = []
        self._side_row(_("Home"), "user-home", Gio.File.new_for_path(HOME))
        self._side_row(_("Quick access"), None, None, head=True)
        for label, f, icon in quick_places():
            self._side_row(label, icon, f)
        self._side_row(_("This PC"), None, None, head=True)
        self._side_row(_("File system"), "drive-harddisk", Gio.File.new_for_path("/"))
        for m in self._mounts.get_mounts():
            if m.is_shadowed():
                continue
            root = m.get_default_location() or m.get_root()
            if root.get_path() in ("/", None) and root.get_uri_scheme() == "file":
                continue
            self._side_row(m.get_name(), m.get_icon(), root)
        for v in self._mounts.get_volumes():
            if v.get_mount() is None and v.can_mount():
                self._side_row(v.get_name(), v.get_icon(), v)
        self._side_row(_("Recycle Bin"), "user-trash", Gio.File.new_for_uri("trash:///"))
        cur = self.current()
        if cur:
            self._sync_sidebar(cur.loc)

    def _side_activated(self, _lb, row):
        t = self.side_items[row.get_index()]
        if isinstance(t, Gio.Volume):
            t.mount(Gio.MountMountFlags.NONE, None, None, lambda v, res: self._mounted(v, res))
        elif t is not None:
            self.cur().go(t)

    def _mounted(self, vol, res):
        try:
            vol.mount_finish(res)
            m = vol.get_mount()
            if m:
                self.cur().go(m.get_default_location() or m.get_root())
        except GLib.Error as e:
            self.toast(e.message)

    def _sync_sidebar(self, loc):
        self.side.unselect_all()
        best, blen = None, -1
        for i, t in enumerate(self.side_items):
            if isinstance(t, Gio.File) and loc is not None and (t.equal(loc) or (loc.has_prefix(t) and t.get_path() != "/")):
                n = len(t.get_path() or t.get_uri())
                if t.equal(loc):
                    best, blen = i, 10 ** 6
                elif n > blen:
                    best, blen = i, n
        if best is not None:
            self.side.select_row(self.side.get_row_at_index(best))

    # ---- tabs
    def current(self):
        p = self.tabview.get_selected_page()
        return p.get_child() if p else None

    cur = current

    def new_tab(self, f):
        v = FilesView(self)
        v.set_mode(self.lookup_action("view").get_state().get_string())
        page = self.tabview.append(v)
        page.set_title(_("Home"))
        self.tabview.set_selected_page(page)
        v.go(f)

    def close_tab(self):
        p = self.tabview.get_selected_page()
        if p:
            self.tabview.close_page(p)

    def open_in_tab(self):
        for f in self.cur().selected_files():
            self.new_tab(f)

    def _tab_changed(self):
        v = self.current()
        if v:
            self.location_changed(v)
            self.selection_changed(v)
            self.status.set_label(self.status.get_label())
            v._status()

    def location_changed(self, v):
        if v.loc is None:                      # the tab was just added, nothing opened yet
            return
        page = self.tabview.get_page(v)
        name = v.loc.get_basename() or "/"
        if v.loc.get_uri_scheme() == "trash":
            name = _("Recycle Bin")
        elif v.loc.get_path() == HOME:
            name = _("Home")
        page.set_title(name)
        if v is not self.current():
            return
        self.set_title(name)
        self._crumbs(v.loc)
        self.act["back"].set_enabled(bool(v.back_stack))
        self.act["forward"].set_enabled(bool(v.fwd_stack))
        self.act["up"].set_enabled(v.loc.get_parent() is not None)
        self.search.set_placeholder_text(_("Search %s") % name)
        self.search.set_text("")
        self._sync_sidebar(v.loc)

    def selection_changed(self, v):
        if v is not self.current():
            return
        has = bool(v.selected())
        for n in ("cut", "copy", "rename", "delete", "deleteperm", "open", "opentab"):
            self.act[n].set_enabled(has)

    # ---- path bar
    def _crumbs(self, f):
        c = self.crumbs
        while c.get_first_child():
            c.remove(c.get_first_child())

        def btn(label, target, icon=None):
            b = Gtk.Button()
            b.add_css_class("flat")
            if icon:
                b.set_child(Gtk.Image.new_from_icon_name(icon))
            else:
                b.set_label(label)
            b.connect("clicked", lambda _b: self.cur().go(target))
            c.append(b)

        def sep():
            c.append(Gtk.Label(label="›", margin_start=2, margin_end=2))

        if f.get_uri_scheme() == "file":
            path = f.get_path()
            if path == HOME or path.startswith(HOME + "/"):
                base, rest = HOME, [p for p in path[len(HOME):].split("/") if p]
                btn(_("Home"), Gio.File.new_for_path(HOME), "user-home-symbolic")
            else:
                base, rest = "/", [p for p in path.split("/") if p]
                btn("/", Gio.File.new_for_path("/"), "drive-harddisk-symbolic")
            acc = base
            for part in rest:
                sep()
                acc = os.path.join(acc, part)
                btn(part, Gio.File.new_for_path(acc))
        else:
            name = _("Recycle Bin") if f.get_uri_scheme() == "trash" else f.get_parse_name()
            btn(name, f)
        filler = Gtk.Box(hexpand=True)
        g = Gtk.GestureClick()
        g.connect("pressed", lambda *_a: self._path_mode(True))
        filler.add_controller(g)
        c.append(filler)
        adj = self.crumb_scroll.get_hadjustment()
        GLib.idle_add(lambda: adj.set_value(adj.get_upper() - adj.get_page_size()) and False)
        self.pathstack.set_visible_child_name("crumbs")

    def _path_mode(self, edit):
        if edit:
            f = self.cur().loc
            self.pathentry.set_text(f.get_path() or f.get_uri())
            self.pathstack.set_visible_child_name("entry")
            self.pathentry.grab_focus()
            self.pathentry.select_region(0, -1)
        else:
            self.pathstack.set_visible_child_name("crumbs")

    def focus_path(self):
        self._path_mode(True)

    def _path_entered(self, entry):
        text = entry.get_text().strip()
        f = Gio.File.new_for_uri(text) if "://" in text else Gio.File.new_for_path(os.path.expanduser(text))
        if f.query_file_type(Gio.FileQueryInfoFlags.NONE, None) == FOLDER:
            self._path_mode(False)
            self.cur().go(f)
            self.cur().list.grab_focus()
        else:
            self.toast(_("Windows cannot find '%s'. Check the spelling and try again.") % text)

    def _search(self, entry):
        v = self.cur()
        if v:
            v.text = entry.get_text().strip().lower()
            v.refilter()

    # ---- file operations
    def toast(self, text):
        self.toasts.add_toast(Adw.Toast.new(text))

    def open_selected(self):
        for i in self.cur().selected():
            self.cur().open_info(i)

    def toggle_hidden(self):
        self.show_hidden = not self.show_hidden
        for i in range(self.tabview.get_n_pages()):
            v = self.tabview.get_nth_page(i).get_child()
            v.show_hidden = self.show_hidden
            v.refilter()

    def terminal(self):
        p = self.cur().loc.get_path() or HOME
        subprocess.Popen(["xfce4-terminal", f"--working-directory={p}"])

    def clip_set(self, cut):
        if self._in_text():
            self._edit("cut" if cut else "copy", None)
            return
        files = self.cur().selected_files()
        if not files:
            return
        self.clip, self.clip_cut = files, cut
        try:
            self.get_clipboard().set_content(Gdk.ContentProvider.new_for_value(Gdk.FileList.new_from_list(files)))
        except Exception:
            pass
        self.toast((_("Cut %d items") if cut else _("Copied %d items")) % len(files))

    def paste(self):
        if self._in_text():
            self._edit("paste", None)
            return
        if self.clip:
            self._paste_files(self.clip, self.clip_cut)
            if self.clip_cut:
                self.clip, self.clip_cut = [], False
            return

        def got(cb, res):
            try:
                fl = cb.read_value_finish(res)
                self._paste_files(fl.get_files(), False)
            except Exception:
                self.toast(_("Nothing to paste"))
        self.get_clipboard().read_value_async(Gdk.FileList, GLib.PRIORITY_DEFAULT, None, got)

    def _paste_files(self, files, cut):
        dest = self.cur().loc
        if dest.get_path() is None:
            self.toast(_("You cannot paste here"))
            return
        jobs = []
        for f in files:
            if f.get_path() is None:
                continue
            same = f.get_parent() is not None and f.get_parent().equal(dest)
            if cut and same:
                continue
            name = f.get_basename()
            if same or dest.get_child(name).query_exists():
                name = unique(dest, name, os.path.isdir(f.get_path()))
            jobs.append(("mv" if cut else "cp", f.get_path(), dest.get_child(name).get_path()))
        if not jobs:
            return
        self.toast(_("Moving…") if cut else _("Copying…"))

        def work():
            errs = []
            for op, s, d in jobs:
                cmd = ["cp", "-a", "--", s, d] if op == "cp" else ["mv", "--", s, d]
                r = subprocess.run(cmd, capture_output=True, text=True)
                if r.returncode:
                    errs.append(r.stderr.strip())
            GLib.idle_add(lambda: self.toast(errs[0] if errs else _("Done")))
        threading.Thread(target=work, daemon=True).start()

    def delete(self, permanent):
        if self._in_text():
            return
        files = self.cur().selected_files()
        if not files:
            return
        in_trash = self.cur().loc.get_uri_scheme() == "trash"
        if permanent or in_trash:
            d = Adw.AlertDialog.new(_("Delete permanently?"),
                                    _("%d item(s) will be deleted for good. This cannot be undone.") % len(files))
            d.add_response("cancel", _("Cancel"))
            d.add_response("delete", _("Delete"))
            d.set_response_appearance("delete", Adw.ResponseAppearance.DESTRUCTIVE)
            d.connect("response", lambda _d, r: r == "delete" and self._delete_now(files, True))
            d.present(self)
        else:
            self._delete_now(files, False)

    def _delete_now(self, files, permanent):
        for f in files:
            try:
                if permanent:
                    self._rm(f)
                else:
                    f.trash(None)
            except GLib.Error as e:
                self.toast(e.message)

    def _rm(self, f):
        if f.query_file_type(Gio.FileQueryInfoFlags.NOFOLLOW_SYMLINKS, None) == FOLDER:
            en = f.enumerate_children("standard::name", Gio.FileQueryInfoFlags.NOFOLLOW_SYMLINKS, None)
            for i in en:
                self._rm(f.get_child(i.get_name()))
        f.delete(None)

    def rename(self):
        if self._in_text():
            return
        sel = self.cur().selected()
        if len(sel) != 1:
            return
        info = sel[0]
        f = file_of(info)
        d = Adw.AlertDialog.new(_("Rename"), None)
        e = Gtk.Entry(text=info.get_display_name(), activates_default=True)
        d.set_extra_child(e)
        d.add_response("cancel", _("Cancel"))
        d.add_response("ok", _("Rename"))
        d.set_default_response("ok")
        d.set_response_appearance("ok", Adw.ResponseAppearance.SUGGESTED)

        def done(_d, r):
            new = e.get_text().strip()
            if r == "ok" and new and new != info.get_display_name():
                try:
                    f.set_display_name(new, None)
                except GLib.Error as err:
                    self.toast(err.message)
        d.connect("response", done)
        d.present(self)
        stem = os.path.splitext(info.get_display_name())[0] if not is_dir(info) else info.get_display_name()
        GLib.idle_add(lambda: (e.grab_focus(), e.select_region(0, len(stem))) and False)

    def new_folder(self):
        loc = self.cur().loc
        name = unique(loc, _("New folder"), True)
        try:
            loc.get_child(name).make_directory(None)
            self.toast(_("Created '%s'. Press F2 to rename it.") % name)
        except GLib.Error as e:
            self.toast(e.message)

    def new_file(self):
        loc = self.cur().loc
        name = unique(loc, _("New Text Document") + ".txt")
        try:
            loc.get_child(name).create(Gio.FileCreateFlags.NONE, None).close(None)
            self.toast(_("Created '%s'. Press F2 to rename it.") % name)
        except GLib.Error as e:
            self.toast(e.message)


class App(Adw.Application):
    def __init__(self):
        super().__init__(application_id=APP_ID, flags=Gio.ApplicationFlags.HANDLES_COMMAND_LINE)
        self.connect("command-line", self._cmd)

    def _cmd(self, _app, cmdline):
        files = [cmdline.create_file_for_arg(a) for a in cmdline.get_arguments()[1:]]
        win = self.props.active_window or Window(self)
        for f in files or ([Gio.File.new_for_path(HOME)] if win.tabview.get_n_pages() == 0 else []):
            win.new_tab(f)
        win.present()
        return 0


if __name__ == "__main__":
    sys.exit(App().run(sys.argv))
