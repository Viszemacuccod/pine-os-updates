"""Accounts: your name, picture, password, automatic sign-in, other users."""
import grp
import os
import pty
import pwd
import re
import select
import time

from gi.repository import Adw, Gdk, GdkPixbuf, Gio, GLib, Gtk

import common as c

PAGES, SEARCH = {}, []
AUTOLOGIN = "/etc/lightdm/lightdm.conf.d/60-pine-autologin.conf"
FACE = os.path.join(GLib.get_home_dir(), ".face")
USER_GROUPS = "cdrom audio dip video plugdev netdev lpadmin scanner bluetooth users"


def me():
    return pwd.getpwuid(os.getuid())


def real_name(p):
    return p.pw_gecos.split(",")[0] or p.pw_name


def is_admin(username):
    try:
        return username in grp.getgrnam("sudo").gr_mem
    except KeyError:
        return False


def load_avatar(avatar):
    if os.path.exists(FACE):
        try:
            avatar.set_custom_image(Gdk.Texture.new_from_filename(FACE))
        except GLib.Error:
            pass


def accounts_user():
    """D-Bus proxy for this user in AccountsService (None if it is not available)."""
    try:
        bus = Gio.bus_get_sync(Gio.BusType.SYSTEM, None)
        res = bus.call_sync("org.freedesktop.Accounts", "/org/freedesktop/Accounts", "org.freedesktop.Accounts",
                            "FindUserByName", GLib.Variant("(s)", (me().pw_name,)), GLib.VariantType("(o)"),
                            Gio.DBusCallFlags.NONE, 3000, None)
        return Gio.DBusProxy.new_sync(bus, Gio.DBusProxyFlags.NONE, None, "org.freedesktop.Accounts",
                                      res.unpack()[0], "org.freedesktop.Accounts.User", None)
    except GLib.Error:
        return None


def accounts_call(method, value):
    u = accounts_user()
    if not u:
        return False
    try:
        u.call_sync(method, GLib.Variant("(s)", (value,)), Gio.DBusCallFlags.ALLOW_INTERACTIVE_AUTHORIZATION, 60000, None)
        return True
    except GLib.Error:
        return False


# ================================================================ picture and name
def change_picture():
    f = Gtk.FileFilter()
    f.set_name("Pictures")
    f.add_mime_type("image/*")
    filters = Gio.ListStore.new(Gtk.FileFilter)
    filters.append(f)
    d = Gtk.FileDialog(title="Choose your picture", filters=filters)

    def done(dlg, res):
        try:
            file = dlg.open_finish(res)
        except GLib.Error:
            return
        try:
            pb = GdkPixbuf.Pixbuf.new_from_file(file.get_path())
            side = min(pb.get_width(), pb.get_height())
            pb = pb.new_subpixbuf((pb.get_width() - side) // 2, (pb.get_height() - side) // 2, side, side)
            pb = pb.scale_simple(256, 256, GdkPixbuf.InterpType.BILINEAR)
            pb.savev(FACE, "png", [], [])
        except GLib.Error as e:
            c.error("This picture can't be used", e.message)
            return
        accounts_call("SetIconFile", FACE)
        load_avatar(c.WINDOW.avatar)
        c.toast("Picture changed")
        c.WINDOW.refresh()
    d.open(c.WINDOW, None, done)


def edit_name():
    d = Adw.AlertDialog(heading="Your name", body="Shown on the sign-in screen and in the start menu.")
    lb = Gtk.ListBox()
    lb.add_css_class("boxed-list")
    e = Adw.EntryRow(title="Name")
    e.set_text(real_name(me()))
    lb.append(e)
    d.set_extra_child(lb)
    d.add_response("cancel", "Cancel")
    d.add_response("save", "Save")
    d.set_response_appearance("save", Adw.ResponseAppearance.SUGGESTED)

    def resp(_d, r):
        name = e.get_text().strip()
        if r != "save" or not name:
            return
        if accounts_call("SetRealName", name):
            c.toast("Name changed. You'll see it everywhere after signing in again.")
        else:
            c.run_async(["pkexec", "usermod", "-c", name.replace(":", ""), me().pw_name],
                        lambda rc, o, e: c.toast("Name changed" if rc == 0 else "The name was not changed"))
        GLib.timeout_add(500, lambda: (c.WINDOW.refresh(), False)[1])
    d.connect("response", resp)
    d.present(c.WINDOW)


# ================================================================ password
def change_password_with_passwd(old, new):
    """Run `passwd` for the current user. Returns (ok, message)."""
    pid, fd = pty.fork()
    if pid == 0:
        os.environ["LC_ALL"] = "C"
        os.execvp("passwd", ["passwd"])
    out, answers, deadline = b"", [old, new, new], time.time() + 20
    try:
        while time.time() < deadline:
            r, _, _ = select.select([fd], [], [], 0.5)
            if not r:
                continue
            try:
                chunk = os.read(fd, 1024)
            except OSError:
                break
            if not chunk:
                break
            out += chunk
            if out.rstrip().endswith(b":") and answers:
                time.sleep(0.1)
                os.write(fd, (answers.pop(0) + "\n").encode())
                out += b"\n"
    finally:
        _, status = os.waitpid(pid, 0)
    text = out.decode(errors="replace")
    if os.WEXITSTATUS(status) == 0:
        return True, "Password changed"
    if "Authentication token manipulation error" in text or "authentication failure" in text.lower():
        return False, "The current password is not right."
    last = [l for l in text.splitlines() if l.strip() and not l.strip().endswith(":")]
    return False, last[-1] if last else "The password was not changed."


def password_dialog():
    d = Adw.AlertDialog(heading="Change your password", body="Use something you can remember.")
    lb = Gtk.ListBox()
    lb.add_css_class("boxed-list")
    old, new, again = (Adw.PasswordEntryRow(title=t) for t in ("Current password", "New password", "Type the new password again"))
    for w in (old, new, again):
        lb.append(w)
    d.set_extra_child(lb)
    d.add_response("cancel", "Cancel")
    d.add_response("change", "Change")
    d.set_response_appearance("change", Adw.ResponseAppearance.SUGGESTED)

    def resp(_d, r):
        if r != "change":
            return
        if not new.get_text() or new.get_text() != again.get_text():
            c.error("The passwords don't match", "Type the same new password twice.")
            return
        c.call_async(lambda: change_password_with_passwd(old.get_text(), new.get_text()),
                     lambda res: c.toast(res[1]) if res[0] else c.error("The password was not changed", res[1]))
    d.connect("response", resp)
    d.present(c.WINDOW)


# ================================================================ automatic sign-in
def autologin_on():
    try:
        with open(AUTOLOGIN) as f:
            return f"autologin-user={me().pw_name}" in f.read()
    except OSError:
        return False


def set_autologin(on):
    if on:
        c.root_write(AUTOLOGIN, f"[Seat:*]\nautologin-user={me().pw_name}\nautologin-user-timeout=0\n",
                     lambda ok, e: c.toast("You'll be signed in automatically" if ok else "Not changed"))
    else:
        c.root_sh(f"rm -f {AUTOLOGIN}", lambda rc, o, e: c.toast("The sign-in screen will be shown" if rc == 0 else "Not changed"))
    GLib.timeout_add(800, lambda: (c.WINDOW.refresh(), False)[1])


# ================================================================ other users
def other_users():
    mine = me().pw_name
    return [p for p in pwd.getpwall() if 1000 <= p.pw_uid < 60000 and p.pw_name != mine
            and not p.pw_shell.endswith(("nologin", "false"))]


def add_user_dialog():
    box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=12, margin_top=6, margin_bottom=18,
                  margin_start=18, margin_end=18)
    lb = Gtk.ListBox()
    lb.add_css_class("boxed-list")
    name = Adw.EntryRow(title="Full name")
    login = Adw.EntryRow(title="User name (for signing in)")
    pw1 = Adw.PasswordEntryRow(title="Password")
    pw2 = Adw.PasswordEntryRow(title="Type the password again")
    admin = Adw.SwitchRow(title="Administrator", subtitle="Can install apps and change system settings")
    for w in (name, login, pw1, pw2, admin):
        lb.append(w)
    box.append(lb)

    def auto_login(*_):
        if not login.edited:
            base = re.sub(r"[^a-z0-9]", "", name.get_text().split(" ")[0].lower()) if name.get_text() else ""
            login.set_text(base)
            login.edited = False
    login.edited = False
    name.connect("changed", auto_login)
    login.connect("changed", lambda *_: setattr(login, "edited", True) if login.has_focus() else None)
    d = c.dialog("Add a user", box, 460)

    def create():
        full, user = name.get_text().strip().replace(":", ""), login.get_text().strip()
        if not re.fullmatch(r"[a-z][a-z0-9_-]{0,30}", user):
            c.error("Choose another user name", "Use small letters and numbers, starting with a letter.")
            return
        try:
            pwd.getpwnam(user)
            c.error("This user name is taken", "Choose another one.")
            return
        except KeyError:
            pass
        if not pw1.get_text() or pw1.get_text() != pw2.get_text():
            c.error("The passwords don't match", "Type the same password twice.")
            return
        d.close()
        script = ('set -e; adduser --disabled-password --comment "$1" "$2" >/dev/null; chpasswd; '
                  f'for g in {USER_GROUPS}; do adduser "$2" "$g" >/dev/null 2>&1 || true; done; '
                  'if [ "$3" = 1 ]; then adduser "$2" sudo >/dev/null; fi')
        c.run_async(["pkexec", "sh", "-c", script, "sh", full, user, "1" if admin.get_active() else "0"],
                    lambda rc, o, e: (c.toast(f"{full or user} can now sign in" if rc == 0 else "The user was not added"),
                                      c.WINDOW.refresh()),
                    input=f"{user}:{pw1.get_text()}\n")
    btn = c.button("Add user", create, "suggested-action")
    btn.set_halign(Gtk.Align.END)
    box.append(btn)
    d.present(c.WINDOW)


def remove_user(p):
    who = real_name(p)
    c.confirm(f"Remove {who}?", "Their account and all of their files will be deleted.", "Remove",
              lambda: c.root_sh(f"deluser --remove-home {p.pw_name}",
                                lambda rc, o, e: (c.toast(f"{who} was removed" if rc == 0 else "The user was not removed"),
                                                  c.WINDOW.refresh())), True)


def toggle_admin(p, on):
    c.root_sh(f"{'adduser' if on else 'deluser'} {p.pw_name} sudo",
              lambda rc, o, e: c.toast("Account type changed" if rc == 0 else "Not changed"))


# ================================================================ page
def build_accounts():
    p = me()
    name = real_name(p)
    av = Adw.Avatar(size=72, text=name, show_initials=True)
    load_avatar(av)
    hero = c.hero(widget=av, title=name, subtitle="Local account · " + ("Administrator" if is_admin(p.pw_name) else "Standard user"),
                  suffix=c.button("Change picture", change_picture))
    you = c.group(None, None, [
        c.row("Your name", name, "avatar-default-symbolic", c.button("Edit", edit_name)),
        c.row("Password", "Change your sign-in password", "dialog-password-symbolic", c.button("Change", password_dialog)),
        c.switch_row("Sign in automatically", "Skip the sign-in screen when the computer starts", autologin_on(),
                     set_autologin, "system-lock-screen-symbolic"),
    ])
    others = c.group("Other users", "Family members or guests get their own space and files",
                     suffix=c.button("Add user", add_user_dialog, "suggested-action", "list-add-symbolic"))
    users = other_users()
    if not users:
        others.add(c.row("No other users yet", None, "system-users-symbolic"))
    for u in users:
        sw = Gtk.Switch(active=is_admin(u.pw_name), valign=Gtk.Align.CENTER, tooltip_text="Administrator")
        sw.connect("notify::active", lambda s, _p, u=u: toggle_admin(u, s.get_active()))
        rm = c.button(None, lambda u=u: remove_user(u), "flat", "user-trash-symbolic")
        rm.set_tooltip_text("Remove user")
        lbl = Gtk.Label(label="Admin")
        lbl.add_css_class("dim-label")
        others.add(c.row(real_name(u), u.pw_name, "avatar-default-symbolic", [lbl, sw, rm]))
    return c.page("Accounts", hero, you, others)


PAGES["accounts"] = {"title": "Accounts", "build": build_accounts, "parent": None}
SEARCH += [(t, s, "accounts") for t, s in (
    ("Your name", "Account, user name"), ("Password", "Change password, sign in"),
    ("Account picture", "Avatar, photo"), ("Sign in automatically", "Auto login"),
    ("Add user", "Other users, family, guest"))]
