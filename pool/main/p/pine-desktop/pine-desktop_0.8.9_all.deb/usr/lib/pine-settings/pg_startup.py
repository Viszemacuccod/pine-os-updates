"""Startup: what happens when the computer starts and when you sign in.

 - Pine OS USB stick: ask (5 s, Esc = install again) or start the installed Pine OS at once
   (/boot/grub/pine-usb-start-directly, read by the USB stick's boot menu; it still asks after a
   start that failed, see hook 9120-pine-installed-entry)
 - Boot menu: hidden (default, also next to Windows: Esc while starting shows it) or shown
   for 3 seconds (/etc/pine/show-boot-menu, read by /etc/default/grub.d/pine.cfg; update-grub)
 - Restart into Windows (or another system): grub-reboot picks it for the next start only
   (GRUB_DEFAULT=saved in pine.cfg)
 - Basic graphics: once / until switched back (pine_safe_next in /boot/grub/grubenv, see
   /etc/grub.d/05_pine_safe_graphics)
 - Startup apps (apps that start when you sign in)
"""
import os

import common as c
import pg_apps

PAGES, SEARCH = {}, []

USB_FLAG = "/boot/grub/pine-usb-start-directly"
MENU_FLAG = "/etc/pine/show-boot-menu"
GRUBENV = "/boot/grub/grubenv"


def register(pid, title, build, parent=None, search=()):
    PAGES[pid] = {"title": title, "build": build, "parent": parent}
    for t, s in search:
        SEARCH.append((t, s, pid))


def installed():
    """Settings that change the boot exist only on an installed system (not the live USB)."""
    return os.path.exists("/boot/grub/grub.cfg") and not os.path.exists("/run/live/medium")


def grubenv(key):
    rc, out, _ = c.run(["grub-editenv", GRUBENV, "list"])
    for line in out.splitlines() if rc == 0 else []:
        if line.startswith(key + "="):
            return line.split("=", 1)[1]
    return ""


def as_admin(script, ok_msg, fail_msg="Not changed", timeout=300):
    """Run a script as administrator (password), tell how it went, show the page again."""
    c.root_sh(script, lambda rc, o, e: (c.toast(ok_msg if rc == 0 else fail_msg), c.WINDOW.refresh()),
              timeout=timeout)


def usb_group():
    ask = not os.path.exists(USB_FLAG)

    def set_ask(on):
        as_admin(f"rm -f {USB_FLAG}" if on else f"touch {USB_FLAG}",
                 "The USB stick asks first" if on else "From the USB stick, Pine OS starts straight away")
    return c.group("Pine OS USB stick", "When the computer starts from a Pine OS installer USB stick", [
        c.switch_row("Ask whether to install Pine OS again",
                     "Waits 5 seconds (Esc: install again). When off, Pine OS starts straight away; "
                     "after a start that failed it asks anyway",
                     ask, set_ask, "drive-removable-media-symbolic"),
    ])


def boot_menu_group():
    shown = os.path.exists(MENU_FLAG)

    def set_menu(on):
        flag = f"mkdir -p /etc/pine && touch {MENU_FLAG}" if on else f"rm -f {MENU_FLAG}"
        c.toast("Saving…")
        as_admin(f"{flag} && update-grub", "The boot menu shows at every start" if on else "The boot menu is hidden again",
                 "The boot menu could not be changed")
    rows = [
        c.switch_row("Show the boot menu", "For 3 seconds at every start: choose another system or advanced options. "
                     "When it is off, press Esc while the computer starts to see it.",
                     shown, set_menu, "view-list-symbolic"),
    ]
    other = other_system()
    if other:
        rows.append(c.row(f"Restart into {other_name(other)}", "Only for the next start; after that Pine OS starts again",
                          "system-reboot-symbolic", c.button("Restart", lambda: restart_into(other))))
    return c.group("Boot menu", None, rows)


def other_system():
    """The boot menu entry of another system on this computer (e.g. Windows), or None.
    os-prober's entries are the ones with "--class os" in grub.cfg."""
    try:
        with open("/boot/grub/grub.cfg", errors="replace") as f:
            for line in f:
                line = line.strip()
                if line.startswith("menuentry ") and "--class os" in line:
                    q = line[len("menuentry "):].lstrip()[:1]
                    if q in "'\"":
                        return line.split(q)[1]
    except OSError:
        # grub.cfg can be readable by root only: then look for a Windows disk instead
        # (Windows always makes a "Microsoft reserved" partition on GPT disks)
        rc, out, _ = c.run(["lsblk", "-rno", "PARTTYPE"])
        if rc == 0 and "e3c9e316-0b5c-4db8-817d-f92df00215ae" in out.lower():
            return "?Windows"
    return None


def other_name(entry):
    if entry.startswith("?"):
        return entry[1:] or "the other system"
    return "Windows" if "windows" in entry.lower() else entry.split(" (on ")[0]


def restart_into(entry):
    # /usr/libexec/pine-restart-other finds the entry itself (grub.cfg is root's) and restarts
    as_admin("/usr/libexec/pine-restart-other", "Restarting…", "Could not restart into the other system")


def graphics_group():
    try:
        now_basic = "nomodeset" in open("/proc/cmdline").read().split()
    except OSError:
        now_basic = False
    next_basic = grubenv("pine_safe_next") == "1"
    if now_basic or next_basic:
        row = c.row("Basic graphics is on",
                    "The screen uses simple graphics" + (" now" if now_basic else " from the next start") +
                    ". Switch back when the problem is fixed (for example after a driver update).",
                    "video-display-symbolic",
                    c.button("Use normal graphics", lambda: as_admin(
                        f"grub-editenv {GRUBENV} unset pine_safe_next", "Normal graphics from the next start"),
                        "suggested-action"))
    else:
        row = c.row("Start with basic graphics",
                    "If the screen stays black or flickers, for example after an update. "
                    "Stays on until you switch back here.",
                    "video-display-symbolic",
                    c.button("Next start", lambda: as_admin(
                        f"grub-editenv {GRUBENV} set pine_safe_next=1", "The next start uses basic graphics")))
    return c.group("Graphics", None, [row])


def startup_apps_group():
    entries, user_dir = pg_apps.autostart_entries()
    g = c.group("Startup apps", "Apps that start when you sign in",
                suffix=c.button("Add", lambda: pg_apps.add_startup_dialog(user_dir), icon="list-add-symbolic"))
    for e in entries:
        g.add(c.switch_row(e["name"], e["comment"] or None, e["enabled"],
                           lambda on, e=e: pg_apps.set_autostart(e, user_dir, on)))
    if not entries:
        g.add(c.row("No startup apps", "Add one with the button above"))
    return g


def build_startup():
    groups = [startup_apps_group()]
    if installed():
        groups = [usb_group(), boot_menu_group(), graphics_group()] + groups
    return c.page("Startup", *groups)


register("startup", "Startup", build_startup, search=[
    ("Startup apps", "Apps that start when you sign in, autostart"),
    ("USB stick", "Install again, ask at start, reinstall"),
    ("Boot menu", "Show the boot menu, GRUB, dual boot"),
    ("Basic graphics", "Safe graphics, black screen, nomodeset"),
])
