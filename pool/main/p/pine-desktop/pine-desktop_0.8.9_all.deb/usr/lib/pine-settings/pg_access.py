"""Accessibility: text size, pointer size, keyboard helpers."""
import re

import common as c

PAGES, SEARCH = {}, []
CURSORS = [(24, "Default"), (32, "Large"), (48, "Extra large"), (64, "Huge")]


def build_access():
    font = c.xget("xsettings", "/Gtk/FontName", "Inter 10")
    m = re.match(r"(.*?)\s+(\d+(?:\.\d+)?)$", font)
    family, size = (m.group(1), float(m.group(2))) if m else (font, 10.0)

    def set_text(pct):
        c.set_font(f"{family} {round(10 * pct / 100)}")

    cur = c.xget_int("xsettings", "/Gtk/CursorThemeSize", 24)
    ci = min(range(len(CURSORS)), key=lambda i: abs(CURSORS[i][0] - cur))
    ch = "accessibility"
    return c.page("Accessibility", c.group("Vision", None, [
        c.slider_row("Text size", "Make text bigger without changing anything else", 80, 200, 10, size * 10, set_text,
                     "format-text-larger-symbolic", delay=300, fmt=lambda v: f"{v:.0f}%"),
        c.combo_row("Mouse pointer size", "Bigger pointers are easier to see", [l for _, l in CURSORS], ci,
                    lambda i: c.xset("xsettings", "/Gtk/CursorThemeSize", CURSORS[i][0], "int"), "input-mouse-symbolic"),
        c.row("Scale", "Make everything bigger", "zoom-in-symbolic", nav="display"),
    ]), c.group("Keyboard", None, [
        c.switch_row("Sticky keys", "Press Ctrl, Shift or Alt one at a time instead of together",
                     c.xget_bool(ch, "/StickyKeys"), lambda on: c.xset(ch, "/StickyKeys", on, "bool"),
                     "input-keyboard-symbolic"),
        c.switch_row("Slow keys", "Keys must be held a moment before they count", c.xget_bool(ch, "/SlowKeys"),
                     lambda on: c.xset(ch, "/SlowKeys", on, "bool"), "input-keyboard-symbolic"),
        c.switch_row("Bounce keys", "Ignore quickly repeated presses of the same key", c.xget_bool(ch, "/BounceKeys"),
                     lambda on: c.xset(ch, "/BounceKeys", on, "bool"), "input-keyboard-symbolic"),
    ]))


PAGES["access"] = {"title": "Accessibility", "build": build_access, "parent": None}
SEARCH += [(t, s, "access") for t, s in (
    ("Text size", "Bigger text, font size, vision"), ("Mouse pointer size", "Cursor size, big pointer"),
    ("Sticky keys", "Keyboard shortcuts one at a time"), ("Slow keys", "Keyboard"), ("Bounce keys", "Keyboard"))]
