"""System > Recovery: restore points and Reset this PC.

Restore points are Timeshift copies of the system (not of personal files), made by the user
on a disk they choose, and automatically before updates if they want (only the newest 3 of
those are kept). No factory copy is kept: disk space matters.
Reset this PC needs no copy either: it removes the apps added after installing, brings back
Pine OS's own settings (reinstalls pine-desktop, so it needs the internet), and at the next
start cleans every account's settings, or everything in it ("Remove everything").
Helpers: /usr/libexec/pine-recovery-status (no password), /usr/libexec/pine-recovery.
"""
import datetime
import json
import os
import subprocess
import time

from gi.repository import Adw, Gio, GLib, Gtk

import common as c

PAGES, SEARCH = {}, []
STATUS = "/usr/libexec/pine-recovery-status"
HELPER = "/usr/libexec/pine-recovery"
LINUX_FS = ("ext4", "ext3", "ext2", "btrfs", "xfs", "f2fs")
STATE = {"data": None, "at": 0.0, "loading": False, "error": None, "job": None, "ui": None}


def live_session():
    try:
        with open("/proc/cmdline") as f:
            return "boot=live" in f.read()
    except OSError:
        return False


# ================================================================ reading
def load():
    if STATE["loading"]:
        return
    STATE["loading"], STATE["error"] = True, None

    def done(rc, out, err):
        STATE["loading"] = False
        try:
            STATE["data"], STATE["error"] = json.loads(out), None
        except ValueError:
            STATE["error"] = (err.strip().splitlines() or ["The restore points could not be read"])[-1]
        STATE["at"] = time.monotonic()
        if c.WINDOW:
            c.WINDOW.refresh()
    c.run_async(["pkexec", STATUS], done, timeout=240)


def disks():
    """Partitions restore points can go on (Linux file systems), with free space when mounted."""
    rc, out, _ = c.run(["lsblk", "-J", "-b", "-o", "PATH,UUID,FSTYPE,SIZE,FSAVAIL,LABEL,MOUNTPOINTS,RM,HOTPLUG,MODEL,PKNAME"])
    try:
        devs = json.loads(out).get("blockdevices", []) if rc == 0 else []
    except ValueError:
        devs = []
    flat = []

    def walk(items, model=""):
        for d in items:
            m = d.get("model") or model
            if d.get("fstype") in LINUX_FS and d.get("uuid"):
                mounts = [x for x in (d.get("mountpoints") or []) if x]
                flat.append({"path": d["path"], "uuid": d["uuid"], "fstype": d["fstype"], "size": d.get("size") or 0,
                             "free": d.get("fsavail"), "label": d.get("label") or "", "model": (m or "").strip(),
                             "system": "/" in mounts, "home": "/home" in mounts,
                             "removable": bool(d.get("rm") or d.get("hotplug"))})
            walk(d.get("children") or [], m)
    walk(devs)
    return flat


def disk_name(d):
    name = d["label"] or d["model"] or os.path.basename(d["path"])
    if d["system"]:
        return c._("{n} (where Pine OS is)").format(n=name)
    return name


def when(name):
    try:
        t = datetime.datetime.strptime(name, "%Y-%m-%d_%H-%M-%S")
    except ValueError:
        return name
    return t.strftime("%Y-%m-%d %H:%M")


# ================================================================ doing (as administrator, with progress)
def set_progress(task, fraction):
    def apply():
        job = STATE["job"]
        if not job:
            return False
        if task:
            job["task"] = task
        job["fraction"] = fraction
        ui = STATE.get("ui")
        if ui:
            ui["label"].set_label(job["task"])
            if fraction is not None and fraction >= 0:
                ui["bar"].set_fraction(min(1.0, fraction))
        return False
    GLib.idle_add(apply)


def run_job(args, title, ok_msg, fail_msg, input=None, restarts=False):
    if STATE["job"]:
        c.toast("Wait until the current step is finished")
        return
    app = Gio.Application.get_default()
    app.hold()
    STATE["job"] = {"title": title, "task": c._("Getting ready…"), "fraction": None, "restarts": restarts}
    c.WINDOW.refresh()

    def work():
        from pg_update import Inhibit
        with Inhibit():
            try:
                p = subprocess.Popen(["pkexec", HELPER] + args, stdin=subprocess.PIPE if input else subprocess.DEVNULL,
                                     stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
            except OSError as ex:
                return 127, str(ex)
            if input:
                p.stdin.write(input)
                p.stdin.close()
            for line in p.stdout:
                if line.startswith("PROGRESS "):
                    pct, _, text = line[9:].strip().partition(" ")
                    try:
                        v = int(pct)
                    except ValueError:
                        continue
                    set_progress(text or None, v / 100 if v >= 0 else None)
            err = p.stderr.read().strip().splitlines()
            return p.wait(), "\n".join(err[-6:])

    def done(res):
        app.release()
        STATE["job"], STATE["ui"] = None, None
        rc, err = res if isinstance(res, tuple) else (1, str(res))
        if rc == 0:
            c.toast(ok_msg)
        elif rc in (126, 127):
            c.toast("Not changed")
        else:
            c.error(fail_msg, err or "Something went wrong.")
        STATE["at"] = 0.0
        load()
        if c.WINDOW:
            c.WINDOW.refresh()
    c.call_async(work, done)


# ================================================================ dialogs
def disk_dialog():
    box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=12, margin_top=6, margin_bottom=18,
                  margin_start=18, margin_end=18)
    info = Gtk.Label(label=c._("Restore points are copies of the system (not of your personal files). The first one "
                               "needs about as much space as the system, usually 6 to 10 GB; later ones only store "
                               "what changed. A USB disk must be connected when a restore point is made."),
                     xalign=0, wrap=True)
    info.add_css_class("dim-label")
    box.append(info)
    lb = Gtk.ListBox(selection_mode=Gtk.SelectionMode.NONE)
    lb.add_css_class("boxed-list")
    found = disks()
    d = c.dialog("Where to keep restore points", box, 500)

    def choose(disk):
        d.close()
        run_job(["setup", disk["uuid"]], c._("Setting up restore points"), "Restore points are set up",
                "Restore points were not set up")
    for disk in found:
        free = c._("{f} free").format(f=c.human_size(disk["free"])) if disk["free"] is not None else c._("not opened yet")
        sub = f"{c.human_size(disk['size'])} · {free} · {disk['fstype']}" + (" · USB" if disk["removable"] else "")
        icon = "drive-removable-media-symbolic" if disk["removable"] else "drive-harddisk-symbolic"
        lb.append(c.row(disk_name(disk), sub, icon, c.button("Use", lambda x=disk: choose(x),
                                                             "suggested-action" if disk["system"] else None)))
    if not found:
        lb.append(c.row("No suitable disk found", "Restore points need a disk with a Linux file system (ext4, btrfs…)",
                        "dialog-information-symbolic"))
    box.append(lb)
    d.present(c.WINDOW)


def create_dialog():
    d = Adw.AlertDialog(heading=c._("Make a restore point"),
                        body=c._("A copy of the system as it is now. It can take a few minutes."))
    lb = Gtk.ListBox(selection_mode=Gtk.SelectionMode.NONE)
    lb.add_css_class("boxed-list")
    name = Adw.EntryRow(title=c._("Name (optional)"))
    lb.append(name)
    d.set_extra_child(lb)
    d.add_response("cancel", c._("Cancel"))
    d.add_response("ok", c._("Make"))
    d.set_response_appearance("ok", Adw.ResponseAppearance.SUGGESTED)
    d.set_default_response("ok")
    d.connect("response", lambda _d, r: r == "ok" and run_job(
        ["create", name.get_text().strip().replace("\n", " ")[:80] or c._("Made by hand")],
        c._("Making a restore point"), "Restore point made", "The restore point was not made"))
    d.present(c.WINDOW)
    name.grab_focus()


def reset_dialog():
    box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=12, margin_top=6, margin_bottom=18,
                  margin_start=18, margin_end=18)
    lbl = Gtk.Label(label=c._("Pine OS removes the apps you added and brings back its own settings. "
                              "Choose what happens to your files."), xalign=0, wrap=True)
    lbl.add_css_class("dim-label")
    box.append(lbl)
    lb = Gtk.ListBox(selection_mode=Gtk.SelectionMode.NONE)
    lb.add_css_class("boxed-list")
    d = c.dialog("Reset this PC", box, 520)

    def pick(mode):
        d.close()
        confirm_reset(mode)
    for title, sub, icon, mode in (
            ("Keep my files", "Removes apps and settings. Your files in Documents, Pictures, Desktop… stay.",
             "folder-documents-symbolic", "keep"),
            ("Remove everything", "Removes all your personal files, apps and settings. Accounts and passwords stay.",
             "user-trash-full-symbolic", "all")):
        lb.append(c.row(title, sub, icon, Gtk.Image.new_from_icon_name("go-next-symbolic"),
                        on_click=lambda m=mode: pick(m)))
    box.append(lb)
    d.present(c.WINDOW)


def confirm_reset(mode):
    keep = mode == "keep"
    body = c._("What happens:\n"
               "• Apps you installed are removed (drivers stay)\n"
               "• Pine OS's settings come back, the firewall too\n"
               "• Every account's settings are cleaned at the next start\n") + \
        (c._("• Your personal files stay\n") if keep else c._("• All personal files of every account are deleted\n")) + \
        c._("• Restore points stay\n\nThis needs the internet and restarts the computer. Save your work first.")
    c.confirm("Reset this PC and keep your files?" if keep else "Reset this PC and remove everything?", body,
              "Reset", lambda: run_job(["reset", mode], c._("Resetting this PC"), "Restarting…",
                                       "This PC was not reset", restarts=True), True)


# ================================================================ page
def progress_hero():
    job = STATE["job"]
    box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10, hexpand=True)
    t = Gtk.Label(label=job["title"], xalign=0, wrap=True)
    t.add_css_class("title-2")
    box.append(t)
    label = Gtk.Label(label=job["task"], xalign=0, wrap=True)
    label.add_css_class("dim-label")
    box.append(label)
    bar = Gtk.ProgressBar()
    if job["fraction"] is not None:
        bar.set_fraction(job["fraction"])
    box.append(bar)
    warn = Gtk.Label(label=c._("Please don't turn off your computer.") +
                     (" " + c._("It restarts by itself when this is finished.") if job["restarts"] else ""),
                     xalign=0, wrap=True)
    warn.add_css_class("caption")
    warn.add_css_class("dim-label")
    box.append(warn)
    STATE["ui"] = {"label": label, "bar": bar}

    def pulse():
        if STATE.get("ui") is None or STATE["ui"]["bar"] is not bar:
            return False
        if STATE["job"] and STATE["job"]["fraction"] is None:
            bar.pulse()
        return True
    GLib.timeout_add(250, pulse)
    return c.hero(widget=box)


def build_recovery():
    if live_session():
        return c.page("Recovery", c.hero("dialog-information-symbolic", "Recovery works on an installed Pine OS",
                                         "Install Pine OS first, then restore points and Reset this PC are here."))
    if not STATE["job"] and not STATE["loading"] and (
            STATE["data"] is None and not STATE["error"]
            or STATE["data"] is not None and time.monotonic() - STATE["at"] > 2):
        load()
    data = STATE["data"]
    busy = STATE["job"] is not None
    groups = []
    if busy:
        groups.append(progress_hero())
    else:
        groups.append(c.hero("document-revert-symbolic", "Recovery",
                             "Something went wrong? Go back to a restore point, or reset this PC."))

    # ---- restore points
    if data is None:
        groups.append(c.group("Restore points", None, [c.row(
            "Looking for restore points…" if not STATE["error"] else STATE["error"], None, None,
            c.spinner() if not STATE["error"] else c.button("Try again", load))]))
    elif not data.get("timeshift"):
        groups.append(c.group("Restore points", None, [c.row("Restore points are not available",
                                                             "Timeshift is not installed", "dialog-information-symbolic")]))
    elif not data.get("uuid"):
        g = c.group("Restore points", "Copies of the system to go back to when something breaks")
        b = c.button("Set up", disk_dialog, "suggested-action")
        b.set_sensitive(not busy)
        g.add(c.row("Restore points are off", "Choose a disk for them. Only you decide when one is made, and whether "
                    "one is made before updates.", "document-revert-symbolic", b))
        groups.append(g)
    else:
        found = {d["uuid"]: d for d in disks()}
        disk = found.get(data["uuid"])
        make = c.button("Make a restore point", create_dialog, "suggested-action", "list-add-symbolic")
        make.set_sensitive(not busy and bool(disk))
        g = c.group("Restore points", "Copies of the system (not of your personal files)", suffix=make)
        where = disk_name(disk) if disk else c._("a disk that is not connected")
        sub = c._("Kept on {d}").format(d=where) + (f" · {c._('{f} free').format(f=data['free'])}" if data.get("free") else "")
        ch = c.button("Change disk", disk_dialog)
        ch.set_sensitive(not busy)
        g.add(c.row("Where they are kept", sub, "drive-harddisk-symbolic" if disk else "dialog-warning-symbolic", ch))

        def set_auto(on):
            run_job(["auto", "on" if on else "off"], c._("Saving"),
                    "A restore point is made before updates" if on else "No restore points before updates",
                    "Not changed")
        g.add(c.switch_row("Make one before updates", "At most once a day. Only the newest 3 of these are kept, "
                           "to save disk space.", data.get("auto", True), set_auto, "software-update-available-symbolic"))
        snaps = list(reversed(data.get("snapshots", [])))
        if not snaps:
            g.add(c.row("No restore points yet", "Make one now, while everything works", "document-open-recent-symbolic"))
        for s in snaps:
            auto = "D" in s["tags"] or s["comment"] == "Before updates"
            title = c._(s["comment"]) if s["comment"] else c._("Restore point")
            back = c.button("Go back", lambda s=s: c.confirm(
                c._("Go back to the restore point of {w}?").format(w=when(s["name"])),
                "System files, apps and settings go back to how they were then. Your personal files stay. "
                "The computer restarts by itself.", "Go back",
                lambda: run_job(["restore", s["name"]], c._("Going back to a restore point"), "Restarting…",
                                "The computer could not go back", restarts=True), True))
            back.set_sensitive(not busy)
            rm = c.button(None, lambda s=s: c.confirm(
                c._("Delete the restore point of {w}?").format(w=when(s["name"])), "This frees its disk space.",
                "Delete", lambda: run_job(["delete", s["name"]], c._("Deleting a restore point"),
                                          "Restore point deleted", "The restore point was not deleted"), True),
                "flat", "user-trash-symbolic")
            rm.set_tooltip_text(c._("Delete"))
            rm.set_sensitive(not busy)
            g.add(c.row(title, when(s["name"]) + (" · " + c._("automatic") if auto else ""),
                        "document-revert-symbolic", [back, rm]))
        groups.append(g)

    # ---- reset
    reset = c.button("Reset PC", reset_dialog)
    reset.set_sensitive(not busy)
    pending = (data or {}).get("reset_pending")
    groups.append(c.group("Reset this PC", None, [c.row(
        "Reset this PC" if not pending else "Reset continues at the next start",
        "Start fresh: remove the apps you added and go back to Pine OS's settings. Choose to keep your "
        "files or remove everything." if not pending else "Restart the computer to finish resetting it",
        "view-refresh-symbolic", reset if not pending else
        c.button("Restart now", lambda: c.run_async(["xfce4-session-logout", "--reboot"]), "suggested-action"))]))
    groups.append(c.group(rows=[c.row("Startup options", "Basic graphics, boot menu, start from a USB stick",
                                      "system-run-symbolic", nav="startup")]))
    return c.page("Recovery", *groups)


PAGES["recovery"] = {"title": "Recovery", "build": build_recovery, "parent": "system"}
SEARCH += [(t, s, "recovery") for t, s in (
    ("Recovery", "Repair, fix, go back, undo"), ("Restore points", "Timeshift, snapshot, backup, system restore, go back"),
    ("Reset this PC", "Factory reset, reinstall, start fresh, remove everything, keep my files"))]
