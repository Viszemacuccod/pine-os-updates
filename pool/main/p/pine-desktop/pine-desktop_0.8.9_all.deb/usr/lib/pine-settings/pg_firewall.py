"""Network & internet > Firewall: ufw, fully editable.

On/off, what happens to connections no rule mentions (incoming, outgoing, forwarded), logging,
and the rules: any port, a range or a list of ports, TCP, UDP or both (or all traffic), allow /
block / reject / limit, incoming or outgoing, from and to any address, on one network adapter.
Reading the firewall needs no password (/usr/libexec/pine-firewall-status through pkexec,
polkit action org.pineos.firewall.status); changes ask for the administrator password once
for a few minutes (/usr/libexec/pine-firewall, org.pineos.firewall).
"""
import glob
import json
import os
import time

from gi.repository import Adw, GLib, Gtk

import common as c
import fwrules

PAGES, SEARCH = {}, []
STATUS = "/usr/libexec/pine-firewall-status"
HELPER = "/usr/libexec/pine-firewall"
STATE = {"data": None, "at": 0.0, "loading": False, "error": None}

POLICIES = [("deny", "Block"), ("reject", "Reject (tell the sender)"), ("allow", "Allow")]
LOGGING = [("off", "Off"), ("low", "Low"), ("medium", "Medium"), ("high", "High"), ("full", "Full")]
ACTION_LABELS = {"allow": "Allow", "deny": "Block", "reject": "Reject", "limit": "Limit"}
PROTO_LABELS = {"tcp": "TCP", "udp": "UDP", "both": "TCP and UDP", "all": "All traffic"}


# ================================================================ reading and changing
def load():
    if STATE["loading"]:
        return
    STATE["loading"], STATE["error"] = True, None

    def done(rc, out, err):
        STATE["loading"] = False
        try:
            STATE["data"], STATE["error"] = json.loads(out), None
        except ValueError:
            STATE["data"] = STATE["data"] or None
            STATE["error"] = (err.strip().splitlines() or ["The firewall could not be read"])[-1]
        STATE["at"] = time.monotonic()
        if c.WINDOW:
            c.WINDOW.refresh()
    c.run_async(["pkexec", STATUS], done, timeout=90)


def change(ops, ok_msg, fail_msg="Not changed", then=None):
    """Run firewall steps as administrator, then read the firewall again."""
    def done(rc, out, err):
        if rc == 0:
            c.toast(ok_msg)
        elif rc in (126, 127):          # password dialog closed
            c.toast("Not changed")
        else:
            msg = (err.strip().splitlines() or [""])[-1]
            c.error(fail_msg, msg or "The firewall did not accept the change.")
        if then:
            then(rc == 0)
        STATE["at"] = 0.0
        load()
    c.run_async(["pkexec", HELPER], done, input=json.dumps({"ops": ops}), timeout=180)


def interfaces():
    return sorted(os.path.basename(p) for p in glob.glob("/sys/class/net/*") if os.path.basename(p) != "lo")


# ================================================================ how a rule reads
def describe(r):
    """(title, subtitle) of a rule."""
    if "raw" in r:
        return r["raw"][4:] if r["raw"].startswith("ufw ") else r["raw"], c._("A rule made outside Pine Settings")
    if r["proto"] == "all":
        what = c._("All traffic")
    elif r["ports"]:
        what = (c._("Ports {p}") if fwrules._multi(r["ports"]) else c._("Port {p}")).format(
            p=r["ports"].replace(":", "–").replace(",", ", "))
    else:
        what = c._("Every port")
    title = r["comment"] or what
    parts = [c._(ACTION_LABELS[r["action"]]),
             c._("Incoming") if r["direction"] == "in" else c._("Outgoing"),
             c._(PROTO_LABELS[r["proto"]])]
    if r["comment"]:
        parts.append(what)
    if r["src"] != "any" or r["sports"]:
        src = c._("anywhere") if r["src"] == "any" else r["src"]
        parts.append(c._("from {a}").format(a=src) + (c._(", port {p}").format(p=r["sports"]) if r["sports"] else ""))
    if r["dst"] != "any":
        parts.append(c._("to {a}").format(a=r["dst"]))
    if r["iface"]:
        parts.append(c._("on {i}").format(i=r["iface"]))
    if r["log"]:
        parts.append(c._("logged"))
    return title, " · ".join(parts)


# ================================================================ the rule dialog
def rule_dialog(old=None):
    """Add a rule (old=None) or change one: every field ufw has."""
    r = dict(old) if old and "raw" not in old else fwrules.empty_rule()
    box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=12, margin_top=6, margin_bottom=18,
                  margin_start=18, margin_end=18)

    def combo(title, labels, value, values, subtitle=None):
        row = Adw.ComboRow(title=GLib.markup_escape_text(c._(title)),
                           model=Gtk.StringList.new([c._(l) for l in labels]))
        if subtitle:
            row.set_subtitle(GLib.markup_escape_text(c._(subtitle)))
        row.set_selected(values.index(value) if value in values else 0)
        return row

    def entry(title, text, hint=None):
        row = Adw.EntryRow(title=GLib.markup_escape_text(c._(title)))
        row.set_text("" if text in (None, "any") else text)
        if hint:
            row.set_tooltip_text(c._(hint))
        return row

    def boxed(*rows):
        lb = Gtk.ListBox(selection_mode=Gtk.SelectionMode.NONE)
        lb.add_css_class("boxed-list")
        for w in rows:
            lb.append(w)
        return lb

    def caption(text):
        lbl = Gtk.Label(label=c._(text), xalign=0, wrap=True)
        lbl.add_css_class("dim-label")
        lbl.add_css_class("caption")
        return lbl

    name = entry("Name (optional)", r["comment"])
    action = combo("Action", ["Allow", "Block", "Reject (tell the sender)", "Limit (allow, but block repeated tries)"],
                   r["action"], fwrules.ACTIONS)
    direction = combo("Direction", ["Incoming", "Outgoing"], r["direction"], fwrules.DIRECTIONS)
    proto = combo("Protocol", ["TCP", "UDP", "TCP and UDP", "All traffic"], r["proto"], fwrules.PROTOS)
    ports = entry("Port or ports", r["ports"])
    box.append(boxed(name, action, direction, proto, ports))
    box.append(caption("One port (80), a range (8000:8100) or a list (80,443,8000:8100). Empty: every port."))

    src = entry("From address", r["src"])
    sports = entry("From port (optional)", r["sports"])
    dst = entry("To address", r["dst"])
    ifaces = interfaces()
    if r["iface"] and r["iface"] not in ifaces:
        ifaces.append(r["iface"])
    iface = combo("Network adapter", ["Any"] + ifaces, r["iface"], [""] + ifaces)
    log = combo("Log", ["No", "New connections", "Every packet"], r["log"], fwrules.LOGS,
                "Written to the system log")
    box.append(boxed(src, sports, dst, iface, log))
    box.append(caption("Addresses: one computer (192.168.1.20), a network (192.168.1.0/24) or IPv6 (fe80::1). "
                       "Empty: anywhere."))

    err = Gtk.Label(xalign=0, wrap=True)
    err.add_css_class("error")
    err.set_visible(False)
    box.append(err)

    def sync(*_):
        allp = proto.get_selected() == 3
        ports.set_sensitive(not allp)
        sports.set_sensitive(not allp)
    proto.connect("notify::selected", sync)
    sync()

    sc = Gtk.ScrolledWindow(hscrollbar_policy=Gtk.PolicyType.NEVER, propagate_natural_height=True,
                            max_content_height=640)
    sc.set_child(box)
    d = c.dialog("Change rule" if old else "Add rule", sc, 520)

    def save():
        new = fwrules.empty_rule()
        new.update(comment=name.get_text().strip(), action=fwrules.ACTIONS[action.get_selected()],
                   direction=fwrules.DIRECTIONS[direction.get_selected()], proto=fwrules.PROTOS[proto.get_selected()],
                   ports=ports.get_text().replace(" ", "") if proto.get_selected() != 3 else "",
                   sports=sports.get_text().replace(" ", "") if proto.get_selected() != 3 else "",
                   src=src.get_text().strip() or "any", dst=dst.get_text().strip() or "any",
                   iface=([""] + ifaces)[iface.get_selected()], log=fwrules.LOGS[log.get_selected()])
        problem = fwrules.check(new)
        if problem:
            err.set_label(c._(problem))
            err.set_visible(True)
            return
        ops = [["delete"] + w for w in (old or {}).get("words", [])] + [["add"] + w for w in fwrules.build(new)]
        btn.set_sensitive(False)
        change(ops, "Rule saved" if old else "Rule added", "The rule was not saved",
               lambda ok: d.close() if ok else btn.set_sensitive(True))

    buttons = Gtk.Box(spacing=8, halign=Gtk.Align.END)
    buttons.append(c.button("Cancel", d.close))
    btn = c.button("Save" if old else "Add", save, "suggested-action")
    buttons.append(btn)
    box.append(buttons)
    d.present(c.WINDOW)


# ================================================================ page
def build_firewall():
    # read when nothing is known yet (not again after an error: "Try again" does that), or when stale
    if not STATE["loading"] and (STATE["data"] is None and not STATE["error"]
                                 or STATE["data"] is not None and time.monotonic() - STATE["at"] > 2):
        load()
    data = STATE["data"]
    if data is None:
        if STATE["error"] and not STATE["loading"]:
            return c.page("Firewall", c.hero("dialog-warning-symbolic", "The firewall could not be read", STATE["error"],
                                             c.button("Try again", load)))
        return c.page("Firewall", c.hero(widget=c.spinner(), title="Reading the firewall…"))
    if not data.get("installed"):
        return c.page("Firewall", c.hero("security-low-symbolic", "The firewall is not installed",
                                         "Install the “ufw” firewall: Settings > Pine Update brings it with the next update."))
    on = data.get("enabled")
    blocking = data.get("incoming") != "allow"
    hero = c.hero("security-high-symbolic" if on else "security-low-symbolic",
                  "Firewall is on" if on else "Firewall is off",
                  ("Incoming connections are blocked unless a rule below allows them" if blocking
                   else "Incoming connections are allowed unless a rule below blocks them") if on
                  else "Every connection is allowed. Turn the firewall on to protect this computer.",
                  c.button("Turn off", lambda: change([["disable"]], "Firewall turned off")) if on else
                  c.button("Turn on", lambda: change([["enable"]], "Firewall turned on"), "suggested-action",
                           "security-high-symbolic"))

    def policy_row(title, subtitle, key, icon):
        values = [v for v, _l in POLICIES]
        cur = data.get(key, "deny")
        return c.combo_row(title, subtitle, [l for _v, l in POLICIES], values.index(cur) if cur in values else 0,
                           lambda i: values[i] != cur and change([["default", key, values[i]]], "Saved"), icon)
    log_values = [v for v, _l in LOGGING]
    cur_log = data.get("logging", "low")
    defaults = c.group("When no rule matches", "What happens to connections that no rule below mentions", [
        policy_row("Incoming connections", "Other computers connecting to this one", "incoming", "go-down-symbolic"),
        policy_row("Outgoing connections", "This computer connecting to others", "outgoing", "go-up-symbolic"),
        policy_row("Forwarded connections", "Only when this computer shares its connection (like a router)", "routed",
                   "network-workgroup-symbolic"),
        c.combo_row("Logging", "Blocked connections are written to the system log", [l for _v, l in LOGGING],
                    log_values.index(cur_log) if cur_log in log_values else 1,
                    lambda i: log_values[i] != cur_log and change([["logging", log_values[i]]], "Saved"),
                    "document-edit-symbolic"),
    ])

    add = c.button("Add rule", lambda: rule_dialog(), "flat", "list-add-symbolic")
    rules = fwrules.group(data.get("rules", []))
    g = c.group("Rules", "Checked from top to bottom: the first rule that matches decides", suffix=add)
    if not rules:
        g.add(c.row("No rules yet", "Add a rule to open a port for a program or block an address", "view-list-symbolic"))
    for r in rules:
        title, sub = describe(r)
        btns = []
        if "raw" not in r:
            pill = c.pill(ACTION_LABELS[r["action"]])
            if r["action"] in ("deny", "reject"):
                pill.add_css_class("pine-warn")
            btns.append(pill)
            edit = c.button(None, lambda r=r: rule_dialog(r), "flat", "document-edit-symbolic")
            edit.set_tooltip_text(c._("Change"))
            btns.append(edit)
        rm = c.button(None, lambda r=r, t=title: c.confirm(
            c._("Delete the rule “{t}”?").format(t=t), "The firewall stops using it right away.", "Delete",
            lambda: change([["delete"] + w for w in r["words"]], "Rule deleted"), True), "flat", "user-trash-symbolic")
        rm.set_tooltip_text(c._("Delete"))
        btns.append(rm)
        icon = "object-select-symbolic" if r.get("action") in ("allow", "limit") else "action-unavailable-symbolic"
        row = c.row(title, sub, icon, btns, on_click=(lambda r=r: rule_dialog(r)) if "raw" not in r else None)
        g.add(row)

    reset = c.group(rows=[c.row("Reset the firewall", "Delete every rule and go back to Pine OS's settings: "
                                "incoming blocked, outgoing allowed, Phone Link allowed",
                                "edit-undo-symbolic", c.button("Reset", lambda: c.confirm(
                                    "Reset the firewall?", "Every rule you added is deleted.", "Reset",
                                    lambda: change([["reset"]], "Firewall reset"), True)))])
    return c.page("Firewall", hero, defaults, g, reset)


PAGES["firewall"] = {"title": "Firewall", "build": build_firewall, "parent": "network"}
SEARCH += [(t, s, "firewall") for t, s in (
    ("Firewall", "Block, allow, protect, security, ufw"), ("Open a port", "Firewall rule, TCP, UDP, port forwarding, allow"),
    ("Block an address", "Firewall rule, deny, IP address"), ("Firewall logging", "Log blocked connections"))]
