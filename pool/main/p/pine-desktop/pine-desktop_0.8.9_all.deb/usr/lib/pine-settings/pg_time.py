"""Time & language: clock, time zone, display language, region format, keyboard layouts."""
import datetime
import re
from zoneinfo import ZoneInfo

from gi.repository import Adw, GLib, Gtk

import common as c

PAGES, SEARCH = {}, []

LANGS = [("en_US", "English (United States)"), ("en_GB", "English (United Kingdom)"), ("hu_HU", "Magyar"),
         ("de_DE", "Deutsch"), ("fr_FR", "Français"), ("es_ES", "Español"), ("it_IT", "Italiano"),
         ("pt_BR", "Português (Brasil)"), ("pt_PT", "Português (Portugal)"), ("nl_NL", "Nederlands"),
         ("pl_PL", "Polski"), ("cs_CZ", "Čeština"), ("sk_SK", "Slovenčina"), ("ro_RO", "Română"),
         ("hr_HR", "Hrvatski"), ("sl_SI", "Slovenščina"), ("sr_RS", "Српски"), ("bg_BG", "Български"),
         ("el_GR", "Ελληνικά"), ("tr_TR", "Türkçe"), ("ru_RU", "Русский"), ("uk_UA", "Українська"),
         ("sv_SE", "Svenska"), ("da_DK", "Dansk"), ("nb_NO", "Norsk bokmål"), ("fi_FI", "Suomi"),
         ("et_EE", "Eesti"), ("lv_LV", "Latviešu"), ("lt_LT", "Lietuvių"), ("ja_JP", "日本語"),
         ("zh_CN", "中文（简体）"), ("zh_TW", "中文（繁體）"), ("ko_KR", "한국어"), ("ar_EG", "العربية"),
         ("he_IL", "עברית"), ("hi_IN", "हिन्दी"), ("id_ID", "Bahasa Indonesia"), ("vi_VN", "Tiếng Việt"),
         ("th_TH", "ไทย")]
REGION_KEYS = ["LC_TIME", "LC_NUMERIC", "LC_MONETARY", "LC_PAPER", "LC_MEASUREMENT"]


def system_locale():
    vals = {}
    try:
        with open("/etc/default/locale") as f:
            for line in f:
                m = re.match(r'\s*([A-Z_]+)=["\']?([^"\'\s]*)', line)
                if m:
                    vals[m.group(1)] = m.group(2)
    except OSError:
        pass
    return vals


def lang_index(code):
    code = (code or "en_US").split(".")[0]
    return next((i for i, (k, _) in enumerate(LANGS) if k == code), 0)


def gen_locale(code):
    return (f"grep -q '^{code}.UTF-8 UTF-8' /etc/locale.gen || "
            f"(sed -i 's/^# *{code}.UTF-8 UTF-8/{code}.UTF-8 UTF-8/' /etc/locale.gen; "
            f"grep -q '^{code}.UTF-8 UTF-8' /etc/locale.gen || echo '{code}.UTF-8 UTF-8' >> /etc/locale.gen; "
            f"locale-gen >/dev/null); ")


def sign_out_prompt(what):
    d = Adw.AlertDialog(heading=f"{what} changed", body="Sign out and back in to see it everywhere.")
    d.add_response("later", "Later")
    d.add_response("now", "Sign out now")
    d.set_response_appearance("now", Adw.ResponseAppearance.SUGGESTED)
    d.connect("response", lambda _d, r: r == "now" and c.run_async(["xfce4-session-logout", "--logout", "--fast"]))
    d.present(c.WINDOW)


def set_language(i):
    code = LANGS[i][0]
    c.toast("Preparing the language…")
    c.root_sh(gen_locale(code) + f"update-locale LANG={code}.UTF-8 LANGUAGE; "
              "rm -f /var/lib/pine/langpacks-done; systemctl start --no-block pine-langpacks.service 2>/dev/null; true",
              lambda rc, o, e: sign_out_prompt("Language") if rc == 0 else c.toast("The language was not changed"))


def set_region(i):
    if i == 0:
        script = "update-locale " + " ".join(REGION_KEYS)
    else:
        code = LANGS[i - 1][0]
        script = gen_locale(code) + "update-locale " + " ".join(f"{k}={code}.UTF-8" for k in REGION_KEYS)
    c.root_sh(script, lambda rc, o, e: sign_out_prompt("Region format") if rc == 0 else c.toast("Not changed"))


# ================================================================ keyboard layouts
def layout_names():
    names, section = {}, None
    try:
        with open("/usr/share/X11/xkb/rules/evdev.lst") as f:
            for line in f:
                if line.startswith("!"):
                    section = line[1:].strip()
                elif section == "layout" and line.strip():
                    code, desc = line.strip().split(None, 1)
                    names[code] = desc
    except OSError:
        pass
    return names


def current_layouts():
    _, out, _ = c.run(["localectl", "status"])
    lay = re.search(r"X11 Layout: (\S+)", out)
    var = re.search(r"X11 Variant: (\S*)", out)
    layouts = lay.group(1).split(",") if lay else []
    if not layouts:
        try:
            with open("/etc/default/keyboard") as f:
                txt = f.read()
            m = re.search(r'XKBLAYOUT="([^"]*)"', txt)
            layouts = m.group(1).split(",") if m and m.group(1) else ["us"]
            m = re.search(r'XKBVARIANT="([^"]*)"', txt)
            var_list = m.group(1).split(",") if m else []
        except OSError:
            layouts, var_list = ["us"], []
    else:
        var_list = var.group(1).split(",") if var else []
    variants = (var_list + [""] * len(layouts))[:len(layouts)]
    return list(zip(layouts, variants))


def set_layouts(pairs):
    lays = ",".join(l for l, _ in pairs)
    vars_ = ",".join(v for _, v in pairs)
    opts = "grp:win_space_toggle" if len(pairs) > 1 else ""
    c.run(["setxkbmap", "-option", ""])
    c.run(["setxkbmap", "-layout", lays, "-variant", vars_] + (["-option", opts] if opts else []))
    c.run_async(["localectl", "set-x11-keymap", lays, "", vars_, opts],
                lambda rc, o, e: (c.toast("Keyboard layouts saved" if rc == 0 else "Saved for now; not kept after restarting"),
                                  c.WINDOW.refresh()))


def add_layout_dialog(pairs):
    names = layout_names()
    box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10, margin_top=6, margin_bottom=18,
                  margin_start=18, margin_end=18)
    search = Gtk.SearchEntry(placeholder_text="Search, e.g. German")
    box.append(search)
    lb = Gtk.ListBox(selection_mode=Gtk.SelectionMode.NONE)
    lb.add_css_class("boxed-list")
    sc = Gtk.ScrolledWindow(vexpand=True, min_content_height=360)
    sc.set_child(lb)
    box.append(sc)
    d = c.dialog("Add a keyboard layout", box, 460, 560)
    have = {l for l, _ in pairs}
    rows = []
    for code, desc in sorted(names.items(), key=lambda kv: kv[1]):
        if code in have:
            continue
        r = c.row(desc, code, None, c.button("Add", lambda code=code: (d.close(), set_layouts(pairs + [(code, "")]))))
        r.key = f"{desc} {code}".lower()
        rows.append(r)
        lb.append(r)
    search.connect("search-changed", lambda e: [r.set_visible(e.get_text().lower() in r.key) for r in rows])
    d.present(c.WINDOW)


def keyboard_group():
    pairs = current_layouts()
    names = layout_names()
    g = c.group("Keyboard", "Switch between layouts with Super + Space" if len(pairs) > 1 else None,
                suffix=c.button("Add layout", lambda: add_layout_dialog(pairs), icon="list-add-symbolic"))
    for i, (lay, var) in enumerate(pairs):
        title = names.get(lay, lay) + (f" ({var})" if var else "")
        btns = []
        if i == 0:
            btns.append(c.pill("Default"))
        elif len(pairs) > 1:
            btns.append(c.button("Make default", lambda i=i: set_layouts([pairs[i]] + pairs[:i] + pairs[i + 1:])))
        if len(pairs) > 1:
            rm = c.button(None, lambda i=i: set_layouts(pairs[:i] + pairs[i + 1:]), "flat", "user-trash-symbolic")
            rm.set_tooltip_text("Remove")
            btns.append(rm)
        g.add(c.row(title, lay, "input-keyboard-symbolic", btns))
    return g


# ================================================================ clock
def clock_plugin():
    for p in c.xlist("xfce4-panel"):
        if re.fullmatch(r"/plugins/plugin-\d+", p) and c.xget("xfce4-panel", p) == "clock":
            return p
    return None


def set_time_dialog():
    box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=12, margin_top=6, margin_bottom=18,
                  margin_start=18, margin_end=18)
    cal = Gtk.Calendar()
    box.append(cal)
    now = datetime.datetime.now()
    tb = Gtk.Box(spacing=6, halign=Gtk.Align.CENTER)
    hh = Gtk.SpinButton.new_with_range(0, 23, 1)
    mm = Gtk.SpinButton.new_with_range(0, 59, 1)
    hh.set_value(now.hour)
    mm.set_value(now.minute)
    tb.append(hh)
    tb.append(Gtk.Label(label=":"))
    tb.append(mm)
    box.append(tb)
    d = c.dialog("Set the date and time", box, 360)

    def save():
        dt = cal.get_date()
        stamp = f"{dt.get_year():04d}-{dt.get_month():02d}-{dt.get_day_of_month():02d} {int(hh.get_value()):02d}:{int(mm.get_value()):02d}:00"
        d.close()
        c.run_async(["timedatectl", "set-time", stamp],
                    lambda rc, o, e: (c.toast("Time changed" if rc == 0 else "The time was not changed"), c.WINDOW.refresh()))
    btn = c.button("Set", save, "suggested-action")
    btn.set_halign(Gtk.Align.END)
    box.append(btn)
    d.present(c.WINDOW)


def build_time():
    now = datetime.datetime.now()
    hero = c.hero("preferences-system-time-symbolic", now.strftime("%H:%M"), now.strftime("%A, %d %B %Y"))

    def tick():
        if hero.get_root() is None:
            return False
        n = datetime.datetime.now()
        hero.title_label.set_label(n.strftime("%H:%M"))
        hero.subtitle_label.set_label(n.strftime("%A, %d %B %Y"))
        return True
    GLib.timeout_add_seconds(5, tick)

    _, ntp, _ = c.run(["timedatectl", "show", "-p", "NTP", "--value"])
    ntp = ntp.strip() == "yes"
    _, tz, _ = c.run(["timedatectl", "show", "-p", "Timezone", "--value"])
    tz = tz.strip() or "UTC"
    _, zones, _ = c.run(["timedatectl", "list-timezones"])
    zones = zones.split() or [tz]
    labels = []
    for z in zones:
        try:
            off = datetime.datetime.now(ZoneInfo(z)).strftime("%z")
            labels.append(f"(UTC{off[:3]}:{off[3:]}) {z.replace('_', ' ')}")
        except Exception:
            labels.append(z)
    zi = zones.index(tz) if tz in zones else 0

    clock = clock_plugin()
    fmt = c.xget("xfce4-panel", f"{clock}/digital-time-format", "%H:%M") if clock else "%H:%M"
    layout = c.xget_int("xfce4-panel", f"{clock}/digital-layout", 1) if clock else 1

    def set_ntp(on):
        c.run_async(["timedatectl", "set-ntp", "true" if on else "false"],
                    lambda rc, o, e: (c.toast("Saved" if rc == 0 else "Not changed"), c.WINDOW.refresh()))

    dt_rows = [
        c.switch_row("Set time automatically", "Uses internet time servers", ntp, set_ntp, "emblem-synchronizing-symbolic"),
        None if ntp else c.row("Set the date and time manually", None, "x-office-calendar-symbolic",
                               c.button("Change", set_time_dialog)),
        c.combo_row("Time zone", None, labels, zi,
                    lambda i: c.run_async(["timedatectl", "set-timezone", zones[i]],
                                          lambda rc, o, e: (c.toast("Time zone changed" if rc == 0 else "Not changed"),
                                                            c.WINDOW.refresh())),
                    "mark-location-symbolic", search=True),
    ]
    if clock:
        dt_rows += [
            c.switch_row("24-hour clock", "Shows 14:30 instead of 2:30 PM", "%H" in fmt,
                         lambda on: c.xset("xfce4-panel", f"{clock}/digital-time-format", "%H:%M" if on else "%l:%M %p", "string"),
                         "preferences-system-time-symbolic"),
            c.switch_row("Show the date on the taskbar", None, layout in (0, 1),
                         lambda on: c.xset("xfce4-panel", f"{clock}/digital-layout", 1 if on else 3, "uint"),
                         "x-office-calendar-symbolic"),
        ]

    loc = system_locale()
    region = loc.get("LC_TIME")
    lang_rows = [
        c.combo_row("Display language", "Menus, apps and settings appear in this language", [n for _, n in LANGS],
                    lang_index(loc.get("LANG")), set_language, "preferences-desktop-locale-symbolic", search=True),
        c.combo_row("Region format", "How dates, times, numbers and money look",
                    ["Same as display language"] + [n for _, n in LANGS],
                    0 if not region or region == loc.get("LANG") else lang_index(region) + 1, set_region,
                    "accessories-calculator-symbolic", search=True),
    ]
    return c.page("Time & language", hero, c.group("Date & time", None, dt_rows),
                  c.group("Language & region", None, lang_rows), keyboard_group())


PAGES["time"] = {"title": "Time & language", "build": build_time, "parent": None}
SEARCH += [(t, s, "time") for t, s in (
    ("Time zone", "Clock, region"), ("Set time automatically", "Date and time, NTP"),
    ("24-hour clock", "Time format, AM PM"), ("Display language", "Language, translation"),
    ("Region format", "Date format, numbers, currency"), ("Keyboard layout", "Input language, typing"))]
