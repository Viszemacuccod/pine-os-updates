"""Devices > Drivers: everything this computer needs, found and installed with one click.

Graphics (NVIDIA's driver or the open-source one, AMD and Intel firmware, Vulkan for games,
video acceleration), Wi-Fi and network chips, sound firmware, printers and scanners, drawing
tablets, fingerprint readers, game controllers, virtual machine tools, processor microcode,
firmware files the kernel asked for, and whatever else Debian knows for this hardware
(isenkram). What is found: drivers_db.py. Installing and removing:
/usr/libexec/pine-drivers through pkexec (administrator password). Drivers built for the
kernel (NVIDIA, Broadcom...) need their key approved once when Secure Boot is on: the page
asks for a one-time code and explains the blue screen at the next start.
"""
import subprocess
import time

from gi.repository import Adw, Gio, GLib, Gtk

import common as c
import drivers_db as db

PAGES, SEARCH = {}, []
HELPER = "/usr/libexec/pine-drivers"
STATE = {"devices": None, "scan": {}, "at": 0.0, "scanning": False, "job": None, "ui": None, "restart": False,
         "error": None}


def missing_recommended():
    """For Pine Update: recommended drivers that are not installed (looks at the hardware)."""
    try:
        return db.missing_recommended()
    except Exception:  # never stop Pine Update's check because of this
        return []


# ================================================================ looking
def rescan(show=True):
    if STATE["scanning"]:
        return
    STATE["scanning"], STATE["error"] = True, None

    def work():
        hw = db.gather()
        return hw.get("scan", {}), db.finish(db.detect(hw))

    def done(res):
        STATE["scanning"] = False
        STATE["at"] = time.monotonic()
        if isinstance(res, Exception):
            STATE["error"] = str(res)
        else:
            STATE["scan"], STATE["devices"], STATE["error"] = res[0], res[1], None
        if c.WINDOW:
            c.WINDOW.refresh()
    c.call_async(work, done)
    if show and c.WINDOW:
        c.WINDOW.refresh()


# ================================================================ installing and removing
def set_progress(task=None, fraction=None):
    def apply():
        job = STATE["job"]
        if not job:
            return False
        if task is not None:
            job["task"] = task
        if fraction is not None:
            job["fraction"] = fraction
        ui = STATE.get("ui")
        if ui:
            ui["label"].set_label(job["task"])
            ui["bar"].set_fraction(max(0.0, min(1.0, job["fraction"])))
        return False
    GLib.idle_add(apply)


def run_job(args, title, ok_msg, restart=True):
    """Run pine-drivers as administrator with progress; shutdown waits until it finishes."""
    if STATE["job"]:
        c.toast("Wait until the driver being installed is finished")
        return
    app = Gio.Application.get_default()
    app.hold()
    STATE["job"] = {"title": title, "task": c._("Getting ready…"), "fraction": 0.0}
    c.WINDOW.refresh()

    def work():
        from pg_update import Inhibit   # (pg_update imports this module)
        mok, tail = False, []
        with Inhibit():
            try:
                p = subprocess.Popen(["pkexec", HELPER] + args, stdin=subprocess.DEVNULL, stdout=subprocess.PIPE,
                                     stderr=subprocess.PIPE, text=True)
            except OSError as ex:
                return 127, str(ex), False
            for line in p.stdout:
                if line.startswith("PROGRESS "):
                    pct, _, text = line[9:].strip().partition(" ")
                    try:
                        set_progress(text or None, int(pct) / 100)
                    except ValueError:
                        pass
                elif line.strip() == "MOK_NEEDED":
                    mok = True
            tail = p.stderr.read().strip().splitlines()
            rc = p.wait()
        return rc, "\n".join(tail[-6:]), mok

    def done(res):
        app.release()
        STATE["job"], STATE["ui"] = None, None
        rc, err, mok = res if isinstance(res, tuple) else (1, str(res), False)
        if rc == 0:
            if restart:
                STATE["restart"] = True
            if c.WINDOW and c.WINDOW.get_visible():
                c.toast(ok_msg)
            else:
                c.run_async(["notify-send", "-a", "Pine Settings", "-i", "application-x-firmware", c._(ok_msg)])
        elif rc in (126, 127):
            c.toast("Not changed")
        else:
            c.error("The driver was not changed", err or "Something went wrong. Are you connected to the internet?")
        rescan()
        if mok:
            mok_dialog()
    c.call_async(work, done)


def install(o):
    run_job(["install"] + o["pkgs"], c._("Installing {t}").format(t=c._(o["title"])),
            c._("{t} installed").format(t=c._(o["title"])), o["restart"])


def install_all():
    todo = db.missing_recommended(STATE["devices"] or [])
    pkgs = []
    for o in todo:
        pkgs += [p for p in o["pkgs"] if p not in pkgs]
    if pkgs:
        run_job(["install"] + pkgs, c._("Installing recommended drivers"), "Recommended drivers installed")


def remove(o, then_msg="Driver removed"):
    # the parts that came along (headers, 32-bit libraries) go with autoremove when nothing needs them
    c.confirm(c._("Remove {t}?").format(t=c._(o["title"])),
              "The computer uses the built-in driver again after a restart." if o["dkms"] else
              "You can install it again here any time.", "Remove",
              lambda: run_job(["remove", o["check"]], c._("Removing {t}").format(t=c._(o["title"])), then_msg,
                              o["restart"]), True)


def mok_dialog():
    """Secure Boot: approve the key that signs drivers built on this computer."""
    d = Adw.AlertDialog(heading=c._("Approve the new driver for Secure Boot"),
                        body=c._("Secure Boot only starts drivers it knows. Choose a short code of 4 to 16 digits "
                                 "and remember it.\n\nAt the next start a blue screen appears: choose “Enroll MOK”, "
                                 "then “Continue” and “Yes”, type the same code and choose “Reboot”. "
                                 "Until then the new driver is not used."))
    lb = Gtk.ListBox(selection_mode=Gtk.SelectionMode.NONE)
    lb.add_css_class("boxed-list")
    code = Adw.PasswordEntryRow(title=c._("One-time code (digits)"))
    code.set_input_purpose(Gtk.InputPurpose.DIGITS)
    lb.append(code)
    d.set_extra_child(lb)
    d.add_response("later", c._("Later"))
    d.add_response("ok", c._("Approve"))
    d.set_response_appearance("ok", Adw.ResponseAppearance.SUGGESTED)
    d.set_default_response("ok")

    def answer(_d, r):
        if r != "ok":
            return
        text = code.get_text().strip()
        if not text.isdigit() or not 4 <= len(text) <= 16:
            c.error("That code can't be used", "Use 4 to 16 digits, for example 1234. Try again from Drivers.")
            return

        def done(rc, out, err):
            if rc == 0:
                STATE["restart"] = True
                c.toast("Approved. Restart and follow the blue screen")
            elif rc not in (126, 127):
                c.error("The key was not approved", (err.strip().splitlines() or [""])[-1])
            rescan()
        c.run_async(["pkexec", HELPER, "mok-enroll"], done, input=text + "\n", timeout=90)
    d.connect("response", answer)
    d.present(c.WINDOW)


# ================================================================ page
def progress_hero():
    job = STATE["job"]
    box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10, hexpand=True)
    t = Gtk.Label(label=job["title"], xalign=0, wrap=True)
    t.add_css_class("title-2")
    box.append(t)
    label = Gtk.Label(label=job["task"], xalign=0, wrap=True)
    label.add_css_class("dim-label")
    box.append(label)
    bar = Gtk.ProgressBar(fraction=job["fraction"])
    box.append(bar)
    warn = Gtk.Label(label=c._("Please don't turn off your computer. You can close this window: installing continues."),
                     xalign=0, wrap=True)
    warn.add_css_class("caption")
    warn.add_css_class("dim-label")
    box.append(warn)
    STATE["ui"] = {"label": label, "bar": bar}
    return c.hero(widget=box)


def option_row(dev, o):
    busy = STATE["job"] is not None
    suffix = []
    if o["builtin"]:
        if o["installed"]:
            suffix.append(c.pill("In use"))
        else:
            other = next((x for x in dev["options"] if x["installed"] and not x["builtin"]), None)
            if other:
                b = c.button("Use this", lambda: remove(other, "Switched to the open-source driver"))
                b.set_sensitive(not busy)
                suffix.append(b)
    elif o["installed"]:
        suffix.append(c.pill("Installed"))
        # firmware and processor updates stay: removing them can switch off hardware
        if not (o["check"].startswith("firmware-") or o["check"].endswith("microcode")):
            rm = c.button(None, lambda: remove(o), "flat", "user-trash-symbolic")
            rm.set_tooltip_text(c._("Remove"))
            rm.set_sensitive(not busy)
            suffix.append(rm)
    else:
        if o["recommended"]:
            suffix.append(c.pill("Recommended"))
        b = c.button("Install", lambda: install(o), "suggested-action" if o["recommended"] else None)
        b.set_sensitive(not busy)
        suffix.append(b)
    r = c.row(o["title"], o["sub"] or None, None, suffix)
    return r


def device_row(cat_icon, dev):
    ex = Adw.ExpanderRow(title=GLib.markup_escape_text(c._(dev["name"])))
    if dev["driver"]:
        ex.set_subtitle(GLib.markup_escape_text(c._("Driver in use: {d}").format(d=dev["driver"])))
    elif dev["detail"]:
        ex.set_subtitle(GLib.markup_escape_text(c._(dev["detail"])))
    img = Gtk.Image.new_from_icon_name(cat_icon)
    img.add_css_class("pine-row-icon")
    ex.add_prefix(img)
    todo = [o for o in dev["options"] if o["recommended"] and not o["installed"] and not o["builtin"]]
    if todo:
        ex.add_suffix(c.pill("Driver available"))
    ex.set_expanded(bool(todo) or len(dev["options"]) <= 2)
    for o in dev["options"]:
        ex.add_row(option_row(dev, o))
    if not dev["options"]:
        ex.add_row(c.row("Works with the built-in driver", None, None))
    return ex


def build_drivers():
    if STATE["devices"] is None and not STATE["scanning"] and not STATE["error"]:
        rescan(show=False)
    groups = []
    devices = STATE["devices"]
    if STATE["job"]:
        groups.append(progress_hero())
    elif devices is None:
        if STATE["error"]:
            groups.append(c.hero("dialog-warning-symbolic", "The drivers could not be checked", STATE["error"],
                                 c.button("Try again", rescan)))
        else:
            groups.append(c.hero(widget=c.spinner(), title="Looking at this computer…",
                                 subtitle="Finding the parts of this computer and the drivers they need"))
        return c.page("Drivers", *groups)
    else:
        todo = db.missing_recommended(devices)
        again = c.button(None, rescan, "flat", "view-refresh-symbolic")
        again.set_tooltip_text(c._("Look again"))
        if STATE["scanning"]:
            again = c.spinner()
        if todo:
            n = len(todo)
            title = c._("{n} recommended drivers are not installed").format(n=n) if n > 1 else \
                c._("1 recommended driver is not installed")
            box = Gtk.Box(spacing=6)
            box.append(again)
            box.append(c.button("Install recommended", install_all, "suggested-action", "folder-download-symbolic"))
            groups.append(c.hero("application-x-firmware-symbolic", title,
                                 ", ".join(c._(o["title"]) for o in todo[:3]) + ("…" if n > 3 else ""), box))
        else:
            groups.append(c.hero("emblem-ok-symbolic", "Every recommended driver is installed",
                                 "Extra drivers below are optional", again))

    if STATE["restart"] and not STATE["job"]:
        groups.append(c.group(rows=[c.row("Restart to use the new drivers", "Drivers start with the computer",
                                          "system-reboot-symbolic",
                                          c.button("Restart now", lambda: c.run_async(["xfce4-session-logout", "--reboot"]),
                                                   "suggested-action"))]))
    scan = STATE["scan"] or {}
    if scan.get("secure_boot") and scan.get("mok_pending"):
        groups.append(c.group(rows=[c.row("Secure Boot: one more step at the next start",
                                          "A blue screen appears: choose “Enroll MOK”, “Continue”, “Yes”, type your "
                                          "code and choose “Reboot”", "security-medium-symbolic")]))
    elif scan.get("secure_boot") and scan.get("mok_enrolled") is False:
        groups.append(c.group(rows=[c.row("Secure Boot: approve your drivers",
                                          "Drivers built on this computer (like NVIDIA's) start only after this",
                                          "security-medium-symbolic", c.button("Approve…", mok_dialog, "suggested-action"))]))

    for cat, title, icon in db.CATEGORIES:
        devs = [d for d in devices if d["cat"] == cat]
        if not devs:
            continue
        g = c.group(title)
        for d in devs:
            g.add(device_row(icon, d))
        groups.append(g)
    groups.append(c.group(rows=[c.row("Firmware updates", "BIOS and device updates from their makers are in Pine Update",
                                      "software-update-available-symbolic", nav="update")]))
    return c.page("Drivers", *groups)


PAGES["drivers"] = {"title": "Drivers", "build": build_drivers, "parent": "devices"}
SEARCH += [(t, s, "drivers") for t, s in (
    ("Drivers", "Hardware, install driver, missing driver"), ("Graphics driver", "NVIDIA, AMD, Intel, GPU, video card, Vulkan"),
    ("Wi-Fi driver", "Broadcom, Realtek, wireless, network card"), ("Sound driver", "Audio, speakers, SOF firmware"),
    ("Printer driver", "HP, Brother, Epson, Canon, Samsung, scanner"), ("Fingerprint reader", "Sign in with finger"),
    ("Game controller", "Xbox, PlayStation, gamepad, joystick"), ("Missing firmware", "Firmware, hardware not working"),
    ("Secure Boot", "MOK, NVIDIA, signed driver"))]
