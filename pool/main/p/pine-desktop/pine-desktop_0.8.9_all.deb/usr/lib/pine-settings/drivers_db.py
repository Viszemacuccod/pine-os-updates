"""Which drivers this computer needs (no GTK; Settings > Devices > Drivers shows the result).

gather() reads the hardware (lspci, /sys, the kernel's missing firmware through
/usr/libexec/pine-drivers-scan, isenkram); detect() turns that into devices and the drivers
each can use. detect() is plain data in, data out: run this file to check it (python3 drivers_db.py).

A device: {"cat", "name", "detail", "driver" (kernel driver in use), "options": [option...]}
An option: {"id", "title", "sub", "pkgs" (to install), "check" (the package that tells it is
installed), "recommended", "builtin" (nothing to install), "dkms" (built for the kernel:
Secure Boot needs its key approved), "restart", "installed"}
"""
import glob
import json
import os
import re
import subprocess


def N_(text):
    """Marks text Pine Settings shows translated (tools/i18n.py finds it)."""
    return text


CATEGORIES = [  # (id, title, icon)
    ("graphics", "Graphics", "video-display-symbolic"),
    ("network", "Network and Bluetooth", "network-wireless-symbolic"),
    ("sound", "Sound", "audio-card-symbolic"),
    ("printing", "Printers and scanners", "printer-symbolic"),
    ("input", "Input devices", "input-mouse-symbolic"),
    ("vm", "Virtual machine", "computer-symbolic"),
    ("cpu", "Processor", "cpu-symbolic"),
    ("firmware", "Missing firmware", "application-x-firmware-symbolic"),
    ("other", "Other suggestions", "application-x-addon-symbolic"),
]

# Broadcom Wi-Fi chips that only work with the "wl" driver (broadcom-sta)
BROADCOM_WL = {"4311", "4312", "4313", "4315", "4328", "4329", "432a", "432b", "432c", "432d",
               "4353", "4357", "4358", "4359", "4365", "43a0", "43b1"}
# USB Wi-Fi sticks with Realtek RTL8812AU / 8821AU chips (out-of-tree driver)
RTL88XXAU = {"0bda:8812", "0bda:881a", "0bda:881b", "0bda:881c", "0bda:a811", "0bda:8811", "0bda:0811",
             "2357:0101", "2357:0103", "2357:010d", "2357:0115", "0846:9052", "7392:a812", "7392:a822", "0e66:0022"}
PRINTER_VENDORS = {  # USB vendor id -> (maker, driver packages)
    "03f0": ("HP", ["hplip", "printer-driver-hpcups"]),
    "04f9": ("Brother", ["printer-driver-brlaser", "printer-driver-ptouch"]),
    "04b8": ("Epson", ["printer-driver-escpr", "printer-driver-gutenprint"]),
    "04a9": ("Canon", ["printer-driver-gutenprint", "printer-driver-cjet"]),
    "04e8": ("Samsung", ["printer-driver-splix"]),
    "0924": ("Xerox", ["printer-driver-splix", "printer-driver-foo2zjs"]),
    "0482": ("Kyocera", ["printer-driver-gutenprint"]),
    "05ca": ("Ricoh", ["printer-driver-gutenprint"]),
    "043d": ("Lexmark", ["printer-driver-postscript-hp"]),
    "0550": ("Fuji Xerox", ["printer-driver-fujixerox"]),
}
FINGERPRINT_VENDORS = {"27c6", "138a", "06cb", "08ff", "147e", "1c7a", "298d", "10a5", "2808", "04f3"}
CONTROLLER_VENDORS = {"045e": "Xbox", "054c": "PlayStation", "057e": "Nintendo", "28de": "Steam", "2dc8": "8BitDo",
                      "046d": "Logitech", "0e6f": "PDP", "24c6": "PowerA", "0f0d": "Hori"}
# firmware file (beginning of its path) -> Debian packages that may have it (first available wins)
FIRMWARE_PACKAGES = [
    ("iwlwifi-", ["firmware-iwlwifi"]), ("intel/ibt-", ["firmware-iwlwifi"]),
    ("intel/sof", ["firmware-sof-signed"]), ("intel/avs", ["firmware-intel-sound"]), ("sof-", ["firmware-sof-signed"]),
    ("intel/ipu", ["firmware-intel-misc", "firmware-misc-nonfree"]),
    ("i915/", ["firmware-intel-graphics", "firmware-misc-nonfree"]),
    ("xe/", ["firmware-intel-graphics", "firmware-misc-nonfree"]),
    ("amdgpu/", ["firmware-amd-graphics"]), ("radeon/", ["firmware-amd-graphics"]),
    ("amd/", ["firmware-amd-graphics", "firmware-misc-nonfree"]),
    ("nvidia/", ["firmware-nvidia-graphics", "firmware-misc-nonfree"]),
    ("rtw88/", ["firmware-realtek"]), ("rtw89/", ["firmware-realtek"]), ("rtl_nic/", ["firmware-realtek"]),
    ("rtlwifi/", ["firmware-realtek"]), ("rtl_bt/", ["firmware-realtek"]), ("rtl", ["firmware-realtek"]),
    ("ath", ["firmware-atheros"]), ("qca/", ["firmware-atheros"]),
    ("brcm/", ["firmware-brcm80211"]), ("mediatek/", ["firmware-mediatek", "firmware-misc-nonfree"]),
    ("mt7", ["firmware-mediatek", "firmware-misc-nonfree"]),
    ("ti-connectivity/", ["firmware-ti-connectivity"]), ("libertas/", ["firmware-libertas"]),
    ("mrvl/", ["firmware-libertas"]), ("bnx2x/", ["firmware-bnx2x"]), ("bnx2/", ["firmware-bnx2"]),
    ("qed/", ["firmware-qlogic"]), ("cirrus/", ["firmware-cirrus"]), ("qcom/", ["firmware-qcom-soc"]),
    ("regulatory.db", ["wireless-regdb"]), ("", ["firmware-misc-nonfree"]),
]
SHORT_VENDOR = [(r"Advanced Micro Devices.*|AMD/ATI.*|ATI Technologies.*", "AMD"), (r"NVIDIA.*", "NVIDIA"),
                (r"Intel.*", "Intel"), (r"Realtek.*", "Realtek"), (r"Broadcom.*", "Broadcom"),
                (r"Qualcomm Atheros.*|Atheros.*", "Qualcomm Atheros"), (r"MEDIATEK.*|MediaTek.*", "MediaTek"),
                (r"VMware.*", "VMware"), (r"Red Hat.*", "Virtual"), (r"InnoTek.*|Oracle.*", "VirtualBox")]


# ================================================================ reading the hardware
def run(cmd, timeout=30):
    try:
        p = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout,
                           env=dict(os.environ, LC_ALL="C.UTF-8"))
        return p.returncode, p.stdout
    except (OSError, subprocess.TimeoutExpired):
        return 127, ""


def parse_lspci(text):
    """lspci -vmmnnk -> [{"slot", "class", "class_id", "vendor", "vendor_id", "device", "device_id", "driver"}]"""
    devs = []
    for block in text.strip().split("\n\n"):
        d = {}
        for line in block.splitlines():
            key, _, val = line.partition(":")
            d[key.strip().lower()] = val.strip()
        if "slot" not in d:
            continue

        def split(v):
            m = re.match(r"^(.*?)\s*\[([0-9a-fA-F]{4})\]$", v or "")
            return (m.group(1), m.group(2).lower()) if m else (v or "", "")
        cls, cls_id = split(d.get("class"))
        ven, ven_id = split(d.get("vendor"))
        dev, dev_id = split(d.get("device"))
        devs.append({"slot": d["slot"], "class": cls, "class_id": cls_id, "vendor": ven, "vendor_id": ven_id,
                     "device": dev, "device_id": dev_id, "driver": d.get("driver", "")})
    return devs


def read_usb():
    """USB devices from /sys: [{"id": "vvvv:pppp", "vendor_id", "name", "classes": {interface classes}}]"""
    devs = []
    for path in glob.glob("/sys/bus/usb/devices/*"):
        def rd(name, p=path):
            try:
                with open(os.path.join(p, name)) as f:
                    return f.read().strip()
            except OSError:
                return ""
        vid, pid = rd("idVendor"), rd("idProduct")
        if not vid or vid == "1d6b":          # root hubs
            continue
        classes = {rd("bInterfaceClass", p) for p in glob.glob(path + "/*:*")} | {rd("bDeviceClass")}
        name = " ".join(x for x in (rd("manufacturer"), rd("product")) if x) or f"USB device {vid}:{pid}"
        devs.append({"id": f"{vid}:{pid}", "vendor_id": vid, "name": name, "classes": classes - {""}})
    return devs


def gather():
    """Everything detect() needs, read from this computer (takes a few seconds)."""
    _, lspci = run(["lspci", "-vmmnnk"])
    scan = {}
    rc, out = run(["pkexec", "/usr/libexec/pine-drivers-scan"], timeout=60)
    if rc == 0:
        try:
            scan = json.loads(out)
        except ValueError:
            scan = {}
    rc, out = run(["isenkram-lookup"], timeout=90)
    isenkram = out.split() if rc == 0 else []
    _, arch = run(["dpkg", "--print-foreign-architectures"])
    _, nv = run(["nvidia-detect"], timeout=30) if any(d["vendor_id"] == "10de" for d in parse_lspci(lspci)) else (1, "")
    joy = bool(glob.glob("/dev/input/by-id/*-joystick"))     # (not js*: a USB tablet makes those too)
    return {"pci": parse_lspci(lspci), "usb": read_usb(), "scan": scan, "isenkram": isenkram,
            "i386": "i386" in arch.split(), "nvidia_detect": nv, "joystick": joy,
            "dmi": (read_file("/sys/class/dmi/id/sys_vendor") + " " + read_file("/sys/class/dmi/id/product_name")).lower(),
            "cpu": read_file("/proc/cpuinfo")}


def read_file(path):
    try:
        with open(path) as f:
            return f.read()
    except OSError:
        return ""


def installed_set(pkgs):
    """Which of these packages are installed (one dpkg-query for all)."""
    pkgs = sorted(set(pkgs))
    if not pkgs:
        return set()
    _, out = run(["dpkg-query", "-W", "-f=${Package}:${Architecture} ${Status}\n"] + [p.split(":")[0] for p in pkgs])
    have = set()
    for line in out.splitlines():
        name, _, status = line.partition(" ")
        if status.endswith("install ok installed"):
            n, _, a = name.partition(":")
            have.add(n)
            have.add(f"{n}:{a}")
    return have


def available_set(pkgs):
    """Which of these packages can be installed (one apt-cache policy for all)."""
    pkgs = sorted(set(pkgs))
    if not pkgs:
        return set()
    _, out = run(["apt-cache", "policy"] + pkgs, timeout=60)
    ok, cur = set(), None
    for line in out.splitlines():
        if line and not line.startswith(" ") and line.endswith(":"):
            cur = line[:-1]
        elif cur and "Candidate:" in line and "(none)" not in line:
            ok.add(cur)
    return ok


def summaries(pkgs):
    """package -> its one-line description (for isenkram's other suggestions)."""
    if not pkgs:
        return {}
    _, out = run(["apt-cache", "show", "--no-all-versions"] + list(pkgs), timeout=60)
    res, cur = {}, None
    for line in out.splitlines():
        if line.startswith("Package: "):
            cur = line[9:].strip()
        elif line.startswith("Description: ") and cur and cur not in res:
            res[cur] = line[13:].strip()
    return res


# ================================================================ what each device needs
def short_vendor(v):
    for pat, short in SHORT_VENDOR:
        if re.match(pat, v):
            return short
    return re.sub(r",?\s*(Corporation|Corp\.|Inc\.|Co\.,? Ltd\.?|Ltd\.?|Semiconductor|Technology)\b", "", v).strip()


def device_name(d):
    """ "NVIDIA" + "GP106 [GeForce GTX 1060 6GB]" -> "NVIDIA GeForce GTX 1060 6GB" """
    m = re.search(r"\[([^\]]+)\]\s*$", d["device"])
    model = m.group(1) if m else d["device"]
    ven = short_vendor(d["vendor"])
    return model if model.lower().startswith(ven.lower()) else f"{ven} {model}"


def option(oid, title, sub, pkgs, recommended=False, dkms=False, restart=True, check=None, builtin=False):
    return {"id": oid, "title": title, "sub": sub, "pkgs": list(pkgs), "check": check or (pkgs[0] if pkgs else None),
            "recommended": recommended, "dkms": dkms, "restart": restart, "builtin": builtin, "installed": False}


def nvidia_choice(text):
    """nvidia-detect's answer -> the driver package, None (only the open-source driver), or
    "nvidia-driver" when it can't tell."""
    m = re.findall(r"^\s+(nvidia-\S*driver)\s*$", text, re.M)
    if m:
        return m[0]
    if re.search(r"only supported by the nouveau|not supported by any", text, re.I):
        return None
    return "nvidia-driver"


def firmware_package(path):
    for prefix, pkgs in FIRMWARE_PACKAGES:
        if path.startswith(prefix):
            return pkgs
    return ["firmware-misc-nonfree"]


def detect(hw):
    """hw (from gather()) -> devices with their driver options (not yet marked installed)."""
    devices = []
    pci, usb = hw.get("pci", []), hw.get("usb", [])
    i386 = hw.get("i386")
    gpus = [d for d in pci if d["class_id"][:2] == "03"]

    for d in gpus:
        dev = {"cat": "graphics", "name": device_name(d), "detail": d["class"], "driver": d["driver"], "options": []}
        o = dev["options"]
        if d["vendor_id"] == "10de":
            pkg = nvidia_choice(hw.get("nvidia_detect", ""))
            if pkg:
                pkgs = [pkg, "linux-headers-amd64"] + ([pkg + "-libs:i386"] if i386 else [])
                o.append(option("nvidia", "NVIDIA driver",
                                "Best speed and games. Made by NVIDIA (closed source)", pkgs, recommended=True, dkms=True))
            o.append(option("nouveau", "Open-source driver (Nouveau)",
                            "Built in. Works without installing anything, but slower in games", [], builtin=True,
                            restart=False))
        elif d["vendor_id"] == "1002":
            o.append(option("amdgpu-fw", "AMD graphics firmware", "Needed by AMD graphics cards",
                            ["firmware-amd-graphics"], recommended=True))
            o.append(option("vulkan", "Vulkan for games", "Modern 3D graphics used by games and Steam",
                            ["mesa-vulkan-drivers"] + (["mesa-vulkan-drivers:i386"] if i386 else []), recommended=True,
                            restart=False))
            o.append(option("vaapi-amd", "Video acceleration", "Smoother videos with less power (VA-API)",
                            ["mesa-va-drivers", "mesa-vdpau-drivers"], restart=False))
        elif d["vendor_id"] == "8086":
            o.append(option("intel-fw", "Intel graphics firmware", "Power saving and newer Intel graphics",
                            ["firmware-intel-graphics"], recommended=False))
            o.append(option("vulkan", "Vulkan for games", "Modern 3D graphics used by games and Steam",
                            ["mesa-vulkan-drivers"] + (["mesa-vulkan-drivers:i386"] if i386 else []), recommended=True,
                            restart=False))
            o.append(option("vaapi-intel", "Video acceleration", "Smoother videos with less power (Intel 2014 and newer)",
                            ["intel-media-va-driver-non-free"], restart=False))
            o.append(option("vaapi-intel-old", "Video acceleration for older Intel graphics",
                            "Intel graphics made before 2014", ["i965-va-driver-shaders"], restart=False))
        devices.append(dev)

    for d in pci:
        if d["class_id"] in ("0280", "0200"):        # Wi-Fi, Ethernet
            o = []
            if d["vendor_id"] == "14e4" and d["device_id"] in BROADCOM_WL:
                o.append(option("broadcom-wl", "Broadcom Wi-Fi driver (wl)", "Needed for the Wi-Fi of this computer",
                                ["broadcom-sta-dkms", "linux-headers-amd64"], recommended=True, dkms=True))
            if d["vendor_id"] == "10ec" and d["device_id"] in ("8168", "8161", "8136"):
                o.append(option("r8168", "Realtek r8168 driver", "Try this if the wired network keeps dropping "
                                "(the built-in r8169 driver works for most)", ["r8168-dkms", "linux-headers-amd64"],
                                dkms=True))
            if o or not d["driver"]:
                devices.append({"cat": "network", "name": device_name(d), "detail": d["class"], "driver": d["driver"],
                                "options": o})
        elif d["class_id"] in ("0403", "0401") and d["vendor_id"] == "8086":   # Intel sound
            # only chips that use the newer firmware-based drivers (an old AC97 or HDA chip needs nothing)
            if d["driver"].startswith(("sof", "snd_soc", "snd_intel_avs", "avs")) or not d["driver"]:
                devices.append({"cat": "sound", "name": device_name(d), "detail": d["class"], "driver": d["driver"],
                                "options": [option("sof", "Intel sound firmware (SOF)",
                                                   "Speakers and microphones of most laptops from 2019 on",
                                                   ["firmware-sof-signed"], recommended=True),
                                            option("intel-sound", "Intel sound firmware (AVS)",
                                                   "Some newer Intel laptops", ["firmware-intel-sound"])]})

    for u in usb:
        if u["id"] in RTL88XXAU:
            devices.append({"cat": "network", "name": u["name"], "detail": N_("USB Wi-Fi"), "driver": "",
                            "options": [option("rtl88xxau", "Realtek RTL8812AU / 8821AU driver",
                                               "Needed for this USB Wi-Fi stick",
                                               ["realtek-rtl88xxau-dkms", "linux-headers-amd64"], recommended=True,
                                               dkms=True)]})

    # printers (USB printer class 07) and scanners
    printers = [u for u in usb if "07" in u["classes"]]
    if printers:
        for u in printers:
            maker = PRINTER_VENDORS.get(u["vendor_id"])
            o = [option("ipp-usb", "Driverless USB printing", "Most printers from the last ten years need nothing more",
                        ["ipp-usb"], recommended=True, restart=False)]
            if maker:
                o.append(option(f"printer-{u['vendor_id']}", f"{maker[0]} printer drivers",
                                f"For {maker[0]} printers that need their own driver", maker[1], recommended=True,
                                restart=False))
            o.append(option("printer-all", "All printer drivers", "Every printer driver in Pine OS (about 100 MB)",
                            ["printer-driver-all"], restart=False))
            devices.append({"cat": "printing", "name": u["name"], "detail": N_("USB printer"), "driver": "", "options": o})
    devices.append({"cat": "printing", "name": N_("Network printers and scanners"), "detail": "", "driver": "",
                    "options": [option("printer-all", "All printer drivers",
                                       "For printers that don't work without their own driver (about 100 MB)",
                                       ["printer-driver-all"], restart=False),
                                option("hplip", "HP printers and scanners", "HP's own drivers (HPLIP)", ["hplip"],
                                       restart=False),
                                option("scan", "Scanning", "Scanners and all-in-one printers, with the Document Scanner "
                                       "app", ["sane-airscan", "sane-utils", "simple-scan"], restart=False)]})

    # input devices
    for u in usb:
        vid = u["vendor_id"]
        if vid == "056a":
            devices.append({"cat": "input", "name": u["name"], "detail": N_("Drawing tablet"), "driver": "",
                            "options": [option("wacom", "Wacom tablet driver", "Pen pressure and tablet buttons",
                                               ["xserver-xorg-input-wacom"], recommended=True)]})
        elif vid in FINGERPRINT_VENDORS and "03" not in u["classes"] and "e0" not in u["classes"]:
            devices.append({"cat": "input", "name": u["name"], "detail": N_("Fingerprint reader"), "driver": "",
                            "options": [option("fprint", "Fingerprint reader support",
                                               "Sign in with your finger (works with many readers)",
                                               ["fprintd", "libpam-fprintd"], restart=False)]})
    pads = [u for u in usb if u["vendor_id"] in CONTROLLER_VENDORS and "03" in u["classes"]
            and u["vendor_id"] != "046d" or u["vendor_id"] == "046d" and re.search(r"pad|controller|joystick", u["name"], re.I)]
    if pads or hw.get("joystick"):
        devices.append({"cat": "input", "name": pads[0]["name"] if pads else "Game controller", "detail": N_("Game controller"),
                        "driver": "", "options": [option("steam-devices", "Game controller support",
                                                         "Steam, Xbox, PlayStation and other controllers in games",
                                                         ["steam-devices"], recommended=True, restart=False)]})

    # virtual machines
    vendors = {d["vendor_id"] for d in pci}
    dmi = hw.get("dmi", "")
    vm = None
    if "80ee" in vendors or "virtualbox" in dmi or "innotek" in dmi:
        vm = ("VirtualBox", [option("vbox", "VirtualBox guest additions", "Shared clipboard, any window size",
                                    ["virtualbox-guest-x11"], recommended=True)])
    elif "15ad" in vendors or "vmware" in dmi:
        vm = ("VMware", [option("vmware", "VMware tools", "Shared clipboard, any window size, shared folders",
                                ["open-vm-tools-desktop"], recommended=True)])
    elif "1af4" in vendors or "qemu" in dmi or "kvm" in dmi:
        vm = ("QEMU / KVM", [option("spice", "Virtual machine tools", "Shared clipboard and any window size (SPICE)",
                                    ["spice-vdagent", "qemu-guest-agent"], recommended=True)])
    elif "1414" in vendors or "microsoft corporation virtual" in dmi:
        vm = ("Hyper-V", [option("hyperv", "Hyper-V tools", "Better speed inside Hyper-V", ["hyperv-daemons"],
                                 recommended=True)])
    if vm:
        devices.append({"cat": "vm", "name": vm[0], "detail": N_("This computer is a virtual machine"), "driver": "",
                        "options": vm[1]})

    # processor microcode (security and stability fixes from Intel / AMD)
    cpu = hw.get("cpu", "")
    if "GenuineIntel" in cpu or "AuthenticAMD" in cpu:
        intel = "GenuineIntel" in cpu
        model = re.search(r"^model name\s*:\s*(.+)$", cpu, re.M)
        devices.append({"cat": "cpu", "name": model.group(1).strip() if model else ("Intel" if intel else "AMD"),
                        "detail": N_("Processor"), "driver": "",
                        "options": [option("microcode", "Processor updates (microcode)",
                                           "Security and stability fixes from " + ("Intel" if intel else "AMD"),
                                           ["intel-microcode" if intel else "amd64-microcode"], recommended=True)]})

    # firmware files the kernel asked for and didn't find
    missing = hw.get("scan", {}).get("missing_firmware", [])
    by_pkg = {}
    for f in missing:
        by_pkg.setdefault(tuple(firmware_package(f)), []).append(f)
    for pkgs, files in by_pkg.items():
        devices.append({"cat": "firmware", "name": ", ".join(files[:2]) + (f" (+{len(files) - 2})" if len(files) > 2 else ""),
                        "detail": N_("Asked for by a part of this computer"), "driver": "", "alternatives": list(pkgs),
                        "options": [option("fw-" + pkgs[0], "Firmware for a part of this computer",
                                           "The part may not work, or not fully, without it", [pkgs[0]],
                                           recommended=True)]})

    # anything else Debian knows for this hardware
    known = {p for dev in devices for o in dev["options"] for p in o["pkgs"]}
    extra = [p for p in hw.get("isenkram", []) if p not in known]
    if extra:
        devices.append({"cat": "other", "name": N_("Suggested for this hardware"), "detail": "", "driver": "",
                        "options": [option("isenkram-" + p, p, "", [p], restart=False) for p in extra[:20]]})
    return devices


def finish(devices):
    """Marks what is installed, drops what can't be installed here, fills in descriptions.
    Uses dpkg and apt-cache (a second or two)."""
    pkgs = {p for d in devices for o in d["options"] for p in o["pkgs"]} | \
           {p for d in devices for p in d.get("alternatives", [])}
    have, avail = installed_set(pkgs), available_set(pkgs)
    for d in devices:
        if d.get("alternatives"):                     # firmware: the first package that exists
            pick = next((p for p in d["alternatives"] if p in avail or p in have), None)
            if pick:
                d["options"][0].update(id="fw-" + pick, pkgs=[pick], check=pick)
        keep = []
        for o in d["options"]:
            if o["builtin"]:
                keep.append(o)
                continue
            o["installed"] = o["check"] in have
            # i386 parts and headers come along only when they exist
            needed = [p for p in o["pkgs"] if p == o["check"] or p in avail or p in have]
            if o["installed"] or o["check"] in avail:
                o["pkgs"] = needed
                keep.append(o)
        d["options"] = keep
        for o in d["options"]:
            if o["builtin"]:
                # the open-source NVIDIA driver is "in use" when NVIDIA's isn't installed
                o["installed"] = not any(x["installed"] for x in d["options"] if not x["builtin"])
    other = [o for d in devices if d["cat"] == "other" for o in d["options"]]
    if other:
        desc = summaries([o["check"] for o in other])
        for o in other:
            o["sub"] = desc.get(o["check"], "")
    return [d for d in devices if d["options"] or d["cat"] in ("graphics",)]


def scan():
    return finish(detect(gather()))


def missing_recommended(devices=None):
    """Recommended drivers that are not installed: [{"title", "pkgs"}]."""
    devices = scan() if devices is None else devices
    seen, out = set(), []
    for d in devices:
        for o in d["options"]:
            if o["recommended"] and not o["installed"] and not o["builtin"] and o["id"] not in seen:
                seen.add(o["id"])
                out.append({"title": o["title"], "pkgs": o["pkgs"], "id": o["id"]})
    return out


if __name__ == "__main__":
    # self-check with a made-up computer
    lspci = """Slot:\t01:00.0
Class:\tVGA compatible controller [0300]
Vendor:\tNVIDIA Corporation [10de]
Device:\tGP106 [GeForce GTX 1060 6GB] [1c03]
Driver:\tnouveau

Slot:\t00:1f.3
Class:\tMultimedia audio controller [0401]
Vendor:\tIntel Corporation [8086]
Device:\tCannon Lake PCH cAVS [a348]
Driver:\tsof-audio-pci-intel-cnl

Slot:\t02:00.0
Class:\tNetwork controller [0280]
Vendor:\tBroadcom Inc. and subsidiaries [14e4]
Device:\tBCM4360 802.11ac Wireless Network Adapter [43a0]
"""
    hw = {"pci": parse_lspci(lspci), "i386": True,
          "usb": [{"id": "03f0:1234", "vendor_id": "03f0", "name": "HP LaserJet", "classes": {"07"}},
                  {"id": "27c6:5395", "vendor_id": "27c6", "name": "Goodix FingerPrint", "classes": {"ff"}},
                  {"id": "045e:028e", "vendor_id": "045e", "name": "Microsoft X-Box 360 pad", "classes": {"ff", "03"}}],
          "scan": {"missing_firmware": ["iwlwifi-so-a0-gf-a0-86.ucode", "rtl_bt/rtl8761bu_fw.bin", "nonsense.bin"]},
          "nvidia_detect": "It is recommended to install the\n    nvidia-tesla-535-driver\npackage.\n",
          "isenkram": ["firmware-iwlwifi", "fwupd-extra"], "cpu": "vendor_id\t: GenuineIntel\nmodel name\t: Intel(R) Core(TM) i5\n",
          "dmi": "lenovo thinkpad"}
    devs = detect(hw)
    cats = [d["cat"] for d in devs]
    assert parse_lspci(lspci)[0]["vendor_id"] == "10de" and parse_lspci(lspci)[0]["driver"] == "nouveau"
    g = devs[0]
    assert g["name"] == "NVIDIA GeForce GTX 1060 6GB", g["name"]
    assert g["options"][0]["pkgs"] == ["nvidia-tesla-535-driver", "linux-headers-amd64", "nvidia-tesla-535-driver-libs:i386"]
    assert g["options"][1]["builtin"]
    assert nvidia_choice("Your card is only supported by the nouveau driver") is None
    assert nvidia_choice("") == "nvidia-driver"
    assert any(o["id"] == "broadcom-wl" for d in devs for o in d["options"])
    assert any(o["id"] == "sof" and o["recommended"] for d in devs for o in d["options"])
    ac97 = dict(hw, pci=parse_lspci("Slot:\t00:05.0\nClass:\tMultimedia audio controller [0401]\nVendor:\tIntel Corporation [8086]\nDevice:\t82801AA AC\x2797 [2415]\nDriver:\tsnd_intel8x0\n"),
                joystick=False, usb=[], scan={}, isenkram=[])
    assert not [d for d in detect(ac97) if d["cat"] in ("sound", "input")], "AC97 and no controller need nothing"
    assert any(o["id"] == "printer-03f0" for d in devs for o in d["options"])
    assert any(o["id"] == "fprint" for d in devs for o in d["options"])
    assert any(o["id"] == "steam-devices" for d in devs for o in d["options"])
    fw = [d for d in devs if d["cat"] == "firmware"]
    assert {d["alternatives"][0] for d in fw} == {"firmware-iwlwifi", "firmware-realtek", "firmware-misc-nonfree"}, fw
    other = [o["check"] for d in devs if d["cat"] == "other" for o in d["options"]]
    assert other == ["fwupd-extra"], other
    assert "cpu" in cats and "vm" not in cats
    assert firmware_package("amdgpu/navi10_sos.bin") == ["firmware-amd-graphics"]
    assert device_name({"vendor": "Intel Corporation", "device": "UHD Graphics 620"}) == "Intel UHD Graphics 620"
    print("drivers_db: ok")
