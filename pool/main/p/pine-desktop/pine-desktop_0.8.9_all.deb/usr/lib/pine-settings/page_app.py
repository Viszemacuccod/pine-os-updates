#!/usr/bin/python3
"""One page of Pine Settings in its own window: Network & Wi-Fi, Sound, Bluetooth & devices,
Printers & scanners, Restore points, Updates, Display.

Usage: page_app.py <page id>      (the launchers are /usr/bin/pine-page and the .desktop files)
Same pages, same look as in Settings (it builds the very same page), only without the sidebar.
"""
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

import gi  # noqa: E402
gi.require_version("Gtk", "4.0")
gi.require_version("Adw", "1")
from gi.repository import Adw, Gio, GLib  # noqa: E402

import common  # noqa: E402
import look  # noqa: E402
import main as settings  # noqa: E402  (registers every page; does not start Settings)

# window title shown to the user, per page id
NAMES = {"network": "Network & Wi-Fi", "devices": "Bluetooth & devices", "sound": "Sound",
         "printers": "Printers & scanners", "recovery": "Restore points", "update": "Updates",
         "display": "Display"}
PAGES = settings.PAGES


class PageWindow(Adw.ApplicationWindow):
    """Stands in for Settings' window: pages call common.WINDOW.toast / show_page / refresh."""

    def __init__(self, app, pid):
        self.pid = pid
        super().__init__(application=app, title=common._(NAMES.get(pid, PAGES[pid]["title"])))
        self.set_default_size(780, 700)
        self.set_size_request(360, 400)
        common.WINDOW = self
        self.toasts = Adw.ToastOverlay()
        self.nav = Adw.NavigationView()
        self.toasts.set_child(self.nav)
        self.set_content(self.toasts)
        self.nav.add(self._make(pid))

    def _make(self, pid):
        title = common._(NAMES.get(pid, PAGES[pid]["title"])) if pid == self.pid else PAGES[pid]["title"]
        try:
            widget = PAGES[pid]["build"]()
        except Exception as ex:  # a broken page must not take the window down
            import traceback
            traceback.print_exc()
            widget = Adw.StatusPage(icon_name="dialog-warning-symbolic", title="This page could not be opened",
                                    description=str(ex))
        tv = Adw.ToolbarView()
        tv.add_top_bar(Adw.HeaderBar())
        tv.set_content(widget)
        return Adw.NavigationPage(title=title, tag=pid, child=tv)

    def show_page(self, pid):
        pid = settings.ALIASES.get(pid, pid)
        if pid in PAGES and (self.nav.get_visible_page() is None or self.nav.get_visible_page().get_tag() != pid):
            self.nav.push(self._make(pid))

    def refresh(self):
        pages = self.nav.get_navigation_stack()
        tags = [pages.get_item(i).get_tag() for i in range(pages.get_n_items())]
        new = Adw.NavigationView()          # a fresh view: replacing in place trips over equal page tags
        new.replace([self._make(t) for t in tags])
        self.toasts.set_child(new)
        self.nav = new

    def toast(self, text):
        t = Adw.Toast.new(text)
        t.set_timeout(3)
        self.toasts.add_toast(t)


class App(Adw.Application):
    def __init__(self, pid):
        super().__init__(application_id=f"org.pineos.Page.{pid}", flags=Gio.ApplicationFlags.FLAGS_NONE)
        self.pid, self.win = pid, None

    def do_startup(self):
        Adw.Application.do_startup(self)
        self.provider = look.apply()

    def do_activate(self):
        if self.win is None:
            self.win = PageWindow(self, self.pid)
        self.win.present()


if __name__ == "__main__":
    pid = next((a for a in sys.argv[1:] if not a.startswith("-")), "network")
    pid = settings.ALIASES.get(pid, pid)
    if pid not in PAGES:
        sys.exit(f"pine-page: no such page '{pid}'. Pages: {', '.join(sorted(PAGES))}")
    sys.exit(App(pid).run([sys.argv[0]]))
