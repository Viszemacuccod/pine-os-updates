"""Firewall rules: ufw's rule words <-> the fields Settings shows (no GTK, testable alone).

A rule here: {"action": allow|deny|reject|limit, "direction": in|out, "iface": "", "log": ""|log|log-all,
              "proto": tcp|udp|both|all, "ports": "", "src": "any", "sports": "", "dst": "any",
              "comment": "", "words": [[...ufw words of each underlying ufw rule...]]}
"TCP and UDP" with a range or a list of ports is two ufw rules (ufw needs one protocol for
those); grouping puts them back together. Run this file to check it: python3 fwrules.py
"""
import ipaddress
import re
import shlex


def N_(text):
    """Marks text Pine Settings shows translated (tools/i18n.py finds it)."""
    return text

ACTIONS = ["allow", "deny", "reject", "limit"]
DIRECTIONS = ["in", "out"]
PROTOS = ["tcp", "udp", "both", "all"]
LOGS = ["", "log", "log-all"]
SIMPLE = re.compile(r"^([\d:,]+)(?:/(tcp|udp))?$")
IFACE = re.compile(r"^[A-Za-z0-9_.\-]{1,15}$")


def empty_rule():
    return {"action": "allow", "direction": "in", "iface": "", "log": "", "proto": "tcp", "ports": "",
            "src": "any", "sports": "", "dst": "any", "comment": "", "words": []}


def parse(spec):
    """One line of "ufw show added" (or its words) -> a rule, or None when it uses something
    Settings doesn't edit (app profiles): those can still be deleted."""
    try:
        w = shlex.split(spec) if isinstance(spec, str) else list(spec)
    except ValueError:
        return None
    if w[:1] == ["ufw"]:
        w = w[1:]
    if not w or w[0] not in ACTIONS:
        return None
    r = empty_rule()
    r.update(action=w[0], proto="all", words=[list(w)])
    i, last = 1, None
    while i < len(w):
        t, nxt = w[i], (w[i + 1] if i + 1 < len(w) else None)
        if t in DIRECTIONS:
            r["direction"] = t
            i += 1
        elif t in ("log", "log-all"):
            r["log"] = t
            i += 1
        elif t in ("on", "proto", "from", "to", "port", "comment") and nxt is not None:
            if t == "on":
                r["iface"] = nxt
            elif t == "proto":
                if nxt not in ("tcp", "udp"):
                    return None
                r["proto"] = nxt
            elif t == "from":
                r["src"], last = nxt, "from"
            elif t == "to":
                r["dst"], last = nxt, "to"
            elif t == "port":
                r["sports" if last == "from" else "ports"] = nxt
            else:
                r["comment"] = nxt
            i += 2
        elif last is None and not r["ports"] and SIMPLE.match(t):     # simple form: "ufw allow 22/tcp"
            m = SIMPLE.match(t)
            r["ports"] = m.group(1)
            if m.group(2):
                r["proto"] = m.group(2)
            i += 1
        else:
            return None
    # a port without a protocol: ufw means TCP and UDP
    if r["proto"] == "all" and (r["ports"] or r["sports"]):
        r["proto"] = "both"
    return r


def _key(r):
    return (r["action"], r["direction"], r["iface"], r["log"], r["ports"], r["src"], r["sports"], r["dst"], r["comment"])


def group(specs):
    """ "ufw show added" lines -> rules to show; a TCP rule and a UDP rule that are otherwise
    the same become one "TCP and UDP" rule. Lines Settings can't read: {"raw": line, "words": [...]}."""
    out, seen = [], {}
    for spec in specs:
        r = parse(spec)
        if r is None:
            try:
                words = shlex.split(spec)[1:]
            except ValueError:
                continue
            out.append({"raw": spec, "words": [words]})
            continue
        k = _key(r)
        other = seen.get(k)
        if other is not None and {other["proto"], r["proto"]} == {"tcp", "udp"}:
            other["proto"] = "both"
            other["words"] += r["words"]
            del seen[k]
            continue
        if r["proto"] in ("tcp", "udp"):
            seen[k] = r
        out.append(r)
    return out


def _multi(ports):
    return "," in ports or ":" in ports


def build(r):
    """A rule -> the ufw words of each ufw rule it needs (one, or two for TCP and UDP)."""
    if r["proto"] == "both":
        protos = ["tcp", "udp"] if (not r["ports"] and not r["sports"]) or _multi(r["ports"]) or _multi(r["sports"]) \
            else [None]
    elif r["proto"] == "all":
        protos = [None]
    else:
        protos = [r["proto"]]
    rules = []
    for p in protos:
        w = [r["action"], r["direction"]]
        if r["iface"]:
            w += ["on", r["iface"]]
        if r["log"]:
            w.append(r["log"])
        if p:
            w += ["proto", p]
        w += ["from", r["src"] or "any"]
        if r["sports"] and r["proto"] != "all":
            w += ["port", r["sports"]]
        w += ["to", r["dst"] or "any"]
        if r["ports"] and r["proto"] != "all":
            w += ["port", r["ports"]]
        if r["comment"]:
            w += ["comment", r["comment"]]
        rules.append(w)
    return rules


def check_ports(text):
    """None if fine, else what is wrong. 80 | 8000:8100 | 80,443,8000:8100 (ufw: at most 15 ports,
    a range counts as two)."""
    if not text:
        return None
    count = 0
    for part in text.split(","):
        m = re.fullmatch(r"(\d{1,5})(?::(\d{1,5}))?", part)
        if not m:
            return N_("Ports are numbers: 80, a range like 8000:8100, or a list like 80,443")
        a, b = int(m.group(1)), int(m.group(2) or m.group(1))
        if not (1 <= a <= 65535 and 1 <= b <= 65535):
            return N_("Ports go from 1 to 65535")
        if m.group(2) and a >= b:
            return N_("In a range the first port must be smaller, like 8000:8100")
        count += 2 if m.group(2) else 1
    if count > 15:
        return N_("At most 15 ports in one rule (a range counts as two). Make another rule for the rest")
    return None


def check_address(text):
    """None if fine, else what is wrong. any | 192.168.1.20 | 192.168.1.0/24 | fe80::1 | fe80::/10"""
    if not text or text == "any":
        return None
    try:
        ipaddress.ip_network(text, strict=False)
        return None
    except ValueError:
        return N_("Addresses look like 192.168.1.20, 192.168.1.0/24 or fe80::1 (empty: anywhere)")


def version(text):
    if not text or text == "any":
        return None
    return ipaddress.ip_network(text, strict=False).version


def check(r):
    """Everything about a rule from the dialog: None if it can be saved, else what is wrong."""
    for key in ("ports", "sports"):
        e = check_ports(r[key])
        if e:
            return e
    if r["proto"] == "all" and (r["ports"] or r["sports"]):
        return N_("\"All traffic\" means every port: leave the ports empty, or choose TCP or UDP")
    for key in ("src", "dst"):
        e = check_address(r[key])
        if e:
            return e
    if version(r["src"]) and version(r["dst"]) and version(r["src"]) != version(r["dst"]):
        return N_("Both addresses must be the same kind (IPv4 or IPv6)")
    if r["iface"] and not IFACE.match(r["iface"]):
        return N_("Unknown network adapter")
    if "'" in r["comment"] or "\n" in r["comment"] or len(r["comment"]) > 200:
        return N_("The name may not contain ' and must be shorter than 200 letters")
    return None


if __name__ == "__main__":
    # self-check
    a = parse("ufw allow 1714:1764/tcp comment 'Phone Link'")
    assert a["ports"] == "1714:1764" and a["proto"] == "tcp" and a["comment"] == "Phone Link" and a["direction"] == "in"
    grouped = group    # (not the name tools/i18n.py looks for)
    g = grouped(["ufw allow 1714:1764/tcp comment 'Phone Link'", "ufw allow 1714:1764/udp comment 'Phone Link'",
               "ufw allow 22", "ufw deny out 25/tcp", "ufw allow OpenSSH",
               "ufw allow from 192.168.1.0/24 to any port 80,443 proto tcp",
               "ufw reject in on eth0 log from 10.0.0.5 port 5000 to any port 6000 proto udp comment 'x y'"])
    assert len(g) == 6, g
    assert g[0]["proto"] == "both" and len(g[0]["words"]) == 2
    assert g[1]["proto"] == "both" and g[1]["ports"] == "22"
    assert g[2]["direction"] == "out" and g[2]["action"] == "deny" and g[2]["ports"] == "25"
    assert "raw" in g[3] and g[3]["words"] == [["allow", "OpenSSH"]]
    assert g[4]["src"] == "192.168.1.0/24" and g[4]["ports"] == "80,443" and g[4]["proto"] == "tcp"
    assert g[5]["iface"] == "eth0" and g[5]["sports"] == "5000" and g[5]["ports"] == "6000" and g[5]["log"] == "log"
    # building: TCP and UDP with a range -> two rules; one port -> one rule without a protocol
    r = dict(empty_rule(), proto="both", ports="8000:8100", comment="Game")
    assert [w[w.index("proto") + 1] for w in build(r)] == ["tcp", "udp"]
    assert "proto" not in build(dict(empty_rule(), proto="both", ports="53"))[0]
    assert build(dict(empty_rule(), proto="all", action="deny", src="10.0.0.0/8")) == \
        [["deny", "in", "from", "10.0.0.0/8", "to", "any"]]
    # what was built reads back the same
    for r in (dict(empty_rule(), proto="udp", ports="27015", direction="out", log="log-all", iface="wlan0"),
              dict(empty_rule(), proto="both", ports="80,443", src="fe80::/10", comment="web")):
        back = grouped([" ".join(["ufw"] + [shlex.quote(x) for x in w]) for w in build(r)])
        assert len(back) == 1 and all(back[0][k] == r[k] for k in ("action", "direction", "iface", "log", "proto",
                                                                   "ports", "src", "dst", "comment")), (r, back)
    assert check(dict(empty_rule(), ports="70000")) and check(dict(empty_rule(), ports="9:3"))
    assert check(dict(empty_rule(), proto="all", ports="80")) and check(dict(empty_rule(), src="1.2.3"))
    assert check(dict(empty_rule(), src="10.0.0.1", dst="fe80::1"))
    assert check(dict(empty_rule(), ports=",".join(str(p) for p in range(1, 17))))
    assert check(dict(empty_rule(), ports="80,443,8000:8100", src="192.168.0.0/16")) is None
    print("fwrules: ok")
