#!/usr/bin/python3
"""Pine OS sign-in screen (LightDM greeter), built from mockups/login-screen.html.

  Lock screen    a big clock over the softly blurred wallpaper; a click or any key slides
                 it up (typing starts the password right away)
  Sign in        the person's picture (5 px square) and name, password with show / sign-in
                 buttons, wrong password: the box shakes; Caps Lock warning; back to the
                 lock screen after 30 s without typing or with Esc
  Bottom left    the people on this computer (when there is more than one, or a guest)
  Bottom right   keyboard layout, network, accessibility (bigger text, high contrast),
                 power (sleep, restart, shut down)

It is also the unlock screen: locking (xflock4 -> dm-tool lock) switches to LightDM, which
starts this greeter with the "lock" hint and the signed-in person chosen.

  greeter.py             run by LightDM (/usr/share/xgreeters/pine-greeter.desktop, through
                         /usr/libexec/pine-greeter-session, which falls back to slick-greeter)
  greeter.py --preview   without LightDM, for testing (people are made up; password "pine")
"""
import gettext
import os
import re
import shutil
import subprocess
import sys
import time

import gi
gi.require_version("Gtk", "3.0")
gi.require_version("Gdk", "3.0")
gi.require_version("GdkPixbuf", "2.0")
from gi.repository import GLib  # noqa: E402
GLib.set_prgname("pine-greeter")
from gi.repository import Gdk, GdkPixbuf, Gtk, Pango  # noqa: E402

PREVIEW = "--preview" in sys.argv
if not PREVIEW:
    gi.require_version("LightDM", "1")
    from gi.repository import LightDM  # noqa: E402

_ = gettext.translation("pine", fallback=True).gettext

WALLPAPER = "/usr/share/backgrounds/pine/pine-wallpaper.png"
ACCENT, ON_ACCENT = "#3ccf7d", "#04130b"
IDLE_SECONDS = 30
ANIM_MS = 260


# ---------------------------------------------------------------- look
def css(big=False, contrast=False):
    fg, muted = ("#ffffff", "#e6ecea") if contrast else ("#f2f4f3", "#a3b1ab")
    field = "rgba(0, 0, 0, 0.85)" if contrast else "rgba(14, 22, 26, 0.74)"
    line = "rgba(255, 255, 255, 0.45)" if contrast else "rgba(255, 255, 255, 0.12)"
    pop = "#000000" if contrast else "rgba(13, 21, 24, 0.97)"
    scale = 1.15 if big else 1.0
    px = lambda n: f"{round(n * scale)}px"  # noqa: E731
    return f"""
#pine-greeter {{ background-color: #06090c; color: {fg}; font-family: Inter, sans-serif; font-size: {px(14)}; }}
#pine-greeter label {{ color: {fg}; }}
#pine-greeter .time {{ font-size: {px(118)}; font-weight: 300; letter-spacing: -2px; text-shadow: 0 2px 24px rgba(0,0,0,.35); }}
#pine-greeter .date {{ font-size: {px(21)}; font-weight: 500; text-shadow: 0 1px 12px rgba(0,0,0,.45); }}
#pine-greeter .hint, #pine-greeter .host, #pine-greeter .muted {{ color: {muted}; font-size: {px(13)}; }}
#pine-greeter .avatar {{ border-radius: 5px; min-width: 128px; min-height: 128px;
  background-image: linear-gradient(145deg, #8fe7b0, {ACCENT} 45%, #2a9d63); }}
#pine-greeter .avatar label {{ color: {ON_ACCENT}; font-family: Poppins, Inter, sans-serif; font-size: 48px; font-weight: 600; }}
#pine-greeter .avatar.b {{ background-image: linear-gradient(145deg, #a8c8ff, #4c8dff 50%, #2f5fc4); }}
#pine-greeter .avatar.b label {{ color: #ffffff; }}
#pine-greeter .avatar.guest {{ background-image: linear-gradient(145deg, #3a4a45, #26312e); }}
#pine-greeter .avatar.guest image {{ color: {fg}; }}
#pine-greeter .name {{ font-family: Poppins, Inter, sans-serif; font-size: {px(26)}; font-weight: 600; }}
#pine-greeter .field {{ border-radius: 5px; background-color: {field}; border: 1px solid {line};
  border-bottom: 2px solid rgba(255, 255, 255, 0.35); min-height: {px(38)}; padding: 0 4px 0 6px; }}
#pine-greeter .field.focus {{ border-bottom-color: {ACCENT}; }}
#pine-greeter .field entry {{ background: none; border: none; box-shadow: none; color: {fg}; min-height: {px(36)};
  font-size: {px(14)}; caret-color: {ACCENT}; }}
#pine-greeter .field entry placeholder {{ color: {muted}; }}
#pine-greeter button.fieldbtn {{ min-width: 30px; min-height: 30px; padding: 0; border: none; border-radius: 5px;
  background: none; box-shadow: none; color: {muted}; }}
#pine-greeter button.fieldbtn:hover {{ background-color: rgba(255, 255, 255, 0.12); color: {fg}; }}
#pine-greeter button.fieldbtn image {{ color: inherit; }}
#pine-greeter button.go {{ background-color: rgba(255, 255, 255, 0.10); color: {fg}; }}
#pine-greeter button.go:hover {{ background-color: {ACCENT}; color: {ON_ACCENT}; }}
#pine-greeter .error {{ color: #ff8a8d; font-size: {px(13)}; }}
#pine-greeter .caps {{ color: #ffb35c; font-size: {px(13)}; }}
#pine-greeter .caps image {{ color: #ffb35c; }}
#pine-greeter .welcome {{ font-size: {px(17)}; font-weight: 500; }}
#pine-greeter spinner {{ color: {ACCENT}; }}
#pine-greeter button.user {{ border-radius: 5px; border: none; background: none; box-shadow: none; padding: 6px 14px 6px 6px; }}
#pine-greeter button.user:hover {{ background-color: rgba(255, 255, 255, 0.08); }}
#pine-greeter button.user.sel {{ background-color: rgba(11, 18, 21, 0.62); box-shadow: inset 0 0 0 1px {line}; }}
#pine-greeter .mini {{ border-radius: 5px; min-width: 40px; min-height: 40px;
  background-image: linear-gradient(145deg, #8fe7b0, {ACCENT} 45%, #2a9d63); }}
#pine-greeter .mini label {{ color: {ON_ACCENT}; font-family: Poppins, Inter, sans-serif; font-size: 16px; font-weight: 600; }}
#pine-greeter .mini.b {{ background-image: linear-gradient(145deg, #a8c8ff, #4c8dff 50%, #2f5fc4); }}
#pine-greeter .mini.b label {{ color: #ffffff; }}
#pine-greeter .mini.guest {{ background-image: linear-gradient(145deg, #3a4a45, #26312e); }}
#pine-greeter button.tray {{ min-width: 40px; min-height: 40px; padding: 0 10px; border: none; border-radius: 5px;
  background: none; box-shadow: none; color: {fg}; }}
#pine-greeter button.tray:hover, #pine-greeter button.tray:checked {{ background-color: rgba(255, 255, 255, 0.08); }}
#pine-greeter button.tray label {{ font-weight: 600; font-size: {px(13)}; }}
popover.pine-pop {{ background-color: {pop}; border: 1px solid {line}; border-radius: 5px; padding: 6px;
  box-shadow: 0 18px 50px rgba(0, 0, 0, 0.55); color: {fg}; }}
popover.pine-pop label {{ color: {fg}; }}
popover.pine-pop .head {{ color: {muted}; font-size: 12px; font-weight: 600; margin: 4px 8px 6px; }}
popover.pine-pop button.item {{ border: none; border-radius: 5px; background: none; box-shadow: none; padding: 8px 10px; }}
popover.pine-pop button.item:hover {{ background-color: rgba(255, 255, 255, 0.08); }}
popover.pine-pop button.item image {{ color: {muted}; }}
popover.pine-pop .check {{ color: {ACCENT}; }}
popover.pine-pop .net image {{ color: {ACCENT}; }}
popover.pine-pop switch {{ border-radius: 5px; }}
popover.pine-pop switch slider {{ border-radius: 4px; }}
popover.pine-pop switch:checked {{ background-color: {ACCENT}; border-color: {ACCENT}; }}
"""


def icon(name, size=18):
    img = Gtk.Image.new_from_icon_name(name, Gtk.IconSize.BUTTON)
    img.set_pixel_size(size)
    return img


def styled(w, *classes):
    for c in classes:
        w.get_style_context().add_class(c)
    return w


def blurred(pix, w, h, factor):
    """The picture covering w x h, softly blurred (shrunk a lot, then enlarged again)."""
    pw, ph = pix.get_width(), pix.get_height()
    s = max(w / pw, h / ph)
    cw, ch = int(w / s), int(h / s)
    crop = pix.new_subpixbuf((pw - cw) // 2, (ph - ch) // 2, cw, ch)
    tw, th = max(8, w // factor), max(5, h // factor)
    img = crop.scale_simple(tw, th, GdkPixbuf.InterpType.HYPER)
    # enlarge in steps of 2x: one big bilinear jump shows blocks and diamonds, steps stay smooth
    while img.get_width() < w:
        img = img.scale_simple(min(w, img.get_width() * 2), min(h, img.get_height() * 2), GdkPixbuf.InterpType.BILINEAR)
    return img.scale_simple(w, h, GdkPixbuf.InterpType.BILINEAR)


# ---------------------------------------------------------------- what the greeter talks to
class Person:
    def __init__(self, name, display, image=None, session=None, logged_in=False, guest=False):
        self.name, self.display, self.image = name, display or name, image
        self.session, self.logged_in, self.guest = session, logged_in, guest


class Backend:
    """LightDM: people, signing in, power. Callbacks: on_prompt(secret, text), on_message(text,
    error), on_done(ok)."""

    def __init__(self, on_prompt, on_message, on_done):
        self.on_prompt, self.on_message, self.on_done = on_prompt, on_message, on_done
        self.g = LightDM.Greeter()
        self.g.connect("show-prompt", lambda g, text, kind: self.on_prompt(kind == LightDM.PromptType.SECRET, text))
        self.g.connect("show-message", lambda g, text, kind: self.on_message(text, kind == LightDM.MessageType.ERROR))
        self.g.connect("authentication-complete", lambda g: self.on_done(g.get_is_authenticated()))
        self.g.connect_to_daemon_sync()

    def people(self):
        out = []
        # Debian's 01_debian.conf sets greeter-hide-users=true; this greeter is a picture picker, so
        # the hint is ignored (with it honoured the list was empty and Enter did nothing)
        for u in LightDM.UserList.get_instance().get_users():
            img = u.get_image()
            out.append(Person(u.get_name(), u.get_display_name(), img if img and os.path.exists(img) else None,
                              u.get_session(), u.get_logged_in()))
        if self.g.get_has_guest_account_hint():
            out.append(Person("*guest", _("Guest"), guest=True))
        return out

    def hints(self):
        return {"lock": self.g.get_lock_hint(), "select": self.g.get_select_user_hint(),
                "manual": self.g.get_show_manual_login_hint(), "host": LightDM.get_hostname()}

    def authenticate(self, person):
        if self.g.get_in_authentication():
            self.g.cancel_authentication()
        if person.guest:
            self.g.authenticate_as_guest()
        else:
            self.g.authenticate(person.name)

    def respond(self, text):
        self.g.respond(text)

    def start(self, person):
        session = person.session or self.g.get_default_session_hint() or None
        try:
            return self.g.start_session_sync(session)
        except GLib.Error as e:
            print("pine-greeter: start session:", e, file=sys.stderr)
            return False

    def can(self, what):
        return {"suspend": LightDM.get_can_suspend, "restart": LightDM.get_can_restart,
                "shutdown": LightDM.get_can_shutdown}[what]()

    def power(self, what):
        try:
            {"suspend": LightDM.suspend, "restart": LightDM.restart, "shutdown": LightDM.shutdown}[what]()
        except GLib.Error as e:
            print("pine-greeter: power:", e, file=sys.stderr)

    def layouts(self):
        """[(name, short, description)] of the keyboard layouts set up for this computer."""
        wanted = keyboard_layouts()
        found = {}
        for lay in LightDM.get_layouts():
            n = lay.get_name()
            if n in wanted or n.split("\t")[0] in wanted:
                found[n] = (n, lay.get_short_description() or n[:2], lay.get_description())
        cur = LightDM.get_layout()
        if cur and cur.get_name() not in found:
            found[cur.get_name()] = (cur.get_name(), cur.get_short_description() or cur.get_name()[:2],
                                     cur.get_description())
        return list(found.values()), (cur.get_name() if cur else None)

    def set_layout(self, name):
        for lay in LightDM.get_layouts():
            if lay.get_name() == name:
                LightDM.set_layout(lay)
                return


class PreviewBackend:
    """Made-up people for testing without LightDM; the password is "pine"."""

    def __init__(self, on_prompt, on_message, on_done):
        self.on_prompt, self.on_message, self.on_done = on_prompt, on_message, on_done
        self.who = None
        self.layout = "hu"

    def people(self):
        return [Person("testu", "Test User", logged_in=True), Person("anna", "Anna Kovács"),
                Person("*guest", _("Guest"), guest=True)]

    def hints(self):
        return {"lock": "--lock" in sys.argv, "select": "testu", "manual": False, "host": "test-pc"}

    def authenticate(self, person):
        self.who = person
        GLib.timeout_add(80, lambda: (self.on_done(True) if person.guest else self.on_prompt(True, "Password:"), False)[1])

    def respond(self, text):
        GLib.timeout_add(500, lambda: (self.on_done(text == "pine"), False)[1])

    def start(self, person):
        print("pine-greeter (preview): would start the session of", person.name)
        GLib.timeout_add(1500, Gtk.main_quit)
        return True

    def can(self, what):
        return True

    def power(self, what):
        print("pine-greeter (preview): power", what)

    def layouts(self):
        return [("hu", "HU", "Hungarian"), ("us", "US", "English (US)")], self.layout

    def set_layout(self, name):
        self.layout = name


def keyboard_layouts():
    """The layouts in /etc/default/keyboard (set by the installer), e.g. {"hu", "us"}."""
    try:
        text = open("/etc/default/keyboard").read()
        m = re.search(r'^XKBLAYOUT="?([^"\n]*)', text, re.M)
        return {x.strip() for x in m.group(1).split(",") if x.strip()} if m else set()
    except OSError:
        return set()


def network_state():
    """("ethernet" / "wifi" / None, name) from NetworkManager, or None without it."""
    if not shutil.which("nmcli"):
        return None
    try:
        out = subprocess.run(["nmcli", "-t", "-f", "TYPE,STATE,CONNECTION", "device"], capture_output=True,
                             text=True, timeout=4).stdout
    except (OSError, subprocess.TimeoutExpired):
        return None
    for line in out.splitlines():
        parts = line.split(":")
        if len(parts) >= 3 and parts[1] == "connected" and parts[0] in ("ethernet", "wifi"):
            return parts[0], parts[2]
    return (None, "")


# ---------------------------------------------------------------- the screen
class Greeter(Gtk.Window):
    def __init__(self):
        super().__init__(type=Gtk.WindowType.TOPLEVEL)
        self.set_name("pine-greeter")
        self.set_decorated(False)
        self.connect("destroy", Gtk.main_quit)
        self.provider = Gtk.CssProvider()
        Gtk.StyleContext.add_provider_for_screen(Gdk.Screen.get_default(), self.provider,
                                                 Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION + 2)
        self.big = self.contrast = False
        self.restyle()

        disp = Gdk.Display.get_default()
        # the window covers every monitor (the background everywhere); the content goes on
        # the main one
        self.sw = self.sh = 0
        for i in range(disp.get_n_monitors()):
            g = disp.get_monitor(i).get_geometry()
            self.sw, self.sh = max(self.sw, g.x + g.width), max(self.sh, g.y + g.height)
        mon = disp.get_primary_monitor() or disp.get_monitor(0)
        self.mg = mon.get_geometry()                      # the main screen: the content goes here
        self.move(0, 0)
        self.set_default_size(self.sw, self.sh)
        self.set_size_request(self.sw, self.sh)

        cls = PreviewBackend if PREVIEW else Backend
        self.be = cls(self.on_prompt, self.on_message, self.on_done)
        self.hint = self.be.hints()
        self.people = self.be.people()
        if not self.people:       # nobody to sign in: let slick-greeter (with manual login) take over
            print("pine-greeter: no users found", file=sys.stderr)
            sys.exit(1)
        self.person = None
        self.prompt_secret = False
        self.pending = None           # the password typed before LightDM asked for it
        self.signing = False          # the person pressed Enter: an answer counts now
        self.auth_ok = False          # LightDM said yes without asking (guest, no password)
        self.tray_btns = []

        # background: lock (soft blur) and sign-in (strong blur) pictures, cross-faded
        try:
            src = GdkPixbuf.Pixbuf.new_from_file(WALLPAPER)
        except GLib.Error:
            src = GdkPixbuf.Pixbuf.new(GdkPixbuf.Colorspace.RGB, False, 8, 16, 10)
            src.fill(0x06090cff)
        self.bg_lock = blurred(src, self.sw, self.sh, 6)
        self.bg_sign = blurred(src, self.sw, self.sh, 64)
        self.t = 0.0                  # 0 = lock screen, 1 = sign in
        self.anim = None

        overlay = Gtk.Overlay()
        self.add(overlay)
        area = Gtk.DrawingArea()
        area.connect("draw", self.draw_bg)
        self.area = area
        overlay.add(area)
        for w in (self.lock_layer(), self.sign_layer(), self.users_layer(), self.tray_layer()):
            overlay.add_overlay(w)
            overlay.set_overlay_pass_through(w, True)

        self.add_events(Gdk.EventMask.KEY_PRESS_MASK | Gdk.EventMask.BUTTON_PRESS_MASK)
        self.connect("key-press-event", self.on_key)
        self.connect("button-press-event", self.on_click)
        self.keymap = Gdk.Keymap.get_for_display(disp)
        self.keymap.connect("state-changed", lambda *a: self.show_caps())
        self.idle = 0
        GLib.timeout_add_seconds(1, self.tick)
        self.tick()

        first = next((p for p in self.people if p.name == self.hint.get("select")), None) \
            or next((p for p in self.people if p.logged_in), None) or (self.people[0] if self.people else None)
        if first:
            self.choose(first)
        self.show_all()
        self.after_show()

    # ---- placement inside the main screen
    def place(self, w, halign, valign, top=0, bottom=0, left=0, right=0):
        """Put w inside the main monitor (the window spans every monitor)."""
        w.set_halign(halign)
        w.set_valign(valign)
        w.set_margin_top(self.mg.y + top)
        w.set_margin_bottom(self.sh - self.mg.y - self.mg.height + bottom)
        w.set_margin_start(self.mg.x + left)
        w.set_margin_end(self.sw - self.mg.x - self.mg.width + right)
        return w

    # ---- layers
    def lock_layer(self):
        """Top to bottom: spacer (its height moves the clock up when signing in), clock, date,
        free space, the hint, spacer down to the bottom of the main screen."""
        # the clock sits bottom left: the middle of the wallpaper is the logo
        col = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, halign=Gtk.Align.FILL, valign=Gtk.Align.FILL)
        col.set_margin_start(self.mg.x + 56)
        col.set_margin_end(self.sw - self.mg.x - self.mg.width)
        self.lock_space = Gtk.Box()
        self.lock_space.set_size_request(-1, self.mg.y)
        col.pack_start(self.lock_space, False, False, 0)
        col.pack_start(Gtk.Box(vexpand=True), True, True, 0)
        self.time = styled(Gtk.Label(halign=Gtk.Align.START), "time")
        self.date = styled(Gtk.Label(margin_top=6, margin_start=6, halign=Gtk.Align.START), "date")
        col.pack_start(self.time, False, False, 0)
        col.pack_start(self.date, False, False, 0)
        bottom = Gtk.Box()
        bottom.set_size_request(-1, self.sh - self.mg.y - self.mg.height + 84)
        col.pack_start(bottom, False, False, 0)
        self.hint_lb = styled(Gtk.Label(label=_("Click or press a key to sign in")), "hint")
        self.place(self.hint_lb, Gtk.Align.CENTER, Gtk.Align.END, bottom=26)

        host = Gtk.Box(spacing=8)
        host.pack_start(styled(icon("computer-symbolic", 15), "host"), False, False, 0)
        host.pack_start(styled(Gtk.Label(label=self.hint.get("host") or ""), "host"), False, False, 0)
        self.place(host, Gtk.Align.START, Gtk.Align.END, left=24, bottom=22)

        o = Gtk.Overlay()
        o.add(col)
        o.add_overlay(host)
        o.add_overlay(self.hint_lb)
        self.lock_o = o
        return o

    def sign_layer(self):
        who = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=0)
        who.set_size_request(320, -1)
        self.avatar = styled(Gtk.Box(halign=Gtk.Align.CENTER), "avatar")
        self.avatar.set_size_request(128, 128)
        who.pack_start(self.avatar, False, False, 0)
        self.name_lb = styled(Gtk.Label(margin_top=18, margin_bottom=22, ellipsize=Pango.EllipsizeMode.END), "name")
        who.pack_start(self.name_lb, False, False, 0)

        self.field = styled(Gtk.Box(spacing=2), "field")
        self.entry = Gtk.Entry(visibility=False, hexpand=True, placeholder_text=_("Password"),
                               input_purpose=Gtk.InputPurpose.PASSWORD)
        self.entry.connect("activate", lambda *a: self.submit())
        self.entry.connect("changed", lambda *a: self.poke())
        self.entry.connect("focus-in-event", lambda *a: (self.field.get_style_context().add_class("focus"), False)[1])
        self.entry.connect("focus-out-event", lambda *a: (self.field.get_style_context().remove_class("focus"), False)[1])
        self.field.pack_start(self.entry, True, True, 0)
        eye = styled(Gtk.Button(valign=Gtk.Align.CENTER), "fieldbtn")
        eye.add(icon("view-reveal-symbolic", 16))
        eye.set_tooltip_text(_("Show the password"))
        eye.connect("clicked", lambda *a: (self.entry.set_visibility(not self.entry.get_visibility()), self.entry.grab_focus()))
        eye.set_can_focus(False)
        go = styled(Gtk.Button(valign=Gtk.Align.CENTER), "fieldbtn", "go")
        go.add(icon("go-next-symbolic", 16))
        go.set_tooltip_text(_("Sign in"))
        go.connect("clicked", lambda *a: self.submit())
        go.set_can_focus(False)
        self.field.pack_start(eye, False, False, 0)
        self.field.pack_start(go, False, False, 0)
        who.pack_start(self.field, False, False, 0)

        self.msg = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=4, margin_top=12)
        self.msg.set_size_request(-1, 40)
        self.err_lb = styled(Gtk.Label(wrap=True, justify=Gtk.Justification.CENTER, max_width_chars=40), "error")
        self.err_lb.set_no_show_all(True)
        self.caps = Gtk.Box(spacing=6, halign=Gtk.Align.CENTER)
        self.caps.pack_start(styled(icon("go-up-symbolic", 14), "caps"), False, False, 0)
        self.caps.pack_start(styled(Gtk.Label(label=_("Caps Lock is on")), "caps"), False, False, 0)
        self.caps.set_no_show_all(True)
        for c in self.caps.get_children():
            c.show()
        self.msg.pack_start(self.err_lb, False, False, 0)
        self.msg.pack_start(self.caps, False, False, 0)
        who.pack_start(self.msg, False, False, 0)

        self.welcome = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=16, margin_top=6)
        self.spinner = Gtk.Spinner(width_request=28, height_request=28, halign=Gtk.Align.CENTER)
        self.welcome.pack_start(self.spinner, False, False, 0)
        self.welcome.pack_start(styled(Gtk.Label(label=_("Welcome back!")), "welcome"), False, False, 0)
        self.welcome.set_no_show_all(True)
        for c in self.welcome.get_children():
            c.show()
        who.pack_start(self.welcome, False, False, 0)
        self.who = who
        self.place(who, Gtk.Align.CENTER, Gtk.Align.CENTER, bottom=int(self.mg.height * 0.06))
        return who

    def users_layer(self):
        box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=4)
        self.user_btns = {}
        show = len(self.people) > 1
        for i, p in enumerate(self.people):
            b = styled(Gtk.Button(), "user")
            row = Gtk.Box(spacing=12)
            row.pack_start(self.mini(p, i), False, False, 0)
            row.pack_start(Gtk.Label(label=p.display, xalign=0), False, False, 0)
            b.add(row)
            b.set_size_request(210, -1)
            b.connect("clicked", lambda _b, p=p: (self.choose(p), self.entry.grab_focus()))
            b.set_can_focus(False)
            box.pack_start(b, False, False, 0)
            self.user_btns[p.name] = b
        box.set_no_show_all(not show)
        if not show:
            box.hide()
        self.users = box
        self.place(box, Gtk.Align.START, Gtk.Align.END, left=20, bottom=20)
        return box

    def mini(self, p, i):
        m = styled(Gtk.Box(), "mini", "guest" if p.guest else ("b" if i % 2 else "a"))
        m.set_size_request(40, 40)
        pic = self.picture(p, 40)
        if pic:
            m.pack_start(pic, True, True, 0)
        elif p.guest:
            m.pack_start(icon("avatar-default-symbolic", 18), True, True, 0)
        else:
            m.pack_start(Gtk.Label(label=(p.display[:1] or "?").upper(), hexpand=True), True, True, 0)
        return m

    @staticmethod
    def picture(p, size):
        if not p.image:
            return None
        try:
            return Gtk.Image.new_from_pixbuf(GdkPixbuf.Pixbuf.new_from_file_at_scale(p.image, size, size, False))
        except GLib.Error:
            return None

    def tray_layer(self):
        box = Gtk.Box(spacing=4)
        # keyboard layout
        self.layouts, cur = self.be.layouts()
        if self.layouts:
            self.lang_btn = styled(Gtk.MenuButton(), "tray")
            self.lang_lb = Gtk.Label(label=self.short(cur))
            self.lang_btn.add(self.lang_lb)
            self.lang_btn.set_tooltip_text(_("Keyboard layout"))
            self.lang_btn.set_popover(self.lang_pop(cur))
            box.pack_start(self.lang_btn, False, False, 0)
        # network (what it is connected to; it can't be changed before signing in)
        net = network_state()
        if net is not None:
            kind, name = net
            nb = styled(Gtk.MenuButton(), "tray")
            nb.add(icon("network-wired-symbolic" if kind == "ethernet" else "network-wireless-symbolic" if kind == "wifi"
                        else "network-offline-symbolic", 18))
            nb.set_tooltip_text(_("Network"))
            pop = styled(Gtk.Popover(), "pine-pop")
            row = styled(Gtk.Box(spacing=12, margin=8), "net")
            row.pack_start(icon(nb.get_child().get_icon_name()[0], 18), False, False, 0)
            texts = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
            texts.pack_start(Gtk.Label(label=("Ethernet" if kind == "ethernet" else name if kind == "wifi"
                                              else _("Not connected")), xalign=0), False, False, 0)
            if kind:
                texts.pack_start(styled(Gtk.Label(label=_("Connected"), xalign=0), "muted"), False, False, 0)
            row.pack_start(texts, False, False, 0)
            pop.add(row)
            row.show_all()
            nb.set_popover(pop)
            box.pack_start(nb, False, False, 0)
        # accessibility
        ab = styled(Gtk.MenuButton(), "tray")
        ab.add(icon("preferences-desktop-accessibility-symbolic", 18))
        ab.set_tooltip_text(_("Accessibility"))
        ab.set_popover(self.a11y_pop())
        box.pack_start(ab, False, False, 0)
        # power
        pb = styled(Gtk.MenuButton(), "tray")
        pb.add(icon("system-shutdown-symbolic", 18))
        pb.set_tooltip_text(_("Power"))
        pb.set_popover(self.power_pop())
        box.pack_start(pb, False, False, 0)
        for b in box.get_children():
            b.set_can_focus(False)
            b.connect("toggled", lambda *a: self.poke())
            self.tray_btns.append(b)
        self.place(box, Gtk.Align.END, Gtk.Align.END, right=16, bottom=16)
        return box

    def short(self, name):
        for n, s, _d in self.layouts:
            if n == name:
                return s.upper()[:3]
        return (name or "")[:2].upper()

    def menu_item(self, text, icon_name=None, check=None, on_click=None):
        b = styled(Gtk.Button(), "item")
        row = Gtk.Box(spacing=12)
        if icon_name:
            row.pack_start(icon(icon_name, 17), False, False, 0)
        row.pack_start(Gtk.Label(label=text, xalign=0), True, True, 0)
        if check is not None:
            c = styled(Gtk.Label(label="✓"), "check")
            c.set_opacity(1 if check else 0)
            row.pack_end(c, False, False, 0)
            b.check = c
        b.add(row)
        if on_click:
            b.connect("clicked", lambda *a: on_click())
        return b

    def lang_pop(self, cur):
        pop = styled(Gtk.Popover(), "pine-pop")
        box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
        box.pack_start(styled(Gtk.Label(label=_("Keyboard layout"), xalign=0), "head"), False, False, 0)
        self.lang_items = {}
        for n, s, d in self.layouts:
            b = self.menu_item(d or s, check=(n == cur), on_click=lambda n=n: self.set_layout(n))
            self.lang_items[n] = b
            box.pack_start(b, False, False, 0)
        box.show_all()
        pop.add(box)
        return pop

    def set_layout(self, name):
        self.be.set_layout(name)
        self.lang_lb.set_text(self.short(name))
        for n, b in self.lang_items.items():
            b.check.set_opacity(1 if n == name else 0)
        self.lang_btn.set_active(False)
        self.entry.grab_focus()

    def a11y_pop(self):
        pop = styled(Gtk.Popover(), "pine-pop")
        box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
        box.pack_start(styled(Gtk.Label(label=_("Accessibility"), xalign=0), "head"), False, False, 0)
        rows = [("format-text-larger-symbolic", _("Bigger text"), "big"),
                ("display-brightness-symbolic", _("High contrast"), "contrast")]
        if shutil.which("onboard"):
            rows.append(("input-keyboard-symbolic", _("On-screen keyboard"), "osk"))
        for ic, text, key in rows:
            row = Gtk.Box(spacing=12, margin_start=10, margin_end=8, margin_top=6, margin_bottom=6)
            row.pack_start(icon(ic, 17), False, False, 0)
            row.pack_start(Gtk.Label(label=text, xalign=0), True, True, 0)
            sw = Gtk.Switch(valign=Gtk.Align.CENTER)
            sw.connect("notify::active", lambda s, _p, key=key: self.a11y(key, s.get_active()))
            row.pack_end(sw, False, False, 0)
            box.pack_start(row, False, False, 0)
        box.show_all()
        pop.add(box)
        return pop

    def a11y(self, key, on):
        if key == "big":
            self.big = on
        elif key == "contrast":
            self.contrast = on
        elif key == "osk":
            if on:
                self.osk = subprocess.Popen(["onboard"], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            elif getattr(self, "osk", None):
                self.osk.terminate()
        self.restyle()
        self.poke()

    def power_pop(self):
        pop = styled(Gtk.Popover(), "pine-pop")
        box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
        for what, ic, text in (("suspend", "weather-clear-night-symbolic", _("Sleep")),
                               ("restart", "system-reboot-symbolic", _("Restart")),
                               ("shutdown", "system-shutdown-symbolic", _("Shut down"))):
            if self.be.can(what):
                box.pack_start(self.menu_item(text, ic, on_click=lambda w=what: self.be.power(w)), False, False, 0)
        box.show_all()
        pop.add(box)
        return pop

    def restyle(self):
        self.provider.load_from_data(css(self.big, self.contrast).encode())

    # ---- background and animation
    def draw_bg(self, _w, cr):
        Gdk.cairo_set_source_pixbuf(cr, self.bg_lock, 0, 0)
        cr.paint()
        if self.t > 0:
            Gdk.cairo_set_source_pixbuf(cr, self.bg_sign, 0, 0)
            cr.paint_with_alpha(self.t)
        cr.set_source_rgba(4 / 255, 7 / 255, 9 / 255, 0.28 + 0.17 * self.t)
        cr.paint()
        return False

    def set_t(self, t):
        self.t = t
        e = 1 - (1 - t) ** 3          # ease out
        self.lock_o.set_opacity(max(0.0, 1 - e * 1.4))
        self.who.set_opacity(min(1.0, max(0.0, (e - 0.15) / 0.85)))
        self.users.set_opacity(self.who.get_opacity())
        self.area.queue_draw()

    def animate(self, to):
        start, t0 = self.t, time.monotonic()
        if self.anim:
            GLib.source_remove(self.anim)

        def step():
            k = min(1.0, (time.monotonic() - t0) * 1000 / ANIM_MS)
            self.set_t(start + (to - start) * k)
            if k >= 1:
                self.anim = None
                return False
            return True
        self.anim = GLib.timeout_add(16, step)

    def after_show(self):
        ready = os.environ.get("PINE_GREETER_READY")      # tells pine-greeter-session the window is up
        if ready:
            try:
                open(ready, "w").close()
            except OSError:
                pass
        self.set_t(0.0)
        self.who.set_sensitive(False)
        self.present()
        win = self.get_window()
        if win:
            win.set_cursor(Gdk.Cursor.new_from_name(win.get_display(), "default"))

    # ---- states
    def signed_in_view(self):
        return self.t >= 0.5

    def open_signin(self, first=None):
        if self.signed_in_view():
            return
        self.who.set_sensitive(True)
        self.animate(1.0)
        self.entry.grab_focus()
        if first:
            self.entry.set_text(self.entry.get_text() + first)
            self.entry.set_position(-1)
        self.poke()

    def back_to_lock(self):
        if not self.signed_in_view() or self.signing:
            return
        for b in self.tray_btns:
            b.set_active(False)
        self.entry.set_text("")
        self.err_lb.hide()
        self.who.set_sensitive(False)
        self.animate(0.0)

    def poke(self):
        self.idle = time.monotonic()

    def tick(self):
        now = GLib.DateTime.new_now_local()
        self.time.set_text(now.format("%H:%M"))
        hu = os.environ.get("LANG", "").startswith("hu")
        self.date.set_text(" ".join(now.format("%B %e., %A" if hu else "%A, %B %e").split()))
        if self.signed_in_view() and not self.signing and self.idle and time.monotonic() - self.idle > IDLE_SECONDS:
            self.back_to_lock()
        return True

    def show_caps(self):
        on = self.keymap.get_caps_lock_state()
        self.caps.set_visible(bool(on))

    # ---- people and signing in
    def choose(self, person):
        if self.signing:
            return
        self.person = person
        for n, b in self.user_btns.items():
            ctx = b.get_style_context()
            (ctx.add_class if n == person.name else ctx.remove_class)("sel")
        for c in self.avatar.get_children():
            self.avatar.remove(c)
        ctx = self.avatar.get_style_context()
        (ctx.add_class if person.guest else ctx.remove_class)("guest")
        # the same color as the person's small picture in the list (green, blue, green...)
        i = self.people.index(person) if person in self.people else 0
        (ctx.add_class if (i % 2 and not person.guest) else ctx.remove_class)("b")
        pic = self.picture(person, 128)
        if pic:
            self.avatar.pack_start(pic, True, True, 0)
        elif person.guest:
            self.avatar.pack_start(icon("avatar-default-symbolic", 52), True, True, 0)
        else:
            lb = Gtk.Label(label=(person.display[:1] or "?").upper(), hexpand=True)
            self.avatar.pack_start(lb, True, True, 0)
        self.avatar.show_all()
        self.name_lb.set_text(person.display)
        self.entry.set_text("")
        self.entry.set_placeholder_text(_("No password needed: press Enter") if person.guest else _("Password"))
        self.err_lb.hide()
        self.pending = None
        self.prompt_secret = False
        self.auth_ok = False
        self.be.authenticate(person)
        self.show_caps()

    def submit(self):
        if self.signing or not self.person:
            return
        text = self.entry.get_text()
        if not text and not (self.person.guest or self.auth_ok):
            self.entry.grab_focus()
            return
        self.signing = True
        self.field.set_sensitive(False)
        self.err_lb.hide()
        if self.auth_ok:                  # guest / no password: LightDM already said yes
            self.on_done(True)
        elif self.prompt_secret:
            self.prompt_secret = False
            self.be.respond(text)
        else:
            self.pending = text       # answered as soon as LightDM asks

    def on_prompt(self, secret, text):
        if self.pending is not None:
            p, self.pending = self.pending, None
            self.be.respond(p)
            return
        self.prompt_secret = True

    def on_message(self, text, error):
        self.err_lb.set_text(text)
        self.err_lb.show()

    def on_done(self, ok):
        if not self.signing:
            # an answer before Enter: yes without a password (guest) waits for Enter; a no is a
            # cancelled try (another person was chosen), not a wrong password
            self.auth_ok = ok
            return
        if ok:
            self.field.hide()
            self.msg.hide()
            self.welcome.show()
            self.spinner.start()
            GLib.timeout_add(300, lambda: (self.start_session(), False)[1])
            return
        self.signing = False
        self.field.set_sensitive(True)
        self.entry.set_text("")
        self.err_lb.set_text(_("The password is incorrect. Try again."))
        self.err_lb.show()
        self.shake()
        self.be.authenticate(self.person)      # ask again
        # the field was insensitive: focus it once it is awake again, or the next key is lost
        GLib.idle_add(lambda: (self.entry.grab_focus(), False)[1])

    def start_session(self):
        if not self.be.start(self.person):
            self.signing = False
            self.welcome.hide()
            self.field.show()
            self.msg.show()
            self.field.set_sensitive(True)
            self.err_lb.set_text(_("Could not start the session. Try again."))
            self.err_lb.show()
            self.be.authenticate(self.person)

    def shake(self):
        base = self.who.get_margin_start()
        steps = [-8, 8, -8, 8, -4, 4, 0]

        def step(i=[0]):
            if i[0] >= len(steps):
                self.who.set_margin_start(base)
                self.who.set_margin_end(self.sw - self.mg.x - self.mg.width)
                return False
            d = steps[i[0]]
            self.who.set_margin_start(base + max(0, d) * 2)
            self.who.set_margin_end(self.sw - self.mg.x - self.mg.width + max(0, -d) * 2)
            i[0] += 1
            return True
        GLib.timeout_add(42, step)

    # ---- input
    def on_key(self, _w, ev):
        self.poke()
        if not self.signed_in_view():
            ch = Gdk.keyval_to_unicode(ev.keyval)
            if ch and ch >= 32 and not (ev.state & (Gdk.ModifierType.CONTROL_MASK | Gdk.ModifierType.MOD1_MASK)):
                self.open_signin(chr(ch))
                return True
            if ev.keyval in (Gdk.KEY_Return, Gdk.KEY_KP_Enter, Gdk.KEY_space, Gdk.KEY_Up):
                self.open_signin()
                return True
            return True
        if ev.keyval == Gdk.KEY_Escape:
            self.back_to_lock()
            return True
        return False

    def on_click(self, _w, ev):
        self.poke()
        if not self.signed_in_view():
            self.open_signin()
        return False


def main():
    GLib.set_application_name("Pine OS")
    settings = Gtk.Settings.get_default()
    settings.set_property("gtk-theme-name", "Pine-Dark")
    settings.set_property("gtk-icon-theme-name", "Pine")
    settings.set_property("gtk-font-name", "Inter 11")
    settings.set_property("gtk-application-prefer-dark-theme", True)
    # the X server of the sign-in screen starts with a cross cursor; make it the arrow
    root = Gdk.get_default_root_window()
    root.set_cursor(Gdk.Cursor.new_from_name(root.get_display(), "default"))
    Greeter()
    Gtk.main()


if __name__ == "__main__":
    main()
