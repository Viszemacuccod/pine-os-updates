#!/usr/bin/python3
"""Calculator: standard calculator in Pine's look (same colors, buttons and header bar as Settings).
Keyboard works too: digits, + - * / . Enter (=), Backspace, Esc (C), Delete (CE), %.
Usage: pine-calculator           pine-calculator --selftest   (checks the arithmetic, no display)
"""
import ast
import operator
import os
import sys

OPS = {ast.Add: operator.add, ast.Sub: operator.sub, ast.Mult: operator.mul, ast.Div: operator.truediv,
       ast.Mod: operator.mod, ast.Pow: operator.pow}


def calc(expr):
    """Evaluate +, -, *, /, %, ** on numbers only (no names, no calls: safe on typed input)."""
    def ev(n):
        if isinstance(n, ast.Expression):
            return ev(n.body)
        if isinstance(n, ast.Constant) and type(n.value) in (int, float):
            return n.value
        if isinstance(n, ast.UnaryOp) and isinstance(n.op, (ast.USub, ast.UAdd)):
            return -ev(n.operand) if isinstance(n.op, ast.USub) else ev(n.operand)
        if isinstance(n, ast.BinOp) and type(n.op) in OPS:
            a, b = ev(n.left), ev(n.right)
            if isinstance(n.op, ast.Pow) and abs(b) > 1000:
                raise ValueError("exponent too large")
            return OPS[type(n.op)](a, b)
        raise ValueError("not a calculation")
    return ev(ast.parse(expr.strip(), mode="eval"))


def fmt(v):
    if isinstance(v, float) and v.is_integer() and abs(v) < 1e15:
        return str(int(v))
    return f"{v:.12g}" if isinstance(v, float) else str(v)


if "--selftest" in sys.argv:
    assert calc("2+3*4") == 14 and calc("(1+2)*3") == 9 and calc("-4+10/4") == -1.5 and calc("7%4") == 3
    assert fmt(calc("0.1+0.2")) == "0.3" and fmt(calc("6/3")) == "2"
    for bad in ("__import__('os')", "1/0", "2**100000", "abs(1)"):
        try:
            calc(bad)
        except (ValueError, ZeroDivisionError, SyntaxError):
            continue
        raise AssertionError(bad)
    print("calculator selftest ok")
    sys.exit(0)

_HERE = os.path.dirname(os.path.abspath(__file__))
for _p in ("/usr/lib/pine-settings", os.path.join(_HERE, "..", "pine-settings")):
    if os.path.isdir(_p):
        sys.path.insert(0, _p)

import gi  # noqa: E402
gi.require_version("Gtk", "4.0")
gi.require_version("Adw", "1")
from gi.repository import Adw, Gdk, Gio, Gtk  # noqa: E402

import look  # noqa: E402

try:
    from common import _
except Exception:  # pragma: no cover
    def _(t):
        return t

KEYS = [["%", "CE", "C", "⌫"], ["1/x", "x²", "√x", "÷"], ["7", "8", "9", "×"], ["4", "5", "6", "−"],
        ["1", "2", "3", "+"], ["±", "0", ".", "="]]
SHOW = {"÷": "/", "×": "*", "−": "-"}


class Window(Adw.ApplicationWindow):
    def __init__(self, app):
        super().__init__(application=app, title=_("Calculator"))
        self.set_default_size(340, 560)
        self.set_size_request(300, 480)
        look.apply()
        css = Gtk.CssProvider()
        css.load_from_string("""
.calc-expr { font-size: 0.95em; opacity: 0.65; }
.calc-value { font-size: 2.6em; font-weight: 600; font-variant-numeric: tabular-nums; }
.calc-key { font-size: 1.15em; min-height: 52px; }
.calc-num { background-color: color-mix(in srgb, currentColor 9%, transparent); font-weight: 600; }
.calc-op { background-color: color-mix(in srgb, currentColor 5%, transparent); }
""")
        Gtk.StyleContext.add_provider_for_display(Gdk.Display.get_default(), css, Gtk.STYLE_PROVIDER_PRIORITY_USER + 2)
        self.expr, self.value, self.done = "", "0", False

        box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=6, margin_start=12, margin_end=12,
                      margin_bottom=12)
        self.expr_l = Gtk.Label(xalign=1, ellipsize=1)
        self.expr_l.add_css_class("calc-expr")
        self.value_l = Gtk.Label(label="0", xalign=1, margin_bottom=8)
        self.value_l.add_css_class("calc-value")
        box.append(self.expr_l)
        box.append(self.value_l)
        grid = Gtk.Grid(column_spacing=4, row_spacing=4, column_homogeneous=True, row_homogeneous=True, vexpand=True)
        for r, row in enumerate(KEYS):
            for c, k in enumerate(row):
                b = Gtk.Button(label=k, focusable=False)   # Enter must mean "=", not "press the focused key"
                b.add_css_class("calc-key")
                b.add_css_class("suggested-action" if k == "=" else "calc-num" if k.isdigit() or k in ".±" else "calc-op")
                b.connect("clicked", lambda _b, k=k: self.press(k))
                grid.attach(b, c, r, 1, 1)
        box.append(grid)
        tv = Adw.ToolbarView()
        tv.add_top_bar(Adw.HeaderBar())
        tv.set_content(box)
        self.set_content(tv)
        keys = Gtk.EventControllerKey()
        keys.set_propagation_phase(Gtk.PropagationPhase.CAPTURE)
        keys.connect("key-pressed", self._key)
        self.add_controller(keys)

    def _key(self, _c, keyval, _code, _st):
        ch = chr(keyval) if 32 <= keyval < 127 else ""
        special = {Gdk.KEY_Return: "=", Gdk.KEY_KP_Enter: "=", Gdk.KEY_BackSpace: "⌫", Gdk.KEY_Escape: "C",
                   Gdk.KEY_Delete: "CE"}
        k = special.get(keyval) or {"/": "÷", "*": "×", "-": "−", "=": "="}.get(ch) or (ch if ch in "0123456789.+%" else "")
        if k:
            self.press(k)
            return True
        return False

    def _eval(self):
        try:
            return calc(self.expr.replace("÷", "/").replace("×", "*").replace("−", "-") or self.value)
        except (ValueError, ZeroDivisionError, SyntaxError, OverflowError):
            return None

    def _show(self):
        self.expr_l.set_label(self.expr)
        self.value_l.set_label(self.value)

    def press(self, k):
        if k.isdigit() or k == ".":
            if self.done:
                self.expr, self.done = "", False
            self.expr += k
            self.value = self._last_number() or "0"
        elif k in ("+", "−", "×", "÷"):
            if self.done:
                self.expr, self.done = self.value, False
            if self.expr and self.expr[-1] in "+−×÷":
                self.expr = self.expr[:-1]
            self.expr += k if self.expr else "0" + k
        elif k == "=":
            r = self._eval()
            self.expr_l.set_label(self.expr + " =")
            self.value = _("Cannot divide by zero") if r is None else fmt(r)
            self.expr, self.done = ("" if r is None else self.value), r is not None
            self.value_l.set_label(self.value)
            return
        elif k == "C":
            self.expr, self.value, self.done = "", "0", False
        elif k == "CE":
            self.expr = self.expr[:len(self.expr) - len(self._last_number())]
            self.value = "0"
        elif k == "⌫":
            self.expr = self.expr[:-1]
            self.value = self._last_number() or "0"
        elif k in ("±", "1/x", "x²", "√x", "%"):
            r = self._eval()
            if r is not None:
                try:
                    r = {"±": -r, "1/x": 1 / r, "x²": r * r, "√x": r ** 0.5, "%": r / 100}[k]
                    self.expr = self.value = fmt(r)
                    self.done = True
                except (ZeroDivisionError, OverflowError):
                    self.value = _("Cannot divide by zero")
        self._show()

    def _last_number(self):
        n = ""
        for ch in reversed(self.expr):
            if ch.isdigit() or ch == ".":
                n = ch + n
            else:
                break
        return n


class App(Adw.Application):
    def __init__(self):
        super().__init__(application_id="org.pineos.Calculator", flags=Gio.ApplicationFlags.FLAGS_NONE)

    def do_activate(self):
        win = self.props.active_window or Window(self)
        win.present()


if __name__ == "__main__":
    sys.exit(App().run(sys.argv))
