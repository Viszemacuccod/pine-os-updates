#!/usr/bin/python3
"""Image Viewer: look at pictures in Pine's look (same colors, header bar and buttons as Settings).

Usage: pine-imageviewer [picture or folder ...]
Left / Right (or the arrows in the header) go to the next picture in the folder; + / - / 0 (fit) /
1 (100 %) zoom, Ctrl + mouse wheel too; R rotates (view only, the file is not changed); F11 full
screen; Delete moves the picture to the Recycle Bin; Ctrl+C copies it; the (i) button shows details.
"""
import os
import re
import subprocess
import sys

_HERE = os.path.dirname(os.path.abspath(__file__))
for _p in ("/usr/lib/pine-settings", os.path.join(_HERE, "..", "pine-settings")):
    if os.path.isdir(_p):
        sys.path.insert(0, _p)

import gi  # noqa: E402
gi.require_version("Gtk", "4.0")
gi.require_version("Adw", "1")
gi.require_version("GdkPixbuf", "2.0")
from gi.repository import Adw, Gdk, GdkPixbuf, Gio, GLib, Gtk  # noqa: E402

import look  # noqa: E402

try:
    from common import _
except Exception:  # pragma: no cover
    def _(t):
        return t

APP_ID = "org.pineos.ImageViewer"
EXTS = (".png", ".jpg", ".jpeg", ".gif", ".webp", ".bmp", ".tif", ".tiff", ".svg", ".ico", ".avif", ".jxl")
ZOOMS = [0.1, 0.25, 0.5, 0.75, 1.0, 1.5, 2.0, 3.0, 4.0, 8.0]


def natural(s):
    return [int(t) if t.isdigit() else t for t in re.split(r"(\d+)", s.casefold())]


def pictures_in(folder):
    try:
        names = [n for n in os.listdir(folder) if n.lower().endswith(EXTS) and not n.startswith(".")]
    except OSError:
        return []
    return [os.path.join(folder, n) for n in sorted(names, key=natural)]


def fmt_size(n):
    for unit in ("bytes", "KB", "MB", "GB"):
        if n < 1024 or unit == "GB":
            return f"{n:.0f} {unit}" if unit in ("bytes", "KB") or n >= 100 else f"{n:.1f} {unit}"
        n /= 1024


class Window(Adw.ApplicationWindow):
    def __init__(self, app):
        super().__init__(application=app, title=_("Image Viewer"))
        self.set_default_size(1000, 720)
        self.set_size_request(360, 360)
        look.apply()
        self.files, self.index, self.path = [], -1, None
        self.pixbuf, self.angle, self.zoom, self.fit = None, 0, 1.0, True

        self.toasts = Adw.ToastOverlay()
        self.split = Adw.OverlaySplitView(sidebar_position=Gtk.PackType.END, show_sidebar=False,
                                          min_sidebar_width=260, max_sidebar_width=320)
        self.toasts.set_child(self.split)

        # the picture: "fit" shows it whole; "zoom" scrolls and drags
        self.fit_pic = Gtk.Picture(content_fit=Gtk.ContentFit.CONTAIN, can_shrink=True, hexpand=True, vexpand=True)
        self.zoom_pic = Gtk.Picture(content_fit=Gtk.ContentFit.FILL, can_shrink=False,
                                    halign=Gtk.Align.CENTER, valign=Gtk.Align.CENTER)
        self.scroll = Gtk.ScrolledWindow(child=self.zoom_pic)
        self.stack = Gtk.Stack()
        self.stack.add_named(self.fit_pic, "fit")
        self.stack.add_named(self.scroll, "zoom")
        self.empty = Adw.StatusPage(icon_name="image-x-generic-symbolic", title=_("No picture open"),
                                    description=_("Open a picture, or drop one here."))
        b = Gtk.Button(label=_("Open picture"), halign=Gtk.Align.CENTER)
        b.add_css_class("suggested-action")
        b.add_css_class("pill")
        b.connect("clicked", lambda _b: self.open_dialog())
        self.empty.set_child(b)
        self.pages = Gtk.Stack()
        self.pages.add_named(self.empty, "empty")
        self.pages.add_named(self.stack, "pic")

        wheel = Gtk.EventControllerScroll(flags=Gtk.EventControllerScrollFlags.VERTICAL)
        wheel.connect("scroll", self._wheel)
        self.pages.add_controller(wheel)
        drag = Gtk.GestureDrag()
        drag.connect("drag-begin", lambda _g, *_a: setattr(self, "_pan", (self.scroll.get_hadjustment().get_value(),
                                                                          self.scroll.get_vadjustment().get_value())))
        drag.connect("drag-update", self._pan_to)
        self.scroll.add_controller(drag)
        click = Gtk.GestureClick()
        click.connect("pressed", lambda _g, n, *_a: n == 2 and self.toggle_fit())
        self.pages.add_controller(click)
        drop = Gtk.DropTarget.new(Gio.File, Gdk.DragAction.COPY)
        drop.connect("drop", lambda _t, f, *_a: (self.open_path(f.get_path()), True)[1])
        self.pages.add_controller(drop)

        # header bar
        self.title = Adw.WindowTitle(title=_("Image Viewer"), subtitle="")
        header = Adw.HeaderBar()
        header.set_title_widget(self.title)
        for icon, cb, tip in (("go-previous-symbolic", lambda: self.step(-1), _("Previous (Left)")),
                              ("go-next-symbolic", lambda: self.step(1), _("Next (Right)"))):
            btn = Gtk.Button(icon_name=icon, tooltip_text=tip)
            btn.add_css_class("flat")
            btn.connect("clicked", lambda _b, cb=cb: cb())
            header.pack_start(btn)
        info = Gtk.ToggleButton(icon_name="dialog-information-symbolic", tooltip_text=_("Details"))
        info.add_css_class("flat")
        info.connect("toggled", lambda b: self.split.set_show_sidebar(b.get_active()))
        header.pack_end(info)
        menu = Gio.Menu()
        sec = Gio.Menu()
        sec.append(_("Open picture…"), "win.open")
        sec.append(_("Copy"), "win.copy")
        sec.append(_("Show in Files"), "win.showfile")
        menu.append_section(None, sec)
        sec = Gio.Menu()
        sec.append(_("Rotate left"), "win.rotl")
        sec.append(_("Rotate right"), "win.rotr")
        menu.append_section(None, sec)
        sec = Gio.Menu()
        sec.append(_("Move to Recycle Bin"), "win.trash")
        menu.append_section(None, sec)
        header.pack_end(Gtk.MenuButton(icon_name="open-menu-symbolic", menu_model=menu))

        # bottom bar: zoom
        bar = Gtk.Box(spacing=4, halign=Gtk.Align.CENTER, margin_top=4, margin_bottom=4)
        z = Gtk.Button(label="−", tooltip_text=_("Zoom out (-)"))      # text: the icon theme's zoom icons are boxes
        z.add_css_class("flat")
        z.connect("clicked", lambda _b: self.zoom_by(-1))
        bar.append(z)
        self.zoom_btn = Gtk.Button(label=_("Fit"), tooltip_text=_("Fit / 100 %"))
        self.zoom_btn.add_css_class("flat")
        self.zoom_btn.set_size_request(80, -1)
        self.zoom_btn.connect("clicked", lambda _b: self.toggle_fit())
        bar.append(self.zoom_btn)
        z = Gtk.Button(label="+", tooltip_text=_("Zoom in (+)"))
        z.add_css_class("flat")
        z.connect("clicked", lambda _b: self.zoom_by(1))
        bar.append(z)

        # details sidebar
        self.det = Adw.PreferencesGroup(title=_("Details"))
        self.det_rows = {}
        for key, label in (("name", _("Name")), ("type", _("Type")), ("size", _("Size")), ("dim", _("Dimensions")),
                           ("date", _("Modified")), ("dir", _("Folder"))):
            r = Adw.ActionRow(title=label, subtitle_selectable=True)
            r.add_css_class("property")
            self.det_rows[key] = r
            self.det.add(r)
        side = Adw.ToolbarView()
        side.add_top_bar(Adw.HeaderBar(show_title=False))
        pp = Adw.PreferencesPage()
        pp.add(self.det)
        side.set_content(pp)
        self.split.set_sidebar(side)

        tv = Adw.ToolbarView()
        tv.add_top_bar(header)
        tv.set_content(self.pages)
        tv.add_bottom_bar(bar)
        self.tv = tv
        self.split.set_content(tv)
        self.set_content(self.toasts)
        self._actions()
        keys = Gtk.EventControllerKey()
        keys.connect("key-pressed", self._key)
        self.add_controller(keys)

    # ---- actions
    def _actions(self):
        for name, cb in (("open", self.open_dialog), ("copy", self.copy), ("showfile", self.show_file),
                         ("rotl", lambda: self.rotate(-90)), ("rotr", lambda: self.rotate(90)),
                         ("trash", self.trash)):
            a = Gio.SimpleAction.new(name, None)
            a.connect("activate", lambda _a, _p, cb=cb: cb())
            self.add_action(a)

    def _key(self, _c, keyval, _code, state):
        ctrl = bool(state & Gdk.ModifierType.CONTROL_MASK)
        table = {Gdk.KEY_Left: lambda: self.step(-1), Gdk.KEY_Right: lambda: self.step(1),
                 Gdk.KEY_plus: lambda: self.zoom_by(1), Gdk.KEY_equal: lambda: self.zoom_by(1),
                 Gdk.KEY_KP_Add: lambda: self.zoom_by(1), Gdk.KEY_minus: lambda: self.zoom_by(-1),
                 Gdk.KEY_KP_Subtract: lambda: self.zoom_by(-1), Gdk.KEY_0: self.set_fit,
                 Gdk.KEY_1: lambda: self.set_zoom(1.0), Gdk.KEY_r: lambda: self.rotate(90),
                 Gdk.KEY_Delete: self.trash, Gdk.KEY_F11: self.toggle_fullscreen,
                 Gdk.KEY_Escape: lambda: self.unfullscreen(), Gdk.KEY_Home: lambda: self.go_to(0),
                 Gdk.KEY_End: lambda: self.go_to(len(self.files) - 1)}
        if ctrl and keyval == Gdk.KEY_c:
            self.copy()
            return True
        if ctrl and keyval == Gdk.KEY_o:
            self.open_dialog()
            return True
        if keyval in table and not ctrl:
            table[keyval]()
            return True
        return False

    def toggle_fullscreen(self):
        if self.is_fullscreen():
            self.unfullscreen()
            self.tv.set_reveal_top_bars(True)
            self.tv.set_reveal_bottom_bars(True)
        else:
            self.fullscreen()
            self.tv.set_reveal_top_bars(False)
            self.tv.set_reveal_bottom_bars(False)

    def open_dialog(self):
        d = Gtk.FileDialog(title=_("Open picture"))
        f = Gtk.FileFilter(name=_("Pictures"))
        f.add_mime_type("image/*")
        d.set_default_filter(f)
        d.open(self, None, lambda dlg, res: self._opened(dlg, res))

    def _opened(self, dlg, res):
        try:
            gf = dlg.open_finish(res)
        except GLib.Error:
            return
        self.open_path(gf.get_path())

    # ---- showing a picture
    def open_path(self, path):
        if path and os.path.isdir(path):
            files = pictures_in(path)
            if not files:
                self.toast(_("No pictures in this folder"))
                return
            path = files[0]
        if not path or not os.path.isfile(path):
            return
        folder = os.path.dirname(os.path.abspath(path))
        self.files = pictures_in(folder)
        path = os.path.abspath(path)
        self.index = self.files.index(path) if path in self.files else -1
        if self.index < 0:
            self.files.append(path)
            self.index = len(self.files) - 1
        self.load(path)

    def load(self, path):
        try:
            pb = GdkPixbuf.Pixbuf.new_from_file(path)
            pb = pb.apply_embedded_orientation() or pb
        except GLib.Error as e:
            self.toast(e.message)
            return
        self.path, self.pixbuf, self.angle = path, pb, 0
        self.fit = True
        self.pages.set_visible_child_name("pic")
        self.pages.set_focusable(True)
        self.pages.grab_focus()                 # no focus ring on the first header button
        self.render()
        self.fill_info()

    def render(self):
        pb = self.pixbuf
        if self.angle:
            pb = pb.rotate_simple({90: GdkPixbuf.PixbufRotation.CLOCKWISE, 180: GdkPixbuf.PixbufRotation.UPSIDEDOWN,
                                   270: GdkPixbuf.PixbufRotation.COUNTERCLOCKWISE}[self.angle % 360])
        tex = Gdk.Texture.new_for_pixbuf(pb)
        self.tex, self.size = tex, (pb.get_width(), pb.get_height())
        self.fit_pic.set_paintable(tex)
        self.zoom_pic.set_paintable(tex)
        self._apply_zoom()

    def _apply_zoom(self):
        if self.fit:
            self.stack.set_visible_child_name("fit")
            self.zoom_btn.set_label(_("Fit"))
        else:
            w, h = self.size
            self.zoom_pic.set_size_request(max(1, int(w * self.zoom)), max(1, int(h * self.zoom)))
            self.stack.set_visible_child_name("zoom")
            GLib.idle_add(self._center)
            self.zoom_btn.set_label(f"{round(self.zoom * 100)} %")

    def _center(self):
        for adj in (self.scroll.get_hadjustment(), self.scroll.get_vadjustment()):
            adj.set_value(max(0, (adj.get_upper() - adj.get_page_size()) / 2))
        return False

    def fill_info(self):
        name = os.path.basename(self.path)
        self.title.set_title(name)
        self.title.set_subtitle(f"{self.index + 1} / {len(self.files)}" if len(self.files) > 1 else "")
        self.set_title(f"{name} – {_('Image Viewer')}")
        try:
            st = os.stat(self.path)
            size, when = fmt_size(st.st_size), GLib.DateTime.new_from_unix_local(int(st.st_mtime)).format("%Y-%m-%d %H:%M")
        except OSError:
            size = when = ""
        ctype = Gio.content_type_get_description(Gio.content_type_guess(self.path, None)[0]) or ""
        vals = {"name": name, "type": ctype, "size": size, "dim": f"{self.pixbuf.get_width()} × {self.pixbuf.get_height()}",
                "date": when, "dir": os.path.dirname(self.path)}
        for k, r in self.det_rows.items():
            r.set_subtitle(GLib.markup_escape_text(vals[k]))

    # ---- navigation and zoom
    def step(self, d):
        if len(self.files) > 1:
            self.go_to((self.index + d) % len(self.files))

    def go_to(self, i):
        if 0 <= i < len(self.files) and self.files:
            self.index = i
            self.load(self.files[i])

    def set_fit(self):
        self.fit = True
        self._apply_zoom()

    def set_zoom(self, z):
        if not self.pixbuf:
            return
        self.fit, self.zoom = False, max(0.05, min(z, 16.0))
        self._apply_zoom()

    def current_zoom(self):
        if not self.fit:
            return self.zoom
        w, h = self.size
        alloc_w, alloc_h = max(1, self.fit_pic.get_width()), max(1, self.fit_pic.get_height())
        return min(alloc_w / w, alloc_h / h, 1.0) if w and h else 1.0

    def zoom_by(self, d):
        if not self.pixbuf:
            return
        z = self.current_zoom()
        nxt = [v for v in ZOOMS if v > z + 1e-3] if d > 0 else [v for v in reversed(ZOOMS) if v < z - 1e-3]
        self.set_zoom(nxt[0] if nxt else z)

    def toggle_fit(self):
        if self.fit:
            self.set_zoom(1.0)
        else:
            self.set_fit()

    def _wheel(self, ctrl, _dx, dy):
        if ctrl.get_current_event_state() & Gdk.ModifierType.CONTROL_MASK:
            self.zoom_by(-1 if dy > 0 else 1)
            return True
        return False

    def _pan_to(self, _g, dx, dy):
        h, v = self.scroll.get_hadjustment(), self.scroll.get_vadjustment()
        h.set_value(self._pan[0] - dx)
        v.set_value(self._pan[1] - dy)

    def rotate(self, deg):
        if self.pixbuf:
            self.angle = (self.angle + deg) % 360
            self.render()

    # ---- file things
    def toast(self, text):
        self.toasts.add_toast(Adw.Toast.new(text))

    def copy(self):
        if self.pixbuf:
            self.get_clipboard().set_texture(self.tex)
            self.toast(_("Copied"))

    def show_file(self):
        if self.path:
            subprocess.Popen(["pine-files", os.path.dirname(self.path)])

    def trash(self):
        if not self.path:
            return
        try:
            Gio.File.new_for_path(self.path).trash(None)
        except GLib.Error as e:
            self.toast(e.message)
            return
        self.toast(_("Moved to the Recycle Bin"))
        self.files.pop(self.index)
        if self.files:
            self.go_to(min(self.index, len(self.files) - 1))
        else:
            self.path = self.pixbuf = None
            self.pages.set_visible_child_name("empty")
            self.title.set_title(_("Image Viewer"))
            self.title.set_subtitle("")


class App(Adw.Application):
    def __init__(self):
        super().__init__(application_id=APP_ID, flags=Gio.ApplicationFlags.HANDLES_COMMAND_LINE)
        self.connect("command-line", self._cmd)

    def _cmd(self, _app, cmdline):
        args = [a for a in cmdline.get_arguments()[1:] if not a.startswith("-")]
        win = self.props.active_window or Window(self)
        if args:
            win.open_path(cmdline.create_file_for_arg(args[0]).get_path())
        win.present()
        return 0


if __name__ == "__main__":
    sys.exit(App().run(sys.argv))
