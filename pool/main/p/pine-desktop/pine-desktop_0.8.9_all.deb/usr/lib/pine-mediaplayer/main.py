#!/usr/bin/python3
"""Media Player: video and music in Pine's look (Settings colors, header bar and buttons).

Usage: pine-mediaplayer [file ...]
Space play / pause, Left / Right jump 10 s, Up / Down volume, N / P next / previous, F or F11 full
screen, M mute. Double-click the picture for full screen. The list on the right is the playlist
(the (list) button in the header); drop files on the window to add them.
Plays through GTK's GStreamer backend (libgtk-4-media-gstreamer).
"""
import os
import sys

_HERE = os.path.dirname(os.path.abspath(__file__))
for _p in ("/usr/lib/pine-settings", os.path.join(_HERE, "..", "pine-settings")):
    if os.path.isdir(_p):
        sys.path.insert(0, _p)

import gi  # noqa: E402
gi.require_version("Gtk", "4.0")
gi.require_version("Adw", "1")
from gi.repository import Adw, Gdk, Gio, GLib, Gtk  # noqa: E402

import look  # noqa: E402

try:
    from common import _
except Exception:  # pragma: no cover
    def _(t):
        return t

APP_ID = "org.pineos.MediaPlayer"


def clock(us):
    s = max(0, int(us // 1_000_000))
    h, r = divmod(s, 3600)
    return f"{h}:{r // 60:02d}:{r % 60:02d}" if h else f"{r // 60}:{r % 60:02d}"


def flat(icon, tip, cb):
    b = Gtk.Button(icon_name=icon, tooltip_text=tip)
    b.add_css_class("flat")
    b.connect("clicked", lambda _b: cb())
    return b


class Window(Adw.ApplicationWindow):
    def __init__(self, app):
        super().__init__(application=app, title=_("Media Player"))
        self.set_default_size(980, 640)
        self.set_size_request(360, 320)
        look.apply()
        self.playlist, self.index, self.seeking = [], -1, False
        self.media = Gtk.MediaFile.new()      # the GStreamer backend (the class itself is abstract)
        self.media.connect("notify::playing", lambda *_a: self._state())
        self.media.connect("notify::timestamp", lambda *_a: self._tick())
        self.media.connect("notify::prepared", lambda *_a: self._tick())
        self.media.connect("notify::ended", lambda m, _p: m.get_ended() and self.step(1, auto=True))
        self.media.connect("notify::error", lambda m, _p: m.get_error() and self.toast(m.get_error().message))

        self.toasts = Adw.ToastOverlay()
        self.split = Adw.OverlaySplitView(sidebar_position=Gtk.PackType.END, show_sidebar=False,
                                          min_sidebar_width=260, max_sidebar_width=340)
        self.toasts.set_child(self.split)

        # picture (black, like a screen) with an empty state
        self.pic = Gtk.Picture(content_fit=Gtk.ContentFit.CONTAIN, can_shrink=True, hexpand=True, vexpand=True)
        self.pic.set_paintable(self.media)
        screen = Gtk.Box()
        screen.add_css_class("card")
        screen.set_overflow(Gtk.Overflow.HIDDEN)
        screen.append(self.pic)
        css = Gtk.CssProvider()
        css.load_from_string("picture { background: #000; } .mp-time { font-variant-numeric: tabular-nums; }")
        Gtk.StyleContext.add_provider_for_display(Gdk.Display.get_default(), css, Gtk.STYLE_PROVIDER_PRIORITY_USER + 2)
        self.empty = Adw.StatusPage(icon_name="multimedia-player-symbolic", title=_("Nothing is playing"),
                                    description=_("Open a video or a song, or drop files here."))
        b = Gtk.Button(label=_("Open files"), halign=Gtk.Align.CENTER)
        b.add_css_class("suggested-action")
        b.add_css_class("pill")
        b.connect("clicked", lambda _b: self.open_dialog())
        self.empty.set_child(b)
        self.pages = Gtk.Stack()
        self.pages.add_named(self.empty, "empty")
        self.pages.add_named(screen, "screen")
        self.music = Adw.StatusPage(icon_name="audio-x-generic-symbolic", title="")   # shown for songs
        self.pages.add_named(self.music, "music")
        click = Gtk.GestureClick()
        click.connect("pressed", lambda _g, n, *_a: self.toggle_fullscreen() if n == 2 else self.toggle_play() if n == 1 else None)
        self.pic.add_controller(click)
        drop = Gtk.DropTarget.new(Gio.File, Gdk.DragAction.COPY)
        drop.connect("drop", lambda _t, f, *_a: (self.add_files([f.get_path()]), True)[1])
        self.pages.add_controller(drop)

        # controls (bottom bar)
        self.play_btn = flat("media-playback-start-symbolic", _("Play (Space)"), self.toggle_play)
        self.scale = Gtk.Scale.new_with_range(Gtk.Orientation.HORIZONTAL, 0, 1, 1)
        self.scale.set_hexpand(True)
        self.scale.set_draw_value(False)
        self.scale.connect("change-value", self._seek)
        self.t_cur, self.t_len = Gtk.Label(label="0:00"), Gtk.Label(label="0:00")
        for t in (self.t_cur, self.t_len):
            t.add_css_class("mp-time")
            t.add_css_class("dim-label")
        self.vol = Gtk.ScaleButton(icons=["audio-volume-muted-symbolic", "audio-volume-high-symbolic",
                                          "audio-volume-low-symbolic", "audio-volume-medium-symbolic"])
        self.vol.set_adjustment(Gtk.Adjustment(value=1.0, lower=0, upper=1.0, step_increment=0.05, page_increment=0.1))
        self.vol.set_value(1.0)
        self.vol.connect("value-changed", lambda _b, v: self.media.set_volume(v))
        bar = Gtk.Box(spacing=4, margin_start=8, margin_end=8, margin_top=4, margin_bottom=4)
        for w in (flat("media-skip-backward-symbolic", _("Previous (P)"), lambda: self.step(-1)), self.play_btn,
                  flat("media-skip-forward-symbolic", _("Next (N)"), lambda: self.step(1)), self.t_cur, self.scale,
                  self.t_len, self.vol, flat("view-fullscreen-symbolic", _("Full screen (F)"), self.toggle_fullscreen)):
            bar.append(w)

        # header
        self.wtitle = Adw.WindowTitle(title=_("Media Player"), subtitle="")
        header = Adw.HeaderBar()
        header.set_title_widget(self.wtitle)
        header.pack_start(flat("document-open-symbolic", _("Open files (Ctrl+O)"), self.open_dialog))
        tog = Gtk.ToggleButton(icon_name="view-list-symbolic", tooltip_text=_("Playlist"))
        tog.add_css_class("flat")
        tog.connect("toggled", lambda b: self.split.set_show_sidebar(b.get_active()))
        header.pack_end(tog)

        # playlist (a card list like the groups in Settings)
        self.list = Gtk.ListBox()
        self.list.add_css_class("boxed-list")
        self.list.set_selection_mode(Gtk.SelectionMode.SINGLE)
        self.list.connect("row-activated", lambda _l, r: self.play_index(r.get_index()))
        sc = Gtk.ScrolledWindow(child=self.list, vexpand=True, margin_start=12, margin_end=12, margin_top=6, margin_bottom=12)
        side = Adw.ToolbarView()
        side.add_top_bar(Adw.HeaderBar(show_title=False))
        side.set_content(sc)
        self.split.set_sidebar(side)

        self.tv = Adw.ToolbarView()
        self.tv.add_top_bar(header)
        self.tv.set_content(self.pages)
        self.tv.add_bottom_bar(bar)
        self.split.set_content(self.tv)
        self.set_content(self.toasts)
        keys = Gtk.EventControllerKey()
        keys.connect("key-pressed", self._key)
        self.add_controller(keys)
        self.connect("close-request", lambda *_a: (self.media.set_playing(False), False)[1])

    # ---- keys and fullscreen
    def _key(self, _c, keyval, _code, state):
        ctrl = bool(state & Gdk.ModifierType.CONTROL_MASK)
        if ctrl and keyval == Gdk.KEY_o:
            self.open_dialog()
            return True
        table = {Gdk.KEY_space: self.toggle_play, Gdk.KEY_Left: lambda: self.jump(-10), Gdk.KEY_Right: lambda: self.jump(10),
                 Gdk.KEY_Up: lambda: self.vol.set_value(min(1, self.vol.get_value() + 0.05)),
                 Gdk.KEY_Down: lambda: self.vol.set_value(max(0, self.vol.get_value() - 0.05)),
                 Gdk.KEY_n: lambda: self.step(1), Gdk.KEY_p: lambda: self.step(-1), Gdk.KEY_f: self.toggle_fullscreen,
                 Gdk.KEY_F11: self.toggle_fullscreen, Gdk.KEY_m: lambda: self.media.set_muted(not self.media.get_muted()),
                 Gdk.KEY_Escape: self.leave_fullscreen}
        if keyval in table and not ctrl:
            table[keyval]()
            return True
        return False

    def toggle_fullscreen(self):
        if self.is_fullscreen():
            self.leave_fullscreen()
        else:
            self.fullscreen()
            self.tv.set_reveal_top_bars(False)
            self.tv.set_reveal_bottom_bars(False)

    def leave_fullscreen(self):
        if self.is_fullscreen():
            self.unfullscreen()
            self.tv.set_reveal_top_bars(True)
            self.tv.set_reveal_bottom_bars(True)

    # ---- playlist
    def open_dialog(self):
        d = Gtk.FileDialog(title=_("Open files"))
        f = Gtk.FileFilter(name=_("Video and audio"))
        f.add_mime_type("video/*")
        f.add_mime_type("audio/*")
        d.set_default_filter(f)
        d.open_multiple(self, None, self._opened)

    def _opened(self, dlg, res):
        try:
            files = dlg.open_multiple_finish(res)
        except GLib.Error:
            return
        self.add_files([files.get_item(i).get_path() for i in range(files.get_n_items())], play=True)

    def add_files(self, paths, play=False):
        first = len(self.playlist)
        for p in paths:
            if p and os.path.isfile(p):
                self.playlist.append(p)
                row = Adw.ActionRow(title=GLib.markup_escape_text(os.path.splitext(os.path.basename(p))[0]),
                                    subtitle=GLib.markup_escape_text(os.path.dirname(p)), activatable=True)
                row.set_subtitle_lines(1)
                rm = Gtk.Button(icon_name="list-remove-symbolic", valign=Gtk.Align.CENTER, tooltip_text=_("Remove"))
                rm.add_css_class("flat")
                rm.connect("clicked", lambda _b, row=row: self.remove(row.get_index()))
                row.add_suffix(rm)
                self.list.append(row)
        if play and len(self.playlist) > first:
            self.play_index(first)
        elif self.index < 0 and self.playlist:
            self.play_index(0)

    def remove(self, i):
        if not 0 <= i < len(self.playlist):
            return
        self.playlist.pop(i)
        self.list.remove(self.list.get_row_at_index(i))
        if i == self.index:
            self.media.clear()
            self.index = -1
            if self.playlist:
                self.play_index(min(i, len(self.playlist) - 1))
            else:
                self.pages.set_visible_child_name("empty")
                self.wtitle.set_title(_("Media Player"))
                self.wtitle.set_subtitle("")
        elif i < self.index:
            self.index -= 1

    def play_index(self, i):
        if not 0 <= i < len(self.playlist):
            return
        self.index = i
        path = self.playlist[i]
        self.media.clear()
        self.media.set_file(Gio.File.new_for_path(path))
        self.media.set_playing(True)
        self.list.select_row(self.list.get_row_at_index(i))
        self.wtitle.set_title(os.path.splitext(os.path.basename(path))[0])
        self.wtitle.set_subtitle(f"{i + 1} / {len(self.playlist)}" if len(self.playlist) > 1 else "")
        self.music.set_title(GLib.markup_escape_text(os.path.splitext(os.path.basename(path))[0]))
        self.pages.set_visible_child_name("screen")

    def step(self, d, auto=False):
        if not self.playlist:
            return
        j = self.index + d
        if auto and j >= len(self.playlist):
            self.media.set_playing(False)           # the list is finished
            return
        self.play_index(j % len(self.playlist))

    # ---- playing
    def toggle_play(self):
        if self.index < 0:
            self.open_dialog()
        elif self.media.get_ended():
            self.media.seek(0)
            self.media.set_playing(True)
        else:
            self.media.set_playing(not self.media.get_playing())

    def jump(self, seconds):
        if self.media.is_prepared():
            self.media.seek(max(0, min(self.media.get_timestamp() + seconds * 1_000_000, self.media.get_duration())))

    def _state(self):
        self.play_btn.set_icon_name("media-playback-pause-symbolic" if self.media.get_playing()
                                    else "media-playback-start-symbolic")
        self.play_btn.set_tooltip_text(_("Pause (Space)") if self.media.get_playing() else _("Play (Space)"))

    def _tick(self):
        if self.index >= 0 and self.media.is_prepared():      # a song has no picture: show a music page
            self.pages.set_visible_child_name("screen" if self.media.has_video() else "music")
        dur = self.media.get_duration() if self.media.is_prepared() else 0
        self.seeking = True
        self.scale.set_range(0, max(dur, 1))
        self.scale.set_value(self.media.get_timestamp())
        self.seeking = False
        self.t_cur.set_label(clock(self.media.get_timestamp()))
        self.t_len.set_label(clock(dur))

    def _seek(self, _scale, _scroll, value):
        if not self.seeking and self.media.is_prepared():
            self.media.seek(int(max(0, min(value, self.media.get_duration()))))
        return False

    def toast(self, text):
        self.toasts.add_toast(Adw.Toast.new(text))


class App(Adw.Application):
    def __init__(self):
        super().__init__(application_id=APP_ID, flags=Gio.ApplicationFlags.HANDLES_COMMAND_LINE)
        self.connect("command-line", self._cmd)

    def _cmd(self, _app, cmdline):
        files = [cmdline.create_file_for_arg(a).get_path() for a in cmdline.get_arguments()[1:] if not a.startswith("-")]
        win = self.props.active_window or Window(self)
        if files:
            win.add_files(files, play=True)
        win.present()
        return 0


if __name__ == "__main__":
    sys.exit(App().run(sys.argv))
