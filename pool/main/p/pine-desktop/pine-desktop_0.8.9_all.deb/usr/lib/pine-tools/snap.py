#!/usr/bin/python3
"""Pine OS snap preview (pine-snap): while a window is dragged to the edge of the screen, a soft
rectangle shows where it will land, and glides there from the window's own place; it fades away
when the window is let go (xfwm4 does the real snapping, "tile_on_move").

Where xfwm4 snaps (found by trying it out), with the pointer:
  at the left / right edge (6 px)  -> left / right half; near the top or the bottom (the outer
                                       fifth of the edge) -> that quarter
  at the top edge                  -> maximized; near its left / right end (fifth) -> quarter
A window is being dragged when the left button is down and the active window moves without
changing its size. The preview follows Settings > Personalization > Animations (instant when off).
"""
import os
import sys

import gi
gi.require_version("Gtk", "3.0")
gi.require_version("Gdk", "3.0")
gi.require_version("GdkX11", "3.0")
from gi.repository import GLib  # noqa: E402
GLib.set_prgname("pine-snap")                        # window class "Pine-snap" (picom rule in theme.py)
from gi.repository import Gdk, GdkX11, Gtk  # noqa: E402

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(1, "/usr/lib/pine-settings")
import x11  # noqa: E402
import theme  # noqa: E402

BAND = 6                 # px from the screen edge where xfwm4 snaps
CORNER = 0.2             # the outer fifth of an edge is the corner
INSET = 6                # px the preview keeps from the real edges
GAME_FILE = os.path.join(os.environ.get("XDG_CONFIG_HOME") or os.path.expanduser("~/.config"),
                         "pine", "game-mode-restore.json")
# mode: (glide ms, glide power, fade ms)
MOTION = {"smooth": (240, 4, 170), "fast": (120, 3, 90), "off": (0, 1, 0)}


def zone_rect(wa, x, y, mon):
    """The rectangle (x, y, w, h) a window dragged to the pointer (x, y) will fill, or None."""
    left, right = x - mon.x <= BAND, mon.x + mon.width - 1 - x <= BAND
    top = y - mon.y <= BAND
    hw, hh = wa.width // 2, wa.height // 2
    corner_y = (y - wa.y < CORNER * wa.height, wa.y + wa.height - y < CORNER * wa.height)   # top, bottom
    corner_x = (x - wa.x < CORNER * wa.width, wa.x + wa.width - x < CORNER * wa.width)      # left, right
    if left or right:
        cx = wa.x if left else wa.x + hw
        if corner_y[0]:
            return (cx, wa.y, hw, hh)
        if corner_y[1]:
            return (cx, wa.y + hh, hw, wa.height - hh)
        return (cx, wa.y, hw, wa.height)
    if top:
        if corner_x[0]:
            return (wa.x, wa.y, hw, hh)
        if corner_x[1]:
            return (wa.x + hw, wa.y, hw, hh)
        return (wa.x, wa.y, wa.width, wa.height)
    return None


class Preview(Gtk.Window):
    def __init__(self):
        super().__init__(type=Gtk.WindowType.POPUP)
        screen = self.get_screen()
        vis = screen.get_rgba_visual()
        if vis:
            self.set_visual(vis)
        self.set_app_paintable(True)
        self.set_accept_focus(False)
        self.connect("draw", self.on_draw)
        self.rgb = (0.24, 0.81, 0.49)
        self.cur = (0.0, 0.0, 10.0, 10.0)
        self.target = None
        self.anim = 0                                # a newer animation stops the older one
        self.shown = False

    def set_accent(self, hexcol):
        self.rgb = tuple(c / 255.0 for c in theme.rgb(hexcol))

    def on_draw(self, _w, cr):
        a = self.get_allocation()
        w, h, r, m = a.width, a.height, 10.0, 1.5
        cr.set_operator(0)                           # clear
        cr.paint()
        cr.set_operator(2)                           # over
        cr.new_sub_path()
        for cx, cy, a0 in ((w - m - r, m + r, -90), (w - m - r, h - m - r, 0), (m + r, h - m - r, 90), (m + r, m + r, 180)):
            cr.arc(cx, cy, r, a0 * 3.14159265 / 180, (a0 + 90) * 3.14159265 / 180)
        cr.close_path()
        cr.set_source_rgba(*self.rgb, 0.16)
        cr.fill_preserve()
        cr.set_source_rgba(*self.rgb, 0.7)
        cr.set_line_width(2 * m)
        cr.stroke()
        return True

    def go(self, rect, start, mode):
        """Glide to rect (x, y, w, h); a hidden preview first grows out of `start` while fading in."""
        glide, power, fade = MOTION[mode]
        self.anim += 1
        token = self.anim
        was_hidden = not self.shown
        if was_hidden and start:
            self.cur = tuple(float(v) for v in start)
        elif was_hidden:
            self.cur = tuple(float(v) for v in rect)
        origin, op0 = self.cur, (0.0 if was_hidden else self.get_opacity())
        self.apply(origin, op0 if glide else 1.0)
        if not self.shown:
            self.show()
            self.shown = True
        if not glide:
            self.apply(rect, 1.0)
            return
        t0 = []

        def tick(_w, clock):
            if token != self.anim:
                return False
            now = clock.get_frame_time() / 1000.0
            if not t0:
                t0.append(now)
            e = now - t0[0]
            k = 1 - (1 - min(1.0, e / glide)) ** power
            box = tuple(origin[i] + (rect[i] - origin[i]) * k for i in range(4))
            self.apply(box, op0 + (1 - op0) * min(1.0, e / max(1, fade)))
            return e < max(glide, fade)
        self.add_tick_callback(tick)

    def apply(self, box, opacity):
        self.cur = box
        x, y, w, h = (int(round(v)) for v in box)
        self.move(x, y)
        self.resize(max(8, w), max(8, h))
        self.set_opacity(max(0.0, min(1.0, opacity)))

    def away(self, mode):
        if not self.shown:
            return
        self.anim += 1
        token, fade, op0 = self.anim, MOTION[mode][2], self.get_opacity()

        def finish():
            self.hide()
            self.shown = False

        if not fade:
            finish()
            return
        t0 = []

        def tick(_w, clock):
            if token != self.anim:
                return False
            now = clock.get_frame_time() / 1000.0
            if not t0:
                t0.append(now)
            k = min(1.0, (now - t0[0]) / fade)
            self.set_opacity(op0 * (1 - k))
            if k >= 1.0:
                finish()
                return False
            return True
        self.add_tick_callback(tick)


class Watcher:
    def __init__(self):
        self.disp = Gdk.Display.get_default()
        self.seat = self.disp.get_default_seat()
        self.pointer = self.seat.get_pointer()
        self.root = Gdk.get_default_root_window()
        self.preview = Preview()
        self.down = False
        self.win = None
        self.last = None             # (x, y, w, h) of the active window at the last look
        self.dragging = False
        self.zone = None
        self.accent_seen = None
        GLib.timeout_add(120, self.poll)

    def frame(self, xid):
        try:
            gw = GdkX11.X11Window.foreign_new_for_display(self.disp, xid)
            r = gw.get_frame_extents()
            return (r.x, r.y, r.width, r.height)
        except (TypeError, GLib.Error, AttributeError):
            return None

    def poll(self):
        _w, x, y, mask = self.root.get_device_position(self.pointer)
        down = bool(mask & Gdk.ModifierType.BUTTON1_MASK) and not os.path.exists(GAME_FILE)
        if down and not self.down:
            self.down, self.win, self.last, self.dragging, self.zone = True, None, None, False, None
            GLib.timeout_add(20, self.poll)
            return False                              # (re-armed at a fast pace while the button is down)
        if down:
            self.look(x, y)
            GLib.timeout_add(20, self.poll)
            return False
        if self.down:
            self.down = False
            self.release()
        GLib.timeout_add(120, self.poll)
        return False

    def look(self, x, y):
        xid = x11.active_window()
        r = self.frame(xid) if xid else None
        if not self.dragging:
            if r and xid == self.win and self.last and (r[0], r[1]) != (self.last[0], self.last[1]) \
                    and (r[2], r[3]) == (self.last[2], self.last[3]):
                self.dragging = True
            self.win, self.last = xid, r
            if not self.dragging:
                return
        mode = theme.motion_now()
        mon = self.disp.get_monitor_at_point(x, y)
        rect = zone_rect(mon.get_workarea(), x, y, mon.get_geometry())
        if rect is not None:
            rect = (rect[0] + INSET, rect[1] + INSET, rect[2] - 2 * INSET, rect[3] - 2 * INSET)
        if rect == self.zone:
            return
        self.zone = rect
        if rect is None:
            self.preview.away(mode)
        else:
            if not self.preview.shown:
                self.preview.set_accent(theme.saved()[1])
            self.preview.go(rect, r, mode)

    def release(self):
        self.dragging = False
        self.zone = None
        self.preview.away(theme.motion_now())


def main():
    if "--zones" in sys.argv:                       # self-check: python3 snap.py --zones
        class R:                                    # a 1280 x 800 screen, taskbar 49 px
            x, y, width, height = 0, 0, 1280, 751
        class M(R):
            height = 800
        cases = {(3, 400): (0, 0, 640, 751), (1277, 400): (640, 0, 640, 751), (640, 2): (0, 0, 1280, 751),
                 (2, 2): (0, 0, 640, 375), (1278, 2): (640, 0, 640, 375), (2, 740): (0, 375, 640, 376),
                 (100, 3): (0, 0, 640, 375), (300, 3): (0, 0, 1280, 751), (640, 400): None, (12, 400): None,
                 (3, 200): (0, 0, 640, 751), (3, 600): (0, 0, 640, 751), (3, 700): (0, 375, 640, 376)}
        bad = {k: (zone_rect(R, *k, M), v) for k, v in cases.items() if zone_rect(R, *k, M) != v}
        print("zones ok" if not bad else "zones WRONG: %s" % bad)
        return 0 if not bad else 1
    if not os.environ.get("DISPLAY"):
        return 1
    Watcher()
    Gtk.main()
    return 0


if __name__ == "__main__":
    sys.exit(main())