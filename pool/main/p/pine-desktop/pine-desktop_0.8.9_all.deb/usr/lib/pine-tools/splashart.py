"""The Pine splash picture, shared by the login veil and the sign-out / shut-down screen.

It is the wallpaper picture (logo, name and waves), scaled to cover the screen and centred like
the boot splash does: boot splash -> sign-in screen (the same picture blurred) -> this -> desktop
are all the same picture, so nothing jumps and the logo stays where it is."""
from gi.repository import GdkPixbuf

WALLPAPER = "/usr/share/backgrounds/pine/pine-wallpaper.png"
FLAT = (6 / 255, 9 / 255, 12 / 255)             # #06090C, the splash colour


def cover(width, height):
    """The picture scaled to cover width x height (edges cropped), or None."""
    try:
        pix = GdkPixbuf.Pixbuf.new_from_file(WALLPAPER)
    except Exception:
        return None
    s = max(width / pix.get_width(), height / pix.get_height())
    w, h = max(width, int(pix.get_width() * s + 0.5)), max(height, int(pix.get_height() * s + 0.5))
    big = pix.scale_simple(w, h, GdkPixbuf.InterpType.BILINEAR)
    return big.new_subpixbuf((w - width) // 2, (h - height) // 2, width, height)