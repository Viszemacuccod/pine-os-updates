"""The open windows, read straight from the X server (libX11 through ctypes, so no extra
packages are needed): which windows the taskbar shows, in the order they were last used,
with their title, app and icon. Used by the Alt+Tab switcher and the screenshot tool.
"""
import ctypes
import ctypes.util

from gi.repository import GdkPixbuf

_lib = ctypes.cdll.LoadLibrary(ctypes.util.find_library("X11") or "libX11.so.6")
_Atom = ctypes.c_ulong
_Window = ctypes.c_ulong
_lib.XOpenDisplay.restype = ctypes.c_void_p
_lib.XOpenDisplay.argtypes = [ctypes.c_char_p]
_lib.XDefaultRootWindow.restype = _Window
_lib.XDefaultRootWindow.argtypes = [ctypes.c_void_p]
_lib.XInternAtom.restype = _Atom
_lib.XInternAtom.argtypes = [ctypes.c_void_p, ctypes.c_char_p, ctypes.c_int]
_lib.XGetAtomName.restype = ctypes.c_void_p
_lib.XGetAtomName.argtypes = [ctypes.c_void_p, _Atom]
_lib.XGetWindowProperty.restype = ctypes.c_int
_lib.XGetWindowProperty.argtypes = [
    ctypes.c_void_p, _Window, _Atom, ctypes.c_long, ctypes.c_long, ctypes.c_int, _Atom,
    ctypes.POINTER(_Atom), ctypes.POINTER(ctypes.c_int), ctypes.POINTER(ctypes.c_ulong),
    ctypes.POINTER(ctypes.c_ulong), ctypes.POINTER(ctypes.POINTER(ctypes.c_ubyte))]
_lib.XFree.argtypes = [ctypes.c_void_p]
_lib.XSync.argtypes = [ctypes.c_void_p, ctypes.c_int]

# A window can close while we read it: X would then stop the whole program (its default
# error handler); this one ignores the error and the read just comes back empty.
_HANDLER = ctypes.CFUNCTYPE(ctypes.c_int, ctypes.c_void_p, ctypes.c_void_p)(lambda d, e: 0)
_lib.XSetErrorHandler.argtypes = [ctypes.c_void_p]
_lib.XSetErrorHandler(ctypes.cast(_HANDLER, ctypes.c_void_p))

_dpy = None
_atoms = {}


def _display():
    global _dpy
    if _dpy is None:
        _dpy = _lib.XOpenDisplay(None)
    return _dpy


def atom(name):
    if name not in _atoms:
        _atoms[name] = _lib.XInternAtom(_display(), name.encode(), 0)
    return _atoms[name]


def atom_name(a):
    p = _lib.XGetAtomName(_display(), a)
    if not p:
        return ""
    s = ctypes.string_at(p).decode(errors="replace")
    _lib.XFree(p)
    return s


def root():
    return _lib.XDefaultRootWindow(_display())


def prop(win, name, length=1 << 20):
    """(format, raw bytes, item count) of a window property, or (0, b"", 0)."""
    rtype, fmt = _Atom(), ctypes.c_int()
    n, after = ctypes.c_ulong(), ctypes.c_ulong()
    data = ctypes.POINTER(ctypes.c_ubyte)()
    ok = _lib.XGetWindowProperty(_display(), win, atom(name), 0, length, 0, 0,
                                 ctypes.byref(rtype), ctypes.byref(fmt), ctypes.byref(n),
                                 ctypes.byref(after), ctypes.byref(data))
    if ok != 0 or not data:
        return 0, b"", 0
    # 32-bit items are C longs in Xlib (8 bytes on a 64-bit system)
    size = {8: 1, 16: 2, 32: ctypes.sizeof(ctypes.c_long)}.get(fmt.value, 1) * n.value
    raw = ctypes.string_at(data, size)
    _lib.XFree(data)
    return fmt.value, raw, n.value


def cardinals(win, name):
    fmt, raw, n = prop(win, name)
    if fmt != 32:
        return []
    return list((ctypes.c_ulong * n).from_buffer_copy(raw))


def text(win, name):
    fmt, raw, _ = prop(win, name)
    return raw.decode(errors="replace") if fmt == 8 else ""


def title(win):
    return text(win, "_NET_WM_NAME") or text(win, "WM_NAME")


def wm_class(win):
    """(instance, class), e.g. ("Navigator", "firefox-esr")."""
    parts = text(win, "WM_CLASS").split("\0")
    return (parts[0] if parts else ""), (parts[1] if len(parts) > 1 else "")


def types(win):
    return {atom_name(a) for a in cardinals(win, "_NET_WM_WINDOW_TYPE")}


def states(win):
    return {atom_name(a) for a in cardinals(win, "_NET_WM_STATE")}


def desktop(win):
    v = cardinals(win, "_NET_WM_DESKTOP")
    return v[0] if v else None


def current_desktop():
    v = cardinals(root(), "_NET_CURRENT_DESKTOP")
    return v[0] if v else 0


def active_window():
    v = cardinals(root(), "_NET_ACTIVE_WINDOW")
    return v[0] if v and v[0] else None


def minimized(win):
    return "_NET_WM_STATE_HIDDEN" in states(win)


def app_windows(all_desktops=False):
    """The windows the taskbar shows, the most recently used first."""
    here = current_desktop()
    out = []
    for w in reversed(cardinals(root(), "_NET_CLIENT_LIST_STACKING")):
        t = types(w)
        if t and not t & {"_NET_WM_WINDOW_TYPE_NORMAL", "_NET_WM_WINDOW_TYPE_DIALOG"}:
            continue                                   # desktop, taskbar, menus...
        if "_NET_WM_STATE_SKIP_TASKBAR" in states(w):
            continue
        d = desktop(w)
        if not all_desktops and d not in (here, 0xFFFFFFFF, None):
            continue
        out.append(w)
    return out


def icon(win, size=32):
    """The window's own icon (_NET_WM_ICON) as a pixbuf of about that size, or None."""
    v = cardinals(win, "_NET_WM_ICON")
    best, i = None, 0
    while i + 2 <= len(v):
        w, h = v[i], v[i + 1]
        if w <= 0 or h <= 0 or i + 2 + w * h > len(v):
            break
        # the smallest icon that is at least `size`, else the biggest one there is
        if best is None or (best[0] < size and w > best[0]) or (size <= w < best[0]):
            best = (w, h, i + 2)
        i += 2 + w * h
    if not best:
        return None
    w, h, start = best
    rgba = bytearray(w * h * 4)
    for k, argb in enumerate(v[start:start + w * h]):
        rgba[k * 4:k * 4 + 4] = bytes(((argb >> 16) & 255, (argb >> 8) & 255, argb & 255, (argb >> 24) & 255))
    pb = GdkPixbuf.Pixbuf.new_from_bytes(GLib_bytes(bytes(rgba)), GdkPixbuf.Colorspace.RGB, True, 8, w, h, w * 4)
    return pb if w == size else pb.scale_simple(size, max(1, round(h * size / w)), GdkPixbuf.InterpType.BILINEAR)


def GLib_bytes(b):
    from gi.repository import GLib
    return GLib.Bytes.new(b)
