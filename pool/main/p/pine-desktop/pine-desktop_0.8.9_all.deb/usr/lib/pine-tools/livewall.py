#!/usr/bin/python3
"""Pine OS live background (pine-livewall): the waves of the Pine wallpaper drift slowly.

Made from the same pictures as the boot splash (/usr/share/plymouth/themes/pine: bg, wave-back,
wave-front, logo, wordmark; positions from its pine.script), so it looks exactly like the still
wallpaper, with the two waves swaying a little. It costs very little: pictures are scaled once,
only the bottom part of the screen is redrawn, 10 times a second.

It stops by itself (and shows the still picture) when
  - the computer runs on battery and Settings > Personalization > "Only when plugged in" is on,
  - Game mode is on, or another window is full screen,
  - the wallpaper is not the Pine wallpaper any more.
Settings starts and stops it (settings.json: "live_wallpaper": {"on": true, "plugged_in_only": true}).
"""
import glob
import json
import math
import os
import re
import subprocess
import time

import gi
gi.require_version("Gtk", "3.0")
gi.require_version("Gdk", "3.0")
gi.require_version("GdkPixbuf", "2.0")
from gi.repository import GLib  # noqa: E402
GLib.set_prgname("pine-livewall")
from gi.repository import Gdk, GdkPixbuf, Gtk  # noqa: E402
import cairo  # noqa: E402

THEME = "/usr/share/plymouth/themes/pine"
FPS = 10
CONFIG = os.path.join(os.environ.get("XDG_CONFIG_HOME") or os.path.expanduser("~/.config"), "pine", "settings.json")
GAME_FILE = os.path.join(os.path.dirname(CONFIG), "game-mode-restore.json")


def settings():
    try:
        with open(CONFIG) as f:
            return json.load(f).get("live_wallpaper", {})
    except (OSError, ValueError, AttributeError):
        return {}


def on_battery():
    for st in glob.glob("/sys/class/power_supply/BAT*/status"):
        try:
            if open(st).read().strip() == "Discharging":
                return True
        except OSError:
            pass
    return False


def x_out(*cmd):
    try:
        return subprocess.run(cmd, capture_output=True, text=True, timeout=5).stdout
    except (OSError, subprocess.TimeoutExpired):
        return ""


def pine_wallpaper_on():
    out = x_out("xfconf-query", "-c", "xfce4-desktop", "-l", "-v")
    imgs = [l.split(None, 1)[1].strip() for l in out.splitlines() if "/last-image" in l and len(l.split(None, 1)) > 1]
    return not imgs or any("pine-wallpaper" in i for i in imgs)


def fullscreen_window():
    """True when the window in front is full screen (a game, a video)."""
    act = x_out("xdotool", "getactivewindow").strip()
    return bool(act) and "_NET_WM_STATE_FULLSCREEN" in x_out("xprop", "-id", act, "_NET_WM_STATE")


def icons_on_top(own_id):
    """The desktop icons (nemo-desktop) must stay above this window. Windows of the desktop
    layer stack in the order they appeared, so if they came first, start them again."""
    stack = re.findall(r"0x[0-9a-f]+", x_out("xprop", "-root", "_NET_CLIENT_LIST_STACKING"))
    nemo = [hex(int(w)) for w in x_out("xdotool", "search", "--class", "nemo-desktop").split()]
    if not nemo or own_id not in stack:
        return
    if any(w in stack and stack.index(w) < stack.index(own_id) for w in nemo):
        subprocess.run(["pkill", "-u", str(os.getuid()), "-x", "nemo-desktop"])
        time.sleep(0.6)
        subprocess.Popen(["/usr/libexec/pine-desktop-icons"], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)


def layout():
    """The positions (in the 1920x1080 reference picture) from the splash theme's script."""
    vals = {"REF_W": 1920, "REF_H": 1080}
    try:
        text = open(os.path.join(THEME, "pine.script")).read()
        block = text.split("@LAYOUT-BEGIN")[1].split("@LAYOUT-END")[0]     # several "NAME = n;" per line
        for k, v in re.findall(r"(\w+)\s*=\s*(-?\d+);", block):
            vals[k] = int(v)
    except OSError:
        pass
    return vals


class Wall(Gtk.Window):
    def __init__(self):
        super().__init__(type=Gtk.WindowType.TOPLEVEL)
        self.set_type_hint(Gdk.WindowTypeHint.DESKTOP)
        self.set_decorated(False)
        self.set_skip_taskbar_hint(True)
        self.set_skip_pager_hint(True)
        self.set_accept_focus(False)
        self.set_app_paintable(True)
        disp = Gdk.Display.get_default()
        mon = disp.get_primary_monitor() or disp.get_monitor(0)
        g = mon.get_geometry()
        self.mx, self.my, self.sw, self.sh = g.x, g.y, g.width, g.height
        self.move(self.mx, self.my)
        self.set_default_size(self.sw, self.sh)
        self.set_size_request(self.sw, self.sh)
        L = layout()
        s = max(self.sw / L["REF_W"], self.sh / L["REF_H"])
        self.s = s
        self.ox = (self.sw - L["REF_W"] * s) / 2
        self.oy = (self.sh - L["REF_H"] * s) / 2
        self.pos = {k: (L.get(f"{k.upper()}_X", 0), L.get(f"{k.upper()}_Y", 0)) for k in ("back", "front", "logo")}
        self.pos["word"] = (L.get("WORD_X", 0), L.get("WORD_Y", 0))
        self.layers = {n: self.load(f) for n, f in (("bg", "bg.png"), ("back", "wave-back.png"),
                                                    ("front", "wave-front.png"), ("logo", "logo.png"),
                                                    ("word", "wordmark.png"))}
        # redraw only from just above the highest wave down to the bottom
        self.top = max(0, int(self.oy + (min(self.pos["back"][1], self.pos["front"][1]) - 24) * s))
        self.t0 = time.monotonic()
        self.running = False
        self.timer = None
        self.connect("draw", self.draw)
        self.connect("destroy", Gtk.main_quit)
        self.show_all()
        self.get_window().lower()
        own = hex(self.get_window().get_xid())
        GLib.timeout_add(1500, lambda: (icons_on_top(own), False)[1])
        GLib.timeout_add_seconds(4, self.check)
        self.check()

    def load(self, name):
        pb = GdkPixbuf.Pixbuf.new_from_file(os.path.join(THEME, name))
        w, h = max(1, round(pb.get_width() * self.s)), max(1, round(pb.get_height() * self.s))
        pb = pb.scale_simple(w, h, GdkPixbuf.InterpType.BILINEAR)
        surf = cairo.ImageSurface(cairo.FORMAT_ARGB32, w, h)
        cr = cairo.Context(surf)
        Gdk.cairo_set_source_pixbuf(cr, pb, 0, 0)
        cr.paint()
        return surf

    def draw(self, _w, cr):
        t = (time.monotonic() - self.t0) if self.running else 0.0
        s = self.s
        # the waves sway: slowly, in different rhythms
        bdx, bdy = 70 * math.sin(2 * math.pi * t / 17), 5 * math.sin(2 * math.pi * t / 11 + 1)
        fdx, fdy = -90 * math.sin(2 * math.pi * t / 23 + .6), 7 * math.sin(2 * math.pi * t / 13)
        x0, y0, _x, _y = cr.clip_extents()
        for name, dx, dy in (("bg", 0, 0), ("back", bdx, bdy), ("front", fdx, fdy), ("logo", 0, 0), ("word", 0, 0)):
            if name == "bg":
                px, py = self.ox, self.oy
            else:
                lx, ly = self.pos[name]
                px, py = self.ox + (lx + dx) * s, self.oy + (ly + dy) * s
            cr.set_source_surface(self.layers[name], round(px), round(py))
            cr.paint()
        return False

    def tick(self):
        self.queue_draw_area(0, self.top, self.sw, self.sh - self.top)
        return self.running

    def check(self):
        """Run or stand still (the still picture stays)."""
        cfg = settings()
        if not cfg.get("on", False) or not pine_wallpaper_on():
            Gtk.main_quit()          # off, or another wallpaper was chosen: the window must not cover it
            return False
        want = (not os.path.exists(GAME_FILE) and not (cfg.get("plugged_in_only", True) and on_battery())
                and not fullscreen_window())
        if want and not self.running:
            self.running = True
            self.t0 = time.monotonic() - getattr(self, "paused_at", 0.0)
            self.timer = GLib.timeout_add(1000 // FPS, self.tick)
        elif not want and self.running:
            self.paused_at = time.monotonic() - self.t0
            self.running = False
        return True


def main():
    if not settings().get("on", False) or not pine_wallpaper_on():
        return
    Wall()
    Gtk.main()


if __name__ == "__main__":
    main()
