#!/usr/bin/python3
"""Pine OS colour cross-fade (pine-crossfade): dark <-> light (and accent) changes fade instead of
switching abruptly.

theme.apply() starts this first: it takes a picture of the screen, covers the screen with it
(override-redirect window, nothing comes in front) and says "ready". The colours are then
changed behind the picture. When theme.apply() writes "fade <seconds>" the picture waits that long
(apps repaint, the taskbar restarts) and fades out. Without a compositor, with animations off, or
when anything goes wrong it just says "skip" and leaves, and the colours switch as before.
"""
import sys

import gi
gi.require_version("Gtk", "3.0")
gi.require_version("Gdk", "3.0")
from gi.repository import GLib  # noqa: E402
GLib.set_prgname("pine-crossfade")                   # window class "Pine-crossfade" (picom rule in theme.py)
from gi.repository import Gdk, Gtk  # noqa: E402

sys.path.insert(0, "/usr/lib/pine-settings")
import theme  # noqa: E402

FADE = {"smooth": 0.38, "fast": 0.2}                 # seconds


def say(text):
    sys.stdout.write(text + "\n")
    sys.stdout.flush()


class Cover(Gtk.Window):
    def __init__(self, pix, mode):
        super().__init__(type=Gtk.WindowType.POPUP)
        self.pix, self.dur, self.fading = pix, FADE[mode] * 1000.0, False
        self.set_app_paintable(True)
        self.move(0, 0)
        self.set_default_size(pix.get_width(), pix.get_height())
        self.connect("draw", self.on_draw)
        self.show_all()
        GLib.timeout_add(80, self.keep_on_top)
        GLib.timeout_add_seconds(8, self.finish)         # nobody answered: never stay
        GLib.io_add_watch(sys.stdin.fileno(), GLib.IO_IN | GLib.IO_HUP, self.on_command)

    def on_draw(self, _w, cr):
        Gdk.cairo_set_source_pixbuf(cr, self.pix, 0, 0)
        cr.paint()
        return True

    def keep_on_top(self):
        win = self.get_window()
        if win and not self.fading:
            win.raise_()
        return not self.fading

    def on_command(self, fd, cond):
        line = sys.stdin.readline().strip()
        if line.startswith("fade"):
            try:
                wait = float(line.split()[1])
            except (IndexError, ValueError):
                wait = 0.5
            GLib.timeout_add(int(wait * 1000), self.fade)
            return False
        if not line or cond & GLib.IO_HUP:
            self.finish()
            return False
        return True

    def fade(self):
        self.fading = True
        start = []

        def tick(_w, clock):
            now = clock.get_frame_time() / 1000.0
            if not start:
                start.append(now)
            t = min(1.0, (now - start[0]) / self.dur)
            self.set_opacity((1 - t) ** 2)
            if t >= 1.0:
                self.finish()
                return False
            return True
        self.add_tick_callback(tick)
        return False

    def finish(self):
        self.destroy()
        Gtk.main_quit()
        return False


def main():
    mode = theme.motion_now()
    screen = Gdk.Screen.get_default()
    if mode not in FADE or not screen or not screen.is_composited():
        say("skip")
        return 0
    root = Gdk.get_default_root_window()
    pix = Gdk.pixbuf_get_from_window(root, 0, 0, root.get_width(), root.get_height())
    if pix is None:
        say("skip")
        return 0
    Cover(pix, mode)
    say("ready")
    Gtk.main()
    return 0


if __name__ == "__main__":
    sys.exit(main())