#!/usr/bin/python3
"""Pine OS login veil (pine-veil): the desktop is revealed instead of popping up piece by piece.

  veil.py --in    started very early in the session (Xsession.d/23pine-veil): the Pine splash
                  picture (the boot splash's, see splashart.py) covers the screen while the taskbar, desktop icons and wallpaper
                  load, then fades away. It follows Settings > Personalization > Animations
                  (Smooth: slow, soft fade; Minimalistic: short; Off: not started).

No window manager is running yet, so it is an override-redirect window (GTK "popup"): nothing
else can come in front of it. The fade needs the compositor (picom), which starts first.
"""
import os
import sys
import time

import gi
gi.require_version("Gtk", "3.0")
gi.require_version("Gdk", "3.0")
gi.require_version("GdkPixbuf", "2.0")
from gi.repository import GLib  # noqa: E402
GLib.set_prgname("pine-veil")                        # window class "Pine-veil" (see the picom rule in theme.py)
from gi.repository import Gdk, GdkPixbuf, Gtk  # noqa: E402

sys.path.insert(0, "/usr/lib/pine-settings")
import theme  # noqa: E402
import splashart  # noqa: E402

BG = splashart.FLAT                                  # (while the picture is missing)
LOGO = "/usr/share/icons/hicolor/256x256/apps/pine-logo.png"
# mode: (shortest time on screen, wait after the desktop is ready, fade-out), seconds
TIMES = {"smooth": (1.0, 0.45, 0.75), "fast": (0.5, 0.2, 0.3)}
GIVE_UP = 14.0                                       # never keep anyone waiting longer than this


def running(*names):
    """Is a program with one of these names running for me?"""
    uid = os.getuid()
    for pid in filter(str.isdigit, os.listdir("/proc")):
        try:
            if os.stat(f"/proc/{pid}").st_uid != uid:
                continue
            with open(f"/proc/{pid}/comm") as f:
                if f.read().strip() in names:
                    return True
        except OSError:
            continue
    return False


def desktop_ready():
    return running("xfce4-panel") and running("nemo-desktop", "xfdesktop")


class Veil(Gtk.Window):
    def __init__(self, mode):
        super().__init__(type=Gtk.WindowType.POPUP)
        self.times = TIMES[mode]
        self.t0 = time.monotonic()
        self.ready_at = None
        self.fading = False
        screen = self.get_screen()
        self.set_app_paintable(True)
        self.move(0, 0)
        self.set_default_size(screen.get_width(), screen.get_height())
        self.set_keep_above(True)
        disp = Gdk.Display.get_default()
        mon = disp.get_primary_monitor() or disp.get_monitor(0)
        g = mon.get_geometry()
        self.centre = (g.x + g.width // 2, g.y + g.height // 2)
        # the splash picture (like the boot splash and the sign-in screen), on the main screen
        self.art = splashart.cover(g.width, g.height)
        self.art_at = (g.x, g.y)
        size = max(96, min(g.width, g.height) // 6)
        try:
            self.logo = None if self.art else GdkPixbuf.Pixbuf.new_from_file_at_scale(LOGO, size, size, True)
        except GLib.Error:
            self.logo = None
        self.connect("draw", self.on_draw)
        self.connect("realize", lambda w: w.get_window().set_cursor(Gdk.Cursor.new_from_name(disp, "none")))
        self.show_all()
        GLib.timeout_add(120, self.poll)

    def on_draw(self, _w, cr):
        cr.set_source_rgb(*BG)
        cr.paint()
        if self.art:
            Gdk.cairo_set_source_pixbuf(cr, self.art, *self.art_at)
            cr.paint()
        elif self.logo:
            Gdk.cairo_set_source_pixbuf(cr, self.logo, self.centre[0] - self.logo.get_width() / 2,
                                        self.centre[1] - self.logo.get_height() / 2)
            cr.paint()
        return True

    def poll(self):
        if self.fading:
            return False
        now = time.monotonic()
        if self.ready_at is None and desktop_ready():
            self.ready_at = now
        done = self.ready_at is not None and now - self.ready_at >= self.times[1] and now - self.t0 >= self.times[0]
        if done or now - self.t0 > GIVE_UP:
            self.fade()
            return False
        return True

    def fade(self):
        """Opacity 1 -> 0 on the frame clock (ease-out), then gone."""
        self.fading = True
        dur = self.times[2] * 1000.0
        start = []

        def tick(_w, clock):
            now = clock.get_frame_time() / 1000.0
            if not start:
                start.append(now)
            t = min(1.0, (now - start[0]) / dur)
            self.set_opacity(1 - (1 - (1 - t) ** 3))     # = (1 - t) ** 3 : quick at first, then soft
            if t >= 1.0:
                self.destroy()
                Gtk.main_quit()
                return False
            return True
        self.add_tick_callback(tick)


def main():
    mode = theme.motion_now()
    if mode not in TIMES or "--in" not in sys.argv:
        return 0
    Veil(mode)
    Gtk.main()
    return 0


if __name__ == "__main__":
    sys.exit(main())