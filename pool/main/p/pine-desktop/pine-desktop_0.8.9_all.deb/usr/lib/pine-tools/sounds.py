#!/usr/bin/python3
"""Pine OS system sounds (pine-sounds), started at sign-in:

  - the start-up sound, once, when the desktop is ready
  - a short sound for every new notification (not for the volume pop-up, not in Do not disturb,
    not in Game mode)
  - OFF unless chosen: a very soft tap for every mouse click and a soft blip when a window closes
    (not in Game mode)
All can be changed in Settings > System > Sound (settings.json "sounds": {"startup", "notify", "ui"}).
It waits for notifications with dbus-monitor, so it uses no CPU in between; the click and close
listeners (xinput, xprop) only run while "ui" is on. Only one copy runs (a second one just leaves).
"""
import fcntl
import json
import os
import shutil
import subprocess
import sys
import threading
import time

SOUNDS = "/usr/share/sounds/pine"
CONFIG = os.path.join(os.environ.get("XDG_CONFIG_HOME") or os.path.expanduser("~/.config"), "pine", "settings.json")
GAME_FILE = os.path.join(os.path.dirname(CONFIG), "game-mode-restore.json")
SKIP_APPS = {"Volume"}          # the volume pop-up has its own feedback


def want(key, default=True):
    try:
        with open(CONFIG) as f:
            return bool(json.load(f).get("sounds", {}).get(key, default))
    except (OSError, ValueError, AttributeError):
        return default


def player():
    for cmd in (["pw-play"], ["paplay"], ["aplay", "-q"]):
        if shutil.which(cmd[0]):
            return cmd
    return None


def play(name):
    p = player()
    f = os.path.join(SOUNDS, name)
    if p and os.path.exists(f):
        subprocess.Popen(p + [f], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)


def do_not_disturb():
    try:
        out = subprocess.run(["xfconf-query", "-c", "xfce4-notifyd", "-p", "/do-not-disturb"],
                             capture_output=True, text=True, timeout=5).stdout.strip()
    except (OSError, subprocess.TimeoutExpired):
        return False
    return out == "true"


# ---------------------------------------------------------------- click and close sounds
def watch(cmd, handle, stop):
    """Run a listener program and hand every output line to handle(line) until `stop` is set."""
    try:
        proc = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL, text=True)
    except OSError:
        return
    threading.Thread(target=lambda: (stop.wait(), proc.terminate()), daemon=True).start()
    for line in proc.stdout:
        handle(line)
    proc.wait()


def click_listener(stop):
    state = {"press": False, "last": 0.0}

    def handle(line):
        s = line.strip()
        if "RawButtonPress" in s:
            state["press"] = True
        elif state["press"] and s.startswith("detail:"):
            state["press"] = False
            now = time.monotonic()
            if s.split()[-1] in ("1", "3") and now - state["last"] > 0.06 and not os.path.exists(GAME_FILE):
                state["last"] = now           # (buttons 4-7 are the scroll wheel)
                play("click.wav")
    watch(["xinput", "test-xi2", "--root"], handle, stop)


def close_listener(stop):
    state = {"ids": None, "last": 0.0}

    def handle(line):
        if "window id #" not in line:
            return
        ids = {w.strip() for w in line.split("#", 1)[1].split(",") if w.strip()}
        old, state["ids"] = state["ids"], ids
        now = time.monotonic()
        if old and old - ids and now - state["last"] > 0.4 and not os.path.exists(GAME_FILE):
            state["last"] = now               # (a minimized window stays in the list: only a real close)
            play("close.wav")
    watch(["xprop", "-root", "-spy", "_NET_CLIENT_LIST"], handle, stop)


def ui_supervisor():
    """Starts and stops the click and close listeners as the setting changes (checked every 4 s)."""
    stop = None
    while True:
        on = want("ui", False) and os.environ.get("DISPLAY") and shutil.which("xinput") and shutil.which("xprop")
        if on and stop is None:
            stop = threading.Event()
            for fn in (click_listener, close_listener):
                threading.Thread(target=fn, args=(stop,), daemon=True).start()
        elif not on and stop is not None:
            stop.set()
            stop = None
        time.sleep(4)


_LOCK = None


def only_copy():
    """Only one pine-sounds at a time (Settings starts one whenever a sound setting changes)."""
    global _LOCK
    path = os.path.join(os.environ.get("XDG_RUNTIME_DIR") or "/tmp", "pine-sounds.lock")
    _LOCK = open(path, "w")
    try:
        fcntl.flock(_LOCK, fcntl.LOCK_EX | fcntl.LOCK_NB)
    except OSError:
        return False
    return True


def main():
    if "--test" in sys.argv:
        play(next((n + ".wav" for n in ("startup", "click", "close") if n in sys.argv), "notification.wav"))
        time.sleep(3)
        return
    if "--login" in sys.argv and want("startup"):      # only the sign-in start plays the chime
        play("startup.wav")
    if not only_copy():
        return
    threading.Thread(target=ui_supervisor, daemon=True).start()
    if not shutil.which("dbus-monitor"):
        while True:
            time.sleep(3600)
    mon = subprocess.Popen(["dbus-monitor", "--session",
                            "type='method_call',interface='org.freedesktop.Notifications',member='Notify'"],
                           stdout=subprocess.PIPE, stderr=subprocess.DEVNULL, text=True)
    last, pending = 0.0, None        # pending: the argument lines after a Notify call
    for line in mon.stdout:
        if "member=Notify" in line and line.startswith("method call"):
            pending = []
            continue
        if pending is None:
            continue
        s = line.strip()
        if s.startswith(("string", "uint32")):
            pending.append(s)
        if len(pending) >= 2:        # app name, replaces_id
            app = pending[0].split('"', 1)[1].rsplit('"', 1)[0] if '"' in pending[0] else ""
            replaces = pending[1].split()[-1] if pending[1].startswith("uint32") else "0"
            pending = None
            if (app in SKIP_APPS or replaces != "0" or not want("notify") or os.path.exists(GAME_FILE)
                    or time.monotonic() - last < 1.5 or do_not_disturb()):
                continue
            last = time.monotonic()
            play("notification.wav")


if __name__ == "__main__":
    main()
