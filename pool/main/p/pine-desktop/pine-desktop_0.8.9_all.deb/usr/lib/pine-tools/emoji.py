#!/usr/bin/python3
"""Pine OS emoji picker (pine-emoji), Win+. like on Windows.

A small window above the taskbar: a search box and a grid of emoji; click one (or press
Enter on the first match) and it is typed into the window you were in. Esc closes it.
The emoji list is /usr/share/pine/emoji.tsv (tools/make-emoji.py): "emoji<TAB>group<TAB>name".
"""
import os
import subprocess
import sys

import gi
gi.require_version("Gtk", "3.0")
gi.require_version("Gdk", "3.0")
from gi.repository import GLib  # noqa: E402
GLib.set_prgname("pine-emoji")
from gi.repository import Gdk, Gtk  # noqa: E402

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(1, "/usr/lib/pine-settings")
import theme  # noqa: E402  (Pine colors, dark / light mode, accent)

import gettext  # noqa: E402
_ = gettext.translation("pine", fallback=True).gettext

DATA = "/usr/share/pine/emoji.tsv"
COLUMNS = 8
RECENT = os.path.join(os.environ.get("XDG_CONFIG_HOME") or os.path.expanduser("~/.config"), "pine", "emoji-recent")


def load():
    out = []
    try:
        with open(DATA, encoding="utf-8") as f:
            for line in f:
                parts = line.rstrip("\n").split("\t")
                if len(parts) == 3:
                    out.append(parts)
    except OSError:
        pass
    return out


def recent():
    try:
        with open(RECENT, encoding="utf-8") as f:
            return [x for x in f.read().split() if x][:16]
    except OSError:
        return []


def remember(ch):
    items = [ch] + [x for x in recent() if x != ch]
    try:
        os.makedirs(os.path.dirname(RECENT), exist_ok=True)
        with open(RECENT, "w", encoding="utf-8") as f:
            f.write(" ".join(items[:16]))
    except OSError:
        pass


def css():
    mode, accent = theme.saved()
    p = theme.colors(mode, accent)
    return f"""
#pine-emoji {{ background-color: {p['popover']}; color: {p['fg']}; border: 1px solid {p['line']}; border-radius: 5px;
  font-family: Inter, sans-serif; }}
#pine-emoji label {{ color: {p['fg']}; }}
#pine-emoji .muted {{ color: {p['muted']}; font-size: 11pt; }}
#pine-emoji entry {{ background: {p['surface']}; color: {p['fg']}; border: 1px solid {p['line']}; border-radius: 5px;
  min-height: 34px; padding: 0 8px; }}
#pine-emoji button.em {{ background: none; border: none; box-shadow: none; border-radius: 5px; padding: 0;
  min-width: 42px; min-height: 42px; font-size: 20pt; }}
#pine-emoji button.em:hover, #pine-emoji button.em:focus {{ background-color: {p['accent_soft']}; }}
"""


class Picker(Gtk.Window):
    def __init__(self):
        super().__init__(type=Gtk.WindowType.TOPLEVEL)
        self.set_name("pine-emoji")
        self.set_decorated(False)
        self.set_keep_above(True)
        self.set_skip_taskbar_hint(True)
        self.set_type_hint(Gdk.WindowTypeHint.DIALOG)
        self.set_default_size(COLUMNS * 44 + 24, 400)
        prov = Gtk.CssProvider()
        prov.load_from_data(css().encode())
        Gtk.StyleContext.add_provider_for_screen(Gdk.Screen.get_default(), prov, Gtk.STYLE_PROVIDER_PRIORITY_USER)

        self.all = load()
        box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=8, margin=12)
        self.add(box)
        self.entry = Gtk.SearchEntry(placeholder_text=_("Search emoji"))
        self.entry.connect("search-changed", lambda *_a: self.fill())
        self.entry.connect("activate", lambda *_a: self.pick_first())
        box.pack_start(self.entry, False, False, 0)
        self.title = Gtk.Label(xalign=0)
        self.title.get_style_context().add_class("muted")
        box.pack_start(self.title, False, False, 0)
        sc = Gtk.ScrolledWindow(hscrollbar_policy=Gtk.PolicyType.NEVER)
        sc.set_vexpand(True)
        self.grid = Gtk.FlowBox(selection_mode=Gtk.SelectionMode.NONE, max_children_per_line=COLUMNS,
                                min_children_per_line=COLUMNS, homogeneous=True, valign=Gtk.Align.START)
        sc.add(self.grid)
        box.pack_start(sc, True, True, 0)
        self.connect("key-press-event", self.on_key)
        self.connect("focus-out-event", lambda *_a: GLib.timeout_add(150, self.maybe_close))
        self.connect("destroy", Gtk.main_quit)
        self.fill()
        self.show_all()
        self.place()
        self.present()
        self.entry.grab_focus()

    def place(self):
        """Bottom middle of the main screen, above the taskbar."""
        mon = Gdk.Display.get_default().get_primary_monitor() or Gdk.Display.get_default().get_monitor(0)
        g = mon.get_workarea()
        w, h = self.get_size()
        self.move(g.x + (g.width - w) // 2, g.y + g.height - h - 12)

    def fill(self):
        for c in self.grid.get_children():
            self.grid.remove(c)
        q = self.entry.get_text().strip().lower()
        if q:
            shown = [e for e in self.all if all(w in e[2] or w in e[1].lower() for w in q.split())][:160]
            self.title.set_text(_("Results") if shown else _("Nothing found"))
        else:
            rec = recent()
            shown = [e for e in self.all if e[0] in rec] if rec else self.all[:96]
            shown.sort(key=lambda e: rec.index(e[0]) if e[0] in rec else 0)
            self.title.set_text(_("Recently used") if rec else _("Smileys"))
        self.shown = shown
        for ch, _g, name in shown:
            b = Gtk.Button(label=ch)
            b.get_style_context().add_class("em")
            b.set_tooltip_text(name)
            b.set_can_focus(True)
            b.connect("clicked", lambda _b, ch=ch: self.choose(ch))
            self.grid.add(b)
        self.grid.show_all()

    def pick_first(self):
        if self.shown:
            self.choose(self.shown[0][0])

    def choose(self, ch):
        remember(ch)
        self.hide()
        GLib.timeout_add(200, lambda: (self.type_it(ch), False)[1])

    def type_it(self, ch):
        # focus goes back to the window you were in; xdotool types into it
        subprocess.run(["xdotool", "type", "--clearmodifiers", "--delay", "20", ch])
        Gtk.main_quit()

    def on_key(self, _w, ev):
        if ev.keyval == Gdk.KEY_Escape:
            Gtk.main_quit()
            return True
        return False

    def maybe_close(self):
        if not self.is_active() and self.get_visible():
            Gtk.main_quit()
        return False


def main():
    Picker()
    Gtk.main()


if __name__ == "__main__":
    main()
