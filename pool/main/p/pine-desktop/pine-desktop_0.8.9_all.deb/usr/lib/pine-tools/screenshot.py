#!/usr/bin/python3
"""Pine screenshots (like the Windows Snipping Tool).

  pine-screenshot region   Super+Shift+S, Shift+Print: the screen freezes and dims; drag over
                           an area, or click a window to take just that window. Esc cancels.
  pine-screenshot full     Print: the whole screen
  pine-screenshot window   Alt+Print: the active window (with its title bar)
Every screenshot is copied to the clipboard (paste it anywhere with Ctrl+V) and saved in
Pictures/Screenshots; a notification offers to open it or show it in Files.
"""
import os
import subprocess
import sys
import time

import gi
gi.require_version("Gtk", "3.0")
gi.require_version("Gdk", "3.0")
gi.require_version("GdkX11", "3.0")
gi.require_version("GdkPixbuf", "2.0")
from gi.repository import GLib  # noqa: E402
GLib.set_prgname("pine-screenshot")
import math  # noqa: E402
gi.require_version("PangoCairo", "1.0")
from gi.repository import Gdk, GdkX11, Gtk, PangoCairo  # noqa: E402

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import x11  # noqa: E402

import gettext  # noqa: E402
_ = gettext.translation("pine", fallback=True).gettext

KEEP_CLIPBOARD = 30 * 60      # s: X forgets a copied image when its program ends, so we wait
                              # until something else is copied (or a clipboard manager took it)


def grab_screen():
    """The whole screen as a pixbuf, and the scale (device pixels per GTK pixel)."""
    root = Gdk.get_default_root_window()
    scale = root.get_scale_factor()
    pb = Gdk.pixbuf_get_from_window(root, 0, 0, root.get_width(), root.get_height())
    return pb, scale


def frame_rect(xid):
    """(x, y, w, h) of a window with its frame (title bar), in GTK pixels; None if gone."""
    try:
        gw = GdkX11.X11Window.foreign_new_for_display(Gdk.Display.get_default(), xid)
    except (TypeError, GLib.Error):
        return None
    if gw is None:
        return None
    r = gw.get_frame_extents()
    return (r.x, r.y, r.width, r.height) if r.width > 1 and r.height > 1 else None


def crop(pb, scale, rect):
    x, y, w, h = (round(v * scale) for v in rect)
    x, y = max(0, x), max(0, y)
    w, h = min(w, pb.get_width() - x), min(h, pb.get_height() - y)
    if w < 1 or h < 1:
        return None
    return pb.new_subpixbuf(x, y, w, h).copy()


def save_path():
    pics = GLib.get_user_special_dir(GLib.UserDirectory.DIRECTORY_PICTURES) or os.path.expanduser("~/Pictures")
    folder = os.path.join(pics, _("Screenshots"))
    os.makedirs(folder, exist_ok=True)
    base = os.path.join(folder, _("Screenshot") + time.strftime(" %Y-%m-%d %H-%M-%S"))
    path, n = base + ".png", 2
    while os.path.exists(path):
        path, n = f"{base} ({n}).png", n + 1
    return path


class Shot(Gtk.Application):
    def __init__(self, mode):
        super().__init__(application_id=None)
        self.mode = mode
        # what keeps us running: the screenshot itself, then the clipboard and the notification
        self.pending = 1
        self.clip_done = False

    def do_activate(self):
        self.hold()
        pb, scale = grab_screen()
        if pb is None:
            self.done_one()
            return
        if self.mode == "full":
            self.finish(pb)
        elif self.mode == "window":
            win = x11.active_window()
            rect = frame_rect(win) if win and win in x11.app_windows() else None
            self.finish(crop(pb, scale, rect) if rect else pb)
        else:
            Picker(self, pb, scale).present()

    def finish(self, pb):
        """Copy to the clipboard, save, tell the user."""
        if pb is None:
            self.done_one()
            return
        path = save_path()
        try:
            pb.savev(path, "png", [], [])
        except GLib.Error as e:
            print("pine-screenshot:", e, file=sys.stderr)
            path = None
        cb = Gtk.Clipboard.get(Gdk.SELECTION_CLIPBOARD)
        cb.set_image(pb)
        cb.store()                      # a clipboard manager (if there is one) keeps a copy
        self.pending += 1
        # another program owning the clipboard (owner None: not one of our windows) = copied
        cb.connect("owner-change", lambda _cb, ev: ev.owner is None and self.clipboard_done())
        GLib.timeout_add_seconds(KEEP_CLIPBOARD, self.clipboard_done)
        self.notify(path)
        self.done_one()

    def clipboard_done(self):
        if not self.clip_done:
            self.clip_done = True
            self.done_one()
        return False

    def notify(self, path):
        title = _("Screenshot copied")
        body = (_("Paste it with Ctrl+V. Saved in Pictures, Screenshots.") if path
                else _("Paste it with Ctrl+V. It could not be saved."))
        cmd = ["notify-send", "-a", _("Screenshot"), "-i", path or "applets-screenshooter", "-w",
               title, body]
        if path:
            cmd[cmd.index("-w") + 1:cmd.index("-w") + 1] = ["-A", "open=" + _("Open"),
                                                            "-A", "folder=" + _("Show in Files")]
        try:
            p = subprocess.Popen(cmd, stdout=subprocess.PIPE, text=True)
        except OSError:
            return
        self.pending += 1

        def answered(_pid, _status):
            choice = (p.stdout.read() or "").strip()
            if choice == "open":
                subprocess.Popen(["xdg-open", path])
            elif choice == "folder":
                subprocess.Popen(["pine-files", path])
            self.done_one()
        GLib.child_watch_add(GLib.PRIORITY_DEFAULT, p.pid, answered)

    def done_one(self):
        self.pending -= 1
        if self.pending == 0:
            self.release()


class Picker(Gtk.Window):
    """The frozen, dimmed screen to drag an area on (or click a window)."""
    def __init__(self, app, pb, scale):
        super().__init__(type=Gtk.WindowType.POPUP)
        self.app, self.pb, self.scale = app, pb, scale
        self.start = self.end = None
        self.windows = [(w, frame_rect(w)) for w in x11.app_windows() if not x11.minimized(w)]
        self.windows = [(w, r) for w, r in self.windows if r]
        self.hover = None
        root = Gdk.get_default_root_window()
        self.move(0, 0)
        self.set_default_size(root.get_width(), root.get_height())
        self.area = Gtk.DrawingArea()
        self.area.connect("draw", self.on_draw)
        self.add(self.area)
        self.add_events(Gdk.EventMask.BUTTON_PRESS_MASK | Gdk.EventMask.BUTTON_RELEASE_MASK
                        | Gdk.EventMask.POINTER_MOTION_MASK | Gdk.EventMask.KEY_PRESS_MASK)
        self.connect("button-press-event", self.on_press)
        self.connect("button-release-event", self.on_release)
        self.connect("motion-notify-event", self.on_motion)
        self.connect("key-press-event", self.on_key)
        self.connect("map-event", self.on_map)
        self.show_all()

    def on_map(self, *_a):
        seat = Gdk.Display.get_default().get_default_seat()
        cursor = Gdk.Cursor.new_from_name(Gdk.Display.get_default(), "crosshair")
        for _try in range(20):
            if seat.grab(self.get_window(), Gdk.SeatCapabilities.ALL, False, cursor, None, None) \
                    == Gdk.GrabStatus.SUCCESS:
                break
            GLib.usleep(10000)
        self.on_motion(None, None)
        return False

    def selection(self):
        if not (self.start and self.end):
            return None
        (x1, y1), (x2, y2) = self.start, self.end
        return min(x1, x2), min(y1, y2), abs(x2 - x1), abs(y2 - y1)

    def window_at(self, x, y):
        for w, (rx, ry, rw, rh) in self.windows:          # topmost first
            if rx <= x < rx + rw and ry <= y < ry + rh:
                return (rx, ry, rw, rh)
        return None

    def on_draw(self, _w, cr):
        cr.save()
        cr.scale(1 / self.scale, 1 / self.scale)     # the picture is in device pixels
        Gdk.cairo_set_source_pixbuf(cr, self.pb, 0, 0)
        cr.paint()
        cr.restore()
        sel = self.selection()
        lit = sel if sel and (sel[2] > 4 or sel[3] > 4) else (None if self.start else self.hover)
        # dim everything except the chosen area
        cr.set_source_rgba(0, 0, 0, 0.45)
        cr.rectangle(0, 0, self.get_allocated_width(), self.get_allocated_height())
        if lit:
            cr.rectangle(lit[0] + lit[2], lit[1], -lit[2], lit[3])   # a hole (opposite direction)
        cr.set_fill_rule(0)
        cr.fill()
        if lit:
            accent = self.get_style_context().lookup_color("theme_selected_bg_color")
            c = accent[1] if accent[0] else Gdk.RGBA(0.24, 0.81, 0.49, 1)
            cr.set_source_rgba(c.red, c.green, c.blue, 1)
            cr.set_line_width(2)
            cr.rectangle(lit[0] + 1, lit[1] + 1, max(0, lit[2] - 2), max(0, lit[3] - 2))
            cr.stroke()
            if sel and lit is sel:
                self.draw_size(cr, lit, c)
        self.draw_hint(cr)

    def draw_size(self, cr, r, c):
        text = f"{round(r[2] * self.scale)} × {round(r[3] * self.scale)}"
        layout = self.create_pango_layout(text)
        tw, th = layout.get_pixel_size()
        x, y = r[0], r[1] - th - 10 if r[1] > th + 14 else r[1] + r[3] + 6
        cr.set_source_rgba(0, 0, 0, 0.7)
        self.round_rect(cr, x, y, tw + 12, th + 6, 5)
        cr.fill()
        cr.set_source_rgba(1, 1, 1, 1)
        cr.move_to(x + 6, y + 3)
        PangoCairo.show_layout(cr, layout)

    def draw_hint(self, cr):
        if self.start:
            return
        text = _("Drag over an area, or click a window. Esc cancels.")
        layout = self.create_pango_layout(text)
        tw, th = layout.get_pixel_size()
        mon = Gdk.Display.get_default().get_monitor_at_point(*self.pointer())
        g = mon.get_geometry()
        x, y = g.x + (g.width - tw) / 2 - 14, g.y + 24
        cr.set_source_rgba(0.08, 0.1, 0.1, 0.9)
        self.round_rect(cr, x, y, tw + 28, th + 16, 5)
        cr.fill()
        cr.set_source_rgba(1, 1, 1, 0.95)
        cr.move_to(x + 14, y + 8)
        PangoCairo.show_layout(cr, layout)

    @staticmethod
    def round_rect(cr, x, y, w, h, r):
        cr.new_sub_path()
        cr.arc(x + w - r, y + r, r, -math.pi / 2, 0)
        cr.arc(x + w - r, y + h - r, r, 0, math.pi / 2)
        cr.arc(x + r, y + h - r, r, math.pi / 2, math.pi)
        cr.arc(x + r, y + r, r, math.pi, 3 * math.pi / 2)
        cr.close_path()

    def pointer(self):
        _s, x, y = Gdk.Display.get_default().get_default_seat().get_pointer().get_position()[0:3]
        return x, y

    def on_press(self, _w, ev):
        if ev.button == 1:
            self.start = self.end = (ev.x_root, ev.y_root)
            self.area.queue_draw()
        elif ev.button == 3:
            self.cancel()
        return True

    def on_motion(self, _w, ev):
        x, y = (ev.x_root, ev.y_root) if ev else self.pointer()
        if self.start:
            self.end = (x, y)
        else:
            self.hover = self.window_at(x, y)
        self.area.queue_draw()
        return True

    def on_release(self, _w, ev):
        if ev.button != 1 or not self.start:
            return True
        self.end = (ev.x_root, ev.y_root)
        sel = self.selection()
        if sel[2] <= 4 and sel[3] <= 4:                 # a click: that window, or the screen
            sel = self.window_at(ev.x_root, ev.y_root)
            if sel is None:
                g = Gdk.Display.get_default().get_monitor_at_point(int(ev.x_root), int(ev.y_root)).get_geometry()
                sel = (g.x, g.y, g.width, g.height)
        self.close_picker()
        self.app.finish(crop(self.pb, self.scale, sel))
        return True

    def on_key(self, _w, ev):
        if ev.keyval == Gdk.KEY_Escape:
            self.cancel()
        return True

    def close_picker(self):
        Gdk.Display.get_default().get_default_seat().ungrab()
        self.destroy()

    def cancel(self):
        self.close_picker()
        self.app.done_one()


def main():
    mode = sys.argv[1] if len(sys.argv) > 1 else "region"
    if mode not in ("region", "full", "window"):
        print(__doc__)
        return 1
    return Shot(mode).run([sys.argv[0]])


if __name__ == "__main__":
    sys.exit(main())
