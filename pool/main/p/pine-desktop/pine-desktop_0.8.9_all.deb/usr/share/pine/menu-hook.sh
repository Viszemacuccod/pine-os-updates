#!/bin/sh
# Pine OS: a tidy start menu.
#  - simple app names ("Files" instead of "Nemo")
#  - settings sub-dialogs and developer tools hidden from "All apps"
# Copies go to /usr/local/share/applications, which wins over /usr/share/applications,
# so package updates don't undo this. Only the untranslated Name= line changes:
# other languages keep their own translated names.
set -e
SRC=/usr/share/applications
DST=/usr/local/share/applications
mkdir -p "$DST"

rename() {   # rename <file.desktop> <new name>
    [ -f "$SRC/$1" ] || { echo "pine-menu: $1 not found, skipped"; return 0; }
    sed "s/^Name=.*/Name=$2/" "$SRC/$1" > "$DST/$1"
}
hide() {     # hide <file.desktop>...
    for f in "$@"; do
        [ -f "$SRC/$f" ] || continue
        sed '/^NoDisplay=/d; /^\[Desktop Entry\]/a NoDisplay=true' "$SRC/$f" > "$DST/$f"
    done
}

rename firefox-esr.desktop            "Firefox"
rename nemo.desktop                   "Files"
rename xfce4-terminal.desktop         "Terminal"
rename org.xfce.mousepad.desktop      "Text Editor"
rename org.xfce.ristretto.desktop     "Image Viewer"
rename atril.desktop                  "Document Viewer"
rename org.xfce.Parole.desktop        "Media Player"
rename org.gnome.FileRoller.desktop    "Archive Manager"
rename timeshift-gtk.desktop            "Restore Points"

hide vim.desktop xfce4-appfinder.desktop python3.13.desktop \
     xfce4-terminal-emulator.desktop xfce4-file-manager.desktop xfce4-web-browser.desktop \
     xfce4-mail-reader.desktop xfce4-about.desktop xfce4-taskmanager.desktop nemo.desktop org.xfce.ristretto.desktop org.xfce.Parole.desktop \
     timeshift-gtk.desktop picom.desktop \
     wine.desktop

# All settings live in one app (Pine Settings). Every separate settings window is hidden
# from the menu: XFCE's settings dialogs (category "Settings") and the tools for sound,
# Bluetooth, printers and network connections. They stay installed (tray icons use some).
for f in "$SRC"/*.desktop; do
    id=$(basename "$f")
    case "$id" in org.pineos.Settings.desktop|org.pineos.Page.*.desktop|pine-install.desktop) continue ;; esac
    if grep -qE '^Categories=.*(Settings|X-XFCE-SettingsDialog|X-XFCE-HardwareSettings|X-XFCE-PersonalSettings|X-XFCE-SystemSettings)' "$f"; then
        hide "$id"
    fi
done
hide org.pulseaudio.pavucontrol.desktop blueman-manager.desktop blueman-adapters.desktop \
     system-config-printer.desktop nm-connection-editor.desktop xfce-settings-manager.desktop \
     org.guido-berhoerster.code.package-update-indicator.preferences.desktop
echo "pine-menu: hidden: $(grep -l '^NoDisplay=true' "$DST"/*.desktop | xargs -n1 basename | tr '\n' ' ')"

update-desktop-database -q "$DST" 2>/dev/null || true
