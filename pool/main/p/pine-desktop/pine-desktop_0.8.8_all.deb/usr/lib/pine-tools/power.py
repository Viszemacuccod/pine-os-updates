#!/usr/bin/python3
"""Pine OS power menu (pine-power): the Start menu's power button, Ctrl+Alt+Delete.

The screen dims and the choices stand in the middle (mockups/power-menu.html):
  Lock, Sleep, Sign out  |  Restart, Shut down
  Restart into Windows   (only when another system is in the boot menu)
with a note when apps are still open, and Restart / Shut down wait while Pine Update is
installing. Arrows choose, Enter starts, Esc or a click outside cancels; Shut down is chosen
when it opens.
"""
import os
import pwd
import subprocess
import sys

import gi
gi.require_version("Gtk", "3.0")
gi.require_version("Gdk", "3.0")
gi.require_version("GdkPixbuf", "2.0")
from gi.repository import GLib  # noqa: E402
GLib.set_prgname("pine-power")
from gi.repository import Gdk, GdkPixbuf, Gio, Gtk  # noqa: E402

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(1, "/usr/lib/pine-settings")
import x11  # noqa: E402
import theme  # noqa: E402  (Pine colors, dark / light mode, accent)

import gettext  # noqa: E402
_ = gettext.translation("pine", fallback=True).gettext

FACE = os.path.expanduser("~/.face")

ACTIONS = {   # what each choice runs; the session ends itself for the last three
    "lock": ["xflock4"],
    "sleep": ["systemctl", "suspend"],
    "logout": ["xfce4-session-logout", "--logout", "--fast"],
    "restart": ["xfce4-session-logout", "--reboot", "--fast"],
    "shutdown": ["xfce4-session-logout", "--halt", "--fast"],
    "windows": ["pkexec", "/usr/libexec/pine-restart-other"],
}


def css():
    mode, accent = theme.saved()
    p = theme.colors(mode, accent)
    dark = mode != "light"
    veil = "rgba(6, 9, 12, 0.86)" if dark else "rgba(238, 242, 240, 0.88)"
    # cards, badges and buttons like Pine Settings (theme.SETTINGS_LOOK)
    tile, tile_h = p["card"], p["card_hover"]
    soft = p["accent_soft"]
    return f"""
#pine-power {{ background-color: {veil}; color: {p['fg']}; font-family: Inter, sans-serif; }}
#pine-power.solid {{ background-color: {p['bg']}; }}
#pine-power label {{ color: {p['fg']}; }}
#pine-power .title {{ font-size: 20pt; font-weight: 600; }}
#pine-power .muted {{ color: {p['muted']}; }}
#pine-power .avatar {{ border-radius: 5px; background-color: {p['accent']}; color: {p['on_accent']};
  font-size: 20pt; font-weight: 600; min-width: 64px; min-height: 64px; }}
#pine-power .avatar label {{ color: {p['on_accent']}; }}
#pine-power button.tile {{ min-width: 124px; min-height: 124px; padding: 0; border-radius: 5px;
  border: 1px solid transparent; background-image: none; background-color: {tile}; box-shadow: none;
  outline: none; transition: background-color 120ms ease-out; }}
#pine-power button.tile:hover, #pine-power button.tile:focus {{ background-color: {tile_h};
  border-color: {p['accent_line']}; }}
#pine-power button.tile:focus {{ box-shadow: 0 0 0 2px {p['accent']}; }}
#pine-power button.tile .ring {{ min-width: 54px; min-height: 54px; border-radius: 5px;
  background-color: {soft}; color: {p['badge_fg']}; }}
#pine-power button.tile .ring image {{ color: {p['badge_fg']}; }}
#pine-power button.tile:hover .ring, #pine-power button.tile:focus .ring {{ background-color: {p['accent']}; }}
#pine-power button.tile:hover .ring image, #pine-power button.tile:focus .ring image {{ color: {p['on_accent']}; }}
#pine-power button.tile .name {{ font-weight: 500; }}
#pine-power button.tile:disabled {{ opacity: 0.45; }}
#pine-power button.tile .small {{ color: {p['muted']}; font-size: 0.82em; }}
#pine-power .sep {{ background-color: {p['line']}; min-width: 1px; margin: 12px 4px; }}
#pine-power button.ghost {{ border-radius: 5px; border: none; background-image: none;
  background-color: {p['btn']}; box-shadow: none; padding: 6px 14px; outline: none; }}
#pine-power button.ghost:hover, #pine-power button.ghost:focus {{ background-color: {p['btn_hover']}; }}
#pine-power button.ghost image {{ color: {p['muted']}; }}
#pine-power .note {{ border-radius: 5px; padding: 10px 14px; background-color: rgba(255, 179, 92, 0.10);
  border: 1px solid rgba(255, 179, 92, 0.30); }}
#pine-power .note image {{ color: {'#ffb35c' if dark else '#b86a00'}; }}
#pine-power button.cancel {{ border-radius: 5px; border: none; background-image: none; box-shadow: none;
  background-color: {p['btn']}; padding: 8px 24px; font-weight: 500; outline: none; }}
#pine-power button.cancel:hover, #pine-power button.cancel:focus {{ background-color: {p['btn_hover']}; }}
#pine-power spinner {{ color: {p['accent']}; }}
"""


# ---------------------------------------------------------------- what is going on
def real_name():
    p = pwd.getpwuid(os.getuid())
    return p.pw_gecos.split(",")[0] or p.pw_name


_APPS = None


def _apps():
    """{lowercase window class / program name / desktop id: app name} of the menu's apps."""
    global _APPS
    if _APPS is None:
        _APPS = {}
        for a in Gio.AppInfo.get_all():
            if not isinstance(a, Gio.DesktopAppInfo) or a.get_nodisplay():
                continue        # (hidden helpers like "Text Editor Settings" never win)
            name = a.get_name()
            keys = [a.get_startup_wm_class(), os.path.basename((a.get_executable() or "")),
                    (a.get_id() or "")[:-len(".desktop")]]
            for k in keys:
                if k:
                    _APPS.setdefault(k.lower(), name)
                    _APPS.setdefault(k.lower().split(".")[-1], name)   # org.xfce.mousepad -> mousepad
    return _APPS


def app_name(xid):
    """The name people know an open window's app by (its menu entry), or its title."""
    inst, cls = x11.wm_class(xid)
    apps = _apps()
    for n in (cls, inst):
        if n and n.lower() in apps:
            return apps[n.lower()]
    return x11.title(xid) or cls


def open_apps():
    names = []
    for w in x11.app_windows(all_desktops=True):
        n = app_name(w)
        if n and n not in names:
            names.append(n)
    return names


def updating():
    """Is Pine Update installing (it blocks shutting down while it does)?"""
    try:
        out = subprocess.run(["systemd-inhibit", "--list", "--no-pager", "--no-legend"],
                             capture_output=True, text=True, timeout=5).stdout
    except (OSError, subprocess.TimeoutExpired):
        return False
    return any("Pine Update" in line and "block" in line for line in out.splitlines())


def other_system():
    """Another system in the boot menu (e.g. Windows): its name, or None."""
    try:
        with open("/boot/grub/grub.cfg", errors="replace") as f:
            for line in f:
                line = line.strip()
                if line.startswith("menuentry ") and "--class os" in line:
                    q = line[len("menuentry "):].lstrip()[:1]
                    name = line.split(q)[1] if q in "'\"" else ""
                    return "Windows" if "windows" in name.lower() else name.split(" (on ")[0] or "Windows"
    except OSError:
        # grub.cfg may be root's only: a Windows disk has a "Microsoft reserved" partition
        try:
            out = subprocess.run(["lsblk", "-rno", "PARTTYPE"], capture_output=True, text=True, timeout=5).stdout
            if "e3c9e316-0b5c-4db8-817d-f92df00215ae" in out.lower():
                return "Windows"
        except (OSError, subprocess.TimeoutExpired):
            pass
    return None


# ---------------------------------------------------------------- the window
def styled(w, *classes):
    for c in classes:
        w.get_style_context().add_class(c)
    return w


def icon(name, size):
    img = Gtk.Image.new_from_icon_name(name, Gtk.IconSize.BUTTON)
    img.set_pixel_size(size)
    return img


class PowerMenu(Gtk.Window):
    def __init__(self, app):
        super().__init__(application=app, title="Pine OS power")
        self.set_name("pine-power")
        self.set_decorated(False)
        self.set_skip_taskbar_hint(True)
        self.set_skip_pager_hint(True)
        self.set_keep_above(True)
        screen = self.get_screen()
        vis = screen.get_rgba_visual()
        if vis and screen.is_composited():
            self.set_visual(vis)          # see-through: the desktop shows dimmed under the menu
        else:
            styled(self, "solid")
        disp = Gdk.Display.get_default()
        mon = disp.get_primary_monitor() or disp.get_monitor(0)
        g = mon.get_geometry()
        # the whole main screen, above the taskbar too
        self.move(g.x, g.y)
        self.set_default_size(g.width, g.height)
        self.fullscreen()
        self.connect("key-press-event", self.on_key)
        self.connect("button-press-event", self.on_click)
        self.add_events(Gdk.EventMask.BUTTON_PRESS_MASK)
        self.connect("focus-out-event", lambda *a: False)

        self.stack = Gtk.Stack(transition_type=Gtk.StackTransitionType.CROSSFADE, transition_duration=180)
        self.add(self.stack)
        self.stack.add_named(self.menu(), "menu")
        self.stack.add_named(self.busy_page(), "busy")
        self.show_all()
        self.notes_update()
        # Shut down is chosen when it opens. GTK gives the first button the focus when the
        # window is mapped (after this), so the choice is made once it is on screen.
        self.connect("map-event", lambda *a: GLib.timeout_add(60, self.focus_default))

    def focus_default(self):
        self.present()
        self.default.grab_focus()
        return False

    # ---- the choices
    def menu(self):
        outer = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, halign=Gtk.Align.CENTER, valign=Gtk.Align.CENTER)
        self.panel = outer
        name = real_name()
        av = styled(Gtk.Box(halign=Gtk.Align.CENTER), "avatar")
        pic = None
        if os.path.exists(FACE):
            try:
                pic = GdkPixbuf.Pixbuf.new_from_file_at_scale(FACE, 64, 64, False)
            except GLib.Error:
                pic = None
        if pic:
            av.pack_start(Gtk.Image.new_from_pixbuf(pic), True, True, 0)
        else:
            lb = Gtk.Label(label=(name[:1] or "?").upper(), hexpand=True)
            av.pack_start(lb, True, True, 0)
        outer.pack_start(av, False, False, 0)
        title = styled(Gtk.Label(label=_("What would you like to do?"), margin_top=14), "title")
        outer.pack_start(title, False, False, 0)
        outer.pack_start(styled(Gtk.Label(label=_("Signed in as {name}").format(name=name), margin_top=2,
                                          margin_bottom=28), "muted"), False, False, 0)

        self.update_busy = updating()
        row = Gtk.Box(spacing=12, halign=Gtk.Align.CENTER)
        self.tiles = {}
        for key, ic, text in (("lock", "system-lock-screen-symbolic", _("Lock")),
                              ("sleep", "weather-clear-night-symbolic", _("Sleep")),
                              ("logout", "system-log-out-symbolic", _("Sign out")),
                              (None, None, None),
                              ("restart", "system-reboot-symbolic", _("Restart")),
                              ("shutdown", "system-shutdown-symbolic", _("Shut down"))):
            if key is None:
                row.pack_start(styled(Gtk.Box(), "sep"), False, False, 0)
                continue
            row.pack_start(self.tile(key, ic, text), False, False, 0)
        self.default = self.tiles["shutdown"] if self.tiles["shutdown"].get_sensitive() else self.tiles["lock"]
        outer.pack_start(row, False, False, 0)

        other = other_system()
        if other:
            b = styled(Gtk.Button(halign=Gtk.Align.CENTER, margin_top=16), "ghost")
            inner = Gtk.Box(spacing=8)
            inner.pack_start(icon("computer-symbolic", 15), False, False, 0)
            inner.pack_start(Gtk.Label(label=_("Restart into {system}").format(system=other)), False, False, 0)
            b.add(inner)
            b.connect("clicked", lambda *a: self.run("windows"))
            b.set_sensitive(not self.update_busy)
            outer.pack_start(b, False, False, 0)

        self.notes = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=8, margin_top=18, halign=Gtk.Align.CENTER)
        outer.pack_start(self.notes, False, False, 0)

        cancel = styled(Gtk.Button(label=_("Cancel"), halign=Gtk.Align.CENTER, margin_top=24), "cancel")
        cancel.connect("clicked", lambda *a: self.quit())
        outer.pack_start(cancel, False, False, 0)
        # (no key hints under it: arrows, Enter and Esc work, the screen stays calm)
        return outer

    def tile(self, key, icon_name, text):
        b = styled(Gtk.Button(), "tile")
        box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=12, valign=Gtk.Align.CENTER)
        ring = styled(Gtk.Box(halign=Gtk.Align.CENTER), "ring")
        ring.pack_start(icon(icon_name, 26), True, True, 0)
        box.pack_start(ring, False, False, 0)
        box.pack_start(styled(Gtk.Label(label=text), "name"), False, False, 0)
        if key in ("restart", "shutdown") and self.update_busy:
            box.pack_start(styled(Gtk.Label(label=_("after the update")), "small"), False, False, 0)
            b.set_sensitive(False)
        b.add(box)
        b.connect("clicked", lambda *a: self.run(key))
        self.tiles[key] = b
        return b

    def note(self, icon_name, bold, text):
        n = styled(Gtk.Box(spacing=10), "note")
        n.pack_start(icon(icon_name, 17), False, False, 0)
        lb = Gtk.Label(xalign=0, wrap=True, max_width_chars=64)
        lb.set_markup(f"<b>{GLib.markup_escape_text(bold)}</b> {GLib.markup_escape_text(text)}")
        n.pack_start(lb, True, True, 0)
        self.notes.pack_start(n, False, False, 0)
        n.show_all()

    def notes_update(self):
        apps = open_apps()
        if apps:
            head = _("1 app is still open:") if len(apps) == 1 else _("{n} apps are still open:").format(n=len(apps))
            self.note("dialog-warning-symbolic", head,
                      ", ".join(apps[:4]) + ("…" if len(apps) > 4 else "") + ". "
                      + _("Signing out, restarting and shutting down close them; unsaved work may be lost."))
        if self.update_busy:
            self.note("software-update-available-symbolic", _("Updates are being installed."),
                      _("Restart and Shut down wait until they are finished, so nothing breaks."))

    # ---- doing it
    def busy_page(self):
        box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=18, halign=Gtk.Align.CENTER, valign=Gtk.Align.CENTER)
        self.spinner = Gtk.Spinner(width_request=34, height_request=34)
        box.pack_start(self.spinner, False, False, 0)
        self.busy_text = styled(Gtk.Label(), "title")
        box.pack_start(self.busy_text, False, False, 0)
        return box

    def run(self, key):
        cmd = ACTIONS[key]
        if key in ("lock", "sleep", "windows"):
            # out of the way first: the lock screen and the password question need the screen
            self.hide()
            GLib.timeout_add(250, lambda: (self.spawn(cmd), self.quit(), False)[2])
            return
        self.busy_text.set_text({"logout": _("Signing out…"), "restart": _("Restarting…"),
                                 "shutdown": _("Shutting down…")}[key])
        self.spinner.start()
        self.stack.set_visible_child_name("busy")
        GLib.timeout_add(400, lambda: (self.spawn(cmd), False)[1])
        # the session ends and takes this window with it; if it doesn't (cancelled), go away
        GLib.timeout_add_seconds(30, lambda: (self.quit(), False)[1])

    @staticmethod
    def spawn(cmd):
        try:
            subprocess.Popen(cmd, stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL,
                             stderr=subprocess.DEVNULL, start_new_session=True)
        except OSError as e:
            print("pine-power:", e, file=sys.stderr)

    def quit(self):
        self.get_application().quit()

    def on_key(self, _w, ev):
        if ev.keyval == Gdk.KEY_Escape and self.stack.get_visible_child_name() == "menu":
            self.quit()
            return True
        return False

    def on_click(self, _w, ev):
        # a click on the dimmed screen (outside the panel) cancels
        if self.stack.get_visible_child_name() != "menu":
            return False
        a = self.panel.get_allocation()
        if not (a.x <= ev.x <= a.x + a.width and a.y <= ev.y <= a.y + a.height):
            self.quit()
        return False


class App(Gtk.Application):
    def __init__(self):
        super().__init__(application_id="org.pineos.Power")
        self.win = None

    def do_startup(self):
        Gtk.Application.do_startup(self)
        prov = Gtk.CssProvider()
        prov.load_from_data(css().encode())
        Gtk.StyleContext.add_provider_for_screen(Gdk.Screen.get_default(), prov,
                                                 Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION + 1)

    def do_activate(self):
        if self.win:
            self.win.present()
            return
        self.win = PowerMenu(self)
        self.win.present_with_time(Gtk.get_current_event_time() or GLib.get_monotonic_time() // 1000)


if __name__ == "__main__":
    sys.exit(App().run(sys.argv[:1]))
