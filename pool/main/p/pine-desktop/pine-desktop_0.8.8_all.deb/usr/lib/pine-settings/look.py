"""Pine look for GTK 4 / libadwaita apps (Pine Settings, Welcome, installer dialogs):
the saved dark / light mode and accent color as app CSS."""
import gi
gi.require_version("Gtk", "4.0")
gi.require_version("Adw", "1")
from gi.repository import Adw, Gdk, Gtk  # noqa: E402

import theme  # noqa: E402


LOOK = theme.ADW


def theme_css(accent, mode="dark"):

    v = LOOK.get(mode, LOOK["dark"])
    mix = v["mix"]
    return f"""
:root {{
{theme.adw_vars(accent, mode)}}}
.pine-hero {{ padding: 18px 20px; }}
.pine-badge {{ background-color: color-mix(in srgb, {accent} 16%, transparent);
              color: color-mix(in srgb, {accent} {100 if mode == 'dark' else 70}%, {mix}); border-radius: 5px; padding: 12px; }}
.pine-row-icon {{ color: color-mix(in srgb, {accent} 75%, {mix}); }}
.pine-pill {{ background-color: color-mix(in srgb, {accent} 18%, transparent);
             color: color-mix(in srgb, {accent} {80 if mode == 'dark' else 60}%, {mix}); border-radius: 5px;
             padding: 2px 10px; font-size: 0.85em; font-weight: 600; }}
.pine-pill.pine-pill-dim {{ background-color: color-mix(in srgb, currentColor 10%, transparent); color: inherit; opacity: 0.75; }}
.pine-pill.pine-warn {{ background-color: rgba(255, 179, 92, 0.16); color: {'#ffb35c' if mode == 'dark' else '#9a5a00'}; }}
.pine-mono {{ font-family: monospace; font-size: 0.9em; }}
.pine-usercard {{ padding: 10px 8px; border-radius: 5px; }}
.pine-swatch {{ min-width: 30px; min-height: 30px; padding: 0; border-radius: 5px; }}
.pine-swatch.selected {{ box-shadow: 0 0 0 2px {v['window']}, 0 0 0 4px {v['fg']}; }}
.pine-mode {{ padding: 6px; border-radius: 5px; }}
.pine-mode.selected {{ box-shadow: inset 0 0 0 3px {accent}; }}
.pine-mode label {{ margin-top: 6px; }}
.pine-wall {{ padding: 3px; border-radius: 5px; }}
.pine-wall.selected {{ box-shadow: inset 0 0 0 3px {accent}; }}
.pine-wall picture {{ border-radius: 5px; }}
levelbar.pine-storage block.filled {{ background-color: {accent}; }}
.navigation-sidebar > row {{ min-height: 40px; }}
.navigation-sidebar > row:selected {{ background-color: color-mix(in srgb, {accent} 16%, transparent); }}
.navigation-sidebar > row:selected image {{ color: {accent}; }}
""" + theme.GTK4_SHAPE + theme.gtk4_titlebuttons(mode)


def saved_look():
    """(mode, accent) from ~/.config/pine/settings.json."""
    return theme.saved()


def apply(provider=None, mode=None, accent=None):
    """Use the Pine look in this app. Returns the CSS provider (keep it to update later)."""
    sm, sa = saved_look()
    mode, accent = mode or sm, accent or sa
    Adw.StyleManager.get_default().set_color_scheme(
        Adw.ColorScheme.FORCE_LIGHT if mode == "light" else Adw.ColorScheme.FORCE_DARK)
    if provider is None:
        provider = Gtk.CssProvider()
        Gtk.StyleContext.add_provider_for_display(Gdk.Display.get_default(), provider,
                                                  Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION)
    provider.load_from_string(theme_css(accent, mode))
    return provider
