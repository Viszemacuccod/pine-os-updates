#!/usr/bin/python3
"""Pine Settings: one place for every setting of Pine OS.

Usage: pine-settings [page]     e.g. pine-settings display
       pine-settings --apply    re-apply saved display and mouse settings (runs at sign-in)
"""
import os
import pwd
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

import gi  # noqa: E402
gi.require_version("Gtk", "4.0")
gi.require_version("Adw", "1")
from gi.repository import Adw, Gdk, Gio, GLib, Gtk  # noqa: E402

import common  # noqa: E402
from common import load_config, DEFAULT_ACCENT  # noqa: E402

APP_ID = "org.pineos.Settings"

# ---------------------------------------------------------------- pages
import pg_system, pg_devices, pg_network, pg_personal, pg_apps, pg_startup, pg_accounts, pg_time, pg_access, pg_update  # noqa
import pg_drivers, pg_firewall, pg_recovery  # noqa

MODULES = [pg_system, pg_devices, pg_network, pg_personal, pg_apps, pg_startup, pg_accounts, pg_time, pg_access, pg_update,
           pg_drivers, pg_firewall, pg_recovery]

# Sidebar order: (page id, label, icon)
NAV = [
    ("system", "System", "computer-symbolic"),
    # without Bluetooth hardware: just "Devices"; without Wi-Fi: a network cable icon
    ("devices", pg_devices.DEVICES_TITLE, "bluetooth-active-symbolic" if pg_devices.has_bluetooth() else "input-mouse-symbolic"),
    ("network", "Network & internet", "network-wireless-symbolic" if pg_network.has_wifi() else "network-wired-symbolic"),
    ("personal", "Personalization", "applications-graphics-symbolic"),
    ("apps", "Apps", "view-app-grid-symbolic"),
    ("startup", "Startup", "system-run-symbolic"),
    ("accounts", "Accounts", "system-users-symbolic"),
    ("time", "Time & language", "preferences-system-time-symbolic"),
    ("access", "Accessibility", "preferences-desktop-accessibility-symbolic"),
    ("update", "Pine Update", "software-update-available-symbolic"),
]

PAGES = {}     # id -> dict(title, build, parent)
SEARCH = []    # (title, subtitle, page id)
for m in MODULES:
    PAGES.update(m.PAGES)
    SEARCH.extend(m.SEARCH)
# In the user's language (common._; untranslated text stays English)
NAV = [(pid, common._(label), icon) for pid, label, icon in NAV]
for _info in PAGES.values():
    _info["title"] = common._(_info["title"])
SEARCH[:] = [(common._(t), common._(s), p) for t, s, p in SEARCH]

# Names that may be given on the command line
ALIASES = {"bluetooth": "devices", "wifi": "network", "background": "personal",
           "wallpaper": "personal", "language": "time", "users": "accounts",
           "updates": "update", "mouse": "mouse", "printers": "printers", "autostart": "startup",
           "reset": "recovery", "restore": "recovery", "ufw": "firewall"}


from look import theme_css  # noqa: E402  (Pine colors, shared with Welcome)


class Window(Adw.ApplicationWindow):
    def __init__(self, app):
        super().__init__(application=app, title="Settings")
        self.set_default_size(1040, 720)
        self.set_size_request(360, 400)
        common.WINDOW = self
        self.current_top = None

        self.toasts = Adw.ToastOverlay()
        self.split = Adw.NavigationSplitView()
        self.split.set_min_sidebar_width(260)
        self.split.set_max_sidebar_width(300)
        self.toasts.set_child(self.split)
        self.set_content(self.toasts)

        # Narrow window: sidebar and page on top of each other
        bp = Adw.Breakpoint.new(Adw.BreakpointCondition.parse("max-width: 640sp"))
        bp.add_setter(self.split, "collapsed", True)
        self.add_breakpoint(bp)

        self.split.set_sidebar(self._build_sidebar())
        # Pages inside a section slide (NavigationView); switching sections cross-fades
        # (the stack). Both follow the "Animation effects" setting through GTK.
        self.stack = Gtk.Stack(transition_type=Gtk.StackTransitionType.CROSSFADE, transition_duration=180)
        self.nav = Adw.NavigationView()
        self.stack.add_child(self.nav)
        self.content = Adw.NavigationPage(title="Settings", child=self.stack)
        self.split.set_content(self.content)

    def _swap_nav(self, pages):
        """Show a fresh set of pages, cross-fading from the old ones."""
        old, self.nav = self.nav, Adw.NavigationView()
        self.nav.replace(pages)
        self.stack.add_child(self.nav)
        self.stack.set_visible_child(self.nav)

        def drop():
            if old.get_parent() is self.stack:
                self.stack.remove(old)
            return False
        GLib.timeout_add(self.stack.get_transition_duration() + 120, drop)

    # ---------------------------------------------------------- sidebar
    def _build_sidebar(self):
        box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=6)
        box.set_margin_start(10)
        box.set_margin_end(10)
        box.set_margin_bottom(10)

        # You: picture and name, opens Accounts
        user = pwd.getpwuid(os.getuid())
        name = user.pw_gecos.split(",")[0] or user.pw_name
        card = Gtk.Button()
        card.add_css_class("flat")
        card.add_css_class("pine-usercard")
        inner = Gtk.Box(spacing=12)
        self.avatar = Adw.Avatar(size=48, text=name, show_initials=True)
        pg_accounts.load_avatar(self.avatar)
        inner.append(self.avatar)
        texts = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, valign=Gtk.Align.CENTER)
        n = Gtk.Label(label=name, xalign=0)
        n.add_css_class("heading")
        texts.append(n)
        s = Gtk.Label(label="Local account", xalign=0)
        s.add_css_class("dim-label")
        s.add_css_class("caption")
        texts.append(s)
        inner.append(texts)
        card.set_child(inner)
        card.connect("clicked", lambda *_: self.show_page("accounts"))
        box.append(card)

        self.search = Gtk.SearchEntry(placeholder_text="Find a setting")
        self.search.connect("search-changed", self._on_search)
        box.append(self.search)

        self.list = Gtk.ListBox()
        self.list.add_css_class("navigation-sidebar")
        self.rows = {}
        for pid, label, icon in NAV:
            r = Gtk.ListBoxRow()
            hb = Gtk.Box(spacing=12)
            hb.set_margin_start(6)
            hb.append(Gtk.Image.new_from_icon_name(icon))
            hb.append(Gtk.Label(label=label, xalign=0))
            r.set_child(hb)
            r.pid = pid
            self.rows[pid] = r
            self.list.append(r)
        self.list.connect("row-activated", lambda _l, r: self.show_page(r.pid))
        sc = Gtk.ScrolledWindow(vexpand=True, hscrollbar_policy=Gtk.PolicyType.NEVER)
        sc.set_child(self.list)
        box.append(sc)

        tv = Adw.ToolbarView()
        tv.add_top_bar(Adw.HeaderBar())
        tv.set_content(box)
        return Adw.NavigationPage(title="Settings", child=tv)

    # ---------------------------------------------------------- pages
    def _make_page(self, pid):
        info = PAGES[pid]
        try:
            widget = info["build"]()
        except Exception as ex:  # a broken page must not take the whole app down
            import traceback
            traceback.print_exc()
            widget = Adw.StatusPage(icon_name="dialog-warning-symbolic", title="This page could not be opened",
                                    description=str(ex))
        tv = Adw.ToolbarView()
        tv.add_top_bar(Adw.HeaderBar())
        tv.set_content(widget)
        return Adw.NavigationPage(title=info["title"], tag=pid, child=tv)

    def show_page(self, pid):
        pid = ALIASES.get(pid, pid)
        if pid not in PAGES:
            pid = "system"
        top = PAGES[pid].get("parent") or pid
        if self.search.get_text():
            self.search.set_text("")
        self.list.select_row(self.rows[top])
        if top == pid:
            self._swap_nav([self._make_page(pid)])
        elif self.current_top == top and self.nav.get_visible_page() is not None:
            self.nav.push(self._make_page(pid))
        else:
            self._swap_nav([self._make_page(top), self._make_page(pid)])
        self.current_top = top
        self.content.set_title(PAGES[top]["title"])
        self.split.set_show_content(True)

    def refresh(self):
        """Rebuild the visible page (after a change that affects what it shows)."""
        vis = self.nav.get_visible_page()
        if vis is None:
            return
        stack = [p.get_tag() for p in self._stack()]
        self.nav.replace([self._make_page(t) for t in stack])

    def _stack(self):
        pages, model = [], self.nav.get_navigation_stack()
        for i in range(model.get_n_items()):
            pages.append(model.get_item(i))
        return pages

    # ---------------------------------------------------------- search
    def _on_search(self, entry):
        q = entry.get_text().strip().lower()
        if not q:
            if self.current_top:
                self._swap_nav([self._make_page(self.current_top)])
            return
        def norm(text):   # "Wi-Fi" and "wifi" are the same word
            return "".join(ch for ch in text.lower() if ch.isalnum() or ch == " ")
        words = [norm(w) for w in q.split() if norm(w)]
        hits = [(t, s, p) for (t, s, p) in SEARCH
                if all(w in norm(f"{t} {s} {PAGES[p]['title']}").replace(" ", "") or
                       w in norm(f"{t} {s} {PAGES[p]['title']}") for w in words)]
        g = common.group(None)
        if not hits:
            content = Adw.StatusPage(icon_name="system-search-symbolic", title="No results",
                                     description="Try a different word, like “wifi”, “wallpaper” or “language”.")
        else:
            for t, s, p in hits[:40]:
                where = PAGES[p]["title"]
                g.add(common.row(t, f"{where} · {s}" if s else where, nav=p))
            content = common.page("Search", g)
        tv = Adw.ToolbarView()
        tv.add_top_bar(Adw.HeaderBar())
        tv.set_content(content)
        self.list.unselect_all()
        results = Adw.NavigationPage(title=f"Results for “{entry.get_text().strip()}”", tag="search", child=tv)
        vis = self.nav.get_visible_page()
        if vis is not None and vis.get_tag() == "search":
            self.nav.replace([results])       # typing more: update in place
        else:
            self._swap_nav([results])
        self.split.set_show_content(True)

    def toast(self, text):
        t = Adw.Toast.new(text)
        t.set_timeout(3)
        self.toasts.add_toast(t)


class App(Adw.Application):
    def __init__(self):
        super().__init__(application_id=APP_ID, flags=Gio.ApplicationFlags.HANDLES_COMMAND_LINE)
        self.win = None
        self.css = Gtk.CssProvider()

    def apply_look(self):
        """Pine Settings' own colors: the saved mode (dark / light) and accent color."""
        cfg = load_config()
        accent, mode = cfg.get("accent", DEFAULT_ACCENT), cfg.get("mode", "dark")
        Adw.StyleManager.get_default().set_color_scheme(
            Adw.ColorScheme.FORCE_LIGHT if mode == "light" else Adw.ColorScheme.FORCE_DARK)
        self.css.load_from_string(theme_css(accent, mode))

    def do_startup(self):
        Adw.Application.do_startup(self)
        Gtk.Window.set_default_icon_name("org.xfce.settings.manager")
        self.apply_look()
        Gtk.StyleContext.add_provider_for_display(Gdk.Display.get_default(), self.css,
                                                  Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION)
        quit_action = Gio.SimpleAction.new("quit", None)
        quit_action.connect("activate", lambda *_: self.quit())
        self.add_action(quit_action)
        self.set_accels_for_action("app.quit", ["<Control>q", "<Control>w"])

    def do_command_line(self, cmdline):
        args = cmdline.get_arguments()[1:]
        target = next((a for a in args if not a.startswith("-")), None)
        if self.win is None:
            self.win = Window(self)
            self.win.show_page(target or "system")
        elif target:
            self.win.show_page(target)
        self.win.present()
        return 0


def main():
    if "--apply" in sys.argv:
        import apply
        return apply.main()
    # Window class = app id, so the taskbar matches the window with the pinned Settings icon
    GLib.set_prgname(APP_ID)
    return App().run(sys.argv)


if __name__ == "__main__":
    sys.exit(main())
