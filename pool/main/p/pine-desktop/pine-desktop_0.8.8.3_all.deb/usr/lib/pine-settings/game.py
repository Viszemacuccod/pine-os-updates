"""Pine OS Game mode (the Game mode tile in Quick Settings): as much of the computer as
possible for the game, everything that is only nice to have is paused.

On:
  - gamemode's performance settings (CPU at full speed, the game first), while it is on
  - no compositor (picom: shadows, rounded corners and animations cost frames)
  - no window pictures: the taskbar's previews (docklike) are off, Alt+Tab shows app icons
  - no pop-up notifications (Do not disturb)
  - paused helpers: desktop icons (nemo-desktop), the low disk space check,
    the thumbnail maker (tumblerd, D-Bus starts it again when a program needs it)
Off: everything back the way it was.

What was changed is written to ~/.config/pine/game-mode-restore.json first, so signing out
with Game mode on can't leave it behind: sign-in (pine-settings --apply) puts it back.
No GTK here.
"""
import glob
import json
import os
import re
import shutil
import subprocess

RUNTIME = os.environ.get("XDG_RUNTIME_DIR") or "/tmp"
GAME_PID = os.path.join(RUNTIME, "pine-game-mode.pid")
CONFIG = os.environ.get("XDG_CONFIG_HOME") or os.path.expanduser("~/.config")
RESTORE = os.path.join(CONFIG, "pine", "game-mode-restore.json")
DOCKLIKE_DEFAULT = "/etc/xdg/xfce4/panel/docklike.rc"


def _run(cmd, timeout=10):
    try:
        p = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout)
        return p.returncode, p.stdout.strip()
    except (OSError, subprocess.TimeoutExpired):
        return 1, ""


def _spawn(cmd):
    try:
        subprocess.Popen(cmd, stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL,
                         stderr=subprocess.DEVNULL, start_new_session=True)
    except OSError:
        pass


def _mine(name, full=False):
    """Is a program of this user running (pgrep, by name or by full command line)?"""
    return _run(["pgrep", "-u", str(os.getuid()), "-f" if full else "-x", name])[0] == 0


def _stop(name, full=False):
    _run(["pkill", "-u", str(os.getuid()), "-f" if full else "-x", name])


def active():
    """Is Game mode on?"""
    try:
        with open(GAME_PID) as f:
            os.kill(int(f.read().strip()), 0)
        return True
    except (OSError, ValueError):
        return False


# ---------------------------------------------------------------- taskbar window previews
def _docklike_rcs():
    """The user's docklike settings files (made from the system default if there are none)."""
    rc, out = _run(["xfconf-query", "-c", "xfce4-panel", "-l", "-v"])
    files = []
    for m in re.finditer(r"^/plugins/plugin-(\d+)\s+docklike$", out, re.M):
        user_rc = os.path.join(CONFIG, "xfce4", "panel", f"docklike-{m.group(1)}.rc")
        if not os.path.exists(user_rc) and os.path.exists(DOCKLIKE_DEFAULT):
            os.makedirs(os.path.dirname(user_rc), exist_ok=True)
            shutil.copyfile(DOCKLIKE_DEFAULT, user_rc)
        if os.path.exists(user_rc):
            files.append(user_rc)
    return files


def taskbar_previews():
    """Are the taskbar's window previews on (True if there is no docklike at all)?"""
    for rc in glob.glob(os.path.join(CONFIG, "xfce4", "panel", "docklike-*.rc")) or [DOCKLIKE_DEFAULT]:
        try:
            with open(rc) as f:
                if re.search(r"(?m)^showPreviews=false$", f.read()):
                    return False
        except OSError:
            pass
    return True


def set_taskbar_previews(on):
    """Turn the taskbar's window previews on or off (docklike reads it only when the taskbar
    starts, so the taskbar restarts, about a second)."""
    changed = False
    for rc in _docklike_rcs():
        with open(rc) as f:
            text = f.read()
        value = "true" if on else "false"
        new, n = re.subn(r"(?m)^showPreviews=.*$", f"showPreviews={value}", text)
        if not n:
            new = text.rstrip("\n") + f"\nshowPreviews={value}\n"
        if new != text:
            with open(rc, "w") as f:
                f.write(new)
            changed = True
    if changed:
        _spawn(["xfce4-panel", "--restart"])


# ---------------------------------------------------------------- on / off
def _dnd():
    return _run(["xfconf-query", "-c", "xfce4-notifyd", "-p", "/do-not-disturb"])[1].lower() == "true"


def _set_dnd(on):
    _run(["xfconf-query", "-c", "xfce4-notifyd", "-p", "/do-not-disturb", "-n", "-t", "bool",
          "-s", "true" if on else "false"])


def turn_on():
    if active():
        return
    # what is changed, so it can go back (also after signing out with Game mode on)
    before = {"previews": taskbar_previews(), "dnd": _dnd(),
              "desktop_icons": _mine("nemo-desktop"),
              "disk_check": _mine("/usr/libexec/pine-disk-check", full=True)}
    os.makedirs(os.path.dirname(RESTORE), exist_ok=True)
    with open(RESTORE, "w") as f:
        json.dump(before, f)

    # the marker: a process that lives as long as Game mode is on (with gamemode's settings)
    cmd = ["gamemoderun", "sleep", "infinity"] if shutil.which("gamemoderun") else ["sleep", "infinity"]
    p = subprocess.Popen(cmd, stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL,
                         stderr=subprocess.DEVNULL, start_new_session=True)
    with open(GAME_PID, "w") as f:
        f.write(str(p.pid))

    _stop("picom")
    if before["previews"]:
        set_taskbar_previews(False)
    if not before["dnd"]:
        _set_dnd(True)
    if before["desktop_icons"]:
        _run(["nemo-desktop", "--quit"], timeout=5)
        _stop("nemo-desktop")
    if before["disk_check"]:
        _stop("/usr/libexec/pine-disk-check", full=True)
    _stop("tumblerd")


def restore():
    """Put back what Game mode changed (turn_off, and sign-in after Game mode was left on)."""
    try:
        with open(RESTORE) as f:
            before = json.load(f)
    except (OSError, ValueError):
        before = {}
    if before.get("previews", True) and not taskbar_previews():
        set_taskbar_previews(True)
    if not before.get("dnd", False) and _dnd():
        _set_dnd(False)
    if before.get("desktop_icons") and not _mine("nemo-desktop"):
        _spawn(["/usr/libexec/pine-desktop-icons"])
    if before.get("disk_check") and not _mine("/usr/libexec/pine-disk-check", full=True):
        _spawn(["/usr/libexec/pine-disk-check"])
    try:
        os.remove(RESTORE)
    except OSError:
        pass


def turn_off():
    try:
        with open(GAME_PID) as f:
            os.killpg(int(f.read().strip()), 15)
    except (OSError, ValueError):
        pass
    try:
        os.remove(GAME_PID)
    except OSError:
        pass
    if not _mine("picom"):
        _spawn(["picom"])
    restore()


def after_signin():
    """At sign-in: Game mode is never on yet, so anything it left behind goes back."""
    if os.path.exists(RESTORE) and not active():
        restore()
