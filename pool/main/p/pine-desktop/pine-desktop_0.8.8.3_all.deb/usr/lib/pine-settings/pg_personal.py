"""Personalization: accent color, background, desktop icons, font."""
import glob
import os
import re

from gi.repository import Adw, Gdk, GdkPixbuf, Gio, GLib, Gtk, Pango

import common as c

PAGES, SEARCH = {}, []

ACCENTS = [("#3ccf7d", "Pine green"), ("#2ec4b6", "Teal"), ("#4c8dff", "Blue"), ("#9b7bff", "Violet"),
           ("#ff6b9a", "Pink"), ("#ff9f43", "Orange"), ("#e5484d", "Red"), ("#f2c94c", "Yellow")]
DESK = "xfce4-desktop"

_css = None


def install_swatch_css():
    global _css
    if _css is None:
        _css = Gtk.CssProvider()
        css = "".join(f".pine-sw-{i} {{ background: {col}; }}\n" for i, (col, _) in enumerate(ACCENTS))
        # Mode preview cards: a tiny desktop with a window and a taskbar
        for mode, bg, win, bar, line in (("dark", "#06090c", "#111a1e", "#0b1215", "#26323a"),
                                         ("light", "#dfe6e2", "#ffffff", "#f3f5f4", "#c9d3ce")):
            css += (f".pine-prev-{mode} {{ background: {bg}; border-radius: 5px; }}\n"
                    f".pine-prev-{mode} .win {{ background: {win}; border-radius: 2px; border: 1px solid {line}; }}\n"
                    f".pine-prev-{mode} .bar {{ background: {bar}; border-radius: 0 0 5px 5px; }}\n"
                    f".pine-prev-{mode} .ln {{ background: {line}; border-radius: 2px; }}\n")
        css += ".pine-prev-dot { background: var(--accent-bg-color); border-radius: 5px; }\n"
        _css.load_from_string(css)
        Gtk.StyleContext.add_provider_for_display(Gdk.Display.get_default(), _css,
                                                  Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION + 1)


# ================================================================ mode and accent color
def apply_look(mode=None, accent=None):
    """Save and apply dark/light mode and the accent color everywhere."""
    import theme
    cfg = c.load_config()
    mode = mode or cfg.get("mode", "dark")
    accent = (accent or cfg.get("accent", c.DEFAULT_ACCENT)).lower()
    c.save_config(mode=mode, accent=accent)
    Gio.Application.get_default().apply_look()       # Pine Settings itself, right away
    c.call_async(lambda: theme.apply(mode, accent))  # desktop, taskbar, start menu, other apps
    c.WINDOW.refresh()


def set_accent(col):
    apply_look(accent=col)


def mode_card(mode, label, selected):
    b = Gtk.Button()
    b.add_css_class("flat")
    b.add_css_class("pine-mode")
    if selected:
        b.add_css_class("selected")
    box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
    prev = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
    prev.add_css_class(f"pine-prev-{mode}")
    prev.set_size_request(150, 92)
    win = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=5, vexpand=True)
    win.add_css_class("win")
    win.set_margin_top(12)
    win.set_margin_start(18)
    win.set_margin_end(30)
    win.set_margin_bottom(8)
    for w in (60, 40):
        ln = Gtk.Box()
        ln.add_css_class("ln")
        ln.set_size_request(w, 5)
        ln.set_halign(Gtk.Align.START)
        ln.set_margin_start(8)
        ln.set_margin_top(6 if w == 60 else 0)
        win.append(ln)
    dot = Gtk.Box()
    dot.add_css_class("pine-prev-dot")
    dot.set_size_request(26, 8)
    dot.set_halign(Gtk.Align.START)
    dot.set_margin_start(8)
    win.append(dot)
    prev.append(win)
    bar = Gtk.Box()
    bar.add_css_class("bar")
    bar.set_size_request(-1, 12)
    prev.append(bar)
    box.append(prev)
    box.append(Gtk.Label(label=label))
    b.set_child(box)
    b.connect("clicked", lambda *_: apply_look(mode=mode))
    return b


def mode_row():
    install_swatch_css()
    cur = c.load_config().get("mode", "dark")
    r = Adw.ActionRow(title="Mode", subtitle="Dark or light for apps, the taskbar and the start menu")
    r.add_prefix(Gtk.Image.new_from_icon_name("weather-clear-night-symbolic" if cur == "dark" else "weather-clear-symbolic"))
    box = Gtk.Box(spacing=10, valign=Gtk.Align.CENTER)
    box.set_margin_top(10)
    box.set_margin_bottom(10)
    box.append(mode_card("dark", "Dark", cur == "dark"))
    box.append(mode_card("light", "Light", cur == "light"))
    r.add_suffix(box)
    return r


def accent_row():
    install_swatch_css()
    cur =c.load_config().get("accent", c.DEFAULT_ACCENT).lower()
    r = Adw.ActionRow(title="Accent color", subtitle="Buttons, switches, highlights and the start menu")
    r.add_prefix(Gtk.Image.new_from_icon_name("applications-graphics-symbolic"))
    box = Gtk.Box(spacing=8, valign=Gtk.Align.CENTER)
    for i, (col, name) in enumerate(ACCENTS):
        b = Gtk.Button()
        b.add_css_class("pine-swatch")
        b.add_css_class(f"pine-sw-{i}")
        if col == cur:
            b.add_css_class("selected")
        b.set_tooltip_text(name)
        b.connect("clicked", lambda _b, col=col: set_accent(col))
        box.append(b)
    dlg = Gtk.ColorDialog(title="Choose a color", with_alpha=False)
    pick = Gtk.ColorDialogButton(dialog=dlg)
    rgba = Gdk.RGBA()
    rgba.parse(cur)
    pick.set_rgba(rgba)
    pick.set_tooltip_text("Choose any color")

    def picked(btn, _p):
        v = btn.get_rgba()
        col = "#{:02x}{:02x}{:02x}".format(int(v.red * 255), int(v.green * 255), int(v.blue * 255))
        if col != c.load_config().get("accent", c.DEFAULT_ACCENT).lower():
            set_accent(col)
    pick.connect("notify::rgba", picked)
    box.append(pick)
    r.add_suffix(box)
    return r


def hex_of(rgba):
    return "#{:02x}{:02x}{:02x}".format(round(rgba.red * 255), round(rgba.green * 255), round(rgba.blue * 255))


def set_custom(mode, key, value):
    """Save the person's own window / text color for this mode (None: back to Pine's)."""
    cfg = c.load_config()
    custom = {m: dict(v) for m, v in (cfg.get("custom") or {}).items()}
    if key is None:
        custom.pop(mode, None)
    elif value is None:
        custom.get(mode, {}).pop(key, None)
    else:
        custom.setdefault(mode, {})[key] = value
    c.save_config(custom=custom)
    apply_look()


def custom_rows():
    """Window color and text color of the current mode (everything else follows from them)."""
    import theme
    mode = c.load_config().get("mode", "dark")
    own = theme.saved_custom(mode)
    base = theme.PALETTES.get(mode, theme.PALETTES["dark"])
    rows = []
    for key, title, sub, default in (
            ("window", "Window color", "Background of windows, the taskbar and the start menu", base["bg"]),
            ("text", "Text color", "Letters and icons; cards, lines and menus are matched to your colors", base["fg"])):
        cur = own.get(key, default)
        pick = Gtk.ColorDialogButton(dialog=Gtk.ColorDialog(title=c._(title), with_alpha=False), valign=Gtk.Align.CENTER)
        rgba = Gdk.RGBA()
        rgba.parse(cur)
        pick.set_rgba(rgba)

        def picked(btn, _p, key=key, cur=cur):
            col = hex_of(btn.get_rgba())
            if col != cur:
                set_custom(mode, key, col)
        pick.connect("notify::rgba", picked)
        rows.append(c.row(title, sub, "preferences-color-symbolic", pick))
    if own:
        rows.append(c.row("Back to Pine's colors", f"Window and text colors of {mode} mode", "edit-undo-symbolic",
                          c.button("Reset", lambda: set_custom(mode, None, None))))
    return rows


# ================================================================ background
def wallpapers():
    found = []
    pics = GLib.get_user_special_dir(GLib.UserDirectory.DIRECTORY_PICTURES) or GLib.get_home_dir()
    for ext in ("png", "jpg", "jpeg", "webp", "svg"):
        found += glob.glob(f"/usr/share/backgrounds/**/*.{ext}", recursive=True)
        found += glob.glob(os.path.join(pics, f"Wallpapers/*.{ext}"))
    result, seen = [], set()
    # Pine's own first; one copy of each picture; no small placeholders or the XFCE mascot
    for f in sorted(found, key=lambda p: ("/pine/" not in p, "pine-wallpaper" not in p, p)):
        real = os.path.realpath(f)
        # XFCE's own wallpapers carry the XFCE logo: not offered
        if real in seen or "-1080p" in f or "/xfce/" in real or not os.path.exists(real):
            continue
        seen.add(real)
        result.append(f)
    return result


def wallpaper_props():
    return [p for p in c.xlist(DESK) if p.endswith("/last-image")]


def current_wallpaper():
    props = wallpaper_props()
    return c.xget(DESK, props[0]) if props else None


def set_wallpaper(path):
    props = wallpaper_props()
    if not props:
        rc, out, _ = c.run(["xrandr", "--query"])
        outs = re.findall(r"^(\S+) connected", out, re.M) or ["0"]
        props = [f"/backdrop/screen0/monitor{o}/workspace0/last-image" for o in outs]
    for p in props:
        c.xset(DESK, p, path, "string")
        c.xset(DESK, p.replace("last-image", "image-style"), 5, "int")
    c.toast("Background changed")
    if (c.load_config().get("live_wallpaper") or {}).get("on") and "pine-wallpaper" in path:
        c.run_async(["pine-livewall"])           # the live background goes on with the Pine wallpaper
    c.WINDOW.refresh()


def wall_tile(path, selected):
    b = Gtk.Button()
    b.add_css_class("flat")
    b.add_css_class("pine-wall")
    if selected:
        b.add_css_class("selected")
    pic = Gtk.Picture(content_fit=Gtk.ContentFit.COVER, can_shrink=True)
    pic.set_size_request(176, 110)
    b.set_child(pic)
    b.set_tooltip_text(os.path.basename(path))
    b.connect("clicked", lambda *_: set_wallpaper(path))

    def load():
        return GdkPixbuf.Pixbuf.new_from_file_at_scale(path, 352, 220, True)
    c.call_async(load, lambda pb: isinstance(pb, GdkPixbuf.Pixbuf) and pic.set_paintable(Gdk.Texture.new_for_pixbuf(pb)))
    return b


def browse_wallpaper():
    f = Gtk.FileFilter()
    f.set_name("Pictures")
    f.add_mime_type("image/*")
    filters = Gio.ListStore.new(Gtk.FileFilter)
    filters.append(f)
    d = Gtk.FileDialog(title="Choose a picture", filters=filters)

    def done(dlg, res):
        try:
            file = dlg.open_finish(res)
        except GLib.Error:
            return
        if file:
            set_wallpaper(file.get_path())
    d.open(c.WINDOW, None, done)


def background_group():
    cur = current_wallpaper()
    flow = Gtk.FlowBox(selection_mode=Gtk.SelectionMode.NONE, max_children_per_line=4, min_children_per_line=2,
                       column_spacing=6, row_spacing=6, homogeneous=True)
    flow.set_margin_top(12)
    flow.set_margin_bottom(12)
    flow.set_margin_start(12)
    flow.set_margin_end(12)
    walls = wallpapers()
    cur_real = os.path.realpath(cur) if cur else None
    if cur and cur_real not in {os.path.realpath(w) for w in walls} and os.path.exists(cur):
        walls.insert(0, cur)
    for w in walls:
        flow.append(wall_tile(w, os.path.realpath(w) == cur_real))
    frame = Gtk.ListBox(selection_mode=Gtk.SelectionMode.NONE)
    frame.add_css_class("boxed-list")
    lr = Gtk.ListBoxRow(activatable=False)
    lr.set_child(flow)
    frame.append(lr)
    g = c.group("Background", os.path.basename(cur) if cur else None,
                suffix=c.button("Browse…", browse_wallpaper, icon="folder-pictures-symbolic"))
    g.add(frame)
    return g


def set_live(**changes):
    live = dict(c.load_config().get("live_wallpaper") or {})
    live.update(changes)
    c.save_config(live_wallpaper=live)
    if "on" in changes:
        if changes["on"]:
            c.run_async(["pine-livewall"])
            c.toast("The waves drift")
        else:
            c.run_async(["pkill", "-f", "/usr/lib/pine-tools/livewall.py"])
        if glob.glob("/sys/class/power_supply/BAT*"):     # the "Only when plugged in" row comes or goes
            c.WINDOW.refresh()


def live_group():
    """Live background: only for the Pine wallpaper (the waves are part of that picture)."""
    cur = current_wallpaper() or ""
    if "pine-wallpaper" not in cur:
        return None
    live = c.load_config().get("live_wallpaper") or {}
    on = bool(live.get("on", False))
    rows = [c.switch_row("Live background",
                         "The waves of the Pine wallpaper drift slowly (they stand still in Game mode and in full screen)",
                         on, lambda v: set_live(on=v), "weather-windy-symbolic")]
    if on:
        has_battery = bool(glob.glob("/sys/class/power_supply/BAT*"))
        if has_battery:
            rows.append(c.switch_row("Only when plugged in", "Saves battery: on battery the waves stand still",
                                     bool(live.get("plugged_in_only", True)),
                                     lambda v: set_live(plugged_in_only=v), "battery-symbolic"))
    return c.group(None, None, rows)


# ================================================================ desktop and font
NEMO_DESK = "org.nemo.desktop"


def nemo_desktop():
    """Nemo's desktop settings (Nemo draws the desktop icons), or None without Nemo."""
    src = Gio.SettingsSchemaSource.get_default()
    return Gio.Settings.new(NEMO_DESK) if src and src.lookup(NEMO_DESK, True) else None


def desktop_group():
    nd = nemo_desktop()
    rows = []
    if nd is not None:
        def icons(on):
            nd.set_boolean("show-desktop-icons", on)
            if on:   # nemo-desktop quits when the icons are turned off; start it again
                GLib.spawn_command_line_async("/usr/libexec/pine-desktop-icons")
            c.WINDOW.refresh()

        on = nd.get_boolean("show-desktop-icons")
        rows.append(c.switch_row("Desktop icons", "Show files and shortcuts on the desktop", on, icons,
                                 "user-desktop-symbolic"))
        if on:
            for key, title in (("home-icon-visible", "Home folder"), ("trash-icon-visible", "Trash"),
                               ("volumes-visible", "USB drives and disks")):
                rows.append(c.switch_row(f"Show {title}", None, nd.get_boolean(key),
                                         lambda v, k=key: nd.set_boolean(k, v)))
    # Font family (size is in Accessibility > Text size)
    font = c.xget("xsettings", "/Gtk/FontName", "Inter 10")
    desc = Pango.FontDescription.from_string(font)
    fb = Gtk.FontDialogButton(dialog=Gtk.FontDialog(title="Choose a font"), level=Gtk.FontLevel.FAMILY)
    fb.set_font_desc(desc)
    fb.set_valign(Gtk.Align.CENTER)

    def font_changed(btn, _p):
        d = btn.get_font_desc()
        size = desc.get_size() // Pango.SCALE or 10
        if d and d.get_family():
            c.set_font(f"{d.get_family()} {size}")
    fb.connect("notify::font-desc", font_changed)
    rows.append(c.row("Font", "Used by apps and the desktop", "font-x-generic-symbolic", fb))
    return c.group("Desktop", None, rows)


def set_animations(on):
    import theme
    c.save_config(animations=on)
    c.call_async(lambda: theme.apply_animations(on))
    c.toast("Animations are on" if on else "Animations are off")


def effects_group():
    return c.group("Effects", None, [
        c.switch_row("Animation effects",
                     "Windows, menus, pages and the installer move smoothly. Turn off for a calmer, faster feel.",
                     c.load_config().get("animations", True), set_animations, "view-dual-symbolic"),
    ])


def build_personal():
    return c.page("Personalization", c.group("Colors", None, [mode_row(), accent_row(), *custom_rows()]), effects_group(),
                  background_group(), live_group(), desktop_group())


PAGES["personal"] = {"title": "Personalization", "build": build_personal, "parent": None}
SEARCH += [(t, s, "personal") for t, s in (
    ("Mode", "Dark mode, light mode, night, theme"),
    ("Animation effects", "Animations, transitions, motion, effects, smooth"),
    ("Live background", "Moving wallpaper, animated waves, battery"),
    ("Accent color", "Color, theme, highlight"),
    ("Window color", "Custom colors, background color, own theme, text color"), ("Background", "Wallpaper, desktop picture"),
    ("Desktop icons", "Home, trash on desktop, icons, grid, move icons"), ("Font", "Typeface, letters"))]
