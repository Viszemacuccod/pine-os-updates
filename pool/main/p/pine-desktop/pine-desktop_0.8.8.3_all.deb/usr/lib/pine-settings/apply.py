"""Re-apply saved Pine Settings at sign-in (displays, mouse and touchpad).

XFCE keeps most settings itself (xfconf). These two are applied by Pine Settings directly
with xrandr / xinput, so they are saved in ~/.config/pine/settings.json and set again here.
"""
import os
import re

import common as c

INPUT_DEFAULTS = {"accel": 0.0, "left_handed": False, "natural_mouse": False,
                  "natural_touchpad": True, "tap": True, "dwt": True}


def pointer_devices():
    """[(id, name, set of libinput property names, is_touchpad)] for real pointing devices."""
    rc, out, _ = c.run(["xinput", "list"])
    devs = []
    if rc != 0:
        return devs
    for line in out.splitlines():
        m = re.search(r"[↳ ]*(.+?)\s+id=(\d+)\s+\[slave\s+pointer", line)
        if not m or "XTEST" in m.group(1):
            continue
        dev_id, name = m.group(2), m.group(1).strip(" ⎜↳")
        rc, props, _ = c.run(["xinput", "list-props", dev_id])
        names = set(re.findall(r"^\s+(libinput [^(]+?) \(\d+\)", props, re.M))
        devs.append((dev_id, name, names, "libinput Tapping Enabled" in names))
    return devs


def apply_input(cfg=None):
    s = dict(INPUT_DEFAULTS)
    s.update((cfg or c.load_config()).get("input", {}))
    for dev_id, _name, props, touchpad in pointer_devices():
        def setp(prop, *vals):
            if prop in props:
                c.run(["xinput", "set-prop", dev_id, prop] + [str(v) for v in vals])
        setp("libinput Accel Speed", f"{float(s['accel']):.2f}")
        setp("libinput Left Handed Enabled", int(s["left_handed"]))
        setp("libinput Natural Scrolling Enabled", int(s["natural_touchpad"] if touchpad else s["natural_mouse"]))
        if touchpad:
            setp("libinput Tapping Enabled", int(s["tap"]))
            if s.get("click_method") == "areas":      # Windows: press the bottom right corner = right click
                setp("libinput Click Method Enabled", 1, 0)
            setp("libinput Disable While Typing Enabled", int(s["dwt"]))


def apply_displays(cfg=None):
    cfg = cfg or c.load_config()
    rc, out, _ = c.run(["xrandr", "--query"])
    if rc != 0:
        return
    connected = set(re.findall(r"^(\S+) connected", out, re.M))
    pair = cfg.get("display_pair")
    layout = cfg.get("display_layout")
    if layout and pair and set(pair) <= connected and len(connected) == 2:
        import pg_system
        outs = [{"name": pair[0]}, {"name": pair[1]}]
        c.run(["xrandr"] + pg_system.layout_args(layout, outs))
    for name, d in cfg.get("displays", {}).items():
        if name in connected:
            c.run(["xrandr", "--output", name, "--mode", d["mode"], "--rate", f"{float(d['rate']):.2f}",
                   "--rotate", d.get("rotate", "normal")])


def refresh_gtk4_colors():
    """GTK 4 colors of the saved mode and accent: also replaces the file older Pine versions
    wrote, which GTK 4.18 couldn't read (it used "@media"). A file of the user's own (no Pine
    mark) is left alone."""
    try:
        import theme
        mode, accent = theme.saved()
        theme.write_gtk4(os.path.join(theme._config_dir(), "gtk-4.0", "gtk.css"), accent, mode)
    except Exception as e:  # never stop the sign-in for this
        print("pine-settings --apply: gtk4 colors:", e)


def migrate_once(name, fn):
    """Run fn once per user (a marker in ~/.config/pine/migrated/), for changes of Pine's
    defaults that users who set up an older version should get too."""
    mark = os.path.join(os.environ.get("XDG_CONFIG_HOME") or os.path.expanduser("~/.config"), "pine", "migrated", name)
    if os.path.exists(mark):
        return
    try:
        fn()
        os.makedirs(os.path.dirname(mark), exist_ok=True)
        open(mark, "w").close()
    except Exception as e:  # never stop the sign-in for this
        print(f"pine-settings --apply: {name}:", e)


def middle_click_new_window():
    """0.8.7: middle-clicking an app on the taskbar opens a new window of it (like Windows),
    instead of closing all its windows (docklike's middleButtonBehavior: 0 close all,
    1 launch new instance, 2 nothing)."""
    import glob
    import re
    import subprocess
    changed = False
    base = os.environ.get("XDG_CONFIG_HOME") or os.path.expanduser("~/.config")
    for rc in glob.glob(os.path.join(base, "xfce4", "panel", "docklike-*.rc")):
        with open(rc) as f:
            text = f.read()
        new, n = re.subn(r"(?m)^middleButtonBehavior=0$", "middleButtonBehavior=1", text)
        if not n and "middleButtonBehavior=" not in text:
            new = text.rstrip("\n") + "\nmiddleButtonBehavior=1\n"
        if new != text:
            with open(rc, "w") as f:
                f.write(new)
            changed = True
    if changed:   # docklike reads its settings only when it starts
        subprocess.Popen(["xfce4-panel", "--restart"], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)


def new_keys_087():
    """0.8.7: Alt+Tab is Pine's switcher with window pictures (pine-switcher) and the screenshot
    keys use pine-screenshot. Users who changed any shortcut have their own copy of the list
    ("custom"), which the new defaults don't reach: the keys are set there too. A key the user
    set to something of their own is left alone."""
    import subprocess

    def q(*args):
        r = subprocess.run(["xfconf-query", "-c", "xfce4-keyboard-shortcuts", *args],
                           capture_output=True, text=True)
        return r.returncode, r.stdout.strip()

    def has_custom(section):
        return q("-p", f"/{section}/custom/override")[0] == 0

    if has_custom("xfwm4"):
        for key in ("<Alt>Tab", "<Alt><Shift>Tab"):
            rc, val = q("-p", f"/xfwm4/custom/{key}")
            if rc == 0 and val in ("cycle_windows_key", "cycle_reverse_windows_key"):
                q("-p", f"/xfwm4/custom/{key}", "-r", "-R")
    if has_custom("commands"):
        for key, cmd, old in (
                ("<Alt>Tab", "pine-switcher next", ("",)),
                ("<Alt><Shift>Tab", "pine-switcher prev", ("",)),
                ("<Super><Shift>s", "pine-screenshot region", ("", "xfce4-screenshooter -r")),
                ("<Shift>Print", "pine-screenshot region", ("", "xfce4-screenshooter -r")),
                ("Print", "pine-screenshot full", ("", "xfce4-screenshooter -f")),
                ("<Alt>Print", "pine-screenshot window", ("", "xfce4-screenshooter -w"))):
            rc, val = q("-p", f"/commands/custom/{key}")
            if (val if rc == 0 else "") in old:
                q("-p", f"/commands/custom/{key}", "-r", "-R")     # (drops startup-notify too)
                q("-p", f"/commands/custom/{key}", "-n", "-t", "string", "-s", cmd)


def new_keys_0882():
    """0.8.8.2: Win+. (and Win+;) open the emoji picker. Users who changed any shortcut have their
    own list ("custom"), which new defaults don't reach; a key they use for something else stays."""
    import subprocess
    q = lambda *a: subprocess.run(["xfconf-query", "-c", "xfce4-keyboard-shortcuts", *a],   # noqa: E731
                                  capture_output=True, text=True)
    if q("-p", "/commands/custom/override").returncode != 0:
        return
    for key in ("<Super>period", "<Super>semicolon"):
        if q("-p", f"/commands/custom/{key}").returncode != 0:
            q("-p", f"/commands/custom/{key}", "-n", "-t", "string", "-s", "pine-emoji")


def refresh_user_themes():
    """A user's own accent color lives in their own copy of the Pine themes
    (~/.local/share/themes), and switching animations writes an own compositor file
    (~/.config/picom/picom.conf); updates don't reach them: write them again whenever the
    generated themes change (theme.THEME_VERSION)."""
    import theme
    data = os.environ.get("XDG_DATA_HOME") or os.path.expanduser("~/.local/share")
    themes = os.path.join(data, "themes")
    if os.path.isdir(os.path.join(themes, "Pine-Dark")) or os.path.isdir(os.path.join(themes, "Pine-Light")):
        theme.write_themes(themes, theme.saved()[1])
    # the same for the user's own compositor settings (written when animations were switched)
    picom = os.path.join(theme._config_dir(), "picom", "picom.conf")
    if os.path.exists(picom):
        with open(picom, "w") as f:
            f.write(theme.picom_conf(c.load_config().get("animations", True)))


def power_button():
    """One power button in the Start menu: it opens Pine's power menu (pine-power) instead of
    four buttons (lock, restart, shut down, sign out) and XFCE's question dialog; Ctrl+Alt+Delete
    opens it too (users who changed shortcuts have their own copy of the list)."""
    import re
    import subprocess

    def q(channel, *args):
        r = subprocess.run(["xfconf-query", "-c", channel, *args], capture_output=True, text=True)
        return r.returncode, r.stdout.strip()

    _rc, out = q("xfce4-panel", "-l", "-v")
    for m in re.finditer(r"^/plugins/(plugin-\d+)\s+whiskermenu$", out, re.M):
        base = f"/plugins/{m.group(1)}"
        for prop, typ, val in (("show-command-lockscreen", "bool", "false"), ("show-command-restart", "bool", "false"),
                               ("show-command-logout", "bool", "false"), ("show-command-switchuser", "bool", "false"),
                               ("show-command-shutdown", "bool", "true"), ("command-shutdown", "string", "pine-power"),
                               ("confirm-session-command", "bool", "false")):
            q("xfce4-panel", "-p", f"{base}/{prop}", "-n", "-t", typ, "-s", val)
    key = "/commands/custom/<Primary><Alt>Delete"
    rc, val = q("xfce4-keyboard-shortcuts", "-p", key)
    if rc == 0 and val == "xfce4-session-logout":
        q("xfce4-keyboard-shortcuts", "-p", key, "-s", "pine-power")
    # The computer's power button: Pine answers it (pine-power-key), keeping the person's
    # earlier choice; the power manager then does nothing for it
    # (only a value the person set themselves counts: Pine's own default is now 0 = "do nothing",
    # which xfconf-query reports too, and would turn the button off on every new install)
    own = os.path.join(os.environ.get("XDG_CONFIG_HOME") or os.path.expanduser("~/.config"),
                       "xfce4", "xfconf", "xfce-perchannel-xml", "xfce4-power-manager.xml")
    val = ""
    try:
        m = re.search(r'name="power-button-action" type="uint" value="(\d+)"', open(own).read())
        val = m.group(1) if m else ""
    except OSError:
        pass
    choice = {"4": "shutdown", "1": "sleep", "0": "nothing"}.get(val, "ask")
    c.save_config(power_button=c.load_config().get("power_button", choice))
    q("xfce4-power-manager", "-p", "/xfce4-power-manager/power-button-action", "-n", "-t", "uint", "-s", "0")
    if q("xfce4-keyboard-shortcuts", "-p", "/commands/custom/override")[0] == 0:
        q("xfce4-keyboard-shortcuts", "-p", "/commands/custom/XF86PowerOff", "-n", "-t", "string",
          "-s", "/usr/libexec/pine-power-key")


def game_mode_leftovers():
    """Signed out with Game mode on: put back what it paused (taskbar previews, pop-ups...)."""
    try:
        import game
        game.after_signin()
    except Exception as e:  # never stop the sign-in for this
        print("pine-settings --apply: game mode:", e)


def main():
    cfg = c.load_config()
    apply_displays(cfg)
    apply_input(cfg)
    refresh_gtk4_colors()
    game_mode_leftovers()
    migrate_once("middle-click-new-window", middle_click_new_window)
    migrate_once("new-keys-0.8.7", new_keys_087)
    migrate_once("power-button", power_button)
    migrate_once("new-keys-0.8.8.2", new_keys_0882)
    try:
        import theme
        migrate_once(f"themes-v{theme.THEME_VERSION}", refresh_user_themes)
    except Exception as e:  # never stop the sign-in for this
        print("pine-settings --apply: themes:", e)
    return 0
