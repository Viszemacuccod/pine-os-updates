"""Pine Settings: shared helpers (running commands, xfconf, saved settings, row widgets)."""
import json
import os
import shutil
import subprocess
import threading

import gi
gi.require_version("Gtk", "4.0")
gi.require_version("Adw", "1")
from gi.repository import Adw, GLib, Gtk  # noqa: E402

CONFIG_DIR = os.path.join(GLib.get_user_config_dir(), "pine")
CONFIG_FILE = os.path.join(CONFIG_DIR, "settings.json")
DEFAULT_ACCENT = "#3ccf7d"

# The main window registers itself here (navigation and toasts)
WINDOW = None

# ---------------------------------------------------------------- translations
# The helpers below translate what they show (po/ in the Pine OS project, tools/i18n.py),
# so pages keep plain English strings. Untranslated text is shown as it is.
import gettext  # noqa: E402
_TR = gettext.translation("pine", fallback=True)


def _(text):
    return _TR.gettext(text) if isinstance(text, str) and text else text


# ---------------------------------------------------------------- commands
def run(cmd, input=None, timeout=20, env=None):
    """Run a command and return (exit code, stdout, stderr). Never raises."""
    try:
        e = dict(os.environ)
        e["LC_ALL"] = "C.UTF-8"
        if env:
            e.update(env)
        p = subprocess.run(cmd, input=input, capture_output=True, text=True, timeout=timeout, env=e)
        return p.returncode, p.stdout, p.stderr
    except FileNotFoundError:
        return 127, "", f"{cmd[0]}: not installed"
    except subprocess.TimeoutExpired:
        return 124, "", "timed out"
    except Exception as ex:  # pragma: no cover
        return 1, "", str(ex)


def run_async(cmd, done=None, input=None, timeout=300, env=None):
    """Run a command in the background; done(rc, out, err) is called on the main thread."""
    def work():
        res = run(cmd, input=input, timeout=timeout, env=env)
        if done:
            GLib.idle_add(lambda: (done(*res), False)[1])
    threading.Thread(target=work, daemon=True).start()


def call_async(func, done=None):
    """Run a Python function in the background; done(result) on the main thread."""
    def work():
        try:
            res = func()
        except Exception as ex:
            res = ex
        if done:
            GLib.idle_add(lambda: (done(res), False)[1])
    threading.Thread(target=work, daemon=True).start()


def have(binary):
    return shutil.which(binary) is not None


def root_write(path, text, done=None):
    """Write a system file as administrator (asks for the password)."""
    run_async(["pkexec", "tee", path], lambda rc, o, e: done and done(rc == 0, e), input=text)


def root_sh(script, done=None, input=None, timeout=900):
    """Run a shell script as administrator (asks for the password)."""
    run_async(["pkexec", "sh", "-c", script], lambda rc, o, e: done and done(rc, o, e),
              input=input, timeout=timeout)


# ---------------------------------------------------------------- xfconf
def xget(channel, prop, default=None):
    rc, out, _ = run(["xfconf-query", "-c", channel, "-p", prop])
    return out.strip() if rc == 0 else default


def xget_bool(channel, prop, default=False):
    v = xget(channel, prop)
    return default if v is None else v.lower() == "true"


def xget_int(channel, prop, default=0):
    try:
        return int(float(xget(channel, prop)))
    except (TypeError, ValueError):
        return default


def xset(channel, prop, value, typ):
    if typ == "bool":
        value = "true" if value else "false"
    run(["xfconf-query", "-c", channel, "-p", prop, "-n", "-t", typ, "-s", str(value)])



def set_font(font):
    """The interface font (e.g. "Inter 10") for every app: XFCE / GTK 3 apps (xsettings),
    GTK 4 and Flatpak apps (GNOME setting) and the desktop icons (Nemo)."""
    xset("xsettings", "/Gtk/FontName", font, "string")
    run(["gsettings", "set", "org.gnome.desktop.interface", "font-name", font])
    run(["gsettings", "set", "org.nemo.desktop", "font", font])

def xlist(channel):
    rc, out, _ = run(["xfconf-query", "-c", channel, "-l"])
    return out.split() if rc == 0 else []


# ---------------------------------------------------------------- saved settings
def load_config():
    try:
        with open(CONFIG_FILE) as f:
            return json.load(f)
    except (OSError, ValueError):
        return {}


def save_config(**changes):
    cfg = load_config()
    cfg.update(changes)
    os.makedirs(CONFIG_DIR, exist_ok=True)
    tmp = CONFIG_FILE + ".tmp"
    with open(tmp, "w") as f:
        json.dump(cfg, f, indent=2)
    os.replace(tmp, CONFIG_FILE)
    return cfg


# ---------------------------------------------------------------- feedback
def toast(text):
    if WINDOW:
        WINDOW.toast(_(text))


def go(page_id):
    if WINDOW:
        WINDOW.show_page(page_id)


def confirm(heading, body, ok_label, on_ok, destructive=False):
    d = Adw.AlertDialog(heading=_(heading), body=_(body))
    d.add_response("cancel", _("Cancel"))
    d.add_response("ok", _(ok_label))
    d.set_response_appearance("ok", Adw.ResponseAppearance.DESTRUCTIVE if destructive
                              else Adw.ResponseAppearance.SUGGESTED)
    d.set_default_response("ok")
    d.connect("response", lambda _d, r: r == "ok" and on_ok())
    d.present(WINDOW)


def error(heading, body):
    d = Adw.AlertDialog(heading=_(heading), body=_(body))
    d.add_response("ok", _("OK"))
    d.present(WINDOW)


# ---------------------------------------------------------------- page building
def page(title, *groups):
    """An Adw.PreferencesPage holding the given groups."""
    p = Adw.PreferencesPage()
    p.set_title(_(title))
    for g in groups:
        if g is not None:
            p.add(g)
    return p


def group(title=None, description=None, rows=(), suffix=None):
    g = Adw.PreferencesGroup()
    if title:
        g.set_title(GLib.markup_escape_text(_(title)))
    if description:
        g.set_description(GLib.markup_escape_text(_(description)))
    if suffix:
        g.set_header_suffix(suffix)
    for r in rows:
        if r is not None:
            g.add(r)
    return g


def _icon(row, icon):
    if icon:
        img = Gtk.Image.new_from_icon_name(icon)
        img.add_css_class("pine-row-icon")
        row.add_prefix(img)


def row(title, subtitle=None, icon=None, suffix=None, on_click=None, nav=None):
    """A plain row. nav="page-id" makes it open that page (with a > arrow)."""
    r = Adw.ActionRow(title=GLib.markup_escape_text(_(title)))
    if subtitle:
        r.set_subtitle(GLib.markup_escape_text(_(subtitle)))
    _icon(r, icon)
    if suffix is not None:
        for w in suffix if isinstance(suffix, (list, tuple)) else [suffix]:
            if isinstance(w, Gtk.Widget):
                w.set_valign(Gtk.Align.CENTER)
            r.add_suffix(w)
    if nav:
        r.add_suffix(Gtk.Image.new_from_icon_name("go-next-symbolic"))
        on_click = lambda *_: go(nav)
    if on_click:
        r.set_activatable(True)
        r.connect("activated", lambda *_: on_click())
    return r


def switch_row(title, subtitle, active, on_change, icon=None):
    r = Adw.SwitchRow(title=GLib.markup_escape_text(_(title)))
    if subtitle:
        r.set_subtitle(GLib.markup_escape_text(_(subtitle)))
    _icon(r, icon)
    r.set_active(bool(active))
    r.connect("notify::active", lambda w, _p: on_change(w.get_active()))
    return r


def combo_row(title, subtitle, options, selected, on_change, icon=None, search=False):
    """options: list of labels. selected: index. on_change(index)."""
    r = Adw.ComboRow(title=GLib.markup_escape_text(_(title)))
    if subtitle:
        r.set_subtitle(GLib.markup_escape_text(_(subtitle)))
    _icon(r, icon)
    r.set_model(Gtk.StringList.new([_(str(o)) for o in options]))
    if search:
        r.set_enable_search(True)
        r.set_expression(Gtk.PropertyExpression.new(Gtk.StringObject, None, "string"))
    if 0 <= selected < len(options):
        r.set_selected(selected)
    r.connect("notify::selected", lambda w, _p: on_change(w.get_selected()))
    return r


def slider_row(title, subtitle, lo, hi, step, value, on_change, icon=None, delay=200, fmt=None):
    """A row with a slider; on_change(value) runs shortly after the user stops moving it."""
    r = Adw.ActionRow(title=GLib.markup_escape_text(_(title)))
    if subtitle:
        r.set_subtitle(GLib.markup_escape_text(_(subtitle)))
    _icon(r, icon)
    scale = Gtk.Scale.new_with_range(Gtk.Orientation.HORIZONTAL, lo, hi, step)
    scale.set_value(value)
    scale.set_size_request(240, -1)
    scale.set_valign(Gtk.Align.CENTER)
    scale.set_draw_value(fmt is not None)
    if fmt:
        scale.set_value_pos(Gtk.PositionType.RIGHT)
        scale.set_format_value_func(lambda _s, v: fmt(v))
    pending = {"id": 0}

    def fire():
        pending["id"] = 0
        on_change(scale.get_value())
        return False

    def changed(_s):
        if pending["id"]:
            GLib.source_remove(pending["id"])
        pending["id"] = GLib.timeout_add(delay, fire)

    scale.connect("value-changed", changed)
    r.add_suffix(scale)
    r.scale = scale
    return r


def button(label, on_click, style=None, icon=None):
    b = Gtk.Button()
    if icon and label:
        content = Adw.ButtonContent(icon_name=icon, label=_(label))
        b.set_child(content)
    elif icon:
        b.set_icon_name(icon)
    else:
        b.set_label(_(label))
    if style:
        b.add_css_class(style)
    b.set_valign(Gtk.Align.CENTER)
    b.connect("clicked", lambda *_: on_click())
    return b


def pill(text, style="pine-pill"):
    lbl = Gtk.Label(label=_(text))
    lbl.add_css_class(style)
    lbl.set_valign(Gtk.Align.CENTER)
    return lbl


def spinner():
    s = Adw.Spinner()
    s.set_size_request(20, 20)
    return s


def hero(icon=None, title="", subtitle="", suffix=None, widget=None):
    """The big card at the top of a page."""
    box = Gtk.Box(spacing=18)
    box.add_css_class("card")
    box.add_css_class("pine-hero")
    if widget is not None:
        box.append(widget)
    elif icon:
        badge = Gtk.Image.new_from_icon_name(icon)
        badge.set_pixel_size(32)
        badge.add_css_class("pine-badge")
        box.append(badge)
    texts = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=2, hexpand=True, valign=Gtk.Align.CENTER)
    t = Gtk.Label(label=_(title), xalign=0, wrap=True)
    t.add_css_class("title-2")
    texts.append(t)
    s = None
    if subtitle:
        s = Gtk.Label(label=_(subtitle), xalign=0, wrap=True)
        s.add_css_class("dim-label")
        texts.append(s)
    box.append(texts)
    if suffix is not None:
        suffix.set_valign(Gtk.Align.CENTER)
        box.append(suffix)
    g = Adw.PreferencesGroup()
    g.add(box)
    g.title_label, g.subtitle_label = t, s
    return g


def dialog(title, content, width=460, height=-1):
    """A simple dialog window with a header bar holding `content`."""
    d = Adw.Dialog()
    d.set_title(_(title))
    d.set_content_width(width)
    if height > 0:
        d.set_content_height(height)
    tv = Adw.ToolbarView()
    tv.add_top_bar(Adw.HeaderBar())
    tv.set_content(content)
    d.set_child(tv)
    return d


def human_size(n):
    for unit in ("B", "KB", "MB", "GB", "TB"):
        if abs(n) < 1000 or unit == "TB":
            return f"{n:.0f} {unit}" if unit in ("B", "KB") else f"{n:.1f} {unit}"
        n /= 1000.0
    return str(n)
