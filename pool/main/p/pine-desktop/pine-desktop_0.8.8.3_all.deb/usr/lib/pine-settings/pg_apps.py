"""Apps: default apps, installed apps (startup apps are on the Startup page, pg_startup; the
helpers for them stay here)."""
import glob
import os
import re

from gi.repository import Gio, GLib, Gtk

import common as c

PAGES, SEARCH = {}, []

DEFAULTS = [
    ("Web browser", ["x-scheme-handler/http", "x-scheme-handler/https", "text/html"], "web-browser-symbolic"),
    ("Email", ["x-scheme-handler/mailto"], "mail-unread-symbolic"),
    ("Files and folders", ["inode/directory"], "folder-symbolic"),
    ("Text files", ["text/plain"], "text-x-generic-symbolic"),
    ("Pictures", ["image/png", "image/jpeg", "image/gif", "image/webp", "image/bmp", "image/tiff", "image/svg+xml"],
     "image-x-generic-symbolic"),
    ("Videos", ["video/mp4", "video/x-matroska", "video/webm", "video/quicktime", "video/x-msvideo", "video/mpeg"],
     "video-x-generic-symbolic"),
    ("Music", ["audio/mpeg", "audio/flac", "audio/ogg", "audio/x-wav", "audio/mp4", "audio/x-vorbis+ogg"],
     "audio-x-generic-symbolic"),
    ("PDF documents", ["application/pdf"], "x-office-document-symbolic"),
]

# Apps that belong to Pine OS itself: no Uninstall button
CORE_PACKAGES = {"xfce4-settings", "xfce4-panel", "xfce4-session", "xfwm4", "xfdesktop4", "thunar", "nemo", "lightdm",
                 "network-manager", "network-manager-gnome", "calamares", "flatpak", "xfce4-terminal",
                 "firefox-esr", "xfce4-taskmanager", "xfce4-appfinder", "xfce4-notifyd", "xfce4-power-manager",
                 "blueman", "pavucontrol", "system-config-printer", "xorg", "sudo", "xfce4", "xfce4-whiskermenu-plugin"}
# The App Store (Bazaar, a Flatpak) is part of Pine OS too
STORE_ID = "io.github.kolunmi.Bazaar"


def name_of(app):
    # Name= (Pine's simple names), not the long X-GNOME-FullName
    return app.get_name() or app.get_display_name() or app.get_id()


# ================================================================ default apps
def default_row(title, mimes, icon):
    apps, seen = [], set()
    for a in Gio.AppInfo.get_all_for_type(mimes[0]):
        if a.get_id() not in seen and a.should_show():
            seen.add(a.get_id())
            apps.append(a)
    if not apps:
        return c.row(title, "No app installed for this", icon)
    cur = Gio.AppInfo.get_default_for_type(mimes[0], False)
    idx = next((i for i, a in enumerate(apps) if cur and a.get_id() == cur.get_id()), 0)

    def pick(i):
        a = apps[i]
        for m in mimes:
            try:
                a.set_as_default_for_type(m)
            except GLib.Error:
                pass
        if title == "Web browser":
            c.run(["xdg-settings", "set", "default-web-browser", a.get_id()])
        c.toast(f"{name_of(a)} opens {title.lower()} now")
    return c.combo_row(title, None, [name_of(a) for a in apps], idx, pick, icon)


# ================================================================ startup apps
# Parts of the system that start at sign-in: not shown (switching them off would break things;
# some are started by Pine itself only when needed, e.g. blueman while Bluetooth is on)
SYSTEM_AUTOSTART = {
    "at-spi-dbus-bus.desktop", "blueman.desktop", "nm-applet.desktop", "picom.desktop", "print-applet.desktop",
    "xdg-user-dirs.desktop", "xfce4-notifyd.desktop", "xfce4-power-manager.desktop", "xfsettingsd.desktop",
    "lxpolkit.desktop", "polkit-gnome-authentication-agent-1.desktop", "org.gnome.Software.desktop",
    "gnome-keyring-pkcs11.desktop", "gnome-keyring-secrets.desktop", "gnome-keyring-ssh.desktop",
    "geoclue-demo-agent.desktop", "xscreensaver.desktop", "light-locker.desktop", "xiccd.desktop",
    "org.kde.kdeconnect.daemon.desktop", "user-dirs-update-gtk.desktop", "pulseaudio.desktop",
}


def autostart_entries():
    user_dir = os.path.join(GLib.get_user_config_dir(), "autostart")
    files = {}
    for d in ["/etc/xdg/autostart", user_dir]:
        for f in glob.glob(os.path.join(d, "*.desktop")):
            files[os.path.basename(f)] = f
    entries = []
    for fid, path in sorted(files.items()):
        if fid.startswith("pine-") or fid in SYSTEM_AUTOSTART:
            continue
        kf = GLib.KeyFile()
        try:
            kf.load_from_file(path, GLib.KeyFileFlags.NONE)
        except GLib.Error:
            continue

        def get(key, default=""):
            try:
                return kf.get_locale_string("Desktop Entry", key, None)
            except GLib.Error:
                return default
        only, notin = get("OnlyShowIn"), get("NotShowIn")
        if (only and "XFCE" not in only) or "XFCE" in notin:
            continue
        hidden = get("Hidden").lower() == "true"
        entries.append({"id": fid, "path": path, "name": get("Name", fid), "comment": get("Comment"),
                        "enabled": not hidden, "user": path.startswith(user_dir)})
    return entries, user_dir


def set_autostart(entry, user_dir, on):
    os.makedirs(user_dir, exist_ok=True)
    target = os.path.join(user_dir, entry["id"])
    kf = GLib.KeyFile()
    kf.load_from_file(entry["path"], GLib.KeyFileFlags.KEEP_TRANSLATIONS)
    kf.set_boolean("Desktop Entry", "Hidden", not on)
    kf.save_to_file(target)
    if on and os.path.exists(os.path.join("/etc/xdg/autostart", entry["id"])):
        os.remove(target)   # back to the system default
    entry["path"] = target if os.path.exists(target) else os.path.join("/etc/xdg/autostart", entry["id"])


def add_startup_dialog(user_dir):
    apps = sorted((a for a in Gio.AppInfo.get_all() if a.should_show()), key=lambda a: name_of(a).lower())
    lb = Gtk.ListBox(selection_mode=Gtk.SelectionMode.NONE)
    lb.add_css_class("boxed-list")
    sc = Gtk.ScrolledWindow(vexpand=True, min_content_height=360)
    sc.set_child(lb)
    box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, margin_top=6, margin_bottom=18, margin_start=18, margin_end=18)
    box.append(sc)
    d = c.dialog("Start an app when you sign in", box, 440, 520)

    def add(a):
        os.makedirs(user_dir, exist_ok=True)
        src = a.get_filename()
        kf = GLib.KeyFile()
        kf.load_from_file(src, GLib.KeyFileFlags.KEEP_TRANSLATIONS)
        kf.set_boolean("Desktop Entry", "Hidden", False)
        kf.save_to_file(os.path.join(user_dir, os.path.basename(src)))
        d.close()
        c.toast(f"{name_of(a)} will start when you sign in")
        c.WINDOW.refresh()
    for a in apps:
        r = c.row(name_of(a), None, None, c.button("Add", lambda a=a: add(a)))
        if a.get_icon():
            r.add_prefix(Gtk.Image.new_from_gicon(a.get_icon()))
        lb.append(r)
    d.present(c.WINDOW)


# ================================================================ installed apps
def app_kind(app):
    fn = app.get_filename() or ""
    return "flatpak" if "/flatpak/" in fn else "deb"


def uninstall(app):
    name = name_of(app)
    fn = app.get_filename() or ""
    if app_kind(app) == "flatpak":
        appid = os.path.basename(fn)[:-len(".desktop")]
        user = fn.startswith(GLib.get_home_dir())
        c.confirm(f"Uninstall {name}?", "The app and its data will be removed.", "Uninstall", lambda: (
            c.toast(f"Uninstalling {name}…"),
            c.run_async(["flatpak", "uninstall", "-y", "--noninteractive"] + (["--user"] if user else []) + [appid],
                        lambda rc, o, e: (c.toast(f"{name} was uninstalled" if rc == 0 else f"{name} was not uninstalled"),
                                          c.WINDOW.refresh()), timeout=600)), True)
        return
    rc, out, _ = c.run(["dpkg", "-S", os.path.realpath(fn)])
    pkg = out.split(":")[0].strip() if rc == 0 else ""
    if not pkg:
        c.error("This app can't be uninstalled here", "Pine OS could not tell which package it belongs to.")
        return

    def checked(rc, out, err):
        removed = re.findall(r"^Remv (\S+)", out, re.M)
        if rc != 0 or not removed or len(removed) > 4 or CORE_PACKAGES & set(removed):
            c.error(f"{name} is part of Pine OS", "Removing it would also remove parts of the system, so it stays.")
            return
        c.confirm(f"Uninstall {name}?", "Removed packages: " + ", ".join(removed), "Uninstall", lambda: (
            c.toast(f"Uninstalling {name}…"),
            c.root_sh(f"apt-get remove -y {' '.join(removed)}",
                      lambda rc, o, e: (c.toast(f"{name} was uninstalled" if rc == 0 else f"{name} was not uninstalled"),
                                        c.WINDOW.refresh()))), True)
    c.run_async(["apt-get", "-s", "remove", pkg], checked)


def installed_group():
    apps = sorted((a for a in Gio.AppInfo.get_all() if a.should_show()), key=lambda a: name_of(a).lower())
    g = c.group("Installed apps", f"{len(apps)} apps")
    search = Gtk.SearchEntry(placeholder_text="Search apps", valign=Gtk.Align.CENTER)
    g.set_header_suffix(search)
    rows = []
    for a in apps:
        kind = app_kind(a)
        if a.get_id() == STORE_ID + ".desktop":
            r = c.row(name_of(a), "Part of Pine OS")
        else:
            sub = "Flatpak" if kind == "flatpak" else "System app"
            rm = c.button(None, lambda a=a: uninstall(a), "flat", "user-trash-symbolic")
            rm.set_tooltip_text("Uninstall")
            r = c.row(name_of(a), sub, None, rm)
        if a.get_icon():
            img = Gtk.Image.new_from_gicon(a.get_icon())
            img.set_pixel_size(32)
            r.add_prefix(img)
        r.search_text = name_of(a).lower()
        rows.append(r)
        g.add(r)

    def filt(e):
        q = e.get_text().lower().strip()
        for r in rows:
            r.set_visible(q in r.search_text)
    search.connect("search-changed", filt)
    return g


def build_apps():
    store = c.group(rows=[c.row("Get more apps", "Browse thousands of free apps in the App Store", "system-software-install-symbolic",
                                c.button("Open App Store", lambda: c.run_async(["flatpak", "run", STORE_ID]), "suggested-action"))])
    defaults = c.group("Default apps", "Which app opens each kind of file", [default_row(*d) for d in DEFAULTS])
    # startup apps live on the Startup page now
    start = c.group(rows=[c.row("Startup apps", "Apps that start when you sign in", "system-run-symbolic", nav="startup")])
    return c.page("Apps", store, defaults, start, installed_group())


PAGES["apps"] = {"title": "Apps", "build": build_apps, "parent": None}
SEARCH += [(t, s, "apps") for t, s in (
    ("Default apps", "Browser, email, open with, file associations"),     ("Uninstall", "Remove app, installed apps"), ("App Store", "Install apps, software"))]
