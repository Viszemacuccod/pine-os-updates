#!/usr/bin/python3
"""Pine OS system sounds (pine-sounds), started at sign-in:

  - the start-up sound, once, when the desktop is ready
  - a short sound for every new notification (not for the volume pop-up, not in Do not disturb,
    not in Game mode)
Both can be turned off in Settings > System > Sound (settings.json "sounds": {"startup", "notify"}).
It waits for notifications with dbus-monitor, so it uses no CPU in between.
"""
import json
import os
import shutil
import subprocess
import sys
import time

SOUNDS = "/usr/share/sounds/pine"
CONFIG = os.path.join(os.environ.get("XDG_CONFIG_HOME") or os.path.expanduser("~/.config"), "pine", "settings.json")
GAME_FILE = os.path.join(os.path.dirname(CONFIG), "game-mode-restore.json")
SKIP_APPS = {"Volume"}          # the volume pop-up has its own feedback


def want(key):
    try:
        with open(CONFIG) as f:
            return bool(json.load(f).get("sounds", {}).get(key, True))
    except (OSError, ValueError, AttributeError):
        return True


def player():
    for cmd in (["pw-play"], ["paplay"], ["aplay", "-q"]):
        if shutil.which(cmd[0]):
            return cmd
    return None


def play(name):
    p = player()
    f = os.path.join(SOUNDS, name)
    if p and os.path.exists(f):
        subprocess.Popen(p + [f], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)


def do_not_disturb():
    try:
        out = subprocess.run(["xfconf-query", "-c", "xfce4-notifyd", "-p", "/do-not-disturb"],
                             capture_output=True, text=True, timeout=5).stdout.strip()
    except (OSError, subprocess.TimeoutExpired):
        return False
    return out == "true"


def main():
    if "--test" in sys.argv:
        play("startup.wav" if "startup" in sys.argv else "notification.wav")
        time.sleep(3)
        return
    if "--login" in sys.argv and want("startup"):      # only the sign-in start plays the chime
        play("startup.wav")
    if not shutil.which("dbus-monitor"):
        return
    mon = subprocess.Popen(["dbus-monitor", "--session",
                            "type='method_call',interface='org.freedesktop.Notifications',member='Notify'"],
                           stdout=subprocess.PIPE, stderr=subprocess.DEVNULL, text=True)
    last, pending = 0.0, None        # pending: the argument lines after a Notify call
    for line in mon.stdout:
        if "member=Notify" in line and line.startswith("method call"):
            pending = []
            continue
        if pending is None:
            continue
        s = line.strip()
        if s.startswith(("string", "uint32")):
            pending.append(s)
        if len(pending) >= 2:        # app name, replaces_id
            app = pending[0].split('"', 1)[1].rsplit('"', 1)[0] if '"' in pending[0] else ""
            replaces = pending[1].split()[-1] if pending[1].startswith("uint32") else "0"
            pending = None
            if (app in SKIP_APPS or replaces != "0" or not want("notify") or os.path.exists(GAME_FILE)
                    or time.monotonic() - last < 1.5 or do_not_disturb()):
                continue
            last = time.monotonic()
            play("notification.wav")


if __name__ == "__main__":
    main()
