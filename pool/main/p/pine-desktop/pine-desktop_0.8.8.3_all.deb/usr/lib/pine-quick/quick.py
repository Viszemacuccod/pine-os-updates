#!/usr/bin/python3
"""Pine Quick Settings and notification center (GTK 3: these pop-ups must be placed above the
taskbar, which GTK 4 can't do on X11).

    pine-quick qs                 open / close Quick Settings (taskbar status icons, Win+A)
    pine-quick nc                 open / close the notification center (taskbar clock, Win+N)
    pine-quick volume up|down|mute   volume keys (with an on-screen level)
    pine-quick --daemon           start in the background (session autostart)

The background part keeps the two taskbar buttons up to date: it draws them as small pictures
($XDG_RUNTIME_DIR/pine-quick/*.svg) that the taskbar's "genmon" plugins show (pine-tray), and
asks the taskbar to reload them when something changes (network, volume, battery, a new
notification, the minute).
"""
import datetime
import html
import os
import re
import subprocess
import sys
import threading
import time

import gi
gi.require_version("Gtk", "3.0")
gi.require_version("Gdk", "3.0")
gi.require_version("Pango", "1.0")
gi.require_version("PangoCairo", "1.0")
from gi.repository import GLib  # noqa: E402
# Window class "Pine-quick" (picom lets these pop-ups rise from the taskbar). GTK picks the
# class when it is imported, so the name has to be set before that.
GLib.set_prgname("pine-quick")
from gi.repository import Gdk, Gio, Gtk, Pango, PangoCairo  # noqa: E402

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import system as S  # noqa: E402

# Translations (po/ in the Pine OS project): label(), Tile, flat_button and tooltips translate
# what they show; untranslated text stays English
import gettext  # noqa: E402
_TR = gettext.translation("pine", fallback=True)


def _(text):
    return _TR.gettext(text) if isinstance(text, str) and text else text

APP_ID = "org.pineos.Quick"
RUNDIR = os.path.join(os.environ.get("XDG_RUNTIME_DIR") or f"/tmp/pine-quick-{os.getuid()}", "pine-quick")
ICON_DIRS = ["/usr/share/icons/Papirus/16x16/symbolic", "/usr/share/icons/Adwaita/symbolic",
             "/usr/share/icons/Adwaita/scalable"]
BADGE_GREEN = "#1fae62"


def bg(func, done=None):
    """Run func in a thread; done(result) on the main thread."""
    def work():
        try:
            res = func()
        except Exception as ex:  # keep the pop-ups alive whatever a tool does
            print("pine-quick:", ex, file=sys.stderr)
            res = None
        if done:
            GLib.idle_add(lambda: (done(res), False)[1])
    threading.Thread(target=work, daemon=True).start()


def debounce(owner, key, ms, func):
    """Call func once, ms after the last request with this key."""
    timers = owner.__dict__.setdefault("_debounce", {})
    if timers.get(key):
        GLib.source_remove(timers[key])

    def fire():
        timers[key] = 0
        func()
        return False
    timers[key] = GLib.timeout_add(ms, fire)


# ================================================================ taskbar pictures
_icon_cache = {}


def find_icon(*names):
    for name in names:
        if name in _icon_cache:
            if _icon_cache[name]:
                return _icon_cache[name]
            continue
        path = None
        for d in ICON_DIRS:
            for root, _, files in os.walk(d):
                if name + ".svg" in files:
                    path = os.path.join(root, name + ".svg")
                    break
            if path:
                break
        _icon_cache[name] = path
        if path:
            return path
    return None


def icon_svg(path, color, x, y, size=16):
    """An icon file as a nested <svg>, recolored (symbolic icons are dark grey)."""
    try:
        data = open(path).read()
    except (OSError, TypeError):
        return ""
    root = re.search(r"<svg\b[^>]*>", data)
    body = re.search(r"<svg\b[^>]*>(.*)</svg>", data, re.S)
    if not root or not body:
        return ""
    vb = re.search(r'viewBox="([^"]+)"', root.group(0))
    vb = vb.group(1) if vb else "0 0 16 16"
    # Papirus: ".ColorScheme-Text { color:#dfdfdf; }" (+ fill:currentColor); Adwaita: plain dark grey
    inner = re.sub(r"(\.ColorScheme-Text\s*\{\s*color:\s*)#[0-9a-f]{3,6}", r"\g<1>" + color, body.group(1), flags=re.I)
    inner = re.sub(r"#(444444|444|2e3436|bebebe|dfdfdf)\b", color, inner, flags=re.I)
    return f'<svg x="{x}" y="{y}" width="{size}" height="{size}" viewBox="{vb}" color="{color}" fill="{color}">{inner}</svg>'


def text_width(text, px, bold=False):
    ctx = PangoCairo.FontMap.get_default().create_context()
    lay = Pango.Layout.new(ctx)
    d = Pango.FontDescription.from_string("Inter")
    d.set_absolute_size(px * Pango.SCALE)
    if bold:
        d.set_weight(Pango.Weight.BOLD)
    lay.set_font_description(d)
    lay.set_text(text, -1)
    return lay.get_pixel_size()[0]


def tray_colors():
    mode, accent, _ = S.look()
    dark = mode != "light"
    return {"icon": "#c9d3ce" if dark else "#2f3d37", "time": "#f2f4f3" if dark else "#14201b",
            "date": "#c9d3ce" if dark else "#2f3d37", "ring": "#0b1215" if dark else "#f3f5f4"}


def network_icon(net):
    if net["airplane"]:
        return find_icon("airplane-mode-symbolic", "network-offline-symbolic")
    if net["type"] == "ethernet":
        return find_icon("network-wired-symbolic")
    if net["type"] == "wifi":
        s = net["signal"]
        level = "excellent" if s >= 75 else "good" if s >= 50 else "ok" if s >= 25 else "weak"
        return find_icon(f"network-wireless-signal-{level}-symbolic", "network-wireless-symbolic")
    if net["wifi_dev"] and net["wifi_on"]:
        return find_icon("network-wireless-offline-symbolic", "network-wireless-disconnected-symbolic",
                         "network-offline-symbolic")
    return find_icon("network-offline-symbolic", "network-wired-disconnected-symbolic")


def volume_icon(vol, muted):
    if muted or vol == 0:
        return find_icon("audio-volume-muted-symbolic")
    return find_icon("audio-volume-low-symbolic" if vol < 34 else "audio-volume-medium-symbolic" if vol < 67
                     else "audio-volume-high-symbolic")


def battery_icon(bat):
    pct, state = bat
    lvl = min(100, int(round(pct / 10.0)) * 10)
    if state == "full":
        return find_icon("battery-full-charged-symbolic", "battery-level-100-charged-symbolic", "battery-full-symbolic")
    if state == "charging":
        return find_icon(f"battery-level-{lvl}-charging-symbolic", "battery-good-charging-symbolic")
    return find_icon(f"battery-level-{lvl}-symbolic", "battery-good-symbolic" if pct > 30 else "battery-low-symbolic")


def write_tray(name, svg, xml):
    os.makedirs(RUNDIR, exist_ok=True)
    for fname, text in ((name + ".svg", svg), (name + ".xml", xml)):
        tmp = os.path.join(RUNDIR, fname + ".tmp")
        with open(tmp, "w") as f:
            f.write(text)
        os.replace(tmp, os.path.join(RUNDIR, fname))


def render_status():
    """Network, volume and battery icons in one picture (one button on the taskbar)."""
    col = tray_colors()["icon"]
    net = S.network()
    vol, muted = S.volume()
    bat = S.battery()
    icons = [network_icon(net), volume_icon(vol, muted)] + ([battery_icon(bat)] if bat else [])
    icons = [i for i in icons if i]
    w = len(icons) * 16 + (len(icons) - 1) * 10
    parts = [icon_svg(p, col, i * 26, 0) for i, p in enumerate(icons)]
    svg = f'<svg xmlns="http://www.w3.org/2000/svg" width="{w}" height="16" viewBox="0 0 {w} 16">{"".join(parts)}</svg>'
    tip = [("Airplane mode" if net["airplane"] else f"Wi-Fi: {net['name']}" if net["type"] == "wifi"
            else "Ethernet" if net["type"] == "ethernet" else "Not connected"),
           f"Volume: {'muted' if muted else str(vol) + '%'}"]
    if bat:
        tip.append(f"Battery: {S.battery_text()}")
    # no tooltip: nothing pops up when the mouse only moves over the taskbar (Quick Settings
    # shows all of this on click)
    del tip
    xml = f"<img>{os.path.join(RUNDIR, 'status.svg')}</img><click>pine-quick qs</click><tool></tool>"
    write_tray("status", svg, xml)


def render_clock():
    """Time over date; the date is centered, the time ends where the date ends; a small green
    dot with the number of unread notifications in the top right corner."""
    c = tray_colors()
    now = datetime.datetime.now()
    t, d = now.strftime("%H:%M"), now.strftime("%Y. %m. %d.")
    pad = 18
    inner = max(text_width(d, 12), text_width(t, 13))
    w, h = inner + 2 * pad, 40
    right = w - pad
    parts = [f'<text x="{right}" y="17" text-anchor="end" font-family="Inter" font-size="13" fill="{c["time"]}">{t}</text>',
             f'<text x="{right}" y="33" text-anchor="end" font-family="Inter" font-size="12" fill="{c["date"]}">{d}</text>']
    n = 0 if S.dnd() else S.unread_count()
    if n:
        label = "9+" if n > 9 else str(n)
        bw = 16 if len(label) == 1 else 22
        x = w - bw - 1
        parts.append(f'<rect x="{x}" y="1" width="{bw}" height="16" rx="5" fill="{BADGE_GREEN}" stroke="{c["ring"]}" stroke-width="2"/>'
                     f'<text x="{x + bw / 2}" y="12.5" text-anchor="middle" font-family="Inter" font-weight="700" '
                     f'font-size="10" fill="#ffffff">{label}</text>')
    svg = f'<svg xmlns="http://www.w3.org/2000/svg" width="{w}" height="{h}" viewBox="0 0 {w} {h}">{"".join(parts)}</svg>'
    # no tooltip (calm taskbar): the date and notifications are one click away
    xml = f"<img>{os.path.join(RUNDIR, 'clock.svg')}</img><click>pine-quick nc</click><tool></tool>"
    write_tray("clock", svg, xml)


def panel_plugins():
    """{"status": "genmon-6", "clock": "genmon-9"}: the taskbar plugins that show our pictures
    (their settings: ~/.config/xfce4/panel/genmon-N.rc, defaults in /etc/xdg/xfce4/panel)."""
    found = {}
    cfg = os.environ.get("XDG_CONFIG_HOME") or os.path.expanduser("~/.config")
    for d in ("/etc/xdg/xfce4/panel", os.path.join(cfg, "xfce4", "panel")):   # the user's own wins
        try:
            names = os.listdir(d)
        except OSError:
            continue
        for fn in names:
            m = re.match(r"(genmon-\d+)\.rc$", fn)
            if not m:
                continue
            try:
                text = open(os.path.join(d, fn)).read()
            except OSError:
                continue
            c = re.search(r"^Command=\S*pine-tray (\w+)", text, re.M)
            if c:
                found[c.group(1)] = m.group(1)
    return found


# ================================================================ pop-up look
def css():
    mode, accent, _ = S.look()
    p = S.theme.colors(mode, accent)
    return f"""
/* Like Pine Settings (theme.SETTINGS_LOOK): the Settings window color, cards without frames,
   buttons, accent-tinted icons, bold headings, the same switches and sliders.
   The pop-ups sit in the bottom right corner, on the taskbar and the screen edge: the free
   top left corner is rounded (5 px), the corners on the edges are square. The window itself
   is see-through so the rounded corner shows (solid when there is no compositor). */
#pine-quick {{ background-color: transparent; color: {p['fg']}; border: none; }}
#pine-quick.solid {{ background-color: {p['surface']}; }}
#pine-quick .panel {{ background-color: {p['surface']}; border-top: 1px solid {p['line']};
  border-left: 1px solid {p['line']}; border-radius: 5px 0 0 0; }}
#pine-quick .panel > .foot:last-child {{ border-radius: 0; }}
#pine-quick scale trough, #pine-quick scale highlight, #pine-quick scale slider {{ border-radius: 5px; }}
/* switch: the same as in Pine Settings (a 5 px track, a light square knob; accent track when on) */
#pine-quick switch {{ min-width: 46px; min-height: 26px; border-radius: 5px; border: none; box-shadow: none;
  background-image: none; background-color: {p['slider']}; color: transparent; font-size: 0; text-shadow: none;
  transition: background-color 90ms ease-out; }}
#pine-quick switch slider {{ min-width: 20px; min-height: 20px; margin: 3px; border-radius: 4px; border: none;
  transition: all 110ms ease-out;
  box-shadow: none; background-image: none; background-color: {'#e6eae8' if p['mode'] == 'dark' else '#ffffff'}; }}
#pine-quick switch:checked {{ background-color: {accent}; }}
#pine-quick switch:checked slider {{ background-color: #ffffff; }}
#pine-quick switch label, #pine-quick switch image {{ color: transparent; font-size: 0; opacity: 0; }}
#pine-quick .dnd-card {{ background-color: {p['card']}; border-radius: 5px; }}
#pine-quick image.dnd-icon {{ color: {p['row_icon']}; }}
#pine-quick label {{ color: {p['fg']}; }}
#pine-quick .muted, #pine-quick .tile-sub, #pine-quick .note-src {{ color: {p['muted']}; font-size: 0.85em; }}
#pine-quick .tile-title {{ color: {p['fg']}; font-size: 0.92em; }}
#pine-quick .tilebtn {{ background-color: {p['card']}; border: none; border-radius: 5px; }}
#pine-quick .tilebtn button {{ background: none; border: none; box-shadow: none; min-height: 46px; padding: 0;
  color: {p['row_icon']}; border-radius: 5px; transition: background-color 90ms ease-out; }}
#pine-quick .tilebtn button image {{ color: {p['row_icon']}; }}
#pine-quick .tilebtn button.left {{ border-radius: 5px 0 0 5px; }}
#pine-quick .tilebtn button.more {{ border-radius: 0 5px 5px 0; min-width: 28px; border-left: 1px solid {p['line']}; }}
#pine-quick .tilebtn button.more image {{ color: {p['muted']}; }}
#pine-quick .tilebtn button:hover {{ background-color: {p['card_hover']}; }}
#pine-quick .tile.on .tilebtn {{ background-color: {accent}; }}
#pine-quick .tile.on .tilebtn button, #pine-quick .tile.on .tilebtn button image {{ color: {p['on_accent']}; }}
#pine-quick .tile.on .tilebtn button.more {{ border-left-color: rgba(0,0,0,0.15); }}
#pine-quick .tile.on .tilebtn button:hover {{ background-color: rgba(255,255,255,0.14); }}
#pine-quick button {{ background-image: none; background-color: {p['btn']}; border: none; box-shadow: none;
  border-radius: 5px; color: {p['fg']}; text-shadow: none; -gtk-icon-shadow: none; }}
#pine-quick button:hover {{ background-color: {p['btn_hover']}; }}
#pine-quick button:active {{ background-color: {p['btn_press']}; }}
#pine-quick button.suggested-action {{ background-color: {accent}; color: {p['on_accent']}; }}
#pine-quick button.suggested-action label {{ color: {p['on_accent']}; }}
#pine-quick button.flat, #pine-quick button.icon {{ background: none; min-height: 34px; min-width: 34px; padding: 0 6px; }}
#pine-quick button.flat:hover, #pine-quick button.icon:hover {{ background-color: {p['hover']}; }}
#pine-quick button.link, #pine-quick button.link label {{ color: {p['link']}; }}
#pine-quick .foot {{ background-color: {p['sidebar']}; border-top: 1px solid {p['line']}; }}
#pine-quick .heading {{ font-weight: bold; }}
#pine-quick list {{ background: none; }}
#pine-quick list row {{ background-color: {p['card']}; border-radius: 0; padding: 9px 12px; margin-bottom: 1px; }}
#pine-quick list row:first-child {{ border-radius: 5px 5px 0 0; }}
#pine-quick list row:last-child {{ border-radius: 0 0 5px 5px; margin-bottom: 0; }}
#pine-quick list row:only-child {{ border-radius: 5px; }}
#pine-quick list row:hover {{ background-color: {p['card_hover']}; }}
#pine-quick list row.sel {{ background-color: {p['accent_soft']}; }}
#pine-quick list row image {{ color: {p['row_icon']}; }}
#pine-quick .act {{ color: {p['link']}; font-weight: 600; font-size: 0.88em; }}
#pine-quick .note {{ background-color: {p['card']}; border: none; border-radius: 5px; padding: 10px 10px 11px 12px; }}
#pine-quick .note:hover {{ background-color: {p['card_hover']}; }}
#pine-quick button.note-x {{ min-height: 22px; min-width: 22px; padding: 0; opacity: 0.55; }}
#pine-quick button.note-x:hover {{ opacity: 1; }}
#pine-quick .grp-name {{ font-weight: bold; font-size: 0.9em; color: {p['fg']}; }}
#pine-quick .grp-count {{ background-color: {p['accent_soft']}; border-radius: 5px; padding: 0 7px; font-size: 0.8em;
  font-weight: 600; color: {p['badge_fg']}; }}
#pine-quick button.grp-btn {{ min-height: 22px; min-width: 22px; padding: 0 6px; font-size: 0.82em; color: {p['muted']}; }}
#pine-quick button.grp-btn label {{ color: {p['muted']}; }}
#pine-quick button.grp-btn:hover label, #pine-quick button.grp-btn:hover {{ color: {p['fg']}; }}
#pine-quick .note-summary {{ font-weight: bold; }}
#pine-quick .note-body {{ color: {p['fg2']}; font-size: 0.92em; }}
#pine-quick .sep {{ border-top: 1px solid {p['line']}; }}
#pine-quick calendar {{ background: none; border: none; color: {p['fg']}; padding: 2px; }}
#pine-quick calendar:selected {{ background-color: {accent}; color: {p['on_accent']}; border-radius: 5px; }}
#pine-quick calendar.header {{ background: none; border: none; }}
#pine-quick calendar.button {{ color: {p['muted']}; }}
#pine-quick calendar:indeterminate {{ color: alpha({p['fg']}, 0.35); }}
#pine-quick scale highlight {{ background-color: {accent}; }}
#pine-quick entry {{ min-height: 36px; border-radius: 5px; background-color: {p['card']}; border: 1px solid {p['line']};
  box-shadow: none; color: {p['fg']}; }}
#pine-quick entry:focus {{ border-color: {accent}; box-shadow: inset 0 0 0 1px {accent}; }}
#pine-quick .menu-item {{ padding: 6px 10px; }}
"""


def icon(name, size=18):
    img = Gtk.Image.new_from_icon_name(name, Gtk.IconSize.BUTTON)
    img.set_pixel_size(size)
    return img


def label(text, cls=None, xalign=0, wrap=False, ellipsize=False):
    lb = Gtk.Label(label=_(text), xalign=xalign)
    if cls:
        lb.get_style_context().add_class(cls)
    if wrap:
        lb.set_line_wrap(True)
        lb.set_line_wrap_mode(Pango.WrapMode.WORD_CHAR)
    if ellipsize:
        lb.set_ellipsize(Pango.EllipsizeMode.END)
    return lb


def styled(widget, *classes):
    for cl in classes:
        widget.get_style_context().add_class(cl)
    return widget


def flat_button(child, on_click, *classes):
    b = Gtk.Button()
    b.add(child if not isinstance(child, str) else Gtk.Label(label=_(child)))
    styled(b, "flat", *classes)
    b.connect("clicked", lambda *_: on_click())
    return b


OPEN_MS, CLOSE_MS = 140, 90      # open: fade in and rise; close: fade out and sink a little
RISE, SINK = 10, 6               # px


class Popup(Gtk.Window):
    """A borderless window in the bottom right corner, on the taskbar and the screen edge;
    closes when it loses focus.

    Animations are drawn here, not by the compositor: the window fades in while it rises from
    the taskbar, and fades out while it sinks back. On every frame the bottom edge stays on the
    taskbar while the content grows or shrinks (page changes, notifications), so nothing jumps.
    picom leaves these windows alone (theme.py: class Pine-quick, animations = ())."""

    def __init__(self, app, width):
        super().__init__(application=app)
        self.app = app
        self.set_name("pine-quick")      # window class "Pine-quick" comes from the program name
        # see-through window, so the panel's rounded corner shows (with the compositor on)
        screen = self.get_screen()
        vis = screen.get_rgba_visual()
        if vis and screen.is_composited():
            self.set_visual(vis)
            self.set_app_paintable(True)
        else:
            styled(self, "solid")
        self.set_title("Pine Quick Settings")
        self.set_decorated(False)
        self.set_resizable(False)
        self.set_skip_taskbar_hint(True)
        self.set_skip_pager_hint(True)
        self.set_keep_above(True)
        self.set_type_hint(Gdk.WindowTypeHint.UTILITY)
        self.set_default_size(width, -1)
        self.set_size_request(width, -1)
        self.hidden_at = 0.0
        self.dy = 0                  # how far below its place the window is (animations)
        self.last_h = 0
        self.closing = False
        self.anim = 0                # the running animation (a newer one stops it)
        self.connect("focus-out-event", self.on_focus_out)
        self.connect("key-press-event", self.on_key)
        self.connect("delete-event", lambda *_: (self.close_popup(), True)[1])

    def fit(self):
        """Grow or shrink to the content on the next frame (keep_anchored does it)."""
        self.last_h = 0

    @staticmethod
    def corner(w, h):
        """(x, y) that puts a w x h pop-up in the bottom right corner of the work area (right
        on the taskbar and the screen's right edge)."""
        disp = Gdk.Display.get_default()
        mon = disp.get_primary_monitor() or disp.get_monitor(0)
        wa = mon.get_workarea()
        return wa.x + wa.width - w, wa.y + wa.height - h

    def place(self, resize=False):
        _, nat = self.get_preferred_size()
        w = max(nat.width, self.get_size_request()[0])
        if resize:
            self.resize(w, nat.height)
        x, y = self.corner(w, nat.height)
        self.move(x, y + self.dy)
        return nat.height

    def keep_anchored(self, *_):
        """Every frame while open: the window is as tall as its content, bottom on the taskbar."""
        if not self.get_visible():
            return False
        _, nat = self.get_preferred_size()
        if nat.height != self.last_h:
            self.last_h = self.place(resize=True)
        return True

    def animated(self):
        return bool(S.look()[2]) and self.get_screen().is_composited()

    def slide(self, target, ms, dist, done=None):
        """Fade to opacity target (0 or 1) in ms, the window dist px below its place at
        opacity 0; the bottom stays anchored meanwhile."""
        self.anim += 1
        token, start_op, t0 = self.anim, self.get_opacity(), []

        def tick(_w, clock):
            if token != self.anim:
                return False
            now = clock.get_frame_time() / 1000.0
            if not t0:
                t0.append(now)
            t = min(1.0, (now - t0[0]) / ms)
            e = 1 - (1 - t) ** 3 if target > start_op else t * t       # ease out / ease in
            op = start_op + (target - start_op) * e
            self.set_opacity(op)
            self.dy = round(dist * (1 - op))
            self.place()
            if t >= 1.0:
                if done:
                    done()
                return False
            return True
        self.add_tick_callback(tick)

    def open_popup(self):
        self.anim += 1               # stops a closing animation
        self.closing = False
        self.refresh()
        anim = self.animated()
        self.dy = RISE if anim else 0
        self.set_opacity(0.0 if anim else 1.0)
        self.last_h = 0
        self.place(resize=True)
        self.show()
        self.present_with_time(Gtk.get_current_event_time() or GLib.get_monotonic_time() // 1000)
        self.add_tick_callback(lambda *_: self.keep_anchored())
        if anim:
            self.slide(1.0, OPEN_MS, RISE)

    def close_popup(self):
        if not self.get_visible() or self.closing:
            return
        self.hidden_at = time.monotonic()
        if self.animated():
            self.closing = True
            self.slide(0.0, CLOSE_MS, SINK, self.hide_now)
        else:
            self.hide_now()

    def hide_now(self):
        self.closing = False
        self.anim += 1
        self.hide()
        self.dy = 0
        self.set_opacity(1.0)

    def toggle(self):
        if self.get_visible() and not self.closing:
            self.close_popup()
        elif time.monotonic() - self.hidden_at > 0.4:   # the click that took the focus away closed it
            self.open_popup()

    def on_focus_out(self, *_):
        GLib.timeout_add(120, lambda: (not self.is_active() and self.close_popup(), False)[1])
        return False

    def on_key(self, _w, ev):
        if ev.keyval == Gdk.KEY_Escape:
            self.on_escape()
            return True
        return False

    def on_escape(self):
        self.close_popup()

    def refresh(self):
        pass


# ================================================================ Quick Settings
class Tile(Gtk.Box):
    def __init__(self, icon_name, title, on_toggle, on_more=None):
        super().__init__(orientation=Gtk.Orientation.VERTICAL, spacing=5)
        styled(self, "tile")
        self.btns = styled(Gtk.Box(), "tilebtn")
        self.main = Gtk.Button()
        self.main.add(icon(icon_name, 20))
        self.main.set_hexpand(True)
        self.main.connect("clicked", lambda *_: on_toggle())
        self.btns.pack_start(self.main, True, True, 0)
        if on_more:
            styled(self.main, "left")
            self.more = Gtk.Button()
            self.more.add(icon("pan-end-symbolic", 14))
            styled(self.more, "more")
            self.more.connect("clicked", lambda *_: on_more())
            self.btns.pack_start(self.more, False, False, 0)
        self.title = label(title, "tile-title", xalign=0.5, ellipsize=True)
        self.sub = label("", "tile-sub", xalign=0.5, ellipsize=True)
        for wdg in (self.btns, self.title, self.sub):
            self.pack_start(wdg, False, False, 0)

    def set(self, on, sub="", sensitive=True):
        ctx = self.get_style_context()
        (ctx.add_class if on else ctx.remove_class)("on")
        self.sub.set_text(_(sub))
        self.sub.set_visible(bool(sub))
        self.set_sensitive(sensitive)


class QuickSettings(Popup):
    def __init__(self, app):
        super().__init__(app, 372)
        self.state = {}
        self.busy = False
        outer = styled(Gtk.Box(orientation=Gtk.Orientation.VERTICAL), "panel")
        self.add(outer)
        # each page as tall as it needs (no empty space under fewer tiles); the window follows
        self.stack = Gtk.Stack(hhomogeneous=True, vhomogeneous=False, interpolate_size=True, transition_duration=140)
        outer.pack_start(self.stack, True, True, 0)

        # ---- main page: tiles and sliders
        main = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=18, margin=18)
        self.grid = Gtk.Grid(column_spacing=10, row_spacing=14, column_homogeneous=True)
        self.t_eth = Tile("network-wired-symbolic", "Ethernet", self.toggle_ethernet)
        self.t_wifi = Tile("network-wireless-symbolic", "Wi-Fi", self.toggle_wifi, lambda: self.go("wifi"))
        self.t_bt = Tile("bluetooth-active-symbolic", "Bluetooth", self.toggle_bt, lambda: self.go("bt"))
        self.t_air = Tile("airplane-mode-symbolic", "Airplane mode", self.toggle_airplane)
        self.t_dark = Tile("weather-clear-night-symbolic", "Dark mode", self.toggle_dark)
        self.t_night = Tile("night-light-symbolic", "Night light", self.toggle_night)
        self.t_dnd = Tile("notifications-disabled-symbolic", "Do not disturb", self.toggle_dnd)
        self.t_game = Tile("input-gaming-symbolic", "Game mode", self.toggle_game)
        self.tiles = [self.t_eth, self.t_wifi, self.t_bt, self.t_air, self.t_dark, self.t_night, self.t_dnd, self.t_game]
        self.shown_tiles = None
        self.layout_tiles(self.tiles)
        main.pack_start(self.grid, False, False, 0)

        sliders = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10)
        self.bright_row, self.bright = self.slider_row("display-brightness-symbolic", self.on_bright)
        self.vol_row, self.vol = self.slider_row("audio-volume-high-symbolic", self.on_vol, mute=True,
                                                 more=lambda: self.go("sound"))
        sliders.pack_start(self.bright_row, False, False, 0)
        sliders.pack_start(self.vol_row, False, False, 0)
        main.pack_start(sliders, False, False, 0)
        # battery (laptops only): percentage and time left, under the sliders
        self.bat_box = Gtk.Box(spacing=10, margin_start=8)
        self.bat_icon = icon("battery-good-symbolic", 18)
        self.bat_label = label("", "muted")
        self.bat_box.pack_start(self.bat_icon, False, False, 0)
        self.bat_box.pack_start(self.bat_label, False, False, 0)
        self.bat_box.set_no_show_all(True)
        self.bat_icon.show()
        self.bat_label.show()
        main.pack_start(self.bat_box, False, False, 0)
        self.stack.add_named(main, "main")

        # ---- sub pages
        self.wifi_page, self.wifi_list, self.wifi_switch, self.wifi_msg = self.sub_page(
            "Wi-Fi", lambda on: bg(lambda: S.set_wifi(on), lambda _r: self.after_change(lambda: self.go("wifi"))),
            "Network settings", "network")
        self.bt_page, self.bt_list, self.bt_switch, self.bt_msg = self.sub_page(
            "Bluetooth", lambda on: bg(lambda: S.set_bt(on), lambda _r: self.after_change(lambda: self.go("bt"))),
            "Bluetooth settings", "devices")
        self.sound_page, self.sound_list, _btn, self.sound_msg = self.sub_page("Sound output", None, "Sound settings", "sound")
        self.stack.add_named(self.wifi_page, "wifi")
        self.stack.add_named(self.bt_page, "bt")
        self.stack.add_named(self.sound_page, "sound")
        self.stack.add_named(self.password_page(), "password")
        # (no footer: settings and power are in the Start menu)
        outer.show_all()

    # ---- building blocks
    def layout_tiles(self, tiles):
        """Only the tiles for hardware this computer has (no Wi-Fi tile without Wi-Fi...), 3 per row."""
        if tiles == self.shown_tiles:
            return
        for t in self.grid.get_children():
            self.grid.remove(t)
        for i, t in enumerate(tiles):
            self.grid.attach(t, i % 3, i // 3, 1, 1)
            t.show()
        self.shown_tiles = list(tiles)

    def slider_row(self, icon_name, on_change, mute=False, more=None):
        row = Gtk.Box(spacing=8)
        ib = flat_button(icon(icon_name, 18), self.on_mute if mute else (lambda: None), "icon")
        if mute:
            self.vol_icon = ib.get_child()
            ib.set_tooltip_text(_("Mute"))
        scale = Gtk.Scale.new_with_range(Gtk.Orientation.HORIZONTAL, 0, 100, 1)
        scale.set_draw_value(False)
        scale.set_hexpand(True)
        scale.connect("value-changed", lambda s: None if self.busy else debounce(self, icon_name, 120, lambda: on_change(s.get_value())))
        row.pack_start(ib, False, False, 0)
        row.pack_start(scale, True, True, 0)
        if more:
            mb = flat_button(icon("pan-end-symbolic", 14), more, "icon")
            mb.set_tooltip_text(_("Choose where sound plays"))
            row.pack_start(mb, False, False, 0)
        return row, scale

    def sub_page(self, title, on_switch, settings_label, settings_page):
        page = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=8, margin=14)
        head = Gtk.Box(spacing=6)
        head.pack_start(flat_button(icon("go-previous-symbolic", 16), lambda: self.go("main"), "icon"), False, False, 0)
        head.pack_start(label(title, "heading"), False, False, 4)
        switch = None
        if on_switch:
            switch = Gtk.Switch(valign=Gtk.Align.CENTER)
            switch.connect("notify::active", lambda s, _p: None if self.busy else on_switch(s.get_active()))
            head.pack_end(switch, False, False, 4)
        page.pack_start(head, False, False, 0)
        msg = label("", "muted", wrap=True)
        msg.set_no_show_all(True)
        page.pack_start(msg, False, False, 0)
        sc = Gtk.ScrolledWindow(hscrollbar_policy=Gtk.PolicyType.NEVER, vexpand=True, min_content_height=230)
        lst = Gtk.ListBox(selection_mode=Gtk.SelectionMode.NONE)
        lst.connect("row-activated", lambda _l, r: getattr(r, "action", lambda: None)())
        sc.add(lst)
        page.pack_start(sc, True, True, 0)
        link = flat_button(settings_label + "…", lambda: self.open_settings(settings_page), "link")
        link.set_halign(Gtk.Align.START)
        page.pack_start(link, False, False, 0)
        return page, lst, switch, msg

    def password_page(self):
        page = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=12, margin=18)
        head = Gtk.Box(spacing=6)
        head.pack_start(flat_button(icon("go-previous-symbolic", 16), lambda: self.go("wifi"), "icon"), False, False, 0)
        self.pw_title = label("", "heading", ellipsize=True)
        head.pack_start(self.pw_title, True, True, 4)
        page.pack_start(head, False, False, 0)
        page.pack_start(label("Enter the network password (security key).", "muted", wrap=True), False, False, 0)
        self.pw_entry = Gtk.Entry(visibility=False, placeholder_text="Password", input_purpose=Gtk.InputPurpose.PASSWORD)
        self.pw_entry.set_icon_from_icon_name(Gtk.EntryIconPosition.SECONDARY, "view-reveal-symbolic")
        self.pw_entry.connect("icon-press", lambda e, *_: e.set_visibility(not e.get_visibility()))
        self.pw_entry.connect("activate", lambda *_: self.pw_connect())
        page.pack_start(self.pw_entry, False, False, 0)
        btn = Gtk.Button(label="Connect")
        styled(btn, "suggested-action")
        btn.connect("clicked", lambda *_: self.pw_connect())
        btn.set_halign(Gtk.Align.END)
        page.pack_start(btn, False, False, 0)
        return page

    # ---- state
    def refresh(self):
        self.go("main", animate=False)

        def gather():
            net = S.network()
            bt_hw = S.has_bluetooth()
            bt_av = bt_hw and S.bt_available()
            return {"net": net, "bt_hw": bt_hw, "radios": S.has_radios(), "bt_av": bt_av, "bt_on": bt_av and S.bt_powered(),
                    "bt_name": S.bt_connected_name() if bt_av else None, "vol": S.volume(),
                    "bright": S.brightness(), "bat": S.battery(), "bat_text": S.battery_text(),
                    "dark": S.look()[0] != "light", "night": S.night_light(), "dnd": S.dnd(),
                    "game": S.game_mode()}
        if not self.state:
            # the first time: the tiles are known before the window shows (no jump after opening)
            self.apply_state(gather())
        else:
            bg(gather, self.apply_state)

    def apply_state(self, st):
        if not st:
            return
        self.state = st
        net = st["net"]
        self.busy = True
        self.layout_tiles([t for t, show in ((self.t_eth, bool(net["eth_dev"])),
                                             (self.t_wifi, bool(net["wifi_dev"])), (self.t_bt, st["bt_hw"]),
                                             (self.t_air, st["radios"]), (self.t_dark, True), (self.t_night, True),
                                             (self.t_dnd, True), (self.t_game, True)) if show])
        self.fit()
        # Ethernet: on = connected (or connecting); without a cable it can't be turned on
        eth = net["eth_state"]
        self.t_eth.set(eth in ("connected", "connecting"),
                       "Connected" if eth == "connected" else "Connecting…" if eth == "connecting"
                       else "No cable" if eth == "unavailable" else "Off",
                       eth != "unavailable")
        wifi_on = net["wifi_on"] and not net["airplane"]
        self.t_wifi.set(wifi_on, (net["name"] if net["type"] == "wifi" else "Not connected") if wifi_on
                        else ("Airplane mode" if net["airplane"] else "Off"), bool(net["wifi_dev"]))
        if not net["wifi_dev"]:
            self.t_wifi.set(False, "No Wi-Fi", False)
        bt_on = st["bt_on"] and not net["airplane"]
        self.t_bt.set(bt_on, (st["bt_name"] or "On") if bt_on else ("Off" if st["bt_av"] else "Not available"), st["bt_av"])
        self.t_air.set(net["airplane"])
        self.t_dark.set(st["dark"])
        self.t_night.set(st["night"], "On" if st["night"] else "")
        self.t_dnd.set(st["dnd"])
        self.t_game.set(st["game"], "On" if st["game"] else "")
        vol, muted = st["vol"]
        self.vol.set_value(vol)
        self.vol_icon.set_from_icon_name("audio-volume-muted-symbolic" if muted or vol == 0 else
                                         "audio-volume-low-symbolic" if vol < 34 else "audio-volume-medium-symbolic"
                                         if vol < 67 else "audio-volume-high-symbolic", Gtk.IconSize.BUTTON)
        self.bright_row.set_visible(st["bright"] is not None)
        if st["bright"] is not None:
            self.bright.set_value(st["bright"])
        self.bat_box.set_visible(bool(st["bat"]))
        if st["bat"]:
            self.bat_label.set_text(st["bat_text"])
            self.bat_icon.set_from_icon_name(os.path.basename(battery_icon(st["bat"]) or "battery-good-symbolic.svg")[:-4],
                                             Gtk.IconSize.BUTTON)
        if self.wifi_switch:
            self.wifi_switch.set_active(wifi_on)
        if self.bt_switch:
            self.bt_switch.set_active(bt_on)
        self.busy = False

    def after_change(self, then=None):
        """Something was switched: update the pop-up and the taskbar icons."""
        self.refresh() if not then else (self.refresh(), then())
        self.app.update_status()

    # ---- actions
    def toggle_ethernet(self):
        dev = self.state.get("net", {}).get("eth_dev")
        if not dev:
            return
        on = not self.t_eth.get_style_context().has_class("on")
        self.t_eth.set(on, "Connecting…" if on else "Off")
        bg(lambda: S.set_ethernet(dev, on), lambda _r: self.after_change())

    def toggle_wifi(self):
        on = not self.t_wifi.get_style_context().has_class("on")
        bg(lambda: S.set_wifi(on), lambda _r: self.after_change())

    def toggle_bt(self):
        on = not self.t_bt.get_style_context().has_class("on")

        def work():
            S.set_bt(on)
            S.save_config(bluetooth=on)     # remembered for the next sign-in
            S.bt_helpers(on)
        bg(work, lambda _r: self.after_change())

    def toggle_airplane(self):
        on = not self.t_air.get_style_context().has_class("on")
        bg(lambda: S.set_airplane(on), lambda _r: self.after_change())

    def toggle_dark(self):
        on = not self.t_dark.get_style_context().has_class("on")
        self.t_dark.set(on)
        bg(lambda: S.set_dark(on), lambda _r: (self.app.restyle(), self.app.update_all()))

    def toggle_night(self):
        on = not self.t_night.get_style_context().has_class("on")
        self.t_night.set(on, "On" if on else "")
        bg(lambda: S.set_night_light(on))

    def toggle_game(self):
        on = not self.t_game.get_style_context().has_class("on")
        self.t_game.set(on, "On" if on else "")
        bg(lambda: S.set_game_mode(on))

    def toggle_dnd(self):
        on = not self.t_dnd.get_style_context().has_class("on")
        self.t_dnd.set(on)
        bg(lambda: S.set_dnd(on), lambda _r: self.app.update_clock())

    def on_bright(self, v):
        bg(lambda: S.set_brightness(v))

    def on_vol(self, v):
        bg(lambda: S.set_volume(v), lambda _r: (self.refresh_vol_icon(), self.app.update_status()))

    def on_mute(self):
        bg(S.toggle_mute, lambda _r: (self.refresh_vol_icon(), self.app.update_status()))

    def refresh_vol_icon(self):
        bg(S.volume, lambda r: r and self.vol_icon.set_from_icon_name(
            "audio-volume-muted-symbolic" if r[1] or r[0] == 0 else "audio-volume-low-symbolic" if r[0] < 34
            else "audio-volume-medium-symbolic" if r[0] < 67 else "audio-volume-high-symbolic", Gtk.IconSize.BUTTON))

    def open_settings(self, page=None):
        self.close_popup()
        S.spawn(["pine-settings"] + ([page] if page else []))

    # ---- sub pages
    def go(self, name, animate=True):
        anim = animate and S.look()[2]
        self.stack.set_transition_type(Gtk.StackTransitionType.SLIDE_LEFT_RIGHT if anim else Gtk.StackTransitionType.NONE)
        self.stack.set_visible_child_name(name)
        self.fit()
        if name == "wifi":
            self.fill_wifi()
        elif name == "bt":
            self.fill_bt()
        elif name == "sound":
            self.fill_sound()

    def on_escape(self):
        if self.stack.get_visible_child_name() != "main":
            self.go("main")
        else:
            self.close_popup()

    @staticmethod
    def clear(lst):
        for ch in lst.get_children():
            lst.remove(ch)

    def list_row(self, lst, icon_name, title, sub="", action_text="", action=None, selected=False):
        row = Gtk.ListBoxRow()
        box = Gtk.Box(spacing=12)
        if icon_name:
            box.pack_start(icon(icon_name, 18), False, False, 0)
        texts = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
        texts.pack_start(label(title, ellipsize=True), False, False, 0)
        if sub:
            texts.pack_start(label(sub, "muted", ellipsize=True), False, False, 0)
        box.pack_start(texts, True, True, 0)
        if action_text:
            box.pack_end(label(action_text, "act"), False, False, 0)
        row.add(box)
        row.action = action or (lambda: None)
        if selected:
            styled(row, "sel")
        lst.add(row)
        row.show_all()
        return row

    def show_msg(self, msg_label, text):
        msg_label.set_text(text)
        msg_label.set_visible(bool(text))

    def fill_wifi(self):
        self.clear(self.wifi_list)
        net = self.state.get("net") or {}
        if net.get("airplane") or not net.get("wifi_on"):
            self.list_row(self.wifi_list, None, "Airplane mode is on" if net.get("airplane") else "Wi-Fi is off")
            return
        self.list_row(self.wifi_list, None, "Looking for networks…")

        def got(nets):
            self.clear(self.wifi_list)
            if not nets:
                self.list_row(self.wifi_list, "network-wireless-offline-symbolic", "No networks found")
            for ssid, sig, secured, connected, saved in nets or []:
                level = "excellent" if sig >= 75 else "good" if sig >= 50 else "ok" if sig >= 25 else "weak"
                sub = ("Connected, " if connected else "Saved, " if saved else "") + ("secured" if secured else "open")
                self.list_row(self.wifi_list, f"network-wireless-signal-{level}-symbolic", ssid, sub.capitalize(),
                              "Disconnect" if connected else "Connect",
                              lambda s=ssid, sc=secured, c=connected, sv=saved: self.wifi_click(s, sc, c, sv), connected)
        bg(S.wifi_networks, got)

    def wifi_click(self, ssid, secured, connected, saved):
        dev = (self.state.get("net") or {}).get("wifi_dev")
        if connected:
            bg(lambda: S.wifi_disconnect(dev), lambda _r: self.after_change(lambda: self.go("wifi")))
        elif saved or not secured:
            self.wifi_connect(ssid, None, saved)
        else:
            self.pw_ssid = ssid
            self.pw_title.set_text(ssid)
            self.pw_entry.set_text("")
            self.go("password")
            self.pw_entry.grab_focus()

    def pw_connect(self):
        if self.pw_entry.get_text():
            self.go("wifi", animate=True)
            self.wifi_connect(self.pw_ssid, self.pw_entry.get_text(), False)

    def wifi_connect(self, ssid, password, saved):
        self.show_msg(self.wifi_msg, f"Connecting to {ssid}…")

        def done(res):
            ok, err = res or (False, "")
            self.show_msg(self.wifi_msg, f"Connected to {ssid}" if ok else "Could not connect." +
                          (" Is the password right?" if password else ""))
            GLib.timeout_add_seconds(4, lambda: (self.show_msg(self.wifi_msg, ""), False)[1])
            self.after_change(lambda: self.fill_wifi())
        bg(lambda: S.wifi_connect(ssid, password, saved), done)

    def fill_bt(self):
        self.clear(self.bt_list)
        if not self.state.get("bt_on"):
            self.list_row(self.bt_list, None, "Bluetooth is off" if self.state.get("bt_av") else "No Bluetooth on this computer")
            return
        self.list_row(self.bt_list, None, "Looking for your devices…")

        def got(devs):
            self.clear(self.bt_list)
            if not devs:
                self.list_row(self.bt_list, None, "No paired devices yet", "Pair one in Bluetooth settings")
            for mac, name, con, ic, batt in devs or []:
                sub = ("Connected" if con else "Paired") + (f" · Battery {batt}%" if batt else "")
                self.list_row(self.bt_list, ic, name, sub, "Disconnect" if con else "Connect",
                              lambda m=mac, c=con, n=name: self.bt_click(m, c, n), con)
        bg(S.bt_devices, got)

    def bt_click(self, mac, connected, name):
        self.show_msg(self.bt_msg, ("Disconnecting " if connected else "Connecting to ") + name + "…")

        def done(ok):
            self.show_msg(self.bt_msg, "" if ok else f"Could not {'disconnect' if connected else 'connect to'} {name}")
            self.after_change(lambda: self.fill_bt())
        bg(lambda: S.bt_toggle_device(mac, connected), done)

    def fill_sound(self):
        self.clear(self.sound_list)

        def got(outs):
            self.clear(self.sound_list)
            for name, desc, default in outs or []:
                ic = "audio-headphones-symbolic" if re.search(r"head|bluez", name + desc, re.I) else \
                    "video-display-symbolic" if re.search(r"hdmi|displayport", name + desc, re.I) else "audio-speakers-symbolic"
                self.list_row(self.sound_list, ic, desc, "", "✓" if default else "",
                              lambda n=name: bg(lambda: S.set_output(n), lambda _r: (self.fill_sound(), self.app.update_status())),
                              default)
            if not outs:
                self.list_row(self.sound_list, None, "No sound outputs found")
        bg(S.outputs, got)


# ================================================================ notification center
def ago(ts):
    s = max(0, int(time.time() - ts))
    if s < 60:
        return "now"
    if s < 3600:
        return f"{s // 60} min ago"
    if s < 86400:
        return f"{s // 3600} h ago"
    return datetime.datetime.fromtimestamp(ts).strftime("%b %d")


def ease(t):
    return 1 - (1 - t) ** 3


def animate(widget, ms, step, done=None):
    """Run step(0..1, eased) on every frame for ms milliseconds, then done()."""
    if not widget.get_mapped() or ms <= 0:
        step(1.0)
        if done:
            done()
        return
    start = []

    def tick(_w, clock):
        now = clock.get_frame_time() / 1000.0
        if not start:
            start.append(now)
        t = min(1.0, (now - start[0]) / ms)
        step(ease(t))
        if t >= 1.0:
            if done:
                done()
            return False
        return True
    widget.add_tick_callback(tick)


def note_icon(ic, size=20):
    img = Gtk.Image()
    if ic.startswith("/") and os.path.exists(ic):
        try:
            from gi.repository import GdkPixbuf
            img.set_from_pixbuf(GdkPixbuf.Pixbuf.new_from_file_at_size(ic, size, size))
        except GLib.Error:
            img.set_from_icon_name("dialog-information-symbolic", Gtk.IconSize.MENU)
    else:
        img.set_from_icon_name(ic or "dialog-information-symbolic", Gtk.IconSize.MENU)
    img.set_pixel_size(size)
    return img


class NoteCard(Gtk.Revealer):
    """One notification. Leaves by fading and sliding right, then the gap closes smoothly."""

    def __init__(self, nc, n):
        super().__init__(transition_type=Gtk.RevealerTransitionType.SLIDE_DOWN, transition_duration=140)
        self.nc, self.n, self.nid, self.leaving = nc, n, n["id"], False
        box = styled(Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=2), "note")
        self.box = box
        top = Gtk.Box(spacing=8)
        top.pack_start(note_icon(n["icon"], 16), False, False, 0)
        self.when = label(ago(n["time"]), "note-src", ellipsize=True)
        top.pack_start(self.when, True, True, 0)
        x = flat_button(icon("window-close-symbolic", 12), self.dismiss, "icon", "note-x")
        x.set_tooltip_text(_("Dismiss"))
        top.pack_end(x, False, False, 0)
        box.pack_start(top, False, False, 0)
        if n["summary"]:
            box.pack_start(label(n["summary"], "note-summary", wrap=True), False, False, 0)
        body = html.unescape(re.sub(r"<[^>]+>", "", n["body"])).strip()
        if body:
            box.pack_start(label(body, "note-body", wrap=True), False, False, 0)
        wrap = Gtk.Box(margin_bottom=6)
        wrap.pack_start(box, True, True, 0)
        self.add(wrap)
        self.show_all()

    def appear(self, delay=0):
        self.set_reveal_child(False)
        GLib.timeout_add(max(1, delay), lambda: (self.set_reveal_child(True), False)[1])

    def dismiss(self, then=None, delete=True):
        if self.leaving:
            return
        self.leaving = True
        if delete:
            bg(lambda: S.delete_notification(self.nid), lambda _r: self.nc.app.update_clock())

        def slide(t):
            self.box.set_opacity(1 - t)
            self.box.set_margin_start(int(70 * t))

        def collapse():
            self.set_reveal_child(False)
            GLib.timeout_add(self.get_transition_duration() + 30, lambda: (self.nc.card_gone(self), then and then(), False)[2])
        animate(self.box, 110, slide, collapse)


class NoteGroup(Gtk.Revealer):
    """The notifications of one app: a header (name, count, show all, clear) and the cards.
    With more than one, only the newest shows until "Show all"."""

    def __init__(self, nc, app):
        super().__init__(transition_type=Gtk.RevealerTransitionType.SLIDE_DOWN, transition_duration=150)
        self.nc, self.app_name, self.cards, self.expanded = nc, app, [], False
        v = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=0, margin_top=4)
        head = Gtk.Box(spacing=6, margin_start=4, margin_end=2, margin_bottom=4)
        head.pack_start(label(app or "Notifications", "grp-name", ellipsize=True), False, False, 0)
        self.count = label("", "grp-count")
        head.pack_start(self.count, False, False, 0)
        clear = flat_button(icon("window-close-symbolic", 11), self.clear, "icon", "grp-btn")
        clear.set_tooltip_text(_("Clear"))
        head.pack_end(clear, False, False, 0)
        self.toggle_btn = flat_button("Show all", self.toggle, "grp-btn")
        head.pack_end(self.toggle_btn, False, False, 0)
        v.pack_start(head, False, False, 0)
        self.box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
        v.pack_start(self.box, False, False, 0)
        self.add(v)
        self.show_all()

    def add_card(self, card, top=False, animate_in=False):
        self.cards.insert(0, card) if top else self.cards.append(card)
        self.box.pack_start(card, False, False, 0)
        if top:
            self.box.reorder_child(card, 0)
        visible = self.expanded or card is self.cards[0]
        if animate_in and visible:
            card.appear()
        else:
            card.set_reveal_child(visible)
        if top and not self.expanded and len(self.cards) > 1:
            self.cards[1].set_reveal_child(False)
        self.update()

    def update(self):
        n = len([c for c in self.cards if not c.leaving])
        self.count.set_text(str(n) if n > 1 else "")
        self.count.set_visible(n > 1)
        self.toggle_btn.set_visible(n > 1)
        self.toggle_btn.get_child().set_text(_("Show less") if self.expanded else _("Show all"))

    def toggle(self):
        self.expanded = not self.expanded
        for i, c in enumerate(self.cards):
            if i:
                GLib.timeout_add(1 + 35 * i if self.expanded else 1,
                                 lambda c=c: (c.set_reveal_child(self.expanded), False)[1])
        self.update()

    def remove_card(self, card):
        if card in self.cards:
            self.cards.remove(card)
        card.destroy()
        live = [c for c in self.cards if not c.leaving]
        if live and not self.expanded:
            live[0].set_reveal_child(True)          # the next one moves up
        self.update()
        if not self.cards:
            self.leave()

    def clear(self):
        live = [c for c in self.cards if not c.leaving]
        for i, c in enumerate(live):
            GLib.timeout_add(1 + 45 * i, lambda c=c: (c.dismiss(), False)[1])

    def leave(self):
        self.set_reveal_child(False)
        GLib.timeout_add(self.get_transition_duration() + 30, lambda: (self.nc.group_gone(self), False)[1])


class NotificationCenter(Popup):
    """Notifications grouped by app, do not disturb and the calendar. The bottom edge stays on
    the taskbar while the content grows or shrinks (every frame), so nothing jumps."""

    def __init__(self, app):
        super().__init__(app, 380)
        self.groups = {}
        self.busy = False
        outer = styled(Gtk.Box(orientation=Gtk.Orientation.VERTICAL), "panel")
        self.add(outer)
        head = Gtk.Box(spacing=8, margin_start=16, margin_end=10, margin_top=12, margin_bottom=2)
        head.pack_start(label("Notifications", "heading"), False, False, 0)
        self.total = label("", "grp-count")
        head.pack_start(self.total, False, False, 0)
        self.clear_btn = flat_button("Clear all", self.clear_all, "link")
        head.pack_end(self.clear_btn, False, False, 0)
        outer.pack_start(head, False, False, 0)

        self.scroll = Gtk.ScrolledWindow(hscrollbar_policy=Gtk.PolicyType.NEVER, propagate_natural_height=True,
                                         max_content_height=380)
        self.list = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=2, margin_start=12, margin_end=12,
                            margin_top=2, margin_bottom=8)
        self.scroll.add(self.list)
        outer.pack_start(self.scroll, False, False, 0)

        self.empty = Gtk.Revealer(transition_type=Gtk.RevealerTransitionType.SLIDE_DOWN, transition_duration=140)
        e = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=6, margin_top=22, margin_bottom=20)
        bell = icon("notifications-symbolic", 30)
        bell.set_opacity(0.55)
        e.pack_start(bell, False, False, 0)
        e.pack_start(label("You're all caught up", "muted", xalign=0.5), False, False, 0)
        self.empty.add(e)
        outer.pack_start(self.empty, False, False, 0)

        # a card like the rows in Pine Settings: tinted icon, title, quiet subtitle, the switch
        dnd = Gtk.Box(spacing=12, margin_start=12, margin_end=12, margin_top=9, margin_bottom=9)
        dndwrap = styled(Gtk.Box(margin_start=12, margin_end=12, margin_top=2, margin_bottom=10), "dnd-card")
        dndwrap.pack_start(dnd, True, True, 0)
        dnd.pack_start(styled(icon("notifications-disabled-symbolic", 18), "dnd-icon"), False, False, 0)
        txt = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
        txt.pack_start(label("Do not disturb"), False, False, 0)
        self.dnd_sub = label("", "muted")
        txt.pack_start(self.dnd_sub, False, False, 0)
        dnd.pack_start(txt, True, True, 0)
        self.dnd = Gtk.Switch(valign=Gtk.Align.CENTER)
        self.dnd.connect("notify::active", self.on_dnd)
        dnd.pack_end(self.dnd, False, False, 0)
        outer.pack_start(dndwrap, False, False, 0)

        cal = styled(Gtk.Box(orientation=Gtk.Orientation.VERTICAL), "foot")
        top = Gtk.Box(margin_start=16, margin_end=8, margin_top=4, margin_bottom=4)
        self.today = label("", "heading")
        top.pack_start(self.today, False, False, 0)
        self.cal_arrow = icon("pan-down-symbolic", 14)
        cal_btn = flat_button(self.cal_arrow, self.toggle_calendar, "icon")
        cal_btn.set_tooltip_text(_("Show or hide the calendar"))
        top.pack_end(cal_btn, False, False, 0)
        cal.pack_start(top, False, False, 0)
        self.cal_rev = Gtk.Revealer(transition_type=Gtk.RevealerTransitionType.SLIDE_DOWN, transition_duration=160,
                                    reveal_child=True)
        self.calendar = Gtk.Calendar(margin_start=10, margin_end=10, margin_bottom=8)
        self.calendar.set_display_options(Gtk.CalendarDisplayOptions.SHOW_HEADING | Gtk.CalendarDisplayOptions.SHOW_DAY_NAMES)
        self.cal_rev.add(self.calendar)
        cal.pack_start(self.cal_rev, False, False, 0)
        outer.pack_start(cal, False, False, 0)
        outer.show_all()

    def open_popup(self):
        super().open_popup()          # (the bottom edge stays on the taskbar: Popup.keep_anchored)
        self.set_focus(None)          # no focus ring on "Clear all" when it opens

    # ---- content ----
    def refresh(self):
        now = datetime.datetime.now()
        self.today.set_text(now.strftime("%A, %B ") + str(now.day))
        self.calendar.select_month(now.month - 1, now.year)
        self.calendar.select_day(now.day)
        self.busy = True
        self.dnd.set_active(S.dnd())
        self.busy = False
        self.update_dnd_text()
        self.fill()

    def fill(self):
        for g in list(self.groups.values()):
            g.destroy()
        self.groups = {}
        items = S.notifications()
        # Opening: everything is in place at once (the window itself fades in and rises);
        # only notifications that arrive while it is open slide in (sync)
        for n in items:
            self.card_for(n, animate_in=False)
        self.update_counts()
        if any(not n["read"] for n in items):
            bg(S.mark_all_read, lambda _r: self.app.update_clock())

    def card_for(self, n, animate_in, top=False):
        app = n["app"] or "Notifications"
        g = self.groups.get(app)
        new_group = g is None
        if new_group:
            g = NoteGroup(self, app)
            self.groups[app] = g
            self.list.pack_start(g, False, False, 0)
            if top:
                self.list.reorder_child(g, 0)
        g.add_card(NoteCard(self, n), top=top, animate_in=animate_in and not new_group)
        if new_group and animate_in:
            g.set_reveal_child(False)
            GLib.timeout_add(1, lambda: (g.set_reveal_child(True), False)[1])
        elif new_group:
            g.set_reveal_child(True)
        return g

    def sync(self):
        """The list changed while the center is open: new ones slide in, removed ones leave."""
        if not self.get_visible():
            return
        items = S.notifications()
        ids = {n["id"] for n in items}
        shown = {c.nid: c for g in self.groups.values() for c in g.cards}
        for n in reversed(items):
            if n["id"] not in shown:
                self.card_for(n, animate_in=True, top=True)
        for nid, c in shown.items():
            if nid not in ids and not c.leaving:
                c.dismiss(delete=False)
        self.update_counts()
        if any(not n["read"] for n in items):
            bg(S.mark_all_read, lambda _r: self.app.update_clock())

    def card_gone(self, card):
        for g in self.groups.values():
            if card in g.cards:
                g.remove_card(card)
                break
        self.update_counts()

    def group_gone(self, g):
        self.groups.pop(g.app_name, None)
        g.destroy()
        self.update_counts()

    def update_counts(self):
        n = sum(len([c for c in g.cards if not c.leaving]) for g in self.groups.values())
        self.total.set_text(str(n))
        self.total.set_visible(n > 0)
        self.clear_btn.set_visible(n > 0)
        self.scroll.set_visible(bool(self.groups))
        self.empty.set_reveal_child(n == 0)
        for g in self.groups.values():
            g.update()

    def clear_all(self):
        bg(S.clear_notifications, lambda _r: self.app.update_clock())
        cards = [c for g in self.groups.values() for c in g.cards if not c.leaving and c.get_reveal_child()]
        hidden = [c for g in self.groups.values() for c in g.cards if not c.get_reveal_child()]
        for c in hidden:
            c.leaving = True
            GLib.idle_add(lambda c=c: (self.card_gone(c), False)[1])
        for i, c in enumerate(cards):
            GLib.timeout_add(1 + 40 * i, lambda c=c: (c.dismiss(delete=False), False)[1])

    # ---- do not disturb, calendar ----
    def on_dnd(self, sw, _p):
        if self.busy:
            return
        bg(lambda: S.set_dnd(sw.get_active()), lambda _r: self.app.update_clock())
        self.update_dnd_text(sw.get_active())

    def update_dnd_text(self, on=None):
        on = self.dnd.get_active() if on is None else on
        self.dnd_sub.set_text(_("Only urgent pop-ups; the rest wait here") if on else _("Pop-ups are shown"))

    def toggle_calendar(self):
        show = not self.cal_rev.get_reveal_child()
        self.cal_rev.set_reveal_child(show)
        self.cal_arrow.set_from_icon_name("pan-down-symbolic" if show else "pan-up-symbolic", Gtk.IconSize.BUTTON)


# ================================================================ the application
class QuickApp(Gtk.Application):
    def __init__(self):
        super().__init__(application_id=APP_ID, flags=Gio.ApplicationFlags.HANDLES_COMMAND_LINE)
        self.qs = self.nc = None
        self.provider = None
        self.plugins = {}
        self.started = False

    # ---- start-up (first instance only)
    def do_startup(self):
        Gtk.Application.do_startup(self)
        self.provider = Gtk.CssProvider()
        Gtk.StyleContext.add_provider_for_screen(Gdk.Screen.get_default(), self.provider,
                                                 Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION + 1)
        self.restyle()
        # the pop-up windows are made when first opened (less memory while they are never used)
        self.hold()   # stays running for the taskbar buttons and the keyboard shortcuts
        self.start_watching()

    def get_qs(self):
        if not self.qs:
            self.qs = QuickSettings(self)
        return self.qs

    def get_nc(self):
        if not self.nc:
            self.nc = NotificationCenter(self)
        return self.nc

    def restyle(self):
        try:
            self.provider.load_from_data(css().encode())
        except GLib.Error as ex:
            print("pine-quick: css:", ex, file=sys.stderr)

    def do_command_line(self, cmdline):
        args = cmdline.get_arguments()[1:]
        cmd = args[0] if args else "--daemon"
        if cmd == "qs":
            if self.nc:
                self.nc.close_popup()
            self.get_qs().toggle()
        elif cmd == "nc":
            if self.qs:
                self.qs.close_popup()
            self.get_nc().toggle()
        elif cmd == "volume" and len(args) > 1:
            self.volume_key(args[1])
        elif cmd == "refresh":
            self.update_all()
        return 0

    # ---- taskbar buttons
    def refresh_panel(self, which):
        if not self.plugins.get(which):
            self.plugins = panel_plugins()
        name = self.plugins.get(which)
        if name:
            S.spawn(["xfce4-panel", f"--plugin-event={name}:refresh:bool:true"])

    def update_status(self):
        debounce(self, "status", 250, lambda: bg(render_status, lambda _r: self.refresh_panel("status")))

    def notes_changed(self):
        self.update_clock()
        if self.nc and self.nc.get_visible():
            self.nc.sync()

    def update_clock(self):
        debounce(self, "clock", 250, lambda: bg(render_clock, lambda _r: self.refresh_panel("clock")))

    def update_all(self):
        self.update_status()
        self.update_clock()

    def minute_tick(self):
        self.update_clock()
        self.update_status()          # battery level
        now = datetime.datetime.now()
        GLib.timeout_add((60 - now.second) * 1000 - now.microsecond // 1000 + 50, self.minute_tick)
        return False

    def start_watching(self):
        if self.started:
            return
        self.started = True
        if S.night_light():
            bg(lambda: S.set_night_light(True, save=False))
        self.update_all()
        self.minute_tick()
        # new notifications, read / cleared
        d = Gio.File.new_for_path(os.path.dirname(S.NOTIFY_DB))
        try:
            os.makedirs(d.get_path(), exist_ok=True)
            self.db_mon = d.monitor_directory(Gio.FileMonitorFlags.NONE, None)
            self.db_mon.connect("changed", lambda *_: debounce(self, "notes", 250, self.notes_changed))
        except GLib.Error:
            pass
        # dark / light mode or accent changed in Pine Settings
        try:
            self.cfg_mon = Gio.File.new_for_path(S.CONFIG_FILE).monitor_file(Gio.FileMonitorFlags.NONE, None)
            self.cfg_mon.connect("changed", lambda *_: debounce(self, "cfg", 400, lambda: (self.restyle(), self.update_all())))
        except GLib.Error:
            pass
        # Changes are heard on D-Bus inside this program (no extra monitoring programs running):
        #  network (NetworkManager), do not disturb (xfconf), Bluetooth on / off (BlueZ).
        # Sound has no D-Bus signals: "pactl subscribe" is the one helper program.
        def bus(kind):
            try:
                return Gio.bus_get_sync(kind, None)
            except GLib.Error:
                return None
        system, session = bus(Gio.BusType.SYSTEM), bus(Gio.BusType.SESSION)
        if system:
            for iface in ("org.freedesktop.NetworkManager", "org.freedesktop.NetworkManager.Device"):
                system.signal_subscribe(None, iface, None, None, None,
                                        Gio.DBusSignalFlags.NONE, lambda *_: self.update_status())
        if session:
            session.signal_subscribe(None, "org.xfce.Xfconf", "PropertyChanged", "/org/xfce/Xfconf",
                                     "xfce4-notifyd", Gio.DBusSignalFlags.NONE,
                                     lambda c, s, p, i, sig, args: args[1] == "/do-not-disturb" and self.update_clock())
        self.watch_process(["pactl", "subscribe"], lambda line: ("sink" in line or "server" in line) and self.update_status())
        # Bluetooth: its helpers run only while it is on (switched here, in Pine Settings or by a key)
        if S.has_bluetooth():
            bg(self.bt_at_sign_in)
            if system:
                system.signal_subscribe(None, "org.freedesktop.DBus.Properties", "PropertiesChanged", None,
                                        "org.bluez.Adapter1", Gio.DBusSignalFlags.NONE,
                                        lambda *_: debounce(self, "bt", 800, self.bt_changed))

    def bt_at_sign_in(self):
        for _ in range(10):                 # the Bluetooth service may still be starting
            if S.bt_available():
                break
            time.sleep(2)
        if S.bt_available() and S.load_config().get("bluetooth") is False:
            S.set_bt(False)                 # it was off at the last sign-out: it stays off
        S.bt_helpers(S.bt_available() and S.bt_powered())

    def bt_changed(self):
        def work():
            if S.bt_available():
                on = S.bt_powered()
                S.bt_helpers(on)
                S.save_config(bluetooth=on)
        bg(work, lambda _r: self.update_status())

    def watch_process(self, cmd, on_line):
        """Run a monitoring command (nmcli monitor...) and call on_line for each line it prints."""
        try:
            p = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL, text=True, bufsize=1)
        except OSError:
            return

        def on_data(src, cond):
            if cond & GLib.IO_IN:
                line = p.stdout.readline()
                if line:
                    on_line(line)
                    return True
            p.wait()
            GLib.timeout_add_seconds(10, lambda: (self.watch_process(cmd, on_line), False)[1])
            return False
        GLib.io_add_watch(p.stdout, GLib.PRIORITY_DEFAULT, GLib.IO_IN | GLib.IO_HUP | GLib.IO_ERR, on_data)

    # ---- volume keys
    def volume_key(self, what):
        def work():
            vol, muted = S.volume()
            if what == "up":
                S.set_volume(min(100, vol + 5))
            elif what == "down":
                S.set_volume(max(0, vol - 5))
            else:
                S.toggle_mute()
            vol, muted = S.volume()
            name = "audio-volume-muted-symbolic" if muted or vol == 0 else "audio-volume-low-symbolic" if vol < 34 \
                else "audio-volume-medium-symbolic" if vol < 67 else "audio-volume-high-symbolic"
            S.run(["notify-send", "-e", "-a", "Volume", "-i", name, "-h", f"int:value:{0 if muted else vol}",
                   "-h", "string:x-canonical-private-synchronous:pine-volume", "Volume", "Muted" if muted else f"{vol}%"])
        bg(work, lambda _r: self.update_status())


def main():
    Gdk.set_program_class("Pine-quick")
    app = QuickApp()
    sys.exit(app.run(sys.argv))


if __name__ == "__main__":
    main()
