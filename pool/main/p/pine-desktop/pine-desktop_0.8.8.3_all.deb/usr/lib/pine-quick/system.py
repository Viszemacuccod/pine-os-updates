"""Pine Quick Settings: talking to the system (no GTK here).

Network (NetworkManager / nmcli), Bluetooth (bluetoothctl), sound (pactl), brightness
(xfce4-power-manager's helper), battery (/sys, upower), notifications (xfce4-notifyd's
log database), look (Pine Settings' theme.py) and night light (redshift).
"""
import glob
import json
import os
import shutil
import re
import sqlite3
import subprocess
import sys

sys.path.insert(0, "/usr/lib/pine-settings")
import theme  # noqa: E402  (Pine colors, dark / light mode; no GTK import)

CONFIG_DIR = os.path.join(os.environ.get("XDG_CONFIG_HOME") or os.path.expanduser("~/.config"), "pine")
CONFIG_FILE = os.path.join(CONFIG_DIR, "settings.json")
NOTIFY_DB = os.path.join(os.environ.get("XDG_CACHE_HOME") or os.path.expanduser("~/.cache"),
                         "xfce4", "notifyd", "log.sqlite")
BACKLIGHT_HELPER = "/usr/sbin/xfpm-power-backlight-helper"


def run(cmd, timeout=10, input=None):
    """(exit code, stdout, stderr); never raises."""
    try:
        env = dict(os.environ, LC_ALL="C.UTF-8")
        p = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout, input=input, env=env)
        return p.returncode, p.stdout, p.stderr
    except FileNotFoundError:
        return 127, "", f"{cmd[0]}: not installed"
    except subprocess.TimeoutExpired:
        return 124, "", "timed out"


def spawn(cmd):
    """Start a program and forget about it."""
    try:
        subprocess.Popen(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, start_new_session=True)
    except OSError:
        pass


# ---------------------------------------------------------------- saved settings (shared with Pine Settings)
def load_config():
    try:
        with open(CONFIG_FILE) as f:
            return json.load(f)
    except (OSError, ValueError):
        return {}


def save_config(**changes):
    cfg = load_config()
    cfg.update(changes)
    os.makedirs(CONFIG_DIR, exist_ok=True)
    tmp = CONFIG_FILE + ".tmp"
    with open(tmp, "w") as f:
        json.dump(cfg, f, indent=2)
    os.replace(tmp, CONFIG_FILE)


def look():
    """(mode, accent, animations on?)"""
    cfg = load_config()
    return cfg.get("mode", theme.DEFAULT_MODE), cfg.get("accent", theme.DEFAULT_ACCENT).lower(), cfg.get("animations", True)


def set_dark(on):
    mode, accent, _ = look()
    save_config(mode="dark" if on else "light")
    # the taskbar's color follows by itself (its dark-mode switch), no panel restart needed
    theme.apply("dark" if on else "light", accent, restart_panel=False)


# ---------------------------------------------------------------- xfconf
def xget(channel, prop, default=None):
    rc, out, _ = run(["xfconf-query", "-c", channel, "-p", prop])
    return out.strip() if rc == 0 else default


def xset_bool(channel, prop, value):
    run(["xfconf-query", "-c", channel, "-p", prop, "-n", "-t", "bool", "-s", "true" if value else "false"])


# ---------------------------------------------------------------- network
def _split(line):
    return [p.replace("\\:", ":").replace("\\\\", "\\") for p in re.split(r"(?<!\\):", line)]


def nm_rows(*args, timeout=10):
    rc, out, _ = run(["nmcli", "-t"] + list(args), timeout=timeout)
    return [_split(l) for l in out.splitlines() if l] if rc == 0 else []


def network():
    """Current state: wifi device?, wifi on?, airplane?, connection type and name, signal,
    and the (first) Ethernet port: eth_dev, eth_state = connected / connecting /
    disconnected (turned off or not set up) / unavailable (no cable)."""
    st = {"wifi_dev": None, "wifi_on": False, "airplane": False, "type": None, "name": "", "signal": 0,
          "eth_dev": None, "eth_state": None}
    radio = (nm_rows("-f", "WIFI,WWAN", "radio") or [["enabled", "enabled"]])[0]
    st["wifi_on"] = radio[0] == "enabled"
    for dev, typ, state, con in nm_rows("-f", "DEVICE,TYPE,STATE,CONNECTION", "device"):
        if typ == "wifi" and not st["wifi_dev"]:
            st["wifi_dev"] = dev
        if typ == "ethernet" and state != "unmanaged" and not st["eth_dev"]:
            st["eth_dev"] = dev
            # nmcli says e.g. "connecting (getting IP configuration)"
            st["eth_state"] = "connecting" if state.startswith("connecting") else state.split()[0]
        if state == "connected" and typ in ("wifi", "ethernet") and not st["type"]:
            st["type"], st["name"] = typ, con
    # like Settings > Network: airplane mode = every radio off ("nmcli radio all off")
    st["airplane"] = not st["wifi_on"] and (len(radio) < 2 or radio[1] != "enabled")
    if st["type"] == "wifi":
        for inuse, sig in nm_rows("-f", "IN-USE,SIGNAL", "device", "wifi", "list", "--rescan", "no"):
            if inuse == "*":
                st["signal"] = int(sig or 0)
    return st


def wifi_networks():
    """[(ssid, signal, secured, connected, saved)], best first."""
    known = {n for n, t in nm_rows("-f", "NAME,TYPE", "connection", "show") if t == "802-11-wireless"}
    seen, nets = set(), []
    for inuse, ssid, sig, sec in nm_rows("-f", "IN-USE,SSID,SIGNAL,SECURITY", "device", "wifi", "list", "--rescan", "auto",
                                         timeout=25):
        if not ssid or ssid in seen:
            continue
        seen.add(ssid)
        nets.append((ssid, int(sig or 0), sec not in ("", "--"), inuse == "*", ssid in known))
    nets.sort(key=lambda n: (not n[3], -n[1]))
    return nets[:20]


def wifi_connect(ssid, password=None, saved=False):
    if saved:
        rc, out, err = run(["nmcli", "connection", "up", "id", ssid], timeout=60)
    else:
        rc, out, err = run(["nmcli", "device", "wifi", "connect", ssid] + (["password", password] if password else []), timeout=60)
    return rc == 0, (err or out).strip().splitlines()[-1] if (err or out).strip() else ""


def wifi_disconnect(dev):
    run(["nmcli", "device", "disconnect", dev], timeout=20)


def set_ethernet(dev, on):
    """Turn the Ethernet port on (connect with its saved or automatic connection) or off
    (NetworkManager then leaves it off until it is turned on again or the computer restarts)."""
    run(["nmcli", "device", "connect" if on else "disconnect", dev], timeout=45)


def set_wifi(on):
    run(["nmcli", "radio", "wifi", "on" if on else "off"])


def set_airplane(on):
    run(["nmcli", "radio", "all", "off" if on else "on"])
    run(["rfkill", "block" if on else "unblock", "bluetooth"])


def rfkill_blocked(kind):
    """True / False, or None when there is no such radio."""
    rc, out, _ = run(["rfkill", "-n", "-o", "TYPE,SOFT", "list", kind])
    if rc != 0 or not out.strip():
        return None
    return all(l.split()[-1] == "blocked" for l in out.splitlines() if l.strip())


# ---------------------------------------------------------------- what this computer has
def has_wifi():
    return any(os.path.isdir(p + "/wireless") or os.path.isdir(p + "/phy80211") for p in glob.glob("/sys/class/net/*"))


def has_bluetooth():
    return bool(glob.glob("/sys/class/bluetooth/hci*"))


def has_radios():
    """Any wireless radio (Wi-Fi, Bluetooth, mobile broadband): airplane mode makes sense."""
    return bool(glob.glob("/sys/class/rfkill/rfkill*"))


# ---------------------------------------------------------------- Bluetooth
def bt_helpers(on):
    """The Bluetooth helpers run only while Bluetooth is on: blueman's applet (answers pairing
    requests, switches headphone profiles) and mpris-proxy (headphone play / pause buttons)."""
    running = run(["pgrep", "-u", str(os.getuid()), "-x", "blueman-applet"])[0] == 0
    if on and not running:
        spawn(["blueman-applet"])
        run(["systemctl", "--user", "start", "mpris-proxy.service"])
    elif not on and running:
        run(["pkill", "-u", str(os.getuid()), "-x", "blueman-applet"])
        run(["systemctl", "--user", "stop", "mpris-proxy.service"])


DEVICE_ICONS = {"audio": "audio-headphones-symbolic", "input-mouse": "input-mouse-symbolic",
                "input-keyboard": "input-keyboard-symbolic", "phone": "phone-symbolic",
                "input-gaming": "input-gaming-symbolic", "computer": "computer-symbolic"}


def bt_available():
    rc, out, _ = run(["bluetoothctl", "list"], timeout=4)
    return rc == 0 and "Controller" in out


def bt_powered():
    _, out, _ = run(["bluetoothctl", "show"], timeout=4)
    return "Powered: yes" in out


def set_bt(on):
    if on:
        run(["rfkill", "unblock", "bluetooth"])
    run(["bluetoothctl", "power", "on" if on else "off"], timeout=6)


def bt_devices():
    """[(mac, name, connected, icon, battery)] of paired devices, connected first."""
    _, out, _ = run(["bluetoothctl", "devices", "Paired"], timeout=4)
    devs = []
    for line in out.splitlines():
        m = re.match(r"Device (\S+) (.+)", line.strip())
        if not m:
            continue
        _, info, _ = run(["bluetoothctl", "info", m.group(1)], timeout=4)
        ic = re.search(r"Icon: (\S+)", info)
        ic = ic.group(1) if ic else ""
        icon = next((v for k, v in DEVICE_ICONS.items() if ic.startswith(k)), "bluetooth-active-symbolic")
        bat = re.search(r"Battery Percentage: \S+ \((\d+)\)", info)
        devs.append((m.group(1), m.group(2), "Connected: yes" in info, icon, bat.group(1) if bat else None))
    devs.sort(key=lambda d: not d[2])
    return devs


def bt_connected_name():
    for mac, name, con, _, _ in bt_devices():
        if con:
            return name
    return None


def bt_toggle_device(mac, connected):
    rc, out, _ = run(["bluetoothctl", "--timeout", "15", "disconnect" if connected else "connect", mac], timeout=25)
    return rc == 0 and "fail" not in out.lower()


# ---------------------------------------------------------------- sound
def volume():
    """(percent, muted) of the default output."""
    _, out, _ = run(["pactl", "get-sink-volume", "@DEFAULT_SINK@"], timeout=4)
    m = re.search(r"(\d+)%", out)
    _, mo, _ = run(["pactl", "get-sink-mute", "@DEFAULT_SINK@"], timeout=4)
    return (int(m.group(1)) if m else 0), "yes" in mo


def set_volume(pct):
    run(["pactl", "set-sink-mute", "@DEFAULT_SINK@", "0"], timeout=4)
    run(["pactl", "set-sink-volume", "@DEFAULT_SINK@", f"{max(0, min(100, int(pct)))}%"], timeout=4)


def toggle_mute():
    run(["pactl", "set-sink-mute", "@DEFAULT_SINK@", "toggle"], timeout=4)


def outputs():
    """[(name, description, is default)]"""
    _, default, _ = run(["pactl", "get-default-sink"], timeout=4)
    _, out, _ = run(["pactl", "-f", "json", "list", "sinks"], timeout=6)
    try:
        sinks = json.loads(out)
    except ValueError:
        return []
    return [(s.get("name", ""), s.get("description", s.get("name", "")), s.get("name") == default.strip()) for s in sinks]


def set_output(name):
    run(["pactl", "set-default-sink", name], timeout=4)


# ---------------------------------------------------------------- brightness and battery
def backlight():
    """(sys path, max) of the built-in screen, or None (desktop PCs)."""
    bl = sorted(glob.glob("/sys/class/backlight/*"))
    if not bl or not os.path.exists(BACKLIGHT_HELPER):
        return None
    try:
        return bl[0], int(open(bl[0] + "/max_brightness").read())
    except (OSError, ValueError):
        return None


def brightness():
    b = backlight()
    if not b:
        return None
    try:
        return round(int(open(b[0] + "/brightness").read()) * 100 / b[1])
    except (OSError, ValueError):
        return None


def set_brightness(pct):
    b = backlight()
    if b:
        run(["pkexec", BACKLIGHT_HELPER, "--set-brightness", str(max(1, int(pct * b[1] / 100)))])


def battery():
    """(percent, state) or None when there is no battery. state: charging / discharging / full."""
    for p in glob.glob("/sys/class/power_supply/*"):
        try:
            if open(p + "/type").read().strip() != "Battery":
                continue
            pct = int(open(p + "/capacity").read())
            status = open(p + "/status").read().strip().lower()
        except (OSError, ValueError):
            continue
        state = "full" if status in ("full", "not charging") else "charging" if status == "charging" else "discharging"
        return pct, state
    return None


def battery_text():
    b = battery()
    if not b:
        return ""
    pct, state = b
    if state == "full":
        return f"{pct}% · Fully charged" if pct >= 95 else f"{pct}% · Plugged in"
    _, out, _ = run(["upower", "-i", "/org/freedesktop/UPower/devices/DisplayDevice"], timeout=4)
    m = re.search(r"time to (empty|full):\s+([\d.,]+)\s+(\w+)", out)
    left = ""
    if m:
        v = float(m.group(2).replace(",", "."))
        hours = v if m.group(3).startswith("hour") else v / 60
        h, mins = int(hours), int(round((hours - int(hours)) * 60))
        left = (f"{h} h {mins} min" if h else f"{mins} min") + (" left" if m.group(1) == "empty" else " until full")
    if state == "charging":
        return f"{pct}% · Charging" + (f", {left}" if left else "")
    return f"{pct}%" + (f" · {left}" if left else "")


# ---------------------------------------------------------------- power
def power(action):
    cmd = {"lock": ["xflock4"], "sleep": ["systemctl", "suspend"],
           "restart": ["xfce4-session-logout", "--reboot", "--fast"],
           "shutdown": ["xfce4-session-logout", "--halt", "--fast"]}[action]
    spawn(cmd)


# ---------------------------------------------------------------- night light
def night_light():
    return bool(load_config().get("night_light", False))


def set_night_light(on, save=True):
    if save:
        save_config(night_light=on)
    if on:
        run(["redshift", "-P", "-O", "4300"], timeout=6)
    else:
        run(["redshift", "-x"], timeout=6)


# ---------------------------------------------------------------- notifications (xfce4-notifyd's log)
# ---------------------------------------------------------------- game mode
# Everything that is only nice to have pauses for the game (pine-settings/game.py):
# gamemode, no compositor, no window pictures, no pop-ups, paused helpers.
import game  # noqa: E402


def game_mode():
    return game.active()


def set_game_mode(on):
    if on:
        game.turn_on()
    else:
        game.turn_off()


def dnd():
    return (xget("xfce4-notifyd", "/do-not-disturb", "false") or "").lower() == "true"


def set_dnd(on):
    xset_bool("xfce4-notifyd", "/do-not-disturb", on)


def _db(write=False):
    if not os.path.exists(NOTIFY_DB):
        return None
    try:
        uri = f"file:{NOTIFY_DB}" + ("" if write else "?mode=ro")
        con = sqlite3.connect(uri, uri=True, timeout=2)
        return con
    except sqlite3.Error:
        return None


def notifications(limit=50):
    """[{id, time (unix seconds), app, icon, summary, body, read}] newest first."""
    con = _db()
    if not con:
        return []
    try:
        rows = con.execute("SELECT id, timestamp, COALESCE(NULLIF(app_name, ''), app_id), icon_id, summary, body, is_read "
                           "FROM notifications ORDER BY timestamp DESC LIMIT ?", (limit,)).fetchall()
    except sqlite3.Error:
        rows = []
    finally:
        con.close()
    out = []
    for nid, ts, app, icon, summary, body, read in rows:
        ts = ts or 0
        while ts > 1e11:          # stored in micro- (or milli-) seconds
            ts /= 1000
        out.append({"id": nid, "time": ts, "app": app or "", "icon": icon or "", "summary": summary or "",
                    "body": body or "", "read": bool(read)})
    return out


def unread_count():
    con = _db()
    if not con:
        return 0
    try:
        return con.execute("SELECT COUNT(id) FROM notifications WHERE is_read = FALSE").fetchone()[0]
    except sqlite3.Error:
        return 0
    finally:
        con.close()


def _write(sql, args=()):
    con = _db(write=True)
    if not con:
        return
    try:
        con.execute(sql, args)
        con.commit()
    except sqlite3.Error:
        pass
    finally:
        con.close()


def mark_all_read():
    _write("UPDATE notifications SET is_read = TRUE WHERE is_read = FALSE")


def delete_notification(nid):
    _write("DELETE FROM notifications WHERE id = ?", (nid,))


def clear_notifications():
    _write("DELETE FROM notifications")
