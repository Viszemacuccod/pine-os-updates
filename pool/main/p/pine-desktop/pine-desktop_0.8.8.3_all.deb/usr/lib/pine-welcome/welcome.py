#!/usr/bin/python3
"""Pine OS Welcome: a short tour after the first sign-in (and from the start menu).

Usage: pine-welcome              open the tour
       pine-welcome --first-run  open it only if it was not shown before (autostart)
"""
import os
import subprocess
import sys
import threading

sys.path.insert(0, "/usr/lib/pine-settings")

import gi  # noqa: E402
gi.require_version("Gtk", "4.0")
gi.require_version("Adw", "1")
from gi.repository import Adw, GLib, Gtk  # noqa: E402

import look  # noqa: E402
import gettext  # noqa: E402
_TR = gettext.translation("pine", fallback=True)


def _(text):
    """In the user's language (po/ in the Pine OS project)."""
    return _TR.gettext(text) if isinstance(text, str) and text else text
import theme  # noqa: E402

DONE = os.path.join(GLib.get_user_config_dir(), "pine", "welcome-done")


def launch(*cmd):
    try:
        subprocess.Popen(list(cmd), stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, start_new_session=True)
    except OSError:
        pass


def page(icon, title, text, buttons=(), extra=None):
    box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=14, valign=Gtk.Align.CENTER,
                  halign=Gtk.Align.CENTER, hexpand=True, vexpand=True)
    box.set_margin_start(48)
    box.set_margin_end(48)
    img = Gtk.Image.new_from_icon_name(icon)
    img.set_pixel_size(64 if icon == "pine-logo" else 40)
    if icon != "pine-logo":
        img.add_css_class("pine-badge")
    img.set_halign(Gtk.Align.CENTER)
    box.append(img)
    t = Gtk.Label(label=_(title), wrap=True, justify=Gtk.Justification.CENTER)
    t.add_css_class("title-1")
    box.append(t)
    b = Gtk.Label(label=_(text), wrap=True, justify=Gtk.Justification.CENTER, max_width_chars=52)
    b.add_css_class("dim-label")
    box.append(b)
    if extra is not None:
        box.append(extra)
    if buttons:
        row = Gtk.Box(spacing=10, halign=Gtk.Align.CENTER, margin_top=8)
        for label, action in buttons:
            btn = Gtk.Button(label=_(label))
            btn.add_css_class("pill")
            btn.connect("clicked", lambda _b, a=action: a())
            row.append(btn)
        box.append(row)
    return box


class Window(Adw.ApplicationWindow):
    def __init__(self, app):
        super().__init__(application=app, title="Welcome to Pine OS")
        self.set_default_size(780, 560)
        self.app = app

        self.carousel = Adw.Carousel(hexpand=True, vexpand=True, allow_scroll_wheel=True)
        for p in self.pages():
            self.carousel.append(p)
        self.carousel.connect("page-changed", lambda *_: self.update_buttons())

        dots = Adw.CarouselIndicatorDots(carousel=self.carousel)
        self.back = Gtk.Button(label=_("Back"))
        self.back.connect("clicked", lambda *_: self.go(-1))
        self.next = Gtk.Button(label=_("Next"))
        self.next.add_css_class("suggested-action")
        self.next.connect("clicked", lambda *_: self.go(+1))
        skip = Gtk.Button(label=_("Skip"))
        skip.add_css_class("flat")
        skip.connect("clicked", lambda *_: self.close())

        bar = Gtk.CenterBox(margin_start=18, margin_end=18, margin_top=6, margin_bottom=18)
        bar.set_start_widget(skip)
        bar.set_center_widget(dots)
        right = Gtk.Box(spacing=8)
        right.append(self.back)
        right.append(self.next)
        bar.set_end_widget(right)

        box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
        box.append(self.carousel)
        box.append(bar)
        tv = Adw.ToolbarView()
        header = Adw.HeaderBar()
        header.set_show_title(False)
        tv.add_top_bar(header)
        tv.set_content(box)
        self.set_content(tv)

        keys = Gtk.EventControllerKey()
        keys.connect("key-pressed", self.on_key)
        self.add_controller(keys)
        self.connect("close-request", lambda *_: (self.mark_done(), False)[1])
        self.update_buttons()

    # ------------------------------------------------------------ pages
    def pages(self):
        mode_row = Gtk.Box(spacing=10, halign=Gtk.Align.CENTER, margin_top=8)
        self.mode_buttons = {}
        cur = theme.saved()[0]
        for mode, label, icon in (("dark", "Dark", "weather-clear-night-symbolic"),
                                  ("light", "Light", "weather-clear-symbolic")):
            b = Gtk.ToggleButton()
            b.set_child(Adw.ButtonContent(icon_name=icon, label=label))
            b.add_css_class("pill")
            b.set_active(mode == cur)
            b.connect("toggled", lambda btn, m=mode: btn.get_active() and self.set_mode(m))
            self.mode_buttons[mode] = b
            mode_row.append(b)
        self.mode_buttons["light"].set_group(self.mode_buttons["dark"])

        return [
            page("pine-logo", "Welcome to Pine OS",
                 "Let's take a quick look around. It only takes a minute."),
            page("view-app-grid-symbolic", "Your apps are in the start menu",
                 "Click the Pine logo in the corner, or press the Windows key. "
                 "Start typing to find any app, file or setting.",
                 [("Show me", lambda: launch("xfce4-popup-whiskermenu"))]),
            page("applications-graphics-symbolic", "Make it yours",
                 "Choose dark or light. More colors, backgrounds and effects are in "
                 "Settings > Personalization.", extra=mode_row),
            page("emblem-system-symbolic", "Every setting in one place",
                 "Wi-Fi, display, sound, printers, accounts and more: all in Settings. "
                 "Open it from the start menu, or press Windows + I.",
                 [("Open Settings", lambda: launch("pine-settings"))]),
            page("system-software-install-symbolic", "Thousands of free apps",
                 "The App Store has browsers, games, office apps, photo editors and much more. "
                 "One click installs them.",
                 [("Open App Store", lambda: launch("flatpak", "run", "io.github.kolunmi.Bazaar"))]),
            page("security-high-symbolic", "Safe and up to date",
                 "Security updates install by themselves in the background. "
                 "Pine Update in Settings shows everything else.",
                 [("Check for updates", lambda: launch("pine-settings", "update"))]),
            page("emblem-ok-symbolic", "You're all set",
                 "Enjoy Pine OS! You can open this tour again any time: it is called "
                 "Welcome in the start menu."),
        ]

    def set_mode(self, mode):
        accent = theme.saved()[1]
        cfg_dir = os.path.join(GLib.get_user_config_dir(), "pine")
        os.makedirs(cfg_dir, exist_ok=True)
        path = os.path.join(cfg_dir, "settings.json")
        import json
        try:
            with open(path) as f:
                cfg = json.load(f)
        except (OSError, ValueError):
            cfg = {}
        cfg["mode"] = mode
        with open(path, "w") as f:
            json.dump(cfg, f, indent=2)
        look.apply(self.app.css, mode, accent)
        threading.Thread(target=theme.apply, args=(mode, accent), daemon=True).start()

    # ------------------------------------------------------------ navigation
    def go(self, step):
        n = self.carousel.get_n_pages()
        pos = int(round(self.carousel.get_position())) + step
        if pos >= n:
            self.close()
            return
        pos = max(0, pos)
        self.carousel.scroll_to(self.carousel.get_nth_page(pos), True)

    def update_buttons(self):
        pos = int(round(self.carousel.get_position()))
        last = pos >= self.carousel.get_n_pages() - 1
        self.back.set_visible(pos > 0)
        self.next.set_label(_("Get started") if last else _("Next"))
        # Enter always presses Next / Get started
        self.set_default_widget(self.next)
        self.next.grab_focus()

    def on_key(self, _c, keyval, _code, _state):
        name = Gtk.accelerator_name(keyval, 0)
        if name == "Right":
            self.go(+1)
            return True
        if name == "Left":
            self.go(-1)
            return True
        if name == "Escape":
            self.close()
            return True
        return False

    def mark_done(self):
        try:
            os.makedirs(os.path.dirname(DONE), exist_ok=True)
            open(DONE, "w").close()
        except OSError:
            pass


class App(Adw.Application):
    def __init__(self):
        super().__init__(application_id="org.pineos.Welcome")
        self.css = None

    def do_startup(self):
        Adw.Application.do_startup(self)
        Gtk.Window.set_default_icon_name("pine-logo")
        self.css = look.apply()

    def do_activate(self):
        win = self.get_active_window() or Window(self)
        win.present()


def main():
    if "--first-run" in sys.argv:
        if os.path.exists(DONE) or os.path.isdir("/run/live/medium"):
            return 0
    GLib.set_prgname("org.pineos.Welcome")
    return App().run([sys.argv[0]])


if __name__ == "__main__":
    sys.exit(main())
