"""Re-apply saved Pine Settings at sign-in (displays, mouse and touchpad).

XFCE keeps most settings itself (xfconf). These two are applied by Pine Settings directly
with xrandr / xinput, so they are saved in ~/.config/pine/settings.json and set again here.
"""
import os
import re

import common as c

INPUT_DEFAULTS = {"accel": 0.0, "left_handed": False, "natural_mouse": False,
                  "natural_touchpad": True, "tap": True, "dwt": True}


def pointer_devices():
    """[(id, name, set of libinput property names, is_touchpad)] for real pointing devices."""
    rc, out, _ = c.run(["xinput", "list"])
    devs = []
    if rc != 0:
        return devs
    for line in out.splitlines():
        m = re.search(r"[↳ ]*(.+?)\s+id=(\d+)\s+\[slave\s+pointer", line)
        if not m or "XTEST" in m.group(1):
            continue
        dev_id, name = m.group(2), m.group(1).strip(" ⎜↳")
        rc, props, _ = c.run(["xinput", "list-props", dev_id])
        names = set(re.findall(r"^\s+(libinput [^(]+?) \(\d+\)", props, re.M))
        devs.append((dev_id, name, names, "libinput Tapping Enabled" in names))
    return devs


def apply_input(cfg=None):
    s = dict(INPUT_DEFAULTS)
    s.update((cfg or c.load_config()).get("input", {}))
    for dev_id, _name, props, touchpad in pointer_devices():
        def setp(prop, *vals):
            if prop in props:
                c.run(["xinput", "set-prop", dev_id, prop] + [str(v) for v in vals])
        setp("libinput Accel Speed", f"{float(s['accel']):.2f}")
        setp("libinput Left Handed Enabled", int(s["left_handed"]))
        setp("libinput Natural Scrolling Enabled", int(s["natural_touchpad"] if touchpad else s["natural_mouse"]))
        if touchpad:
            setp("libinput Tapping Enabled", int(s["tap"]))
            setp("libinput Disable While Typing Enabled", int(s["dwt"]))


def apply_displays(cfg=None):
    cfg = cfg or c.load_config()
    rc, out, _ = c.run(["xrandr", "--query"])
    if rc != 0:
        return
    connected = set(re.findall(r"^(\S+) connected", out, re.M))
    pair = cfg.get("display_pair")
    layout = cfg.get("display_layout")
    if layout and pair and set(pair) <= connected and len(connected) == 2:
        import pg_system
        outs = [{"name": pair[0]}, {"name": pair[1]}]
        c.run(["xrandr"] + pg_system.layout_args(layout, outs))
    for name, d in cfg.get("displays", {}).items():
        if name in connected:
            c.run(["xrandr", "--output", name, "--mode", d["mode"], "--rate", f"{float(d['rate']):.2f}",
                   "--rotate", d.get("rotate", "normal")])


def refresh_gtk4_colors():
    """GTK 4 colors of the saved mode and accent: also replaces the file older Pine versions
    wrote, which GTK 4.18 couldn't read (it used "@media"). A file of the user's own (no Pine
    mark) is left alone."""
    try:
        import theme
        mode, accent = theme.saved()
        theme.write_gtk4(os.path.join(theme._config_dir(), "gtk-4.0", "gtk.css"), accent, mode)
    except Exception as e:  # never stop the sign-in for this
        print("pine-settings --apply: gtk4 colors:", e)


def main():
    cfg = c.load_config()
    apply_displays(cfg)
    apply_input(cfg)
    refresh_gtk4_colors()
    return 0
