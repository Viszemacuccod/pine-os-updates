#!/usr/bin/python3
"""Pine Task Manager, laid out like the Windows 11 Task Manager, in Pine's colors.

Usage: pine-taskmgr [processes|performance|history|startup|users|details|services|settings]
Pages: Processes (apps grouped, expand for their processes), Performance (CPU, Memory, Disk,
Network), App history, Startup apps, Users, Details, Services, Settings. Reads /proc directly.
"""
import json
import os
import pwd
import re
import signal
import subprocess
import sys
import threading
import time
from collections import deque

_HERE = os.path.dirname(os.path.abspath(__file__))
for _p in ("/usr/lib/pine-settings", os.path.join(_HERE, "..", "pine-settings")):
    if os.path.isdir(_p):
        sys.path.insert(0, _p)

import gi  # noqa: E402
gi.require_version("Gtk", "4.0")
gi.require_version("Adw", "1")
from gi.repository import Adw, Gdk, Gio, GLib, GObject, Gtk  # noqa: E402

import look  # noqa: E402
import theme  # noqa: E402

try:
    from common import _  # the user's language (untranslated text stays English)
except Exception:  # pragma: no cover
    def _(text):
        return text

APP_ID = "org.pineos.TaskManager"
HZ = os.sysconf("SC_CLK_TCK")
PAGE = os.sysconf("SC_PAGE_SIZE")
NCPU = os.cpu_count() or 1
UID = os.getuid()
SHELLS = {"python3", "python", "sh", "bash", "dash", "perl", "env"}
STATES = {"R": "Running", "S": "Sleeping", "D": "Waiting", "T": "Stopped", "t": "Stopped",
          "Z": "Zombie", "I": "Idle", "X": "Dead"}
SETTINGS_FILE = os.path.expanduser("~/.config/pine/taskmgr.json")
SPEEDS = [(_("High"), 500), (_("Normal"), 1000), (_("Low"), 4000), (_("Paused"), 0)]
PAGES = [("processes", "Processes", "view-list-symbolic"),
         ("performance", "Performance", "utilities-system-monitor-symbolic"),
         ("history", "App history", "document-open-recent-symbolic"),
         ("startup", "Startup apps", "system-run-symbolic"),
         ("users", "Users", "system-users-symbolic"),
         ("details", "Details", "format-justify-fill-symbolic"),
         ("services", "Services", "preferences-system-symbolic")]


# ---------------------------------------------------------------- helpers
def fmt_bytes(n):
    n = float(n or 0)
    for unit in ("B", "KB", "MB", "GB", "TB"):
        if n < 1024 or unit == "TB":
            return f"{n:.0f} {unit}" if unit in ("B", "KB") or n >= 100 else f"{n:.1f} {unit}"
        n /= 1024


def fmt_rate(n):
    return fmt_bytes(n) + "/s"


def fmt_pct(v):
    return f"{(v or 0):.1f}%"


def fmt_uptime(sec):
    d, r = divmod(int(sec), 86400)
    h, r = divmod(r, 3600)
    return (f"{d}:" if d else "") + f"{h:02d}:{r // 60:02d}:{r % 60:02d}"


def fmt_time(sec):
    h, r = divmod(int(sec or 0), 3600)
    return f"{h}:{r // 60:02d}:{r % 60:02d}"


def _read(path):
    try:
        with open(path) as f:
            return f.read()
    except OSError:
        return ""


_users = {}


def user_name(uid):
    if uid not in _users:
        try:
            _users[uid] = pwd.getpwuid(uid).pw_name
        except KeyError:
            _users[uid] = str(uid)
    return _users[uid]


def load_settings():
    try:
        with open(SETTINGS_FILE) as f:
            return json.load(f)
    except (OSError, ValueError):
        return {}


def save_settings(d):
    try:
        os.makedirs(os.path.dirname(SETTINGS_FILE), exist_ok=True)
        with open(SETTINGS_FILE, "w") as f:
            json.dump(d, f)
    except OSError:
        pass


# ---------------------------------------------------------------- system totals
class Sampler:
    DISK = re.compile(r"(sd[a-z]+|vd[a-z]+|xvd[a-z]+|nvme\d+n\d+|mmcblk\d+)$")

    def __init__(self):
        self.t = time.monotonic()
        self.cpu, self.disk, self.net = self._cpu(), self._disk(), self._net()

    @staticmethod
    def _cpu():
        v = [int(x) for x in _read("/proc/stat").split("\n", 1)[0].split()[1:9]]
        return sum(v), sum(v) - v[3] - v[4]

    def _disk(self):
        rd = wr = io = 0
        for line in _read("/proc/diskstats").splitlines():
            p = line.split()
            if len(p) > 12 and self.DISK.match(p[2]):
                rd, wr, io = rd + int(p[5]), wr + int(p[9]), io + int(p[12])
        return rd, wr, io

    @staticmethod
    def _net():
        rx = tx = 0
        for line in _read("/proc/net/dev").splitlines()[2:]:
            name, _sep, data = line.partition(":")
            f = data.split()
            if name.strip() != "lo" and len(f) > 8:
                rx, tx = rx + int(f[0]), tx + int(f[8])
        return rx, tx

    def sample(self):
        now = time.monotonic()
        dt = max(now - self.t, 0.001)
        c, d, n = self._cpu(), self._disk(), self._net()
        tot = c[0] - self.cpu[0]
        mem = {}
        for line in _read("/proc/meminfo").splitlines():
            k, _s, v = line.partition(":")
            if k in ("MemTotal", "MemAvailable", "Cached"):
                mem[k] = int(v.split()[0]) * 1024
        total = mem.get("MemTotal", 1)
        avail = mem.get("MemAvailable", 0)
        out = {
            "cpu": (c[1] - self.cpu[1]) / tot if tot > 0 else 0.0,
            "mem_used": total - avail, "mem_avail": avail, "mem_cached": mem.get("Cached", 0),
            "mem_total": total, "mem": (total - avail) / total,
            "disk_read": (d[0] - self.disk[0]) * 512 / dt, "disk_write": (d[1] - self.disk[1]) * 512 / dt,
            "disk_busy": min(1.0, (d[2] - self.disk[2]) / (dt * 1000)),
            "net_down": (n[0] - self.net[0]) / dt, "net_up": (n[1] - self.net[1]) / dt,
        }
        self.t, self.cpu, self.disk, self.net = now, c, d, n
        return out


def read_procs():
    """{pid: (comm, cpu ticks, resident bytes, uid, state)}"""
    out = {}
    for name in os.listdir("/proc"):
        if not name.isdigit():
            continue
        try:
            s = _read(f"/proc/{name}/stat")
            rp = s.rindex(")")
            rest = s[rp + 2:].split()
            out[int(name)] = (s[s.index("(") + 1:rp], int(rest[11]) + int(rest[12]),
                              int(rest[21]) * PAGE, os.stat(f"/proc/{name}").st_uid, rest[0])
        except (OSError, ValueError, IndexError):
            continue
    return out


class Identify:
    """Which app a process belongs to: its program name matched with the installed apps."""

    def __init__(self):
        self.apps = {}
        for ai in Gio.AppInfo.get_all():
            exe = ai.get_executable()
            if exe and ai.should_show():
                self.apps.setdefault(os.path.basename(exe), ai)
        self.cache = {}

    def of(self, pid, comm):
        hit = self.cache.get(pid)
        if hit and hit[0] == comm:
            return hit[1]
        args = [a for a in _read(f"/proc/{pid}/cmdline").split("\0") if a]
        if not args:
            info = None                                  # kernel thread
        else:
            key = os.path.basename(args[0])
            if key in SHELLS:
                script = next((a for a in args[1:] if not a.startswith("-")), "")
                if script:
                    key = os.path.basename(script)
                    if key == "main.py":
                        key = os.path.basename(os.path.dirname(script))
                    key = re.sub(r"\.(py|sh)$", "", key)
            ai = self.apps.get(key)
            cmd = " ".join(args)
            info = (key, ai.get_name(), ai.get_icon(), True, cmd) if ai else (key, key, None, False, cmd)
        self.cache[pid] = (comm, info)
        return info


# ---------------------------------------------------------------- tables
class Item(GObject.Object):
    """One table row. Values live in .v; bumping rev tells the cells to redraw."""
    rev = GObject.Property(type=int, default=0)

    def __init__(self, **v):
        super().__init__()
        self.v, self.children, self.kids = v, None, {}

    def set(self, **kw):
        if any(self.v.get(k) != x for k, x in kw.items()):
            self.v.update(kw)
            self.rev += 1


def sync(store, rows, data, tree=False):
    """Make store match data ({key: {values}}): add, update and remove rows."""
    for k in [k for k in rows if k not in data]:
        found, pos = store.find(rows.pop(k))
        if found:
            store.remove(pos)
    for k, v in data.items():
        it = rows.get(k)
        if it is None:
            it = rows[k] = Item(**v)
            if tree:
                it.children = Gio.ListStore.new(Item)
            store.append(it)
        else:
            it.set(**v)


def _key(v):
    return v.lower() if isinstance(v, str) else (v or 0)


def _sorter(cid):
    def cmp(a, b, _d):
        x, y = _key(a.v.get(cid)), _key(b.v.get(cid))
        return (x > y) - (x < y)
    return Gtk.CustomSorter.new(cmp, None)


def heat(v, steps):
    return sum((v or 0) >= s for s in steps)


class Table(Gtk.ScrolledWindow):
    """A sortable table. cols: dicts with id, title, width, align, fmt, heat, icon, tree."""

    def __init__(self, cols, tree=False, sort=None):
        super().__init__(vexpand=True, hexpand=True)
        self.tree, self.text, self.hs = tree, "", {}
        self.store = Gio.ListStore.new(Item)
        self.rows = {}
        self.flt = Gtk.CustomFilter.new(lambda it: self.text in it.v.get("_s", ""))
        model = Gtk.FilterListModel.new(self.store, self.flt)
        self.view = Gtk.ColumnView()
        self.view.add_css_class("tm-list")
        self.cols = {}
        for c in cols:
            col = Gtk.ColumnViewColumn.new(c["title"], self._factory(c))
            col.set_sorter(_sorter(c["id"]))
            if c.get("width"):
                col.set_fixed_width(c["width"])
            else:
                col.set_expand(True)
            col.set_resizable(True)
            self.view.append_column(col)
            self.cols[c["id"]] = col
        if tree:
            # only groups of several processes can be opened (no arrow on a lone process)
            tlm = Gtk.TreeListModel.new(model, False, False, lambda it: it.children if it.v.get("multi") else None)
            model = Gtk.SortListModel.new(tlm, Gtk.TreeListRowSorter.new(self.view.get_sorter()))
        else:
            model = Gtk.SortListModel.new(model, self.view.get_sorter())
        self.sel = Gtk.SingleSelection.new(model)
        self.sel.set_autoselect(False)
        self.sel.set_can_unselect(True)
        self.view.set_model(self.sel)
        if sort:
            self.view.sort_by_column(self.cols[sort[0]], sort[1])
        self.set_child(self.view)

    def selected(self):
        it = self.sel.get_selected_item()
        return it.get_item() if (it is not None and self.tree) else it

    def set_text(self, text):
        self.text = text.strip().lower()
        self.flt.changed(Gtk.FilterChange.DIFFERENT)

    def resort(self):
        self.view.get_sorter().changed(Gtk.SorterChange.DIFFERENT)

    def _factory(self, c):
        f = Gtk.SignalListItemFactory()
        icon, tree, cid = c.get("icon"), c.get("tree"), c["id"]

        def setup(_f, li):
            lb = Gtk.Label(xalign=c.get("align", 0), ellipsize=3, hexpand=True)
            if icon:
                w = Gtk.Box(spacing=10)
                w.append(Gtk.Image(pixel_size=20))
                w.append(lb)
                w.add_css_class("tm-name")
            else:
                w = lb
                lb.add_css_class("tm-num")
            if tree:
                ex = Gtk.TreeExpander()
                ex.set_child(w)
                w = ex
            li.set_child(w)

        def bind(_f, li):
            obj, w = li.get_item(), li.get_child()
            if self.tree:                       # every column of a tree gets TreeListRows
                row, obj = obj, obj.get_item()
            if tree:                            # only the name column has the expander arrow
                w.set_list_row(row)
                w = w.get_child()
            lb = w.get_last_child() if icon else w

            def upd(*_a):
                v = obj.v
                raw = v.get(cid)
                lb.set_label(c["fmt"](raw) if c.get("fmt") else str(raw if raw is not None else ""))
                if icon:
                    img = w.get_first_child()
                    g = v.get("_icon")
                    if g:
                        img.set_from_gicon(g)
                    else:
                        img.set_from_icon_name(v.get("_iconname", "application-x-executable-symbolic"))
                if c.get("heat"):
                    for k in ("h1", "h2", "h3"):
                        lb.remove_css_class(k)
                    n = heat(raw, c["heat"])
                    if n:
                        lb.add_css_class(f"h{n}")
            self.hs[li] = (obj, obj.connect("notify::rev", upd))
            upd()

        def unbind(_f, li):
            obj, hid = self.hs.pop(li)
            obj.disconnect(hid)
            if tree:
                li.get_child().set_list_row(None)

        f.connect("setup", setup)
        f.connect("bind", bind)
        f.connect("unbind", unbind)
        return f


# ---------------------------------------------------------------- graphs
class Graph(Gtk.DrawingArea):
    """60 second line graph in the accent color. fixed: 0..1 scale, else scales with the data."""

    def __init__(self, accent, fixed, floor=1.0, height=110, width=None):
        super().__init__()
        self.set_content_height(height)
        if width:
            self.set_content_width(width)
        else:
            self.set_hexpand(True)
        self.hist = deque([0.0] * 60, maxlen=60)
        self.fixed, self.floor = fixed, floor
        self.rgb = tuple(int(accent[i:i + 2], 16) / 255 for i in (1, 3, 5))
        self.set_draw_func(self._draw)

    def push(self, v):
        self.hist.append(v)
        self.queue_draw()

    def _draw(self, _area, cr, w, h):
        r, g, b = self.rgb
        top = 1.0 if self.fixed else max(max(self.hist) * 1.15, self.floor)
        cr.set_line_width(1)
        cr.set_source_rgba(r, g, b, 0.9)                 # frame like the Windows graph
        cr.rectangle(0.5, 0.5, w - 1, h - 1)
        cr.stroke()
        cr.set_source_rgba(r, g, b, 0.16)
        for i in range(1, 10):
            cr.move_to(w * i / 10, 0)
            cr.line_to(w * i / 10, h)
        for i in range(1, 4):
            cr.move_to(0, h * i / 4)
            cr.line_to(w, h * i / 4)
        cr.stroke()
        step = w / (len(self.hist) - 1)
        pts = [(i * step, h - 1 - min(v / top, 1.0) * (h - 3)) for i, v in enumerate(self.hist)]
        cr.move_to(0, h)
        for x, y in pts:
            cr.line_to(x, y)
        cr.line_to(w, h)
        cr.close_path()
        cr.set_source_rgba(r, g, b, 0.22)
        cr.fill()
        cr.set_line_width(1.5)
        cr.move_to(*pts[0])
        for x, y in pts[1:]:
            cr.line_to(x, y)
        cr.set_source_rgba(r, g, b, 1)
        cr.stroke()


def cpu_model():
    for line in _read("/proc/cpuinfo").splitlines():
        if line.startswith("model name"):
            return line.partition(":")[2].strip()
    return ""


RES = [("cpu", "CPU"), ("mem", "Memory"), ("disk", "Disk"), ("net", "Network")]
STAT_DEFS = {
    "cpu": [("util", "Utilization"), ("procs", "Processes"), ("threads", "Threads"),
            ("cores", "Cores"), ("uptime", "Up time")],
    "mem": [("used", "In use"), ("avail", "Available"), ("cached", "Cached"), ("total", "Total")],
    "disk": [("active", "Active time"), ("read", "Read speed"), ("write", "Write speed")],
    "net": [("send", "Send"), ("recv", "Receive")],
}
CAPTIONS = {"cpu": "% Utilization over 60 seconds", "mem": "Memory usage over 60 seconds",
            "disk": "Active time over 60 seconds", "net": "Throughput over 60 seconds"}


# ---------------------------------------------------------------- window
class Window(Adw.ApplicationWindow):
    """Built like Pine Settings: a sidebar (card, search, navigation list) and pages of cards."""

    def __init__(self, app, page):
        super().__init__(application=app, title=_("Task Manager"))
        self.set_default_size(1040, 720)
        self.set_size_request(360, 400)
        _mode, self.accent = look.saved_look()
        look.apply()
        self.cfg = load_settings()
        self.interval = self.cfg.get("interval", 1000)
        acc = self.accent
        css = Gtk.CssProvider()
        css.load_from_string(f"""
.tm-num {{ padding: 10px 12px; font-variant-numeric: tabular-nums; }}
.tm-num.h1 {{ background-color: color-mix(in srgb, {acc} 10%, transparent); }}
.tm-num.h2 {{ background-color: color-mix(in srgb, {acc} 24%, transparent); }}
.tm-num.h3 {{ background-color: color-mix(in srgb, {acc} 42%, transparent); }}
.tm-name {{ padding: 8px 6px; }}
.tm-statv {{ font-size: 1.15em; font-weight: 600; font-variant-numeric: tabular-nums; }}
.tm-tablecard {{ margin: 6px 12px 12px 12px; }}
columnview.tm-list {{ background: transparent; }}
columnview.tm-list > header button {{ padding: 8px 12px; }}
columnview.tm-list > listview > row {{ padding: 0; }}
""")
        Gtk.StyleContext.add_provider_for_display(Gdk.Display.get_default(), css,
                                                  Gtk.STYLE_PROVIDER_PRIORITY_USER + 2)
        self.ident, self.sampler = Identify(), Sampler()
        self.prev_ticks, self.prev_io, self.prev_t = {}, {}, time.monotonic()
        self.hist, self.hist_since = {}, time.time()
        self.show_all = False
        self.timer = 0
        self.hb = {}          # page -> buttons shown in the header bar
        self.tables = {}

        self.toasts = Adw.ToastOverlay()
        self.split = Adw.NavigationSplitView()
        self.split.set_min_sidebar_width(260)
        self.split.set_max_sidebar_width(300)
        self.toasts.set_child(self.split)
        self.set_content(self.toasts)
        bp = Adw.Breakpoint.new(Adw.BreakpointCondition.parse("max-width: 640sp"))
        bp.add_setter(self.split, "collapsed", True)
        self.add_breakpoint(bp)

        self.stack = Gtk.Stack(transition_type=Gtk.StackTransitionType.CROSSFADE, transition_duration=theme.motion_ms(90),
                               hexpand=True, vexpand=True)
        for name, build in (("processes", self._processes_page), ("performance", self._performance_page),
                            ("history", self._history_page), ("startup", self._startup_page),
                            ("users", self._users_page), ("details", self._details_page),
                            ("services", self._services_page), ("settings", self._settings_page)):
            self.stack.add_named(build(), name)
        self.hstack = Gtk.Stack()
        for name, buttons in self.hb.items():
            box = Gtk.Box(spacing=6)
            for b in buttons:
                box.append(b)
            self.hstack.add_named(box, name)
        for name in [p[0] for p in PAGES] + ["settings"]:
            if self.hstack.get_child_by_name(name) is None:
                self.hstack.add_named(Gtk.Box(), name)
        header = Adw.HeaderBar()
        header.pack_end(self.hstack)
        tv = Adw.ToolbarView()
        tv.add_top_bar(header)
        tv.set_content(self.stack)
        self.content = Adw.NavigationPage(title=_("Processes"), child=tv)
        self.split.set_content(self.content)
        self.split.set_sidebar(self._build_sidebar())
        self.add_controller(self._keys())
        self.go(page)
        self._restart_timer()

    # ---- sidebar (same structure as Pine Settings)
    def _build_sidebar(self):
        box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=6)
        box.set_margin_start(10)
        box.set_margin_end(10)
        box.set_margin_bottom(10)
        card = Gtk.Button()
        card.add_css_class("flat")
        card.add_css_class("pine-usercard")
        inner = Gtk.Box(spacing=12)
        badge = Gtk.Image.new_from_icon_name("utilities-system-monitor-symbolic")
        badge.set_pixel_size(24)
        badge.add_css_class("pine-badge")
        inner.append(badge)
        texts = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, valign=Gtk.Align.CENTER)
        n = Gtk.Label(label=_("Task Manager"), xalign=0)
        n.add_css_class("heading")
        texts.append(n)
        self.summary = Gtk.Label(label="", xalign=0)
        self.summary.add_css_class("dim-label")
        self.summary.add_css_class("caption")
        texts.append(self.summary)
        inner.append(texts)
        card.set_child(inner)
        card.connect("clicked", lambda *_a: self.go("performance"))
        box.append(card)

        self.search = Gtk.SearchEntry(placeholder_text=_("Find a process or app"))
        self.search.connect("search-changed", self._search)
        box.append(self.search)

        self.list = Gtk.ListBox()
        self.list.add_css_class("navigation-sidebar")
        self.rows = {}
        for pid, label, icon in PAGES + [("settings", "Settings", "emblem-system-symbolic")]:
            r = Gtk.ListBoxRow()
            hb = Gtk.Box(spacing=12)
            hb.set_margin_start(6)
            hb.append(Gtk.Image.new_from_icon_name(icon))
            hb.append(Gtk.Label(label=_(label), xalign=0))
            r.set_child(hb)
            r.pid, r.label = pid, _(label)
            self.rows[pid] = r
            self.list.append(r)
        self.list.connect("row-activated", lambda _l, r: self.go(r.pid))
        sc = Gtk.ScrolledWindow(vexpand=True, hscrollbar_policy=Gtk.PolicyType.NEVER)
        sc.set_child(self.list)
        box.append(sc)
        tv = Adw.ToolbarView()
        tv.add_top_bar(Adw.HeaderBar())
        tv.set_content(box)
        return Adw.NavigationPage(title=_("Task Manager"), child=tv)

    def go(self, pid):
        self.stack.set_visible_child_name(pid)
        self.hstack.set_visible_child_name(pid)
        self.list.select_row(self.rows[pid])
        self.content.set_title(self.rows[pid].label)
        self.split.set_show_content(True)
        self._search(self.search)
        self.refresh(force=True)

    def _keys(self):
        k = Gtk.EventControllerKey()

        def pressed(_c, keyval, _code, _st):
            if keyval == Gdk.KEY_Delete and not self.search.has_focus():
                self.end_task(signal.SIGTERM)
                return True
            return False
        k.connect("key-pressed", pressed)
        return k

    def _search(self, entry):
        for t in self.tables.values():
            t.set_text(entry.get_text())

    @staticmethod
    def _btn(label, icon, cb, style=None):
        b = Gtk.Button()
        box = Gtk.Box(spacing=6)
        box.append(Gtk.Image.new_from_icon_name(icon))
        box.append(Gtk.Label(label=label))
        b.set_child(box)
        if style:
            b.add_css_class(style)
        b.connect("clicked", lambda _b: cb())
        return b

    def _page(self, name, table, buttons=(), above=None):
        """A table in a card, like the groups on Pine Settings pages."""
        self.tables[name] = table
        self.hb[name] = list(buttons)
        card = Gtk.Box()
        card.add_css_class("card")
        card.add_css_class("tm-tablecard")
        card.set_overflow(Gtk.Overflow.HIDDEN)
        card.append(table)
        box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
        if above is not None:
            box.append(above)
        card.set_vexpand(True)
        box.append(card)
        return box

    # ---- pages
    def _processes_page(self):
        t = Table([
            dict(id="name", title=_("Name"), icon=True, tree=True),
            dict(id="cpu", title=_("CPU"), width=110, align=1, fmt=fmt_pct, heat=(1, 10, 40)),
            dict(id="mem", title=_("Memory"), width=120, align=1, fmt=fmt_bytes, heat=(200 << 20, 800 << 20, 2 << 30)),
            dict(id="disk", title=_("Disk"), width=110, align=1, fmt=fmt_rate, heat=(1 << 20, 10 << 20, 50 << 20)),
        ], tree=True, sort=("mem", Gtk.SortType.DESCENDING))
        check = Gtk.CheckButton(label=_("Show other users' and system processes"))
        check.connect("toggled", lambda b: self._set_show_all(b.get_active()))
        for side in ("start", "end", "top", "bottom"):
            getattr(check, f"set_margin_{side}")(8)
        more = Gtk.MenuButton(icon_name="view-more-symbolic", popover=Gtk.Popover(child=check))
        more.add_css_class("flat")
        return self._page("processes", t, [
            self._btn(_("Run new task"), "list-add-symbolic", self.run_task),
            self._btn(_("End task"), "process-stop-symbolic", lambda: self.end_task(signal.SIGTERM), "destructive-action"),
            self._btn(_("Force quit"), "window-close-symbolic", lambda: self.end_task(signal.SIGKILL)), more])

    def _history_page(self):
        t = Table([
            dict(id="name", title=_("Name"), icon=True),
            dict(id="cpu_time", title=_("CPU time"), width=130, align=1, fmt=fmt_time, heat=(60, 600, 3600)),
            dict(id="disk", title=_("Disk"), width=130, align=1, fmt=fmt_bytes, heat=(50 << 20, 500 << 20, 5 << 30)),
        ], sort=("cpu_time", Gtk.SortType.DESCENDING))
        self.hist_label = Gtk.Label(xalign=0, margin_start=18, margin_top=6)
        self.hist_label.add_css_class("dim-label")
        return self._page("history", t, above=self.hist_label)

    def _startup_page(self):
        t = Table([
            dict(id="name", title=_("Name"), icon=True, width=260),
            dict(id="cmd", title=_("Command")),
            dict(id="status", title=_("Status"), width=120, fmt=_),
        ], sort=("name", Gtk.SortType.ASCENDING))
        return self._page("startup", t, [
            self._btn(_("Enable"), "object-select-symbolic", lambda: self.set_startup(True), "suggested-action"),
            self._btn(_("Disable"), "action-unavailable-symbolic", lambda: self.set_startup(False))])

    def _users_page(self):
        t = Table([
            dict(id="name", title=_("User"), icon=True),
            dict(id="count", title=_("Processes"), width=120, align=1),
            dict(id="cpu", title=_("CPU"), width=110, align=1, fmt=fmt_pct, heat=(1, 10, 40)),
            dict(id="mem", title=_("Memory"), width=120, align=1, fmt=fmt_bytes, heat=(200 << 20, 800 << 20, 2 << 30)),
        ], sort=("mem", Gtk.SortType.DESCENDING))
        return self._page("users", t)

    def _details_page(self):
        t = Table([
            dict(id="name", title=_("Name"), icon=True, width=220),
            dict(id="pid", title=_("PID"), width=80, align=1),
            dict(id="status", title=_("Status"), width=110, fmt=_),
            dict(id="user", title=_("User name"), width=110),
            dict(id="cpu", title=_("CPU"), width=90, align=1, fmt=fmt_pct, heat=(1, 10, 40)),
            dict(id="mem", title=_("Memory"), width=110, align=1, fmt=fmt_bytes, heat=(200 << 20, 800 << 20, 2 << 30)),
            dict(id="cmd", title=_("Command line")),
        ], sort=("pid", Gtk.SortType.ASCENDING))
        return self._page("details", t, [
            self._btn(_("End task"), "process-stop-symbolic", lambda: self.end_task(signal.SIGTERM), "destructive-action"),
            self._btn(_("Force quit"), "window-close-symbolic", lambda: self.end_task(signal.SIGKILL))])

    def _services_page(self):
        t = Table([
            dict(id="name", title=_("Name"), width=260),
            dict(id="desc", title=_("Description")),
            dict(id="status", title=_("Status"), width=110, fmt=_),
        ], sort=("name", Gtk.SortType.ASCENDING))
        return self._page("services", t, [
            self._btn(_("Start"), "media-playback-start-symbolic", lambda: self.service("start"), "suggested-action"),
            self._btn(_("Stop"), "media-playback-stop-symbolic", lambda: self.service("stop")),
            self._btn(_("Restart"), "view-refresh-symbolic", lambda: self.service("restart"))])

    def _settings_page(self):
        page = Adw.PreferencesPage()
        group = Adw.PreferencesGroup(title=_("Updates"))
        row = Adw.ComboRow(title=_("Update speed"), subtitle=_("How often the numbers refresh"))
        row.set_model(Gtk.StringList.new([s[0] for s in SPEEDS]))
        row.set_selected(next((i for i, s in enumerate(SPEEDS) if s[1] == self.interval), 1))
        row.connect("notify::selected", self._speed)
        group.add(row)
        page.add(group)
        return page

    def _speed(self, row, _p):
        self.interval = SPEEDS[row.get_selected()][1]
        self.cfg["interval"] = self.interval
        save_settings(self.cfg)
        self._restart_timer()

    def _performance_page(self):
        a = self.accent
        self.tiles, self.bigs, self.statv, self.subs = {}, {}, {}, {}
        self.rsel, self.checks, self.details = 0, {}, {}
        page = Adw.PreferencesPage()
        overview = Adw.PreferencesGroup(title=_("Resources"), description=_("Choose one to see more"))
        for i, (rid, title) in enumerate(RES):
            row = Adw.ActionRow(title=_(title), activatable=True)
            mini = Graph(a, rid != "net", 100 * 1024, 40, 96)
            mini.set_valign(Gtk.Align.CENTER)
            self.tiles[rid] = mini
            chk = Gtk.Image.new_from_icon_name("object-select-symbolic")
            chk.add_css_class("pine-row-icon")
            self.checks[rid] = chk
            row.add_suffix(mini)
            row.add_suffix(chk)
            row.connect("activated", lambda _r, i=i: self._pick_resource(i))
            self.subs[rid] = row
            overview.add(row)
        page.add(overview)
        for rid, title in RES:
            gA = Adw.PreferencesGroup(title=_(title), description=cpu_model() if rid == "cpu" else _(CAPTIONS[rid]))
            card = Gtk.Box()
            card.add_css_class("card")
            card.set_overflow(Gtk.Overflow.HIDDEN)
            big = self.bigs[rid] = Graph(a, rid != "net", 100 * 1024, 230)
            card.append(big)
            gA.add(card)
            gB = Adw.PreferencesGroup()
            for key, label in STAT_DEFS[rid]:
                r = Adw.ActionRow(title=_(label))
                v = self.statv[(rid, key)] = Gtk.Label(valign=Gtk.Align.CENTER)
                v.add_css_class("tm-statv")
                r.add_suffix(v)
                gB.add(r)
            page.add(gA)
            page.add(gB)
            self.details[rid] = (gA, gB)
        self._pick_resource(0)
        self.hb["performance"] = []
        return page

    def _pick_resource(self, i):
        self.rsel = i
        for j, (rid, _t) in enumerate(RES):
            self.checks[rid].set_opacity(1.0 if j == i else 0.0)   # keeps the row's graph width equal
            for g in self.details[rid]:
                g.set_visible(j == i)

    # ---- actions
    def _set_show_all(self, on):
        self.show_all = on
        self.refresh(force=True)

    def _current(self):
        return self.stack.get_visible_child_name()

    def end_task(self, sig):
        page = self._current()
        if page not in ("processes", "details"):
            return
        it = self.tables[page].selected()
        if it is None:
            return
        denied = 0
        for pid in list(it.v.get("pids", [])):
            try:
                os.kill(pid, sig)
            except ProcessLookupError:
                pass
            except PermissionError:
                denied += 1
        if denied:
            self.toasts.add_toast(Adw.Toast.new(_("Not allowed to end this task")))
        elif sig == signal.SIGTERM:
            self.toasts.add_toast(Adw.Toast.new(_("Asked %s to close. If it does not, use Force quit.") % it.v["name"]))

    def run_task(self):
        d = Adw.AlertDialog.new(_("Create new task"),
                                _("Type the name of a program, folder or document and Pine OS opens it."))
        e = Gtk.Entry(placeholder_text="pine-settings", activates_default=True)
        d.set_extra_child(e)
        d.add_response("cancel", _("Cancel"))
        d.add_response("run", _("Run"))
        d.set_default_response("run")
        d.set_response_appearance("run", Adw.ResponseAppearance.SUGGESTED)
        d.connect("response", lambda _d, r: r == "run" and self._launch(e.get_text().strip()))
        d.present(self)

    def _launch(self, text):
        if not text:
            return
        try:
            path = os.path.expanduser(text)
            if os.path.exists(path):
                Gio.AppInfo.launch_default_for_uri(Gio.File.new_for_path(path).get_uri(), None)
            else:
                Gio.AppInfo.create_from_commandline(text, None, Gio.AppInfoCreateFlags.NONE).launch([], None)
        except GLib.Error as e:
            self.toasts.add_toast(Adw.Toast.new(e.message))

    def set_startup(self, enable):
        it = self.tables["startup"].selected()
        if it is None:
            return
        fn = it.v["file"]
        user_dir = os.path.expanduser("~/.config/autostart")
        os.makedirs(user_dir, exist_ok=True)
        kf = GLib.KeyFile()
        try:
            kf.load_from_file(os.path.join(user_dir, fn) if os.path.exists(os.path.join(user_dir, fn))
                              else os.path.join("/etc/xdg/autostart", fn), GLib.KeyFileFlags.KEEP_TRANSLATIONS)
            kf.set_boolean("Desktop Entry", "Hidden", not enable)
            kf.save_to_file(os.path.join(user_dir, fn))
        except GLib.Error as e:
            self.toasts.add_toast(Adw.Toast.new(e.message))
        self.refresh(force=True)

    def service(self, action):
        it = self.tables["services"].selected()
        if it is None:
            return
        subprocess.Popen(["pkexec", "systemctl", action, it.v["unit"]])
        GLib.timeout_add(2500, lambda: (self.refresh(force=True), False)[1])

    # ---- refresh
    def _restart_timer(self):
        if self.timer:
            GLib.source_remove(self.timer)
            self.timer = 0
        if self.interval:
            self.timer = GLib.timeout_add(self.interval, self.refresh)

    def refresh(self, force=False):
        s = self.sampler.sample()
        self._perf(s)
        scan = self.scan()
        page = self._current()
        if page == "processes":
            self._fill_processes(scan, s)
        elif page == "details":
            self._fill_details(scan)
        elif page == "users":
            self._fill_users(scan)
        elif page == "history":
            self._fill_history()
        elif page == "startup" and force:
            self._fill_startup()
        elif page == "services" and (force or int(time.time()) % 5 == 0):
            self._fill_services(force)
        return True

    def _perf(self, s):
        up = float((_read("/proc/uptime").split() or ["0"])[0])
        total_threads = (_read("/proc/loadavg").split() or ["0", "0", "0", "0/0"])[3].split("/")[-1]
        nprocs = sum(n.isdigit() for n in os.listdir("/proc"))
        vals = {
            "cpu": (s["cpu"], f"{s['cpu'] * 100:.0f}%", {"util": f"{s['cpu'] * 100:.0f}%", "procs": str(nprocs),
                    "threads": total_threads, "cores": str(NCPU), "uptime": fmt_uptime(up)}),
            "mem": (s["mem"], f"{fmt_bytes(s['mem_used'])}/{fmt_bytes(s['mem_total'])} ({s['mem'] * 100:.0f}%)",
                    {"used": fmt_bytes(s["mem_used"]), "avail": fmt_bytes(s["mem_avail"]),
                     "cached": fmt_bytes(s["mem_cached"]), "total": fmt_bytes(s["mem_total"])}),
            "disk": (s["disk_busy"], _("Active %d%%") % (s["disk_busy"] * 100),
                     {"active": f"{s['disk_busy'] * 100:.0f}%", "read": fmt_rate(s["disk_read"]),
                      "write": fmt_rate(s["disk_write"])}),
            "net": (s["net_down"] + s["net_up"], _("S %s  R %s") % (fmt_rate(s["net_up"]), fmt_rate(s["net_down"])),
                    {"send": fmt_rate(s["net_up"]), "recv": fmt_rate(s["net_down"])}),
        }
        for rid, (v, sub, stats) in vals.items():
            self.tiles[rid].push(v)
            self.bigs[rid].push(v)
            self.subs[rid].set_subtitle(GLib.markup_escape_text(sub))
            for k, text in stats.items():
                self.statv[(rid, k)].set_label(text)
        self.summary.set_label(_("CPU %d%% · Memory %d%%") % (s["cpu"] * 100, s["mem"] * 100))
        # column headers show the totals, like the Windows Task Manager
        for tname in ("processes", "users", "details"):
            cols = self.tables[tname].cols
            if "cpu" in cols:
                cols["cpu"].set_title(f"{s['cpu'] * 100:.0f}%  " + _("CPU"))
            if "mem" in cols:
                cols["mem"].set_title(f"{s['mem'] * 100:.0f}%  " + _("Memory"))
        if "disk" in self.tables["processes"].cols:
            self.tables["processes"].cols["disk"].set_title(f"{s['disk_busy'] * 100:.0f}%  " + _("Disk"))

    def scan(self):
        now = time.monotonic()
        dt = max(now - self.prev_t, 0.001)
        procs = read_procs()
        out = {}
        for pid, (comm, ticks, rss, uid, state) in procs.items():
            info = self.ident.of(pid, comm)
            if info is None:
                continue
            key, name, gicon, is_app, cmd = info
            delta = ticks - self.prev_ticks.get(pid, ticks)
            disk = self._disk_rate(pid, dt) if uid == UID else 0.0
            out[pid] = dict(pid=pid, comm=comm, key=key, name=name, gicon=gicon, is_app=is_app, cmd=cmd,
                            uid=uid, cpu=delta / HZ / dt / NCPU * 100, mem=float(rss), state=state,
                            disk=disk, secs=delta / HZ, io=disk * dt)
        self.prev_ticks, self.prev_t = {p: v[1] for p, v in procs.items()}, now
        self.ident.cache = {p: v for p, v in self.ident.cache.items() if p in procs}
        self.prev_io = {p: v for p, v in self.prev_io.items() if p in procs}
        for p in out.values():     # App history: totals since this window opened
            h = self.hist.setdefault(p["key"], dict(name=p["name"], _icon=p["gicon"], cpu_time=0.0, disk=0.0))
            h["cpu_time"] += p["secs"]
            h["disk"] += p["io"]
        return out

    def _disk_rate(self, pid, dt):
        m = re.findall(r"^(?:read|write)_bytes: (\d+)", _read(f"/proc/{pid}/io"), re.M)
        cur = sum(int(x) for x in m)
        rate = max(0, cur - self.prev_io.get(pid, cur)) / dt
        self.prev_io[pid] = cur
        return rate

    def _fill_processes(self, scan, _s):
        groups = {}
        for p in scan.values():
            if p["uid"] != UID and not self.show_all:
                continue
            g = groups.setdefault(p["key"], dict(name=p["name"], gicon=p["gicon"], pids=[], cpu=0.0, mem=0.0,
                                                 disk=0.0, kids={}, text=[p["name"]]))
            g["pids"].append(p["pid"])
            g["cpu"] += p["cpu"]
            g["mem"] += p["mem"]
            g["disk"] += p["disk"]
            g["text"] += [p["comm"], str(p["pid"])]
            g["kids"][p["pid"]] = dict(name=f"{p['comm']}  ·  PID {p['pid']}", cpu=p["cpu"], mem=p["mem"],
                                       disk=p["disk"], pids=[p["pid"]], _icon=p["gicon"],
                                       _s=f"{p['comm']} {p['pid']}".lower())
        t = self.tables["processes"]
        data = {k: dict(name=g["name"] if len(g["pids"]) == 1 else f"{g['name']} ({len(g['pids'])})",
                        cpu=g["cpu"], mem=g["mem"], disk=g["disk"], pids=g["pids"], _icon=g["gicon"],
                        multi=len(g["pids"]) > 1, _s=" ".join(g["text"]).lower()) for k, g in groups.items()}
        for k in [k for k, it in t.rows.items() if k in data and bool(it.v.get("multi")) != data[k]["multi"]]:
            found, pos = t.store.find(t.rows.pop(k))      # one process became several (or back): new row,
            if found:                                    # because only the row's creation decides the arrow
                t.store.remove(pos)
        sync(t.store, t.rows, data, tree=True)
        for k, g in groups.items():
            it = t.rows[k]
            sync(it.children, it.kids, g["kids"] if len(g["pids"]) > 1 else {})
        t.resort()

    def _fill_details(self, scan):
        t = self.tables["details"]
        data = {pid: dict(name=p["comm"], pid=pid, status=STATES.get(p["state"], p["state"]),
                          user=user_name(p["uid"]), cpu=p["cpu"], mem=p["mem"], cmd=p["cmd"], pids=[pid],
                          _icon=p["gicon"], _s=f"{p['comm']} {pid} {user_name(p['uid'])} {p['cmd']}".lower())
                for pid, p in scan.items()}
        sync(t.store, t.rows, data)
        t.resort()

    def _fill_users(self, scan):
        by = {}
        for p in scan.values():
            u = by.setdefault(p["uid"], dict(name=user_name(p["uid"]), count=0, cpu=0.0, mem=0.0, pids=[],
                                             _iconname="avatar-default-symbolic"))
            u["count"] += 1
            u["cpu"] += p["cpu"]
            u["mem"] += p["mem"]
            u["pids"].append(p["pid"])
            u["_s"] = u["name"].lower()
        t = self.tables["users"]
        sync(t.store, t.rows, by)
        t.resort()

    def _fill_history(self):
        t = self.tables["history"]
        self.hist_label.set_label(_("Resource usage since %s for the apps running now and earlier")
                                  % time.strftime("%H:%M", time.localtime(self.hist_since)))
        sync(t.store, t.rows, {k: dict(h, _s=h["name"].lower()) for k, h in self.hist.items()})
        t.resort()

    def _fill_startup(self):
        entries = {}
        for d in ("/etc/xdg/autostart", os.path.expanduser("~/.config/autostart")):
            if not os.path.isdir(d):
                continue
            for fn in os.listdir(d):
                if not fn.endswith(".desktop") or fn.startswith("pine-"):   # Pine's own helpers stay on
                    continue
                kf = GLib.KeyFile()
                try:
                    kf.load_from_file(os.path.join(d, fn), GLib.KeyFileFlags.KEEP_TRANSLATIONS)

                    def g(k, kf=kf):
                        try:
                            return kf.get_locale_string("Desktop Entry", k, None)
                        except GLib.Error:
                            return ""
                    hidden = g("Hidden") == "true"
                    name = g("Name") or fn
                    entries[fn] = dict(name=name, cmd=g("Exec"), status="Disabled" if hidden else "Enabled",
                                       file=fn, _iconname=g("Icon") or "application-x-executable-symbolic",
                                       _s=f"{name} {g('Exec')}".lower())
                except GLib.Error:
                    continue
        t = self.tables["startup"]
        sync(t.store, t.rows, entries)
        t.resort()

    _services_seq, _services_busy = 0, False

    def _fill_services(self, force=False):
        """systemctl can take a moment: ask in the background so the window never stalls."""
        if self._services_busy and not force:
            return
        self._services_busy = True
        self._services_seq += 1
        seq = self._services_seq

        def work():
            try:
                out = subprocess.run(["systemctl", "list-units", "--type=service", "--all", "--no-legend", "--plain",
                                      "--no-pager"], capture_output=True, text=True, timeout=5).stdout
            except (OSError, subprocess.SubprocessError):
                out = None
            GLib.idle_add(self._show_services, seq, out)
        threading.Thread(target=work, daemon=True).start()

    def _show_services(self, seq, out):
        if seq != self._services_seq:
            return False                # a newer request is on its way
        self._services_busy = False
        if out is None:
            return False
        data = {}
        for line in out.splitlines():
            p = line.lstrip("●* ").split(None, 4)
            if len(p) < 4 or p[1] != "loaded":
                continue
            unit, sub, desc = p[0], p[3], (p[4] if len(p) > 4 else "")
            name = unit.removesuffix(".service")
            data[unit] = dict(name=name, desc=desc, unit=unit, _iconname="preferences-system-symbolic",
                              status="Running" if sub == "running" else ("Failed" if sub == "failed" else "Stopped"),
                              _s=f"{name} {desc}".lower())
        t = self.tables["services"]
        sync(t.store, t.rows, data)
        t.resort()
        return False


class App(Adw.Application):
    def __init__(self):
        super().__init__(application_id=APP_ID, flags=Gio.ApplicationFlags.HANDLES_COMMAND_LINE)
        self.connect("command-line", self._cmd)

    def _cmd(self, _app, cmdline):
        args = cmdline.get_arguments()[1:]
        valid = [p[0] for p in PAGES] + ["settings"]
        page = args[0] if args and args[0] in valid else None
        win = self.props.active_window
        if win:
            win.present()
            if page:
                win.go(page)
        else:
            Window(self, page or "processes").present()
        return 0


if __name__ == "__main__":
    sys.exit(App().run(sys.argv))
