"""Pine OS: the taskbar's right-click menu, like on Windows (run by snap.py).

XFCE would show its own menu there (Properties, Move, Remove, Panel) and offers no way to change
it, so Pine takes the right button on the taskbar window itself (a passive X grab) and shows
Task Manager / Show the desktop / Taskbar settings. Over the app icons and the tray icons the
click is handed on untouched: they keep their own menus.
"""
import ctypes
import ctypes.util
import subprocess

import gi
gi.require_version("Gtk", "3.0")
from gi.repository import GLib, Gtk  # noqa: E402
import gettext  # noqa: E402
import x11  # noqa: E402
_ = gettext.translation("pine", fallback=True).gettext

BUTTON, PRESS_MASK = 3, 4
# plain, Caps Lock, Num Lock, both. (Not "any modifier": the window manager has Alt + right button)
MODIFIERS = (0, 2, 16, 18)
SYNC, ASYNC = 0, 1
ASYNC_POINTER, REPLAY_POINTER = 0, 2
OWN_MENU = ("libdocklike.so", "libsystray.so")


def keeps_own_menu(cmdline):
    """Is the plugin of this process one whose own right-click menu stays?"""
    return any(name in cmdline for name in OWN_MENU)


class _ButtonEvent(ctypes.Structure):
    _fields_ = [("type", ctypes.c_int), ("serial", ctypes.c_ulong), ("send_event", ctypes.c_int),
                ("display", ctypes.c_void_p), ("window", ctypes.c_ulong), ("root", ctypes.c_ulong),
                ("subwindow", ctypes.c_ulong), ("time", ctypes.c_ulong)]


class _Event(ctypes.Union):
    _fields_ = [("type", ctypes.c_int), ("button", _ButtonEvent), ("pad", ctypes.c_long * 24)]


class TaskbarMenu:
    def __init__(self):
        x = self.x = ctypes.cdll.LoadLibrary(ctypes.util.find_library("X11") or "libX11.so.6")
        d, w, u = ctypes.c_void_p, ctypes.c_ulong, ctypes.c_uint
        x.XOpenDisplay.restype = d
        x.XOpenDisplay.argtypes = [ctypes.c_char_p]
        x.XConnectionNumber.argtypes = [d]
        x.XPending.argtypes = [d]
        x.XNextEvent.argtypes = [d, ctypes.POINTER(_Event)]
        x.XFlush.argtypes = [d]
        x.XGrabButton.argtypes = [d, u, u, w, ctypes.c_int, u, ctypes.c_int, ctypes.c_int, w, w]
        x.XAllowEvents.argtypes = [d, ctypes.c_int, w]
        x.XUngrabPointer.argtypes = [d, w]
        x.XQueryPointer.argtypes = [d, w] + [ctypes.POINTER(w)] * 2 + [ctypes.POINTER(ctypes.c_int)] * 4 + [ctypes.POINTER(u)]
        x.XQueryTree.argtypes = [d, w, ctypes.POINTER(w), ctypes.POINTER(w), ctypes.POINTER(ctypes.POINTER(w)),
                                 ctypes.POINTER(u)]
        x.XFree.argtypes = [ctypes.c_void_p]
        self.dpy = x.XOpenDisplay(None)
        self.grabbed = set()
        self.menu = None
        GLib.io_add_watch(x.XConnectionNumber(self.dpy), GLib.PRIORITY_HIGH, GLib.IO_IN, self.events)
        self.find_taskbar()
        GLib.timeout_add_seconds(2, self.find_taskbar)      # (a restarted taskbar is a new window)

    def find_taskbar(self):
        bars = {w for w in x11.cardinals(x11.root(), "_NET_CLIENT_LIST")
                if x11.wm_class(w)[1] == "Xfce4-panel" and "_NET_WM_WINDOW_TYPE_DOCK" in x11.types(w)}
        # The window manager holds the buttons on the taskbar window itself (X refuses a second grab
        # there): take it on the frame around it, which comes first
        frames = {self.parent(w) for w in bars} - {0}
        for w in frames - self.grabbed:
            for modifiers in MODIFIERS:
                self.x.XGrabButton(self.dpy, BUTTON, modifiers, w, 0, PRESS_MASK, SYNC, ASYNC, 0, 0)
        self.grabbed = frames
        self.x.XFlush(self.dpy)
        return True

    def parent(self, window):
        """The window around "window" (0 when it is gone or sits straight on the desktop)."""
        root, parent, count = ctypes.c_ulong(), ctypes.c_ulong(), ctypes.c_uint()
        children = ctypes.POINTER(ctypes.c_ulong)()
        if not self.x.XQueryTree(self.dpy, window, ctypes.byref(root), ctypes.byref(parent), ctypes.byref(children),
                                 ctypes.byref(count)):
            return 0
        if children:
            self.x.XFree(children)
        return parent.value if parent.value != root.value else 0

    def child_under_pointer(self, window):
        root, child = ctypes.c_ulong(), ctypes.c_ulong()
        pos = [ctypes.c_int() for _i in range(4)]
        mask = ctypes.c_uint()
        self.x.XQueryPointer(self.dpy, window, ctypes.byref(root), ctypes.byref(child),
                             *[ctypes.byref(v) for v in pos], ctypes.byref(mask))
        return child.value

    def over_own_menu(self, window):
        for _depth in range(6):                      # frame > taskbar > holder > plugin
            window = self.child_under_pointer(window)
            if not window:
                break
            pid = x11.cardinals(window, "_NET_WM_PID")
            if pid:
                try:
                    with open(f"/proc/{pid[0]}/cmdline", "rb") as f:
                        if keeps_own_menu(f.read().decode(errors="replace")):
                            return True
                except OSError:
                    pass
        return False

    def events(self, _fd, _condition):
        ev = _Event()
        while self.x.XPending(self.dpy):
            self.x.XNextEvent(self.dpy, ctypes.byref(ev))
            if ev.type != 4:                                  # ButtonPress
                continue
            # the pointer is frozen until we answer: whatever happens, answer
            own = True
            try:
                own = self.over_own_menu(ev.button.window)
            finally:
                if own:
                    self.x.XAllowEvents(self.dpy, REPLAY_POINTER, ev.button.time)
                else:
                    self.x.XAllowEvents(self.dpy, ASYNC_POINTER, ev.button.time)
                    self.x.XUngrabPointer(self.dpy, 0)
                    GLib.timeout_add(80, self.show)           # (after the button is up again)
                self.x.XFlush(self.dpy)
        return True

    def show(self):
        menu = self.menu = Gtk.Menu()
        for label, command in ((_("Task Manager"), ["pine-taskmgr"]),
                               (_("Show the desktop"), ["sh", "-c", "wmctrl -m | grep -q 'mode: ON' && wmctrl -k off || wmctrl -k on"]),
                               (None, None),
                               (_("Taskbar settings"), ["pine-settings", "personal"])):
            if label is None:
                menu.append(Gtk.SeparatorMenuItem())
                continue
            item = Gtk.MenuItem(label=label)
            item.connect("activate", lambda _i, c=command: subprocess.Popen(c, start_new_session=True))
            menu.append(item)
        menu.show_all()
        menu.popup(None, None, None, None, 0, Gtk.get_current_event_time())
        return False
