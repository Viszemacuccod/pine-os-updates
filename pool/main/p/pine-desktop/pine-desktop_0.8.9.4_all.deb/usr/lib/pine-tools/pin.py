#!/usr/bin/python3
"""Pine OS: pin apps to the taskbar (pine-pin APP.desktop...), like "Pin to taskbar" on Windows.

The taskbar's apps are the docklike plugin's "pinned" list. Three ways lead there:
  - right-click an app > Pin to taskbar (desktop and Files)
  - drag an app from the desktop or the Start menu onto the taskbar (DropZone, run by snap.py)
  - Start menu > Add to Panel: XFCE would put a separate button right of the clock; adopt()
    (run by snap.py) turns every such button into a normal taskbar pin
"""
import glob
import os
import shutil
import subprocess
import sys

import gi
gi.require_version("Gtk", "3.0")
gi.require_version("Gdk", "3.0")
from gi.repository import Gdk, Gio, GLib, Gtk  # noqa: E402
import gettext  # noqa: E402
_ = gettext.translation("pine", fallback=True).gettext

CONFIG = os.environ.get("XDG_CONFIG_HOME") or os.path.expanduser("~/.config")
DATA = os.environ.get("XDG_DATA_HOME") or os.path.expanduser("~/.local/share")
SYSTEM_RC = "/etc/xdg/xfce4/panel/docklike.rc"


def add_pins(text, ids):
    """The docklike settings file with these app ids added to its "pinned" list (once each)."""
    lines = text.splitlines() or ["[user]"]
    at = next((i for i, line in enumerate(lines) if line.startswith("pinned=")), None)
    if at is None:
        at = next((i + 1 for i, line in enumerate(lines) if line.strip() == "[user]"), len(lines))
        lines.insert(at, "pinned=")
    have = [x for x in lines[at][len("pinned="):].split(";") if x]
    # (older lists hold full paths: compare by name)
    names = {os.path.basename(x).removesuffix(".desktop") for x in have}
    for i in ids:
        if i not in names:
            have.append(i)
            names.add(i)
    lines[at] = "pinned=" + "".join(x + ";" for x in have)
    return "\n".join(lines) + "\n"


def remove_pins(text, ids):
    """The docklike settings file without these app ids in its "pinned" list."""
    lines = text.splitlines()
    for i, line in enumerate(lines):
        if line.startswith("pinned="):
            keep = [x for x in line[len("pinned="):].split(";")
                    if x and os.path.basename(x).removesuffix(".desktop") not in ids]
            lines[i] = "pinned=" + "".join(x + ";" for x in keep)
    return "\n".join(lines) + "\n"


def app_dirs():
    dirs = [DATA] + (os.environ.get("XDG_DATA_DIRS") or "/usr/local/share:/usr/share").split(":")
    return [os.path.join(d, "applications") for d in dirs if d]


def app_id(path):
    """The id docklike knows the app of this .desktop file by; None if it isn't an app. A launcher
    that exists nowhere in the applications folders is copied into the user's own one."""
    if not path or not path.endswith(".desktop") or not os.path.isfile(path):
        return None
    kf = GLib.KeyFile()
    try:
        kf.load_from_file(path, GLib.KeyFileFlags.NONE)
        if kf.get_string("Desktop Entry", "Type") != "Application":
            return None
    except GLib.Error:
        return None
    try:                                              # a panel launcher remembers where it came from
        source = kf.get_string("Desktop Entry", "X-XFCE-Source")
        path_of = GLib.filename_from_uri(source)[0]
        if os.path.isfile(path_of):
            path = path_of
    except GLib.Error:
        pass
    name = os.path.basename(path)
    if not any(os.path.isfile(os.path.join(d, name)) for d in app_dirs()):
        os.makedirs(os.path.join(DATA, "applications"), exist_ok=True)
        shutil.copy(path, os.path.join(DATA, "applications", name))
    return name.removesuffix(".desktop")


def xfconf(*args):
    try:
        r = subprocess.run(["xfconf-query", "-c", "xfce4-panel", *args], capture_output=True, text=True, timeout=10)
        return r.stdout if r.returncode == 0 else ""
    except (OSError, subprocess.TimeoutExpired):
        return ""


def plugins():
    """{plugin number: kind} of the taskbar."""
    out = {}
    for line in xfconf("-l", "-v").splitlines():
        parts = line.split()
        if len(parts) == 2 and parts[0].startswith("/plugins/plugin-") and parts[0].count("/") == 2:
            out[int(parts[0].rsplit("-", 1)[1])] = parts[1]
    return out


def pin(ids, change=add_pins):
    """Add the apps to the taskbar (or, with change=remove_pins, take them off); True if something
    changed (the taskbar then restarts)."""
    number = next((n for n, kind in plugins().items() if kind == "docklike"), None)
    if number is None or not ids:
        return False
    rc = os.path.join(CONFIG, "xfce4", "panel", f"docklike-{number}.rc")
    old = ""
    for p in (rc, SYSTEM_RC):
        try:
            with open(p) as f:
                old = f.read()
            break
        except OSError:
            continue
    new = change(old, ids)
    if new.strip() == old.strip():
        return False
    os.makedirs(os.path.dirname(rc), exist_ok=True)
    with open(rc + ".tmp", "w") as f:
        f.write(new)
    os.replace(rc + ".tmp", rc)
    restart_panel()
    return True


def restart_panel():
    subprocess.run(["xfce4-panel", "--restart"], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=20)


def launcher_files(number):
    """The .desktop files a panel launcher shows now (its folder may still hold older ones)."""
    folder = os.path.join(CONFIG, "xfce4", "panel", f"launcher-{number}")
    names = [line.strip() for line in xfconf("-p", f"/plugins/plugin-{number}/items").splitlines()]
    return [os.path.join(folder, n) for n in names if n.endswith(".desktop")]


def array_ints(text):
    """The numbers of an xfconf-query array. Its first line, "Value is an array with 8 items:",
    holds a number too, which is not one of them."""
    return [int(line) for line in text.split("\n") if line.strip().isdigit()]


def adopt():
    """Turn separate panel launchers (the buttons right of the clock) into taskbar pins."""
    kinds = plugins()
    order = array_ints(xfconf("-p", "/panels/panel-1/plugin-ids"))
    taken, ids = [], []
    for n in order:
        if kinds.get(n) != "launcher":
            continue
        found = [app_id(p) for p in launcher_files(n)]
        if found and all(found):                      # anything that isn't an app stays as it is
            taken.append(n)
            ids += found
    left = [n for n in order if n not in taken]
    # only ever write a list that is a whole taskbar
    if not taken or not {"whiskermenu", "docklike"} <= {kinds.get(n) for n in left} or not all(n in kinds for n in order):
        return False
    args = ["-p", "/panels/panel-1/plugin-ids", "--force-array"]
    for n in left:
        args += ["-t", "int", "-s", str(n)]
    xfconf(*args)
    for n in taken:
        xfconf("-p", f"/plugins/plugin-{n}", "-r", "-R")
        shutil.rmtree(os.path.join(CONFIG, "xfce4", "panel", f"launcher-{n}"), ignore_errors=True)
    if not pin(ids):
        restart_panel()
    return True

# ---------------------------------------------------------------- dragging onto the taskbar
class DropZone(Gtk.Window):
    """XFCE's taskbar takes no dropped apps. While something is dragged from elsewhere over it,
    this strip lies on top of it and takes the drop."""

    def __init__(self):
        super().__init__(type=Gtk.WindowType.POPUP)
        self.set_keep_above(True)
        visual = self.get_screen().get_rgba_visual()
        if visual:
            self.set_visual(visual)
        label = Gtk.Label(label=_("Pin to taskbar"))
        css = Gtk.CssProvider()
        css.load_from_data(b"window { background-color: rgba(11, 18, 21, 0.9); border-top: 2px solid #3ccf7d; }"
                           b" label { color: #f2f4f3; font-weight: 600; }")
        for w in (self, label):
            w.get_style_context().add_provider(css, Gtk.STYLE_PROVIDER_PRIORITY_USER + 5)
        self.add(label)
        label.show()
        # copy / link only: with "move" the desktop would delete the dragged shortcut
        self.drag_dest_set(Gtk.DestDefaults.ALL, [], Gdk.DragAction.COPY | Gdk.DragAction.LINK)
        self.drag_dest_add_uri_targets()
        self.connect("drag-data-received", self._dropped)

    def _dropped(self, _w, context, _x, _y, data, _info, time):
        ids = []
        for uri in data.get_uris():
            try:
                found = app_id(GLib.filename_from_uri(uri)[0])
            except (GLib.Error, OSError):
                found = None
            if found:
                ids.append(found)
        Gtk.drag_finish(context, bool(ids), False, time)
        self.hide()
        if ids:
            GLib.idle_add(lambda: pin(ids) and False)

    def over(self, rect):
        self.move(rect[0], rect[1])
        self.resize(rect[2], rect[3])
        self.show()


def taskbar_rect(geometry, workarea):
    """The strip (x, y, w, h) the bottom taskbar takes on this screen, or None."""
    height = geometry.y + geometry.height - (workarea.y + workarea.height)
    return (geometry.x, workarea.y + workarea.height, geometry.width, height) if height > 0 else None


# shown by the patched Start menu and taskbar (hook 9050, text domain "pine"): kept here for i18n.py
MENU_STRINGS = (_("Open"), _("Pin to taskbar"), _("Unpin from taskbar"))


if __name__ == "__main__":
    args = sys.argv[1:]
    if args[:1] == ["--unpin"] and args[1:]:
        pin([a.removesuffix(".desktop") for a in args[1:]], remove_pins)
        sys.exit(0)
    wanted = [i for i in (app_id(os.path.abspath(a)) for a in args) if i]
    if not wanted:
        print("usage: pine-pin APP.desktop... | pine-pin --unpin ID...", file=sys.stderr)
        sys.exit(1)
    pin(wanted)
