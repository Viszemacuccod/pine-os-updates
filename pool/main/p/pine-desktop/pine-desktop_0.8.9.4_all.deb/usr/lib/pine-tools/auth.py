#!/usr/bin/python3
"""Pine OS: the administrator prompt, laid out like Windows' "User Account Control".

A polkit authentication agent: whenever something needs administrator rights (pkexec, Flatpak,
accounts...) the screen dims and Pine asks. Started by /usr/libexec/pine-polkit-agent, which
falls back to lxpolkit if this can't run. The password goes only to polkit's own helper.
"""
import os
import pwd
import sys

import gi
gi.require_version("Gtk", "3.0")
gi.require_version("Gdk", "3.0")
gi.require_version("Polkit", "1.0")
gi.require_version("PolkitAgent", "1.0")
from gi.repository import GLib  # noqa: E402
GLib.set_prgname("pine-auth")
from gi.repository import Gdk, Gio, Gtk, Pango, Polkit, PolkitAgent  # noqa: E402

sys.path.insert(1, "/usr/lib/pine-settings")
import gettext  # noqa: E402
_ = gettext.translation("pine", fallback=True).gettext

# programs that only carry a request on: the app that matters is further up
CARRIERS = {"pkexec", "sh", "bash", "dash", "python3", "env", "sudo", "setsid", "flatpak", "systemctl"}


def names_of(argv):
    """The names a process can be known by: its program and, for a Pine app run through
    Python (/usr/lib/pine-settings/main.py), its folder or script."""
    if not argv:
        return []
    out = [os.path.basename(argv[0])]
    if out[0].startswith("python"):
        out = []
        script = next((a for a in argv[1:] if not a.startswith("-")), "")
        if script:
            folder = os.path.basename(os.path.dirname(script))
            if os.path.basename(script) == "main.py" and folder:
                out.append(folder)
            out.append(os.path.basename(script).removesuffix(".py"))
    return [n.lower() for n in out]


def requester(chain, apps):
    """The (name, icon) of the first known app in a chain of command lines (asking process
    first, then its parents), or None."""
    for argv in chain:
        for name in names_of(argv):
            if name not in CARRIERS and name in apps:
                return apps[name]
    return None


def process_chain(pid):
    chain = []
    while pid > 1 and len(chain) < 12:
        try:
            with open(f"/proc/{pid}/cmdline", "rb") as f:
                chain.append([a.decode(errors="replace") for a in f.read().split(b"\0") if a])
            with open(f"/proc/{pid}/stat") as f:
                pid = int(f.read().rsplit(")", 1)[1].split()[1])
        except (OSError, ValueError, IndexError):
            break
    return chain


def pkexec_command(argv):
    """The program and arguments a "pkexec [options] program..." command line runs, or []."""
    if not argv or os.path.basename(argv[0]) != "pkexec":
        return []
    rest = argv[1:]
    while rest and rest[0].startswith("-"):
        rest = rest[2 if rest[0] == "--user" else 1:]
    return rest


def menu_apps():
    """{program name / desktop id: (app name, icon)} of the menu's apps."""
    apps = {}
    for a in Gio.AppInfo.get_all():
        if not isinstance(a, Gio.DesktopAppInfo) or a.get_nodisplay():
            continue
        entry = (a.get_name(), a.get_icon())
        for key in (os.path.basename(a.get_executable() or ""), (a.get_id() or "").removesuffix(".desktop")):
            if key:
                apps.setdefault(key.lower(), entry)
    return apps


def css():
    import theme                                      # Pine colors: dark / light mode, accent
    p = theme.colors(*theme.saved())
    return f"""
#pine-auth {{ background-color: rgba(0, 0, 0, 0.55); font-family: Inter, sans-serif; }}
#pine-auth.solid {{ background-color: #06090c; }}
#pine-auth .card {{ background-color: {p['bg']}; color: {p['fg']}; border: 1px solid {p['line']};
  border-radius: 8px; box-shadow: 0 18px 48px rgba(0, 0, 0, 0.55); }}
#pine-auth label {{ color: {p['fg']}; }}
#pine-auth .head {{ background-color: {p['card_hover']}; border-radius: 8px 8px 0 0; padding: 14px 24px 18px 24px;
  border-top: 3px solid {p['accent']}; }}
#pine-auth .body {{ padding: 20px 24px; }}
#pine-auth .foot {{ background-color: {p['card_hover']}; border-radius: 0 0 8px 8px; padding: 18px 24px; }}
#pine-auth .small {{ font-size: 0.9em; }}
#pine-auth .title {{ font-size: 15pt; font-weight: 600; }}
#pine-auth .app {{ font-size: 13pt; }}
#pine-auth label.muted {{ color: {p['muted']}; }}
#pine-auth label.error {{ color: #ff6b6b; }}
#pine-auth entry {{ min-height: 34px; border-radius: 5px; }}
#pine-auth button {{ border-radius: 5px; box-shadow: none; text-shadow: none; }}
#pine-auth button.choice {{ min-height: 32px; border: 1px solid {p['line']}; background-image: none;
  background-color: {p['btn']}; }}
#pine-auth button.choice:hover {{ background-color: {p['btn_hover']}; }}
#pine-auth button.choice:focus {{ box-shadow: 0 0 0 2px {p['accent']}; }}
#pine-auth button.choice.primary {{ background-color: {p['accent']}; border-color: {p['accent']}; }}
#pine-auth button.choice.primary label {{ color: {p['on_accent']}; }}
#pine-auth button.choice:disabled {{ opacity: 0.45; }}
#pine-auth button.flat, #pine-auth button.link {{ border: none; background: none; padding: 2px 4px; }}
#pine-auth button.link label {{ color: {p['accent']}; }}
#pine-auth button.flat:hover {{ background-color: {p['btn_hover']}; }}
"""


def styled(w, *classes):
    for c in classes:
        w.get_style_context().add_class(c)
    return w


def label(text, *classes, wrap=True):
    w = Gtk.Label(label=text, xalign=0)
    if wrap:
        w.set_line_wrap(True)
        w.set_line_wrap_mode(Pango.WrapMode.WORD_CHAR)
        w.set_max_width_chars(44)
    return styled(w, *classes)


class Prompt(Gtk.Window):
    """One request. `done(True)` after polkit accepted the password, `done(False)` otherwise."""

    def __init__(self, action_id, message, details, cookie, identities, done):
        super().__init__(title=_("Administrator permission"))
        self.set_name("pine-auth")
        self.cookie, self.done = cookie, done
        self.session, self.asked, self.pending, self.sent = None, False, None, False
        self.users = []                                # (identity, shown name)
        for identity in identities:
            if isinstance(identity, Polkit.UnixUser):
                try:
                    entry = pwd.getpwuid(identity.get_uid())
                except KeyError:
                    continue
                shown = entry.pw_gecos.split(",")[0] or entry.pw_name
                self.users.insert(0 if entry.pw_uid == os.getuid() else len(self.users), (identity, shown))

        self.set_decorated(False)
        self.set_skip_taskbar_hint(True)
        self.set_skip_pager_hint(True)
        self.set_keep_above(True)
        screen = self.get_screen()
        visual = screen.get_rgba_visual()
        if visual and screen.is_composited():
            self.set_visual(visual)                    # the desktop shows dimmed behind
        else:
            styled(self, "solid")
        provider = Gtk.CssProvider()
        provider.load_from_data(css().encode())
        Gtk.StyleContext.add_provider_for_screen(screen, provider, Gtk.STYLE_PROVIDER_PRIORITY_USER + 5)
        self.connect("delete-event", lambda *_a: self.finish(False) or True)
        self.connect("key-press-event", self._key)
        self._build(action_id, message, details)
        self.fullscreen()
        self.show_all()
        self.error.hide()
        self.present_with_time(Gdk.CURRENT_TIME)
        self.entry.grab_focus()
        if self.users:
            self._start()
        else:
            self._fail(_("No administrator account can be used."))

    def _build(self, action_id, message, details):
        card = styled(Gtk.Box(orientation=Gtk.Orientation.VERTICAL), "card")
        card.set_size_request(440, -1)
        card.set_halign(Gtk.Align.CENTER)
        card.set_valign(Gtk.Align.CENTER)

        head = styled(Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=8), "head")
        top = Gtk.Box()
        top.pack_start(label(_("Administrator permission"), "small", wrap=False), True, True, 0)
        close = styled(Gtk.Button.new_from_icon_name("window-close-symbolic", Gtk.IconSize.MENU), "flat")
        close.get_accessible().set_name(_("Close"))
        close.connect("clicked", lambda *_a: self.finish(False))
        top.pack_end(close, False, False, 0)
        head.pack_start(top, False, False, 0)
        head.pack_start(label(_("Do you want to allow this app to make changes to your device?"), "title"),
                        False, False, 0)
        card.pack_start(head, False, False, 0)

        def detail(key):
            return details.get(key, "")

        try:
            pid = int(detail("polkit.subject-pid") or detail("polkit.caller-pid") or 0)
        except ValueError:
            pid = 0
        found = requester(process_chain(pid), menu_apps())
        try:                                           # pkexec asks for itself: what it will run
            caller = process_chain(int(detail("polkit.caller-pid") or 0))[:1]
        except ValueError:
            caller = []
        command = pkexec_command(caller[0] if caller else [])
        program = command[0] if command else ""
        name = found[0] if found else os.path.basename(program) or "Pine OS"

        body = styled(Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10), "body")
        row = Gtk.Box(spacing=14)
        image = Gtk.Image()
        if found and found[1]:
            image.set_from_gicon(found[1], Gtk.IconSize.DIALOG)
        else:
            image.set_from_icon_name("dialog-password", Gtk.IconSize.DIALOG)
        image.set_pixel_size(32)
        row.pack_start(image, False, False, 0)
        row.pack_start(label(name, "app"), True, True, 0)
        body.pack_start(row, False, False, 0)
        body.pack_start(label(message, "muted"), False, False, 0)

        # exactly what is about to run, for whoever wants to know
        lines = [f"{_('Program')}: {program}" if program else "",
                 f"{_('Command')}: {' '.join(command)[:400]}" if command else "",
                 f"{_('Action')}: {action_id}"]
        more = styled(Gtk.Button(label=_("Show more details")), "link")
        more.set_halign(Gtk.Align.START)
        reveal = Gtk.Revealer()
        text = label("\n".join(x for x in lines if x), "small", "muted")
        text.set_selectable(True)
        text.set_can_focus(False)
        reveal.add(text)

        def toggle(*_a):
            show = not reveal.get_reveal_child()
            reveal.set_reveal_child(show)
            more.set_label(_("Hide details") if show else _("Show more details"))
        more.connect("clicked", toggle)
        body.pack_start(more, False, False, 0)
        body.pack_start(reveal, False, False, 0)

        body.pack_start(label(_("To continue, enter an administrator password."), "small"), False, False, 4)
        self.who = Gtk.ComboBoxText()
        for _identity, shown in self.users:
            self.who.append_text(shown)
        self.who.set_active(0)
        if len(self.users) > 1:
            self.who.connect("changed", lambda *_a: self._start())
            body.pack_start(self.who, False, False, 0)
        elif self.users:
            body.pack_start(label(self.users[0][1], "app"), False, False, 0)
        self.entry = Gtk.Entry(visibility=False, input_purpose=Gtk.InputPurpose.PASSWORD,
                               placeholder_text=_("Password"))
        self.entry.get_accessible().set_name(_("Password"))
        self.entry.connect("changed", lambda *_a: self._state())
        self.entry.connect("activate", lambda *_a: self._yes())
        body.pack_start(self.entry, False, False, 0)
        self.error = label("", "small", "error")
        body.pack_start(self.error, False, False, 0)
        card.pack_start(body, False, False, 0)

        foot = styled(Gtk.Box(spacing=10, homogeneous=True), "foot")
        self.yes = styled(Gtk.Button(label=_("Yes")), "choice")
        self.no = styled(Gtk.Button(label=_("No")), "choice", "primary")
        self.yes.connect("clicked", lambda *_a: self._yes())
        self.no.connect("clicked", lambda *_a: self.finish(False))
        foot.pack_start(self.yes, True, True, 0)
        foot.pack_start(self.no, True, True, 0)
        card.pack_start(foot, False, False, 0)
        self.add(card)
        self._state()

    def _state(self):
        """"No" is highlighted until there is a password; then "Yes" is what Enter does."""
        ready = bool(self.entry.get_text()) and self.pending is None and not self.sent
        self.yes.set_sensitive(ready)
        for button, primary in ((self.yes, ready), (self.no, not ready)):
            context = button.get_style_context()
            (context.add_class if primary else context.remove_class)("primary")

    def _key(self, _w, event):
        if event.keyval == Gdk.KEY_Escape:
            self.finish(False)
            return True
        return False

    # ------------------------------------------------------------ polkit's password check
    def _start(self):
        self._drop()
        self.asked, self.pending, self.sent = False, None, False
        identity = self.users[max(self.who.get_active(), 0)][0]
        self.session = PolkitAgent.Session.new(identity, self.cookie)
        self.session.connect("request", self._request)
        self.session.connect("show-error", lambda s, text: s is self.session and self._message(text))
        self.session.connect("show-info", lambda s, text: s is self.session and self._message(text))
        self.session.connect("completed", self._completed)
        self.session.initiate()
        self._state()

    def _drop(self):
        session, self.session = self.session, None
        if session:
            session.cancel()

    def _request(self, session, _prompt, _echo):
        if session is not self.session:
            return
        self.asked = True
        if self.pending is not None:
            self._send(self.pending)

    def _send(self, password):
        self.asked, self.pending, self.sent = False, None, True
        self.session.response(password)

    def _yes(self):
        password = self.entry.get_text()
        if not password or not self.session or self.sent or self.pending is not None:
            return
        self.error.hide()
        self.entry.set_sensitive(False)
        if self.asked:
            self._send(password)
        else:
            self.pending = password                    # the helper hasn't asked yet
        self._state()

    def _completed(self, session, gained):
        if session is not self.session:
            return
        self.session = None
        if gained:
            self.finish(True)
        elif self.sent:
            self.entry.set_sensitive(True)
            self.entry.set_text("")
            self.entry.grab_focus()
            self._message(_("Wrong password. Try again."))
            self._start()
        else:                                          # failed before any password: don't loop
            self._fail(_("The password could not be checked."))

    def _message(self, text):
        self.error.set_text(text)
        self.error.show()

    def _fail(self, text):
        self.entry.set_sensitive(False)
        self._message(text)
        self.no.grab_focus()

    def finish(self, ok):
        if self.done is None:
            return
        done, self.done = self.done, None
        self._drop()
        self.pending = None
        self.entry.set_text("")
        self.destroy()
        done(ok)


# polkit's agent interface, spoken directly: PolkitAgent.Listener can't be subclassed from Python
# (PyGObject drops the reply callback's data and the process crashes)
INTERFACE = """<node><interface name="org.freedesktop.PolicyKit1.AuthenticationAgent">
  <method name="BeginAuthentication">
    <arg type="s" direction="in"/><arg type="s" direction="in"/><arg type="s" direction="in"/>
    <arg type="a{ss}" direction="in"/><arg type="s" direction="in"/><arg type="a(sa{sv})" direction="in"/>
  </method>
  <method name="CancelAuthentication"><arg type="s" direction="in"/></method>
</interface></node>"""
AGENT_PATH = "/org/pineos/AuthAgent"
POLKIT = "org.freedesktop.PolicyKit1"


def unix_uids(identities):
    """The user ids in polkit's [(kind, {detail: value})] list of who may answer."""
    return [d["uid"] for kind, d in identities if kind == "unix-user" and "uid" in d]


class Agent:
    def __init__(self):
        self.waiting, self.open, self.owner = [], None, None       # one prompt at a time

    def call(self, _bus, sender, _path, _interface, method, params, invocation):
        if sender != self.owner:                       # only polkit itself may make Pine ask
            invocation.return_dbus_error("org.freedesktop.DBus.Error.AccessDenied", "polkit only")
        elif method == "BeginAuthentication":
            self.waiting.append((invocation, params.unpack()))
            self._next()
        else:
            self._cancel(params.unpack()[0])
            invocation.return_value(None)

    def _next(self):
        if self.open or not self.waiting:
            return
        invocation, (action_id, message, _icon, details, cookie, identities) = self.waiting.pop(0)

        def done(ok):
            self.open = None
            if ok:
                invocation.return_value(None)
            else:                                      # "No": pkexec reports "dismissed" (126)
                invocation.return_dbus_error(POLKIT + ".Error.Cancelled", "dismissed")
            GLib.idle_add(lambda: self._next() and False)

        try:
            users = [Polkit.UnixUser.new(uid) for uid in unix_uids(identities)]
            self.open = (cookie, Prompt(action_id, message, details, cookie, users, done))
        except Exception:                              # never leave admin requests hanging:
            import traceback                           # give up, the wrapper starts lxpolkit
            traceback.print_exc()
            done(False)
            invocation.get_connection().flush_sync(None)
            os._exit(3)

    def _cancel(self, cookie):
        for request in [r for r in self.waiting if r[1][4] == cookie]:
            self.waiting.remove(request)
            request[0].return_dbus_error(POLKIT + ".Error.Cancelled", "cancelled")
        if self.open and self.open[0] == cookie:
            self.open[1].finish(False)


def main():
    import theme  # noqa: F401  (fail now, not at the first request, if Pine's colors can't load)
    agent = Agent()
    bus = Gio.bus_get_sync(Gio.BusType.SYSTEM, None)
    node = Gio.DBusNodeInfo.new_for_xml(INTERFACE)
    bus.register_object(AGENT_PATH, node.interfaces[0], agent.call, None, None)
    authority = Polkit.Authority.get_sync(None)
    subject = Polkit.UnixSession.new_for_process_sync(os.getpid(), None)
    locale = os.environ.get("LC_MESSAGES") or os.environ.get("LANG") or "C"

    def appeared(_bus, _name, owner):                  # also after polkit restarted
        agent.owner = owner
        try:
            authority.register_authentication_agent_sync(subject, locale, AGENT_PATH, None)
        except GLib.Error as e:                        # e.g. another prompt already runs
            print(e.message, file=sys.stderr)
            os._exit(1)

    Gio.bus_watch_name_on_connection(bus, POLKIT, Gio.BusNameWatcherFlags.AUTO_START, appeared, None)
    Gtk.main()


if __name__ == "__main__":
    main()
