"""Bluetooth & devices: Bluetooth, mouse and touchpad, keyboard, printers.
(Without Bluetooth hardware the page is just "Devices".)"""
import glob
import re

from gi.repository import Adw, Gtk

import apply
import common as c

PAGES, SEARCH = {}, []


def register(pid, title, build, parent=None, search=()):
    PAGES[pid] = {"title": title, "build": build, "parent": parent}
    for t, s in search:
        SEARCH.append((t, s, pid))


# ================================================================ Bluetooth
def bt(*args, timeout=6):
    return c.run(["bluetoothctl"] + list(args), timeout=timeout)


def bt_available():
    rc, out, _ = c.run(["systemctl", "is-active", "bluetooth"])
    if out.strip() != "active":
        return False
    rc, out, _ = bt("list", timeout=4)
    return rc == 0 and "Controller" in out


def bt_powered():
    _, out, _ = bt("show", timeout=4)
    return "Powered: yes" in out


def bt_devices(which="Paired"):
    _, out, _ = bt("devices", which, timeout=4)
    devs = []
    for line in out.splitlines():
        m = re.match(r"Device (\S+) (.+)", line.strip())
        if m:
            devs.append((m.group(1), m.group(2)))
    return devs


DEVICE_ICONS = {"audio": "audio-headphones-symbolic", "input-mouse": "input-mouse-symbolic",
                "input-keyboard": "input-keyboard-symbolic", "phone": "phone-symbolic",
                "input-gaming": "input-gaming-symbolic", "computer": "computer-symbolic"}


def bt_info(mac):
    _, out, _ = bt("info", mac, timeout=4)
    icon = re.search(r"Icon: (\S+)", out)
    icon = icon.group(1) if icon else ""
    sym = next((v for k, v in DEVICE_ICONS.items() if icon.startswith(k)), "bluetooth-active-symbolic")
    bat = re.search(r"Battery Percentage: \S+ \((\d+)\)", out)
    return "Connected: yes" in out, sym, bat.group(1) if bat else None


def set_bt_power(on):
    def work():
        if on:
            c.run(["rfkill", "unblock", "bluetooth"])
        bt("power", "on" if on else "off")
    c.call_async(work, lambda _r: c.WINDOW.refresh())


def bt_action(args, ok_msg, fail_msg, timeout=25):
    c.toast("Working on it…")
    c.run_async(["bluetoothctl", "--timeout", str(timeout)] + args,
                lambda rc, o, e: (c.toast(ok_msg if rc == 0 and "fail" not in o.lower() else fail_msg),
                                  c.WINDOW.refresh()), timeout=timeout + 10)


def add_bt_dialog():
    box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=12, margin_top=6, margin_bottom=18,
                  margin_start=18, margin_end=18)
    status = Gtk.Box(spacing=10, halign=Gtk.Align.CENTER)
    status.append(c.spinner())
    status_lbl = Gtk.Label(label="Looking for devices… Make sure your device is in pairing mode.", wrap=True)
    status.append(status_lbl)
    box.append(status)
    lb = Gtk.ListBox(selection_mode=Gtk.SelectionMode.NONE)
    lb.add_css_class("boxed-list")
    sc = Gtk.ScrolledWindow(vexpand=True, min_content_height=260)
    sc.set_child(lb)
    box.append(sc)
    d = c.dialog("Add a Bluetooth device", box, 480, 460)
    paired = {m for m, _ in bt_devices("Paired")}

    def pair(mac, name):
        d.close()
        c.toast(f"Connecting to {name}…")
        c.run_async(["sh", "-c", f"bluetoothctl --timeout 20 pair {mac}; bluetoothctl trust {mac}; "
                                 f"bluetoothctl --timeout 15 connect {mac}"],
                    lambda rc, o, e: (c.toast(f"{name} is connected" if "Connection successful" in o
                                              else f"Could not connect to {name}"), c.WINDOW.refresh()),
                    timeout=60)

    def found(rc, out, err):
        status.get_first_child().set_visible(False)
        new = [(m, n) for m, n in bt_devices("") if m not in paired and not re.fullmatch(r"([0-9A-F]{2}-){5}[0-9A-F]{2}", n)]
        status_lbl.set_label(f"{len(new)} devices found" if new else "No devices found. Is the device in pairing mode?")
        for mac, name in new:
            _con, icon, _b = bt_info(mac)
            lb.append(c.row(name, mac, icon, c.button("Pair", lambda m=mac, n=name: pair(m, n), "suggested-action")))

    c.run_async(["bluetoothctl", "--timeout", "12", "scan", "on"], found, timeout=30)
    d.present(c.WINDOW)


def has_bluetooth():
    """Bluetooth hardware in this computer (whether it is on or off)."""
    return bool(glob.glob("/sys/class/bluetooth/hci*"))


def bluetooth_group():
    if not has_bluetooth():
        return None      # no Bluetooth in this computer: nothing about it is shown
    if not bt_available():
        return c.group("Bluetooth", None, [c.row("Bluetooth is not ready", "Restart the computer, or check that Bluetooth is on in the firmware",
                                                 "bluetooth-disabled-symbolic")])
    powered = bt_powered()
    rows = [c.switch_row("Bluetooth", "On" if powered else "Off", powered, set_bt_power, "bluetooth-active-symbolic")]
    g = c.group("Bluetooth", None, rows,
                suffix=c.button("Add device", add_bt_dialog, "suggested-action", "list-add-symbolic") if powered else None)
    if powered:
        for mac, name in bt_devices("Paired"):
            con, icon, bat = bt_info(mac)
            sub = ("Connected" if con else "Paired") + (f" · Battery {bat}%" if bat else "")
            btn = c.button("Disconnect" if con else "Connect",
                           lambda m=mac, n=name, cn=con: bt_action(["disconnect" if cn else "connect", m],
                                                                   f"{n} {'disconnected' if cn else 'connected'}",
                                                                   f"Could not reach {n}"))
            rm = c.button(None, lambda m=mac, n=name: c.confirm(
                f"Remove {n}?", "You can pair it again later.", "Remove",
                lambda: bt_action(["remove", m], f"{n} removed", "Could not remove it", 8), True),
                "flat", "user-trash-symbolic")
            rm.set_tooltip_text("Remove device")
            g.add(c.row(name, sub, icon, [btn, rm]))
    return g


DEVICES_TITLE = "Bluetooth & devices" if has_bluetooth() else "Devices"


def build_devices():
    others = c.group("Other devices" if has_bluetooth() else None, None, [
        c.row("Printers & scanners", "Add, remove, set the default printer", "printer-symbolic", nav="printers"),
        c.row("Mouse & touchpad", "Pointer speed, scrolling, primary button, taps", "input-mouse-symbolic", nav="mouse"),
        c.row("Keyboard", "Key repeat, Num Lock, layouts", "input-keyboard-symbolic", nav="keyboard"),
    ])
    return c.page(DEVICES_TITLE, *[g for g in (bluetooth_group(), phone_group(), others) if g])


# ================================================================ Your phone (Valent)
PHONE_APP = "ca.andyholmes.Valent"


def phone_group():
    """Phone link: files both ways, the phone's notifications and texts on this computer.
    Valent (from the App Store) talks to the KDE Connect app on Android."""
    rc, _o, _e = c.run(["flatpak", "info", PHONE_APP])
    if rc == 0:
        btn = c.button("Open", lambda: c.run_async(["flatpak", "run", PHONE_APP]))
        sub = "Send files, see your phone's notifications and texts here"
    else:
        btn = c.button("Get it", lambda: c.run_async(["flatpak", "run", "io.github.kolunmi.Bazaar",
                                                       f"appstream://{PHONE_APP}"]), "suggested-action")
        sub = "Install Phone Link from the App Store, then get KDE Connect on your Android phone"
    btn.set_valign(Gtk.Align.CENTER)
    return c.group("Your phone", None, [c.row("Phone Link", sub, "phone-symbolic", btn)])


register("devices", DEVICES_TITLE, build_devices, search=[
    ("Bluetooth", "Headphones, wireless mouse, pair device"), ("Add device", "Pair Bluetooth device"),
    ("Phone Link", "Phone, Android, KDE Connect, send files")]
    if has_bluetooth() else [("Devices", "Printers, mouse, keyboard"), ("Phone Link", "Phone, Android, KDE Connect")])


# ================================================================ Mouse & touchpad
def build_mouse():
    s = dict(apply.INPUT_DEFAULTS)
    s.update(c.load_config().get("input", {}))
    devs = apply.pointer_devices()
    touchpad = any(t for *_x, t in devs)

    def set_(key, value):
        s[key] = value
        c.save_config(input=s)
        apply.apply_input({"input": s})

    groups = [c.group("Mouse", None, [
        c.slider_row("Pointer speed", None, -1, 1, 0.05, float(s["accel"]), lambda v: set_("accel", round(v, 2)),
                     "input-mouse-symbolic", delay=120),
        c.combo_row("Primary mouse button", None, ["Left", "Right"], int(bool(s["left_handed"])),
                    lambda i: set_("left_handed", i == 1), "input-mouse-symbolic"),
        c.switch_row("Natural scrolling", "Content moves the way your fingers move", s["natural_mouse"],
                     lambda on: set_("natural_mouse", on), "view-sort-ascending-symbolic"),
    ])]
    if touchpad:
        groups.append(c.group("Touchpad", None, [
            c.switch_row("Tap to click", "Tap the touchpad instead of pressing it", s["tap"],
                         lambda on: set_("tap", on), "input-touchpad-symbolic"),
            c.switch_row("Natural scrolling", "Content moves the way your fingers move", s["natural_touchpad"],
                         lambda on: set_("natural_touchpad", on), "view-sort-ascending-symbolic"),
            c.switch_row("Ignore touchpad while typing", None, s["dwt"], lambda on: set_("dwt", on),
                         "input-keyboard-symbolic"),
        ]))
    if not devs:
        groups.insert(0, c.group(rows=[c.row("No mouse settings available", "Changes are saved and used when a mouse is found",
                                             "dialog-information-symbolic")]))
    return c.page("Mouse & touchpad", *groups)


register("mouse", "Mouse & touchpad", build_mouse, "devices", [
    ("Pointer speed", "Mouse speed, sensitivity"), ("Primary mouse button", "Left-handed mouse"),
    ("Natural scrolling", "Scroll direction, reverse"), ("Tap to click", "Touchpad, laptop")])


# ================================================================ Keyboard
def build_keyboard():
    ch = "keyboards"
    delay = c.xget_int(ch, "/Default/KeyRepeat/Delay", 500)
    rate = c.xget_int(ch, "/Default/KeyRepeat/Rate", 20)

    def setk(prop, v):
        c.xset(ch, "/Default/KeyRepeat", True, "bool")
        c.xset(ch, prop, int(v), "int")

    test = Adw.EntryRow(title="Type here to test")
    return c.page("Keyboard", c.group("Key repeat", "When a key is held down", [
        c.slider_row("Wait before repeating", None, 150, 1000, 10, delay,
                     lambda v: setk("/Default/KeyRepeat/Delay", v), "preferences-system-time-symbolic",
                     fmt=lambda v: f"{v:.0f} ms"),
        c.slider_row("Repeat speed", None, 5, 60, 1, rate, lambda v: setk("/Default/KeyRepeat/Rate", v),
                     "media-seek-forward-symbolic", fmt=lambda v: f"{v:.0f} / s"),
        test,
    ]), c.group("Other", None, [
        c.switch_row("Turn on Num Lock at sign-in", None, c.xget_bool(ch, "/Default/Numlock", True),
                     lambda on: (c.xset(ch, "/Default/RestoreNumlock", False, "bool"),
                                 c.xset(ch, "/Default/Numlock", on, "bool")), "input-dialpad-symbolic"),
        c.row("Keyboard layouts", "Languages you type in, switch with Super + Space", "input-keyboard-symbolic",
              nav="time"),
    ]))


register("keyboard", "Keyboard", build_keyboard, "devices", [
    ("Key repeat", "Keyboard delay, repeat speed"), ("Num Lock", "Number keys at start")])


# ================================================================ Printers
def printers():
    rc, out, _ = c.run(["lpstat", "-e"], timeout=5)
    if rc != 0:
        return None
    names = [n for n in out.split() if n]
    _, d, _ = c.run(["lpoptions"], timeout=5)
    _, sysd, _ = c.run(["lpstat", "-d"], timeout=5)
    m = re.search(r"destination: (\S+)", sysd)
    default = m.group(1) if m else None
    _, states, _ = c.run(["lpstat", "-p"], timeout=5)
    info = {}
    for line in states.splitlines():
        m = re.match(r"printer (\S+) (?:is )?(\w+)", line)
        if m:
            info[m.group(1)] = {"idle": "Ready", "now": "Printing", "disabled": "Paused"}.get(m.group(2), m.group(2))
    return [(n, info.get(n, ""), n == default) for n in names]


def add_printer(name, uri):
    safe = re.sub(r"[^A-Za-z0-9_-]+", "_", name).strip("_")[:60] or "Printer"
    c.toast(f"Adding {name}…")

    def done(rc, out, err):
        if rc == 0:
            c.toast(f"{name} is ready")
        else:
            c.error("The printer could not be added",
                    "This printer may need its own driver. Look for its driver in the App Store, "
                    "or connect it over the network.\n\n" + err.strip())
        c.WINDOW.refresh()
    c.run_async(["lpadmin", "-p", safe, "-E", "-v", uri, "-m", "everywhere"], done, timeout=90)


def add_printer_dialog():
    box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=12, margin_top=6, margin_bottom=18,
                  margin_start=18, margin_end=18)
    status = Gtk.Box(spacing=10, halign=Gtk.Align.CENTER)
    sp = c.spinner()
    status.append(sp)
    lbl = Gtk.Label(label="Looking for printers…")
    status.append(lbl)
    box.append(status)
    lb = Gtk.ListBox(selection_mode=Gtk.SelectionMode.NONE)
    lb.add_css_class("boxed-list")
    sc = Gtk.ScrolledWindow(vexpand=True, min_content_height=200)
    sc.set_child(lb)
    box.append(sc)
    manual = Gtk.ListBox()
    manual.add_css_class("boxed-list")
    addr = Adw.EntryRow(title="Or type the printer's network address (e.g. 192.168.1.50)")
    manual.append(addr)
    box.append(manual)
    d = c.dialog("Add a printer", box, 520, 480)

    def add_addr():
        a = addr.get_text().strip()
        if a:
            d.close()
            add_printer(f"Printer {a}", a if "://" in a else f"ipp://{a}/ipp/print")
    btn = c.button("Add", add_addr)
    addr.add_suffix(btn)

    def found(rc, out, err):
        sp.set_visible(False)
        devices, cur = [], {}
        for line in out.splitlines():
            line = line.strip()
            if line.startswith("Device:"):
                if cur:
                    devices.append(cur)
                cur = {"uri": line.split("=", 1)[1].strip()}
            elif "=" in line and cur:
                k, v = line.split("=", 1)
                cur[k.strip()] = v.strip()
        if cur:
            devices.append(cur)
        devices = [x for x in devices if "://" in x["uri"] and x.get("make-and-model", "Unknown") != "Unknown"
                   or x["uri"].startswith(("dnssd://", "usb://", "ipp://", "ipps://"))]
        lbl.set_label(f"{len(devices)} printers found" if devices else "No printers found. Is the printer on?")
        for x in devices:
            name = x.get("info") or x.get("make-and-model") or x["uri"]
            kind = "USB" if x["uri"].startswith("usb") else "Network"
            lb.append(c.row(name, kind, "printer-symbolic",
                            c.button("Add", lambda n=name, u=x["uri"]: (d.close(), add_printer(n, u)), "suggested-action")))

    c.run_async(["lpinfo", "-l", "-v", "--timeout", "8"], found, timeout=40)
    d.present(c.WINDOW)


def build_printers():
    ps = printers()
    add = c.button("Add printer", add_printer_dialog, "suggested-action", "list-add-symbolic")
    if ps is None:
        return c.page("Printers", c.group(rows=[c.row("Printing is not running", "The printing service was not found",
                                                      "dialog-warning-symbolic")]))
    g = c.group("Printers", None, suffix=add)
    if not ps:
        g.add(c.row("No printers yet", "Turn your printer on and choose Add printer", "printer-symbolic"))
    for name, state, default in ps:
        btns = [c.button("Test page", lambda n=name: c.run_async(
            ["lp", "-d", n, "/usr/share/cups/data/testprint"],
            lambda rc, o, e: c.toast("Test page sent" if rc == 0 else "Could not print")))]
        if not default:
            btns.append(c.button("Set as default", lambda n=name: c.run_async(
                ["lpadmin", "-d", n], lambda rc, o, e: (c.toast(f"{n} is now the default printer"), c.WINDOW.refresh()))))
        rm = c.button(None, lambda n=name: c.confirm(f"Remove {n}?", "You can add it again later.", "Remove",
                                                      lambda: c.run_async(["lpadmin", "-x", n],
                                                                          lambda *_: (c.toast(f"{n} removed"), c.WINDOW.refresh())),
                                                      True), "flat", "user-trash-symbolic")
        rm.set_tooltip_text("Remove printer")
        btns.append(rm)
        g.add(c.row(name.replace("_", " "), state + (" · Default" if default else ""), "printer-symbolic", btns))
    return c.page("Printers", g)


register("printers", "Printers & scanners", build_printers, "devices", [
    ("Printers", "Add printer, default printer, test page"), ("Add printer", "Network printer, USB printer")])
