"""System: display, sound, notifications, power, storage, about."""
import glob
import json
import os
import platform
import re
import shutil
import socket

from gi.repository import Adw, GLib, Gtk

import common as c

PAGES, SEARCH = {}, []


def register(pid, title, build, parent=None, search=()):
    PAGES[pid] = {"title": title, "build": build, "parent": parent}
    for t, s in search:
        SEARCH.append((t, s, pid))


def read(path, default=""):
    try:
        with open(path) as f:
            return f.read().strip()
    except OSError:
        return default


def device_model():
    vendor = read("/sys/class/dmi/id/sys_vendor")
    product = read("/sys/class/dmi/id/product_name")
    if "innotek" in vendor.lower() or product == "VirtualBox":
        return "VirtualBox virtual machine"
    if vendor.lower().startswith("qemu") or "kvm" in product.lower():
        return "Virtual machine"
    junk = ("to be filled", "system product name", "default string", "o.e.m")
    parts = [p for p in (vendor, product) if p and not any(j in p.lower() for j in junk)]
    return " ".join(parts) or "Computer"


# ================================================================ System (overview)
def build_system():
    host = socket.gethostname()
    rename = c.button("Rename", lambda: rename_dialog())
    rows = [
        c.row("Display", "Resolution, scale, brightness, multiple displays", "video-display-symbolic", nav="display"),
        c.row("Sound", "Volume, output and input devices", "audio-volume-high-symbolic", nav="sound"),
        c.row("Notifications", "Do not disturb, where alerts appear", "preferences-system-notifications-symbolic", nav="notifications"),
        c.row("Power" + (" & battery" if has_battery() else ""), "Screen off, sleep, power button", "system-shutdown-symbolic", nav="power"),
        c.row("Storage", "Free space, clean up, USB drives", "drive-harddisk-symbolic", nav="storage"),
        c.row("About", "Device specifications, Pine OS version", "help-about-symbolic", nav="about"),
    ]
    return c.page("System", c.hero("computer-symbolic", host, device_model(), rename), c.group(rows=rows))


def rename_dialog():
    box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=12, margin_top=12, margin_bottom=18,
                  margin_start=18, margin_end=18)
    info = Gtk.Label(label="Use letters, numbers and dashes. Other computers on your network see this name.",
                     wrap=True, xalign=0)
    info.add_css_class("dim-label")
    box.append(info)
    lb = Gtk.ListBox()
    lb.add_css_class("boxed-list")
    entry = Adw.EntryRow(title="New name")
    entry.set_text(socket.gethostname())
    lb.append(entry)
    box.append(lb)
    d = c.dialog("Rename your PC", box, 420)

    def save():
        name = entry.get_text().strip()
        if not re.fullmatch(r"[A-Za-z0-9]([A-Za-z0-9-]{0,61}[A-Za-z0-9])?", name):
            c.toast("That name can't be used. Use letters, numbers and dashes.")
            return
        d.close()
        c.root_sh(f"hostnamectl set-hostname '{name}' && "
                  f"sed -i 's/^127.0.1.1.*/127.0.1.1\\t{name}/' /etc/hosts",
                  lambda rc, o, e: (c.toast(f"Your PC is now called {name}") , c.WINDOW.refresh())
                  if rc == 0 else c.toast("The name was not changed"))

    btn = c.button("Rename", save, "suggested-action")
    btn.set_halign(Gtk.Align.END)
    box.append(btn)
    d.present(c.WINDOW)


register("system", "System", build_system, search=[("System", "PC name, device"), ("Rename PC", "Computer name, hostname")])


# ================================================================ Display
ROTATIONS = [("normal", "Landscape"), ("left", "Portrait"), ("inverted", "Landscape (flipped)"),
             ("right", "Portrait (flipped)")]


def parse_xrandr():
    rc, out, _ = c.run(["xrandr", "--query"])
    outputs = []
    if rc != 0:
        return outputs
    cur = None
    for line in out.splitlines():
        m = re.match(r"^(\S+) (connected|disconnected)( primary)?(?: (\d+)x(\d+)\+(\d+)\+(\d+))?(?: (normal|left|inverted|right))?", line)
        if m:
            cur = {"name": m.group(1), "connected": m.group(2) == "connected", "primary": bool(m.group(3)),
                   "active": m.group(4) is not None, "rotate": m.group(8) or "normal",
                   "pos": (int(m.group(6) or 0), int(m.group(7) or 0)), "modes": [], "current": None}
            outputs.append(cur)
            continue
        m = re.match(r"^\s+(\d+)x(\d+)(i?)\S*\s+(.*)$", line)
        if m and cur is not None and not m.group(3):
            w, h = int(m.group(1)), int(m.group(2))
            rates, preferred = [], False
            for tok in m.group(4).split():
                if tok in ("*", "+", "*+"):
                    if "*" in tok and rates:
                        cur["current"] = (w, h, rates[-1])
                    preferred = preferred or "+" in tok
                    continue
                try:
                    r = float(tok.rstrip("*+"))
                except ValueError:
                    continue
                rates.append(r)
                if "*" in tok:
                    cur["current"] = (w, h, r)
                if "+" in tok:
                    preferred = True
            existing = next((x for x in cur["modes"] if x["size"] == (w, h)), None)
            if existing:
                existing["rates"] += [r for r in rates if r not in existing["rates"]]
                existing["preferred"] = existing["preferred"] or preferred
            else:
                cur["modes"].append({"size": (w, h), "rates": rates, "preferred": preferred})
    return [o for o in outputs if o["connected"]]


def xrandr_args(o, size, rate, rotate):
    return ["--output", o, "--mode", f"{size[0]}x{size[1]}", "--rate", f"{rate:.2f}", "--rotate", rotate]


def keep_or_revert(apply_args, revert_args, on_keep):
    """Apply a display change; ask to keep it, go back automatically after 15 seconds."""
    rc, _, err = c.run(["xrandr"] + apply_args)
    if rc != 0:
        c.error("The display could not be changed", err.strip() or "Unknown error")
        return
    left = {"n": 15, "done": False}
    d = Adw.AlertDialog(heading="Keep these display settings?",
                        body="Going back to the previous settings in 15 seconds.")
    d.add_response("revert", "Revert")
    d.add_response("keep", "Keep changes")
    d.set_response_appearance("keep", Adw.ResponseAppearance.SUGGESTED)
    d.set_default_response("keep")
    d.set_close_response("revert")

    def finish(keep):
        if left["done"]:
            return
        left["done"] = True
        if keep:
            on_keep()
        else:
            c.run(["xrandr"] + revert_args)
        GLib.idle_add(lambda: (c.WINDOW.refresh(), False)[1])

    def tick():
        if left["done"]:
            return False
        left["n"] -= 1
        if left["n"] <= 0:
            d.force_close()
            finish(False)
            return False
        d.set_body(f"Going back to the previous settings in {left['n']} seconds.")
        return True

    d.connect("response", lambda _d, r: finish(r == "keep"))
    GLib.timeout_add_seconds(1, tick)
    d.present(c.WINDOW)


def save_display(o, size, rate, rotate):
    cfg = c.load_config()
    disp = cfg.get("displays", {})
    disp[o] = {"mode": f"{size[0]}x{size[1]}", "rate": rate, "rotate": rotate}
    c.save_config(displays=disp)


def display_group(index, o, many):
    modes = o["modes"]
    if not modes:
        return None
    cur = o["current"] or (modes[0]["size"][0], modes[0]["size"][1], modes[0]["rates"][0])
    sizes = [m["size"] for m in modes]
    labels = [f"{w} × {h}" + ("  (Recommended)" if m["preferred"] else "") for m, (w, h) in zip(modes, sizes)]
    try:
        si = sizes.index((cur[0], cur[1]))
    except ValueError:
        si = 0
    rates = sorted(set(round(r, 2) for r in modes[si]["rates"]), reverse=True)
    rate_labels = [f"{r:.0f} Hz" for r in rates]
    ri = min(range(len(rates)), key=lambda i: abs(rates[i] - cur[2])) if rates else 0
    roti = next((i for i, (k, _) in enumerate(ROTATIONS) if k == o["rotate"]), 0)
    old = xrandr_args(o["name"], (cur[0], cur[1]), cur[2], o["rotate"])

    def change(size=None, rate=None, rotate=None):
        size = size or (cur[0], cur[1])
        if rate is None:
            mr = next(m for m in modes if m["size"] == size)["rates"]
            rate = cur[2] if size == (cur[0], cur[1]) else max(mr, key=lambda r: (abs(r - 60) < 1, r))
        rotate = rotate or o["rotate"]
        keep_or_revert(xrandr_args(o["name"], size, rate, rotate), old,
                       lambda: save_display(o["name"], size, rate, rotate))

    rows = [
        c.combo_row("Display resolution", "Adjust the resolution to fit your display", labels, si,
                    lambda i: i != si and change(size=sizes[i]), "video-display-symbolic"),
        c.combo_row("Refresh rate", "Higher is smoother, if your display supports it", rate_labels, ri,
                    lambda i: i != ri and change(rate=rates[i]), "view-refresh-symbolic") if len(rates) > 1 else None,
        c.combo_row("Display orientation", None, [l for _, l in ROTATIONS], roti,
                    lambda i: i != roti and change(rotate=ROTATIONS[i][0]), "object-rotate-right-symbolic"),
    ]
    title = f"Display {index}" if many else "Your display"
    return c.group(title, f"{o['name']} · {cur[0]} × {cur[1]}, {cur[2]:.0f} Hz", rows)


LAYOUTS = [("extend", "Extend these displays"), ("duplicate", "Duplicate these displays"),
           ("first", "Show only on display 1"), ("second", "Show only on display 2")]


def layout_args(layout, outs):
    a, b = outs[0]["name"], outs[1]["name"]
    return {"extend": ["--output", a, "--auto", "--primary", "--output", b, "--auto", "--right-of", a],
            "duplicate": ["--output", a, "--auto", "--output", b, "--auto", "--same-as", a],
            "first": ["--output", a, "--auto", "--primary", "--output", b, "--off"],
            "second": ["--output", b, "--auto", "--primary", "--output", a, "--off"]}[layout]


def current_layout(outs):
    a, b = outs[0], outs[1]
    if not b["active"]:
        return "first"
    if not a["active"]:
        return "second"
    return "duplicate" if a["pos"] == b["pos"] else "extend"


def build_display():
    outs = parse_xrandr()
    groups = []
    if not outs:
        groups.append(c.group(rows=[c.row("No display information", "The display settings are not available right now",
                                          "dialog-information-symbolic")]))
    many = len(outs) > 1
    if many:
        cur = current_layout(outs)
        ci = [k for k, _ in LAYOUTS].index(cur)
        before = layout_args(cur, outs)

        def set_layout(i):
            if i == ci:
                return
            key = LAYOUTS[i][0]
            keep_or_revert(layout_args(key, outs), before, lambda: c.save_config(display_layout=key,
                           display_pair=[outs[0]["name"], outs[1]["name"]]))
        groups.append(c.group("Multiple displays", None, [
            c.combo_row("How to use your displays", "Tip: Super + P switches quickly", [l for _, l in LAYOUTS], ci,
                        set_layout, "video-joined-displays-symbolic")]))
    for i, o in enumerate(outs, 1):
        if o["active"]:
            groups.append(display_group(i, o, many))

    # Scale: everything bigger or smaller (GTK and text DPI)
    dpi = c.xget_int("xsettings", "/Xft/DPI", -1)
    dpi = 96 if dpi <= 0 else dpi
    scales = [100, 125, 150, 175, 200]
    si = min(range(len(scales)), key=lambda i: abs(scales[i] - dpi * 100 / 96))

    def set_scale(i):
        c.xset("xsettings", "/Xft/DPI", int(96 * scales[i] / 100), "int")
        c.toast("Scale changed. Some apps update after they are reopened.")
    scale_rows = [c.combo_row("Scale", "Change the size of text, apps and other items",
                              [f"{s}%" + ("  (Recommended)" if s == 100 else "") for s in scales], si, set_scale,
                              "zoom-in-symbolic")]

    # Brightness (laptops)
    bl = sorted(glob.glob("/sys/class/backlight/*"))
    helper = "/usr/sbin/xfpm-power-backlight-helper"
    if bl and os.path.exists(helper):
        try:
            mx = int(read(bl[0] + "/max_brightness", "100"))
            now = int(read(bl[0] + "/brightness", str(mx)))
            scale_rows.insert(0, c.slider_row(
                "Brightness", "Adjust the brightness of the built-in display", 5, 100, 1, now * 100 / mx,
                lambda v: c.run_async(["pkexec", helper, "--set-brightness", str(max(1, int(v * mx / 100)))]),
                "display-brightness-symbolic", fmt=lambda v: f"{v:.0f}%"))
        except ValueError:
            pass
    groups.append(c.group("Scale & brightness" if len(scale_rows) > 1 else "Scale", None, scale_rows))
    return c.page("Display", *groups)


register("display", "Display", build_display, "system", [
    ("Display resolution", "Screen size, monitor"), ("Refresh rate", "Hz, monitor"),
    ("Display orientation", "Rotate screen, portrait"), ("Scale", "Make everything bigger, zoom, DPI"),
    ("Brightness", "Screen brightness"), ("Multiple displays", "Second monitor, projector, extend, duplicate")])


# ================================================================ Sound
def pactl_json(what):
    rc, out, _ = c.run(["pactl", "-f", "json", "list", what])
    if rc != 0:
        return None
    try:
        return json.loads(out)
    except ValueError:
        return None


def volume_percent(dev):
    vols = dev.get("volume", {})
    for ch in vols.values():
        try:
            return int(str(ch.get("value_percent", "0")).rstrip("%"))
        except ValueError:
            pass
    return 0


def sound_group(kind):
    sink = kind == "sink"
    devs = pactl_json("sinks" if sink else "sources")
    if devs is None:
        return None
    if not sink:
        devs = [d for d in devs if d.get("monitor_of_sink") in (None, "n/a") and not d["name"].endswith(".monitor")]
    _, default, _ = c.run(["pactl", "get-default-sink" if sink else "get-default-source"])
    default = default.strip()
    title = "Output" if sink else "Input"
    if not devs:
        return c.group(title, None, [c.row("No devices found", "Nothing to play sound on" if sink
                                           else "No microphone found", "dialog-information-symbolic")])
    names = [d["name"] for d in devs]
    di = names.index(default) if default in names else 0
    cur = devs[di]
    target = "@DEFAULT_SINK@" if sink else "@DEFAULT_SOURCE@"

    def pick(i):
        if i != di:
            c.run(["pactl", "set-default-sink" if sink else "set-default-source", names[i]])
            c.WINDOW.refresh()

    rows = [
        c.combo_row("Choose where to play sound" if sink else "Choose a device for speaking or recording", None,
                    [d.get("description", d["name"]) for d in devs], di, pick,
                    "audio-speakers-symbolic" if sink else "audio-input-microphone-symbolic"),
        c.slider_row("Volume" if sink else "Input volume", None, 0, 100, 1, volume_percent(cur),
                     lambda v: c.run(["pactl", "set-sink-volume" if sink else "set-source-volume", target, f"{int(v)}%"]),
                     "audio-volume-high-symbolic" if sink else "microphone-sensitivity-high-symbolic",
                     delay=60, fmt=lambda v: f"{v:.0f}%"),
        c.switch_row("Mute", None, cur.get("mute", False),
                     lambda on: c.run(["pactl", "set-sink-mute" if sink else "set-source-mute", target, "1" if on else "0"]),
                     "audio-volume-muted-symbolic" if sink else "microphone-disabled-symbolic"),
    ]
    return c.group(title, None, rows)


def build_sound():
    out, inp = sound_group("sink"), sound_group("source")
    if out is None and inp is None:
        return c.page("Sound", c.group(rows=[c.row("Sound is not running", "No sound service was found",
                                                   "dialog-warning-symbolic")]))
    return c.page("Sound", out, inp)


register("sound", "Sound", build_sound, "system", [
    ("Volume", "Sound, speakers, loudness"), ("Output device", "Speakers, headphones, HDMI"),
    ("Microphone", "Input device, recording"), ("Mute", "Sound off")])


# ================================================================ Notifications
POSITIONS = [(2, "Top right"), (3, "Bottom right"), (0, "Top left"), (1, "Bottom left")]


def build_notifications():
    ch = "xfce4-notifyd"
    pos = c.xget_int(ch, "/notify-location", 2)
    pi = next((i for i, (v, _) in enumerate(POSITIONS) if v == pos), 0)
    times = [5, 10, 15, 30]
    t = c.xget_int(ch, "/expire-timeout", 10)
    ti = min(range(len(times)), key=lambda i: abs(times[i] - t))
    return c.page("Notifications", c.group(None, None, [
        c.switch_row("Do not disturb", "Notifications are silenced and kept in the list",
                     c.xget_bool(ch, "/do-not-disturb"), lambda on: c.xset(ch, "/do-not-disturb", on, "bool"),
                     "notifications-disabled-symbolic"),
        c.combo_row("Where notifications appear", None, [l for _, l in POSITIONS], pi,
                    lambda i: c.xset(ch, "/notify-location", POSITIONS[i][0], "uint"), "view-pin-symbolic"),
        c.combo_row("Show notifications for", None, [f"{s} seconds" for s in times], ti,
                    lambda i: c.xset(ch, "/expire-timeout", times[i], "int"), "alarm-symbolic"),
        c.switch_row("Keep a list of past notifications", "Missed notifications can be read later",
                     c.xget_bool(ch, "/notification-log", True), lambda on: c.xset(ch, "/notification-log", on, "bool"),
                     "view-list-symbolic"),
    ]))


register("notifications", "Notifications", build_notifications, "system", [
    ("Do not disturb", "Silence notifications, quiet"), ("Notification position", "Where alerts appear")])


# ================================================================ Power
def has_battery():
    return any(read(p + "/type") == "Battery" for p in glob.glob("/sys/class/power_supply/*"))


def battery_info():
    for p in glob.glob("/sys/class/power_supply/*"):
        if read(p + "/type") == "Battery":
            return read(p + "/capacity", "?"), read(p + "/status", "")
    return None


SCREEN_OFF = [(1, "1 minute"), (2, "2 minutes"), (5, "5 minutes"), (10, "10 minutes"), (15, "15 minutes"),
              (30, "30 minutes"), (60, "1 hour"), (0, "Never")]
SLEEP = [(15, "15 minutes"), (30, "30 minutes"), (60, "1 hour"), (120, "2 hours"), (180, "3 hours"), (14, "Never")]
# The power button is Pine's (/usr/libexec/pine-power-key, keyboard shortcut XF86PowerOff):
# "Ask what to do" opens the Pine power menu; xfce4-power-manager stays at "do nothing"
BUTTON = [("ask", "Ask what to do"), ("shutdown", "Shut down"), ("sleep", "Sleep"), ("nothing", "Do nothing")]
LID = [(1, "Sleep"), (3, "Lock the screen"), (0, "Turn off the screen")]
PM = "xfce4-power-manager"


def pm_combo(title, subtitle, options, prop, default, icon, extra=None):
    cur = c.xget_int(PM, "/xfce4-power-manager/" + prop, default)
    idx = next((i for i, (v, _) in enumerate(options) if v == cur), None)
    if idx is None:
        idx = next(i for i, (v, _) in enumerate(options) if v == default)

    def set_(i):
        c.xset(PM, "/xfce4-power-manager/" + prop, options[i][0], "uint")
        if extra:
            extra(options[i][0])
    return c.combo_row(title, subtitle, [l for _, l in options], idx, set_, icon)


def power_button_combo():
    """What the computer's power button does (saved for /usr/libexec/pine-power-key)."""
    cur = c.load_config().get("power_button", "ask")
    idx = next((i for i, (v, _) in enumerate(BUTTON) if v == cur), 0)

    def set_(i):
        c.save_config(power_button=BUTTON[i][0])
        c.xset(PM, "/xfce4-power-manager/power-button-action", 0, "uint")   # Pine handles it
    return c.combo_row("When I press the power button", None, [l for _, l in BUTTON], idx, set_,
                       "system-shutdown-symbolic")


def screen_extra(suffix):
    def f(v):
        c.xset(PM, "/xfce4-power-manager/dpms-enabled", True, "bool")
        c.xset(PM, "/xfce4-power-manager/blank-on-" + suffix, v, "int")
    return f


def build_power():
    groups = []
    bat = battery_info()
    if bat:
        cap, status = bat
        groups.append(c.hero("battery-good-symbolic", f"Battery {cap}%", status or ""))
    ac = "When plugged in" if bat else None
    groups.append(c.group("Screen and sleep" if not bat else ac, None, [
        pm_combo("Turn off my screen after", None, SCREEN_OFF, "dpms-on-ac-off", 10, "video-display-symbolic",
                 screen_extra("ac")),
        pm_combo("Put my computer to sleep after", None, SLEEP, "inactivity-on-ac", 14, "weather-clear-night-symbolic"),
        pm_combo("When I close the lid", None, LID, "lid-action-on-ac", 1, "computer-symbolic") if bat else None,
    ]))
    if bat:
        groups.append(c.group("On battery", None, [
            pm_combo("Turn off my screen after", None, SCREEN_OFF, "dpms-on-battery-off", 5, "video-display-symbolic",
                     screen_extra("battery")),
            pm_combo("Put my computer to sleep after", None, SLEEP, "inactivity-on-battery", 30,
                     "weather-clear-night-symbolic"),
            pm_combo("When I close the lid", None, LID, "lid-action-on-battery", 1, "computer-symbolic"),
        ]))
    groups.append(c.group("Buttons", None, [
        power_button_combo(),
    ]))
    return c.page("Power", *groups)


register("power", "Power & battery", build_power, "system", [
    ("Screen off", "Turn off display after, timeout"), ("Sleep", "Suspend after, standby"),
    ("Power button", "What the power button does"), ("Battery", "Laptop battery, lid")])


# ================================================================ Storage
def dir_size(path):
    total = 0
    for root, _dirs, files in os.walk(path):
        for f in files:
            try:
                total += os.lstat(os.path.join(root, f)).st_size
            except OSError:
                pass
    return total


def build_storage():
    du = shutil.disk_usage("/")
    bar = Gtk.LevelBar(min_value=0, max_value=1, value=du.used / du.total)
    bar.add_css_class("pine-storage")
    bar.set_size_request(-1, 10)
    box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10, hexpand=True)
    top = Gtk.Box()
    t = Gtk.Label(label="This PC", xalign=0, hexpand=True)
    t.add_css_class("title-3")
    top.append(t)
    u = Gtk.Label(label=f"{c.human_size(du.used)} used · {c.human_size(du.free)} free")
    u.add_css_class("dim-label")
    top.append(u)
    box.append(top)
    box.append(bar)
    hero = c.hero(widget=box)

    trash = os.path.join(GLib.get_user_data_dir(), "Trash")
    cache = os.path.join(GLib.get_user_cache_dir(), "thumbnails")
    trash_row = c.row("Trash", "Checking…", "user-trash-symbolic",
                      c.button("Empty trash", lambda: c.confirm(
                          "Empty the trash?", "Files in the trash will be deleted for good.", "Empty trash",
                          lambda: c.run_async(["gio", "trash", "--empty"],
                                              lambda *_: (c.toast("Trash emptied"), c.WINDOW.refresh())),
                          destructive=True)))
    thumb_row = c.row("Picture previews", "Checking…", "image-x-generic-symbolic",
                      c.button("Clear", lambda: (shutil.rmtree(cache, ignore_errors=True),
                                                 c.toast("Previews cleared"), c.WINDOW.refresh())))
    c.call_async(lambda: (dir_size(trash), dir_size(cache)),
                 lambda r: isinstance(r, tuple) and (trash_row.set_subtitle(c.human_size(r[0])),
                                                     thumb_row.set_subtitle(c.human_size(r[1]) + " · made again when needed")))

    def system_cleanup():
        before = shutil.disk_usage("/").free
        c.toast("Cleaning up…")
        c.root_sh("apt-get clean; apt-get -y autoremove --purge; "
                  "command -v flatpak >/dev/null && flatpak uninstall --unused -y --noninteractive; true",
                  lambda rc, o, e: c.toast(f"Done. {c.human_size(max(0, shutil.disk_usage('/').free - before))} freed")
                  if rc == 0 else c.toast("Clean up was cancelled"))

    groups = [hero, c.group("Clean up", None, [
        trash_row, thumb_row,
        c.row("System files", "Downloaded updates and apps nothing uses any more", "edit-clear-all-symbolic",
              c.button("Clean up", system_cleanup)),
    ])]

    drives = []
    try:
        with open("/proc/mounts") as f:
            for line in f:
                dev, mnt = line.split()[:2]
                mnt = mnt.replace("\\040", " ")
                if mnt.startswith(("/media/", "/run/media/")):
                    try:
                        d = shutil.disk_usage(mnt)
                        sub = f"{c.human_size(d.used)} used of {c.human_size(d.total)}"
                    except OSError:
                        sub = ""
                    drives.append(c.row(os.path.basename(mnt), sub, "drive-removable-media-symbolic", [
                        c.button("Open", lambda m=mnt: c.run_async(["xdg-open", m])),
                        c.button("Eject", lambda m=mnt: c.run_async(
                            ["gio", "mount", "-e", m],
                            lambda rc, o, e: (c.toast("Safe to remove" if rc == 0 else "The drive is still in use"),
                                              c.WINDOW.refresh())))]))
    except OSError:
        pass
    groups.append(c.group("USB drives and other disks", None,
                          drives or [c.row("No drives connected", None, "drive-removable-media-symbolic")]))
    return c.page("Storage", *groups)


register("storage", "Storage", build_storage, "system", [
    ("Storage", "Disk space, free space"), ("Clean up", "Free space, trash, temporary files"),
    ("Eject USB drive", "Remove safely, external disk")])


# ================================================================ About
def specs():
    cpu = ""
    for line in read("/proc/cpuinfo").splitlines():
        if line.startswith("model name"):
            cpu = line.split(":", 1)[1].strip()
            break
    cores = os.cpu_count() or 0
    mem = 0
    for line in read("/proc/meminfo").splitlines():
        if line.startswith("MemTotal"):
            mem = int(line.split()[1]) * 1024
    gpu = ""
    rc, out, _ = c.run(["lspci", "-mm"])
    for line in out.splitlines():
        if '"VGA' in line or '"3D' in line or '"Display' in line:
            parts = re.findall(r'"([^"]*)"', line)
            if len(parts) >= 3:
                gpu = f"{parts[1]} {parts[2]}"
                break
    os_name = "Pine OS"
    for line in read("/etc/os-release").splitlines():
        if line.startswith("PRETTY_NAME="):
            os_name = line.split("=", 1)[1].strip('"')
    deb = read("/etc/debian_version")
    _, xv, _ = c.run(["xfce4-session", "--version"])
    m = re.search(r"(\d+\.\d+)", xv)
    total = shutil.disk_usage("/").total
    return [
        ("Device", [("Name", socket.gethostname()), ("Model", device_model()),
                    ("Processor", f"{cpu} ({cores} cores)" if cpu else f"{cores} cores"),
                    ("Memory", f"{mem / 1024 ** 3:.1f} GB" if mem else "?"),
                    ("Graphics", gpu or "Unknown"), ("Storage", c.human_size(total))]),
        ("Pine OS", [("Edition", os_name), ("Based on", f"Debian {deb}" if deb else "Debian"),
                     ("Desktop", f"XFCE {m.group(1)}" if m else "XFCE"), ("Linux kernel", platform.release())]),
    ]


def build_about():
    data = specs()

    def copy():
        text = "\n".join(f"{k}: {v}" for _, rows in data for k, v in rows)
        c.WINDOW.get_clipboard().set(text)
        c.toast("Specifications copied")

    groups = [c.hero("computer-symbolic", socket.gethostname(), device_model(),
                     c.button("Copy", copy, icon="edit-copy-symbolic"))]
    for title, rows in data:
        g = c.group(f"{title} specifications")
        for k, v in rows:
            r = Adw.ActionRow(title=k, subtitle=GLib.markup_escape_text(v))
            r.add_css_class("property")
            r.set_subtitle_selectable(True)
            g.add(r)
        groups.append(g)
    return c.page("About", *groups)


register("about", "About", build_about, "system", [
    ("About", "Version, specifications, processor, memory"), ("Pine OS version", "Edition, Debian")])
