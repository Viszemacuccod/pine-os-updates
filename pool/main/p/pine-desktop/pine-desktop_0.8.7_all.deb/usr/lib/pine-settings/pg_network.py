"""Network & internet: Wi-Fi, Ethernet, airplane mode, IP settings (NetworkManager / nmcli).
Wi-Fi and airplane mode are shown only when the computer has them."""
import glob
import os
import re

from gi.repository import Adw, Gtk

import common as c

PAGES, SEARCH = {}, []


def register(pid, title, build, parent=None, search=()):
    PAGES[pid] = {"title": title, "build": build, "parent": parent}
    for t, s in search:
        SEARCH.append((t, s, pid))


def split(line):
    """Split one line of `nmcli -t` output (':' separated, '\\:' is a literal colon)."""
    return [p.replace("\\:", ":").replace("\\\\", "\\") for p in re.split(r"(?<!\\):", line)]


def has_wifi():
    return any(os.path.isdir(p + "/wireless") or os.path.isdir(p + "/phy80211") for p in glob.glob("/sys/class/net/*"))


def has_radios():
    """Any wireless radio (Wi-Fi, Bluetooth, mobile broadband): airplane mode makes sense."""
    return bool(glob.glob("/sys/class/rfkill/rfkill*"))


def nm(*args, timeout=15):
    return c.run(["nmcli"] + list(args), timeout=timeout)


def nm_rows(*args):
    rc, out, _ = nm("-t", *args)
    return [split(l) for l in out.splitlines() if l] if rc == 0 else []


def devices():
    return [{"dev": d, "type": t, "state": s, "con": con} for d, t, s, con in nm_rows("-f", "DEVICE,TYPE,STATE,CONNECTION", "device")
            if t in ("wifi", "ethernet")]


def signal_icon(sig):
    sig = int(sig or 0)
    level = "excellent" if sig >= 75 else "good" if sig >= 50 else "ok" if sig >= 25 else "weak"
    return f"network-wireless-signal-{level}-symbolic"


def details(dev):
    info = {}
    for parts in nm_rows("-f", "IP4.ADDRESS,IP4.GATEWAY,IP4.DNS,GENERAL.HWADDR", "device", "show", dev):
        if len(parts) >= 2:
            key = parts[0].split("[")[0]
            info.setdefault(key, []).append(":".join(parts[1:]))
    return info


def known_wifi():
    return {n: u for n, t, u in nm_rows("-f", "NAME,TYPE,UUID", "connection", "show") if t == "802-11-wireless"}


def after(msg_ok, msg_fail):
    def done(rc, out, err):
        c.toast(msg_ok if rc == 0 else (msg_fail + (f": {err.strip().splitlines()[-1]}" if err.strip() else "")))
        c.WINDOW.refresh()
    return done


def connect(ssid, secured, known):
    if ssid in known:
        c.toast(f"Connecting to {ssid}…")
        c.run_async(["nmcli", "connection", "up", "uuid", known[ssid]], after(f"Connected to {ssid}", "Could not connect"), timeout=60)
        return
    if not secured:
        c.toast(f"Connecting to {ssid}…")
        c.run_async(["nmcli", "device", "wifi", "connect", ssid], after(f"Connected to {ssid}", "Could not connect"), timeout=60)
        return
    password_dialog(ssid)


def password_dialog(ssid, hidden=False):
    d = Adw.AlertDialog(heading=f"Connect to {ssid}" if ssid else "Connect to a hidden network",
                        body="Enter the network password (security key).")
    lb = Gtk.ListBox()
    lb.add_css_class("boxed-list")
    name = Adw.EntryRow(title="Network name (SSID)")
    if hidden:
        lb.append(name)
    pw = Adw.PasswordEntryRow(title="Password")
    lb.append(pw)
    d.set_extra_child(lb)
    d.add_response("cancel", "Cancel")
    d.add_response("connect", "Connect")
    d.set_response_appearance("connect", Adw.ResponseAppearance.SUGGESTED)
    d.set_default_response("connect")
    pw.connect("entry-activated", lambda *_: (d.close(), go()))

    def go():
        s = name.get_text().strip() if hidden else ssid
        if not s:
            return
        args = ["nmcli", "device", "wifi", "connect", s]
        if pw.get_text():
            args += ["password", pw.get_text()]
        if hidden:
            args += ["hidden", "yes"]
        c.toast(f"Connecting to {s}…")
        c.run_async(args, after(f"Connected to {s}", "Could not connect. Is the password right?"), timeout=60)

    d.connect("response", lambda _d, r: r == "connect" and go())
    d.present(c.WINDOW)


def ip_dialog(con_name):
    _, out, _ = nm("-g", "ipv4.method,ipv4.addresses,ipv4.gateway,ipv4.dns", "connection", "show", con_name)
    vals = (out.strip().splitlines() + ["", "", "", ""])[:4]
    method = vals[0]
    box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=12, margin_top=6, margin_bottom=18,
                  margin_start=18, margin_end=18)
    lb = Gtk.ListBox()
    lb.add_css_class("boxed-list")
    mode = Adw.ComboRow(title="IP address", model=Gtk.StringList.new(["Automatic (DHCP)", "Manual"]))
    mode.set_selected(1 if method == "manual" else 0)
    addr = Adw.EntryRow(title="IP address (e.g. 192.168.1.20)")
    prefix = Adw.EntryRow(title="Subnet prefix length (e.g. 24)")
    gw = Adw.EntryRow(title="Gateway (e.g. 192.168.1.1)")
    dns = Adw.EntryRow(title="DNS servers (e.g. 1.1.1.1, 9.9.9.9)")
    if vals[1]:
        a = vals[1].split(",")[0].strip()
        addr.set_text(a.split("/")[0])
        prefix.set_text(a.split("/")[1] if "/" in a else "24")
    gw.set_text(vals[2])
    dns.set_text(vals[3])
    for w in (mode, addr, prefix, gw, dns):
        lb.append(w)
    box.append(lb)

    def sync(*_):
        manual = mode.get_selected() == 1
        for w in (addr, prefix, gw):
            w.set_visible(manual)
    mode.connect("notify::selected", sync)
    sync()
    d = c.dialog(f"IP settings · {con_name}", box, 480)

    def save():
        d.close()
        if mode.get_selected() == 1:
            mods = ["ipv4.method", "manual", "ipv4.addresses", f"{addr.get_text().strip()}/{prefix.get_text().strip() or '24'}",
                    "ipv4.gateway", gw.get_text().strip()]
        else:
            mods = ["ipv4.method", "auto", "ipv4.addresses", "", "ipv4.gateway", ""]
        d_txt = dns.get_text().replace(" ", "")
        mods += ["ipv4.dns", d_txt, "ipv4.ignore-auto-dns", "yes" if d_txt else "no"]
        c.run_async(["sh", "-c", 'nmcli connection modify "$0" "$@" && nmcli connection up "$0"', con_name] + mods,
                    after("IP settings saved", "The settings could not be saved"), timeout=60)

    btn = c.button("Save", save, "suggested-action")
    btn.set_halign(Gtk.Align.END)
    box.append(btn)
    d.present(c.WINDOW)


def build_network():
    rc, out, _ = nm("-t", "-f", "RUNNING", "general")
    if rc != 0 or "running" not in out:
        return c.page("Network", c.group(rows=[c.row("Networking is not running", "The network service was not found",
                                                     "network-offline-symbolic")]))
    devs = devices()
    wifi = next((d for d in devs if d["type"] == "wifi"), None)
    eth = next((d for d in devs if d["type"] == "ethernet"), None)
    active = next((d for d in devs if d["state"] == "connected"), None)
    radio = dict(zip(["WIFI", "WWAN"], (nm_rows("-f", "WIFI,WWAN", "radio") or [["enabled", "enabled"]])[0]))
    wifi_on = radio.get("WIFI") == "enabled"
    airplane = not wifi_on and radio.get("WWAN") != "enabled"

    if active:
        icon = "network-wireless-signal-excellent-symbolic" if active["type"] == "wifi" else "network-wired-symbolic"
        hero = c.hero(icon, active["con"] if active["type"] == "wifi" else "Ethernet", "Connected · Internet access",
                      c.button("IP settings", lambda: ip_dialog(active["con"])))
    else:
        hero = c.hero("network-offline-symbolic", "Not connected",
                      "Turn on Wi-Fi to connect" if wifi and not wifi_on else "Choose a network below")
    groups = [hero]

    def set_wifi(on):
        c.run_async(["nmcli", "radio", "wifi", "on" if on else "off"], lambda *_: c.WINDOW.refresh())

    def set_airplane(on):
        c.run_async(["sh", "-c", f"nmcli radio all {'off' if on else 'on'}; rfkill {'block' if on else 'unblock'} bluetooth"],
                    lambda *_: c.WINDOW.refresh())

    rows = []
    if wifi:
        rows.append(c.switch_row("Wi-Fi", "Connect to wireless networks", wifi_on, set_wifi, "network-wireless-symbolic"))
    if has_radios():
        rows.append(c.switch_row("Airplane mode", "Stop all wireless communication", airplane, set_airplane, "airplane-mode-symbolic"))
    if rows:
        groups.append(c.group(rows=rows))

    if wifi and wifi_on:
        known = known_wifi()
        scan = c.button(None, lambda: c.WINDOW.refresh(), "flat", "view-refresh-symbolic")
        scan.set_tooltip_text("Look again")
        hidden = c.button("Hidden network", lambda: password_dialog("", hidden=True), "flat")
        box = Gtk.Box(spacing=6)
        box.append(hidden)
        box.append(scan)
        g = c.group("Available networks", None, suffix=box)
        waiting = c.row("Looking for networks…", None, None, c.spinner())
        g.add(waiting)

        def got(rc, out, err):
            g.remove(waiting)
            seen = set()
            nets = []
            for line in out.splitlines():
                p = split(line)
                if len(p) < 4 or not p[1] or p[1] in seen:
                    continue
                seen.add(p[1])
                nets.append(p)
            nets.sort(key=lambda p: (p[0] != "*", -int(p[2] or 0)))
            if not nets:
                g.add(c.row("No networks found", None, "network-wireless-offline-symbolic"))
            for inuse, ssid, sig, sec in nets[:25]:
                secured = sec not in ("", "--")
                sub = ("Connected · " if inuse == "*" else "") + ("Secured" if secured else "Open") + \
                      (" · Saved" if ssid in known and inuse != "*" else "")
                if inuse == "*":
                    btn = c.button("Disconnect", lambda: c.run_async(
                        ["nmcli", "device", "disconnect", wifi["dev"]], after("Disconnected", "Could not disconnect")))
                else:
                    btn = c.button("Connect", lambda s=ssid, sc=secured: connect(s, sc, known), "suggested-action" if ssid in known else None)
                g.add(c.row(ssid, sub, signal_icon(sig), btn))

        c.run_async(["nmcli", "-t", "-f", "IN-USE,SSID,SIGNAL,SECURITY", "device", "wifi", "list", "--rescan", "auto"], got, timeout=30)
        groups.append(g)

        if known:
            ex = Adw.ExpanderRow(title="Saved Wi-Fi networks", subtitle=f"{len(known)} networks")
            ex.add_prefix(Gtk.Image.new_from_icon_name("network-wireless-symbolic"))
            for name, uuid in sorted(known.items()):
                ex.add_row(c.row(name, None, None, c.button("Forget", lambda n=name, u=uuid: c.confirm(
                    f"Forget {n}?", "You will need the password to connect again.", "Forget",
                    lambda: c.run_async(["nmcli", "connection", "delete", "uuid", u], after(f"{n} forgotten", "Could not forget it")),
                    True))))
            groups.append(c.group(rows=[ex]))

    if eth:
        connected = eth["state"] == "connected"
        info = details(eth["dev"]) if connected else {}
        ip = info.get("IP4.ADDRESS", [""])[0]
        groups.append(c.group("Ethernet", None, [c.row(
            "Ethernet", ("Connected" + (f" · {ip.split('/')[0]}" if ip else "")) if connected else "Cable not connected",
            "network-wired-symbolic", c.button("IP settings", lambda: ip_dialog(eth["con"])) if connected else None)]))

    if active:
        info = details(active["dev"])
        g = c.group("Connection details")
        for label, key in (("IP address", "IP4.ADDRESS"), ("Gateway", "IP4.GATEWAY"), ("DNS servers", "IP4.DNS"),
                           ("Physical address (MAC)", "GENERAL.HWADDR")):
            v = ", ".join(x.split("/")[0] for x in info.get(key, []) if x)
            if v:
                r = Adw.ActionRow(title=label, subtitle=v)
                r.add_css_class("property")
                r.set_subtitle_selectable(True)
                g.add(r)
        groups.append(g)
    return c.page("Network & internet", *groups)


register("network", "Network & internet", build_network, search=
    ([("Wi-Fi", "Wireless network, internet, WLAN"), ("Hidden network", "Connect to hidden Wi-Fi"),
      ("Forget network", "Saved Wi-Fi networks")] if has_wifi() else []) +
    ([("Airplane mode", "Flight mode, turn off wireless")] if has_radios() else []) +
    [("Ethernet", "Cable, wired network, LAN"), ("IP settings", "Static IP, DNS, gateway, DHCP")])
