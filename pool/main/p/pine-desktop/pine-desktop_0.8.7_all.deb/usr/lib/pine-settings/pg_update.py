"""Pine Update: look for and install updates - by hand, when the user wants.

  Check for updates  = refresh the package lists (like "sudo apt update") and collect:
                       system updates (Debian), apps (Flatpak), drivers for this hardware,
                       firmware (fwupd / LVFS)
  Install            = download and install (like "sudo apt upgrade"), with progress
While installing, the computer can't be shut down, restarted or put to sleep (a logind
inhibitor), and closing the window doesn't stop it. Only security updates may install by
themselves (the switch at the bottom); nothing else happens without the user.

A new Pine OS version (the pine-desktop package from the Pine repository) is shown apart
from the other updates, as a system update with its news (the Pine-News fields of the
package, written by tools/build-pine-debs.sh from NEWS). "Install" for the other updates
leaves it alone: it is only installed with its own "Update now" button.
"""
import datetime
import json
import os
import re
import subprocess

from gi.repository import Adw, Gio, GLib, Gtk

import common as c

PAGES, SEARCH = {}, []
AUTO_FILE = "/etc/apt/apt.conf.d/20auto-upgrades"
WHY = "Updates are being installed. Please wait until they finish."

PINE_PKG = "pine-desktop"
STATE = {"phase": "idle", "checked": None, "error": None,
         "system": [], "apps": [], "drivers": [], "firmware": [], "pine": None,
         "task": "", "fraction": None, "ui": None}


# ================================================================ looking for updates
def parse_debs(out):
    pkgs = []
    for line in out.splitlines():
        m = re.match(r"^(\S+?)/(\S+) (\S+) \S+ \[upgradable from: (\S+)\]", line)
        if m:
            pkgs.append({"name": m.group(1), "new": m.group(3), "old": m.group(4),
                         "security": "security" in m.group(2)})
    return pkgs


def installed(pkg):
    rc, out, _ = c.run(["dpkg-query", "-W", "-f=${Status}", pkg])
    return rc == 0 and "install ok installed" in out


def available(pkg):
    _, out, _ = c.run(["apt-cache", "policy", pkg])
    return re.search(r"Candidate: (?!\(none\))\S+", out) is not None


def pine_version():
    """The Pine OS version this computer runs (os-release)."""
    try:
        with open("/etc/os-release") as f:
            m = re.search(r'^VERSION_ID="?([^"\n]+)', f.read(), re.M)
            return m.group(1) if m else ""
    except OSError:
        return ""


def pine_news(version):
    """What's new in that version, in the user's language if there is a text for it:
    the "- " lines of the package's Pine-News(-<lang>) field."""
    _, out, _ = c.run(["apt-cache", "show", f"{PINE_PKG}={version}"])
    fields, cur = {}, None
    for line in out.split("\n\n")[0].splitlines():
        if line[:1] in (" ", "\t") and cur:
            fields[cur].append(line.strip())
        elif ":" in line:
            cur, _, val = line.partition(":")
            fields[cur] = [val.strip()] if val.strip() else []
        else:
            cur = None
    for lang in [l.split(".")[0] for l in GLib.get_language_names()] + [""]:
        key = f"Pine-News-{lang}" if lang else "Pine-News"
        if key in fields:
            return [l[1:].strip() if l.startswith("-") else l for l in fields[key] if l and l != "."]
    return []


def find_pine(system):
    """Takes pine-desktop out of the system updates: {"old", "new", "news"} or None."""
    for p in system:
        if p["name"] == PINE_PKG:
            system.remove(p)
            return {"old": pine_version() or p["old"], "new": p["new"], "news": pine_news(p["new"])}
    return None


def find_drivers():
    """Driver packages this computer could use and doesn't have yet."""
    found = []
    _, lspci, _ = c.run(["lspci", "-nn"])
    # NVIDIA graphics: Debian's NVIDIA driver (built for the running kernel)
    if re.search(r"(VGA|3D|Display)[^\n]*\[10de:", lspci) and not installed("nvidia-driver"):
        if available("nvidia-driver"):
            found.append({"title": "NVIDIA graphics driver", "pkgs": ["nvidia-driver", "linux-headers-amd64"],
                          "sub": "Faster graphics and games on NVIDIA graphics cards"})
    # Broadcom Wi-Fi chips that need the "wl" driver
    if re.search(r"Network controller[^\n]*\[14e4:(4311|4312|4313|4315|4328|4329|432a|432b|432c|432d|4353|4357|4358|4359|4365|43a0|43b1)\]", lspci) \
            and not installed("broadcom-sta-dkms") and available("broadcom-sta-dkms"):
        found.append({"title": "Broadcom Wi-Fi driver", "pkgs": ["broadcom-sta-dkms", "linux-headers-amd64"],
                      "sub": "Needed for the Wi-Fi of this computer"})
    # Anything else Debian knows for this hardware (firmware, drivers)
    rc, out, _ = c.run(["isenkram-lookup"], timeout=60)
    if rc == 0:
        extra = [p for p in out.split() if p.startswith(("firmware-", "nvidia-", "intel-", "amd64-", "bluez-firmware"))
                 and not installed(p) and available(p)]
        for p in extra:
            found.append({"title": p, "pkgs": [p], "sub": "Firmware or driver for a part of this computer"})
    return found


def find_firmware():
    """Firmware updates from the device makers (fwupd, LVFS)."""
    if not c.have("fwupdmgr"):
        return []
    c.run(["fwupdmgr", "refresh", "--no-metadata-check"], timeout=120)
    rc, out, _ = c.run(["fwupdmgr", "get-updates", "--json"], timeout=120)
    try:
        data = json.loads(out) if out.strip().startswith("{") else {}
    except ValueError:
        data = {}
    devices = []
    for d in data.get("Devices", []):
        rel = (d.get("Releases") or [{}])[0]
        if rel:
            devices.append({"name": d.get("Name", "Device"), "id": d.get("DeviceId", ""),
                            "old": d.get("Version", "?"), "new": rel.get("Version", "?"),
                            "summary": rel.get("Summary", "")})
    return devices


FAILED = re.compile(r"^\s*(Fatal error|Failed to|Error:|E:)", re.M)


def pk_ok(rc, out, err=""):
    """pkcon can exit with 0 even when it failed (e.g. "Failed to contact PackageKit"),
    so its messages are checked too."""
    return rc in (0, 5) and not FAILED.search(out + "\n" + err)


def check():
    STATE.update(phase="checking", error=None, task="Refreshing the package lists…")
    c.WINDOW.refresh()

    def work():
        rc, rout, rerr = c.run(["pkcon", "refresh", "--noninteractive"], timeout=900)
        ok = pk_ok(rc, rout, rerr)
        _, out, _ = c.run(["apt", "list", "--upgradable"], timeout=120)
        _, fp, _ = c.run(["flatpak", "remote-ls", "--updates", "--columns=name,application"], timeout=180)
        apps = [{"name": l.split("\t")[0], "id": (l.split("\t") + [""])[1]} for l in fp.splitlines() if l.strip()]
        system = parse_debs(out)
        pine = find_pine(system)
        return ok, system, pine, apps, find_drivers(), find_firmware()

    def done(res):
        if isinstance(res, Exception):
            STATE.update(phase="idle", error=str(res))
        else:
            ok, system, pine, apps, drivers, firmware = res
            STATE.update(phase="idle", system=system, pine=pine, apps=apps, drivers=drivers, firmware=firmware,
                         checked=datetime.datetime.now() if ok else STATE["checked"],
                         error=None if ok else "Could not check for updates. Are you connected to the internet?")
        if c.WINDOW:
            c.WINDOW.refresh()
    c.call_async(work, done)


# ================================================================ installing
class Inhibit:
    """Block shutdown, restart and sleep while updates install (released when we exit,
    even if Pine Settings stops unexpectedly)."""
    def __init__(self):
        self.proc = None

    def __enter__(self):
        try:
            self.proc = subprocess.Popen(
                ["systemd-inhibit", "--what=shutdown:sleep:idle:handle-power-key:handle-suspend-key:"
                 "handle-hibernate-key:handle-lid-switch", "--who=Pine Update", f"--why={WHY}", "--mode=block",
                 "sh", "-c", f"while kill -0 {os.getpid()} 2>/dev/null; do sleep 5; done"])
        except OSError:
            self.proc = None
        return self

    def __exit__(self, *exc):
        if self.proc:
            self.proc.terminate()


def set_progress(task=None, fraction=None):
    """Update the progress area from the worker thread."""
    def apply():
        if task is not None:
            STATE["task"] = task
        STATE["fraction"] = fraction
        ui = STATE.get("ui")
        if ui:
            ui["label"].set_label(STATE["task"])
            if fraction is None:
                ui["bar"].pulse()
            else:
                ui["bar"].set_fraction(max(0.0, min(1.0, fraction)))
        return False
    GLib.idle_add(apply)


def run_step(cmd, task, share=(0.0, 1.0)):
    """Run one install command, turning its output into progress. Returns the exit code."""
    set_progress(task, share[0])
    try:
        # (no --noninteractive for pkcon: it would also stop the password dialog, and installing
        # needs the administrator password; -y answers pkcon's own questions)
        p = subprocess.Popen(cmd, stdin=subprocess.DEVNULL, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                             text=True, env=dict(os.environ, LC_ALL="C.UTF-8"))
    except OSError:
        return 127
    lo, hi = share
    output = []
    for line in p.stdout:
        output.append(line)
        m = re.search(r"Percentage:\s*(\d+)", line) or re.search(r"(\d+)%", line)
        if m:
            set_progress(None, lo + (hi - lo) * int(m.group(1)) / 100)
        s = re.search(r"Status:\s*(.+)", line)
        if s:
            set_progress(f"{task} ({s.group(1).strip().lower()})", STATE["fraction"])
    rc = p.wait()
    text = "".join(output)
    if "authentication" in text.lower() and FAILED.search(text):
        STATE["why"] = c._("The administrator password was not given.")
    return rc if pk_ok(rc, text) else 1


def install(what):
    """what: "all" (system + apps), "pine" (the new Pine OS version), ("driver", item) or
    ("firmware", device)."""
    app = Gio.Application.get_default()
    app.hold()                                   # keep going if the window is closed
    STATE.update(phase="installing", error=None, task="Getting ready…", fraction=0.0, why=None)
    c.WINDOW.refresh()

    def work():
        ok = True
        with Inhibit():
            if what == "all":
                steps = []
                if STATE["system"]:
                    cmd = ["pkcon", "update", "-y", "--plain"]
                    if STATE["pine"]:
                        # by name, so the new Pine OS version waits for its own button
                        cmd += [p["name"] for p in STATE["system"]]
                    steps.append((cmd, "Downloading and installing system updates"))
                if STATE["apps"]:
                    steps.append((["flatpak", "update", "-y", "--noninteractive"], "Updating apps"))
                for i, (cmd, task) in enumerate(steps):
                    share = (i / len(steps), (i + 1) / len(steps))
                    ok = run_step(cmd, task, share) in (0, 5) and ok   # 5 = nothing to do
            elif what == "pine":
                ok = run_step(["pkcon", "update", "-y", "--plain", PINE_PKG],
                              "Updating Pine OS") in (0, 5)
            elif what[0] == "driver":
                ok = run_step(["pkcon", "install", "-y", "--plain"] + what[1]["pkgs"],
                              f"Installing {what[1]['title']}") == 0
            elif what[0] == "firmware":
                ok = run_step(["fwupdmgr", "update", what[1]["id"], "-y", "--no-reboot-check"],
                              f"Updating firmware: {what[1]['name']}") == 0
        return ok

    def done(ok):
        ok = ok is True
        app.release()
        STATE.update(phase="idle", ui=None, fraction=None,
                     error=None if ok else STATE.get("why") or "Some updates were not installed. Try again later.")
        if what == "pine":
            msg = c._("Pine OS is updated") if ok else c._("Pine OS was not updated")
        else:
            msg = "Updates installed" if ok else "Some updates were not installed"
        if c.WINDOW and c.WINDOW.get_visible():
            c.toast(msg)
            check()                                 # show what is left (normally nothing)
        else:
            c.run_async(["notify-send", "-a", "Pine Update", "-i", "software-update-available", msg])
    c.call_async(work, done)


# ================================================================ automatic security updates
def auto_updates_on():
    try:
        with open(AUTO_FILE) as f:
            return re.search(r'Unattended-Upgrade\s+"1"', f.read()) is not None
    except OSError:
        return False


def set_auto(on):
    v = "1" if on else "0"
    c.root_write(AUTO_FILE, f'APT::Periodic::Update-Package-Lists "{v}";\nAPT::Periodic::Unattended-Upgrade "{v}";\n',
                 lambda ok, e: c.toast(("Security updates install by themselves" if on else "Security updates are manual too")
                                       if ok else "Not changed"))


def history():
    entries = []
    try:
        with open("/var/log/apt/history.log") as f:
            text = f.read()
    except OSError:
        return entries
    for block in text.strip().split("\n\n"):
        date = re.search(r"Start-Date: (\S+)\s+(\S+)", block)
        if not date:
            continue
        counts = []
        for key, word in (("Upgrade", "updated"), ("Install", "installed"), ("Remove", "removed")):
            m = re.search(rf"^{key}: (.*)$", block, re.M)
            if m:
                n = len(re.findall(r"\), ", m.group(1))) + 1
                counts.append(f"{n} {word}")
        if counts:
            entries.append((f"{date.group(1)} {date.group(2)[:5]}", ", ".join(counts)))
    return entries[::-1][:20]


# ================================================================ page
def progress_hero():
    box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10, hexpand=True)
    t = Gtk.Label(label="Installing updates…", xalign=0)
    t.add_css_class("title-2")
    box.append(t)
    label = Gtk.Label(label=STATE["task"], xalign=0, wrap=True)
    label.add_css_class("dim-label")
    box.append(label)
    bar = Gtk.ProgressBar()
    if STATE["fraction"] is not None:
        bar.set_fraction(STATE["fraction"])
    box.append(bar)
    warn = Gtk.Label(label="Please don't turn off your computer. Shutting down is paused until this finishes. "
                           "You can close this window: installing continues.", xalign=0, wrap=True)
    warn.add_css_class("caption")
    warn.add_css_class("dim-label")
    box.append(warn)
    STATE["ui"] = {"label": label, "bar": bar}

    def pulse():
        if STATE.get("ui") is None or STATE["ui"]["bar"] is not bar:
            return False
        if STATE["fraction"] is None:
            bar.pulse()
        return True
    GLib.timeout_add(250, pulse)
    return c.hero(widget=box)


# ================================================================ restore points (Timeshift)
TIMESHIFT_CFG = "/etc/timeshift/timeshift.json"


def restore_group():
    """Restore points: Timeshift copies of the system. Once it is set up, apt makes one before
    updates (at most once a day, /usr/libexec/pine-restore-point)."""
    try:
        with open(TIMESHIFT_CFG) as f:
            ready = bool(json.load(f).get("backup_device_uuid"))
    except (OSError, ValueError, AttributeError):
        ready = False
    if ready:
        sub = "A restore point is made before updates (at most once a day). Something broke? Go back to one."
        btn = c.button("Open", lambda: c.run_async(["timeshift-launcher"]), icon="document-revert-symbolic")
    else:
        sub = "Not set up yet. Choose a disk once, then Pine OS makes a restore point before updates."
        btn = c.button("Set up", lambda: c.run_async(["timeshift-launcher"]), "suggested-action")
    btn.set_valign(Gtk.Align.CENTER)
    return c.group("Restore points", None, [c.row("Restore points", sub, "document-revert-symbolic", btn)])


def confirm_pine(p):
    c.confirm(c._("Update to Pine OS {new}?").format(new=p["new"]),
              "Your files and apps stay as they are. Restart afterwards to see every change.",
              "Update now", lambda: install("pine"))


def pine_group(p):
    """The new Pine OS version: its own card, with what's new."""
    g = c.group("System update")
    sub = c._("Pine OS {old} is installed. Your files and apps stay as they are.").format(old=p["old"])
    btn = c.button("Update now", lambda: confirm_pine(p), "suggested-action", "software-update-available-symbolic")
    g.add(c.row(f"Pine OS {p['new']}", sub, "pine-logo", btn))
    if p["news"]:
        ex = Adw.ExpanderRow(title=GLib.markup_escape_text(c._("What's new")),
                             subtitle=GLib.markup_escape_text(c._("{n} changes").format(n=len(p["news"]))))
        ex.add_prefix(Gtk.Image.new_from_icon_name("starred-symbolic"))
        ex.set_expanded(True)
        for line in p["news"]:
            r = Adw.ActionRow(title=GLib.markup_escape_text(line))
            r.set_title_lines(0)
            r.add_prefix(Gtk.Image.new_from_icon_name("object-select-symbolic"))
            ex.add_row(r)
        g.add(ex)
    return g


def build_update():
    s = STATE
    busy = s["phase"] in ("checking", "installing")
    n_updates = len(s["system"]) + len(s["apps"])
    checked = f"Last checked: {s['checked'].strftime('%H:%M')}" if s["checked"] else "Press Check for updates to see what's new"

    if s["phase"] == "installing":
        hero = progress_hero()
    elif s["phase"] == "checking":
        hero = c.hero(widget=c.spinner(), title="Checking for updates…", subtitle=s["task"])
    elif s["pine"] and not n_updates:
        hero = c.hero("software-update-available-symbolic", c._("Pine OS {new} is available").format(new=s["pine"]["new"]),
                      checked, c.button("Update now", lambda: confirm_pine(s["pine"]), "suggested-action",
                                        "software-update-available-symbolic"))
    elif n_updates:
        sec = sum(1 for p in s["system"] if p["security"])
        hero = c.hero("software-update-available-symbolic", f"{n_updates} update{'s' if n_updates != 1 else ''} available",
                      (f"{sec} security · " if sec else "") + checked,
                      c.button("Install", lambda: install("all"), "suggested-action", "folder-download-symbolic"))
    else:
        title = "You're up to date" if s["checked"] and not s["error"] else "Pine Update"
        hero = c.hero("security-high-symbolic", title, s["error"] or checked,
                      c.button("Check for updates", check, "suggested-action", "view-refresh-symbolic"))
    groups = [hero]
    if s["pine"] and not busy:
        groups.append(pine_group(s["pine"]))

    if n_updates and not busy:
        again =c.button(None, check, "flat", "view-refresh-symbolic")
        again.set_tooltip_text("Check again")
        g = c.group("Updates", None, suffix=again)
        if s["system"]:
            ex = Adw.ExpanderRow(title="System", subtitle=f"{len(s['system'])} packages"
                                 + (f" · {sum(1 for p in s['system'] if p['security'])} security" if any(p["security"] for p in s["system"]) else ""))
            ex.add_prefix(Gtk.Image.new_from_icon_name("computer-symbolic"))
            for p in s["system"][:300]:
                ex.add_row(Adw.ActionRow(title=p["name"], subtitle=("Security · " if p["security"] else "") + f"{p['old']} → {p['new']}"))
            g.add(ex)
        if s["apps"]:
            ex = Adw.ExpanderRow(title="Apps", subtitle=f"{len(s['apps'])} apps from the App Store")
            ex.add_prefix(Gtk.Image.new_from_icon_name("view-app-grid-symbolic"))
            for a in s["apps"]:
                ex.add_row(Adw.ActionRow(title=a["name"], subtitle=a["id"]))
            g.add(ex)
        groups.append(g)

    if s["checked"] and not busy:
        dg = c.group("Drivers", "Drivers and firmware packages for the parts of this computer")
        if not s["drivers"]:
            dg.add(c.row("No extra drivers needed", None, "emblem-ok-symbolic"))
        for d in s["drivers"]:
            dg.add(c.row(d["title"], d["sub"], "application-x-firmware-symbolic",
                         c.button("Install", lambda d=d: install(("driver", d)))))
        groups.append(dg)

        fg = c.group("Firmware", "Updates from the maker of this computer and its devices (via LVFS)")
        if not c.have("fwupdmgr"):
            fg.add(c.row("Firmware updates are not available", None, "dialog-information-symbolic"))
        elif not s["firmware"]:
            fg.add(c.row("Firmware is up to date", None, "emblem-ok-symbolic"))
        for f in s["firmware"]:
            fg.add(c.row(f["name"], f"{f['old']} → {f['new']}" + (f" · {f['summary']}" if f["summary"] else ""),
                         "drive-harddisk-solidstate-symbolic",
                         c.button("Install", lambda f=f: c.confirm(
                             f"Update the firmware of {f['name']}?",
                             "Keep the computer plugged in. It may restart to finish, and must not be turned off meanwhile.",
                             "Update", lambda: install(("firmware", f))))))
        groups.append(fg)

    if os.path.exists("/run/reboot-required") and not busy:
        groups.append(c.group(rows=[c.row("Restart to finish updating", "Some updates take effect after a restart",
                                          "system-reboot-symbolic",
                                          c.button("Restart now", lambda: c.run_async(["xfce4-session-logout", "--reboot"]),
                                                   "suggested-action"))]))

    hist = history()
    hrow = Adw.ExpanderRow(title="Update history", subtitle="What was installed and when")
    hrow.add_prefix(Gtk.Image.new_from_icon_name("document-open-recent-symbolic"))
    for when, what in hist:
        hrow.add_row(Adw.ActionRow(title=what, subtitle=when))
    if not hist:
        hrow.add_row(Adw.ActionRow(title="Nothing yet"))
    groups.append(restore_group())
    groups.append(c.group("More options", None, [
        c.switch_row("Install security updates automatically",
                     "Only security fixes, quietly in the background. Everything else waits for you.",
                     auto_updates_on(), set_auto, "security-high-symbolic"),
        hrow,
    ]))
    return c.page("Pine Update", *groups)


PAGES["update"] = {"title": "Pine Update", "build": build_update, "parent": None}
SEARCH += [(t, s, "update") for t, s in (
    ("Check for updates", "Update, upgrade, apt, security"), ("Drivers", "NVIDIA, Wi-Fi, graphics driver, firmware"),
    ("Firmware", "BIOS, UEFI, device firmware, LVFS"), ("Automatic security updates", "Unattended upgrades"),
    ("Update history", "Installed updates"))]
