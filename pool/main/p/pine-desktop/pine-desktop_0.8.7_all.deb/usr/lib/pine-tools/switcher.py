#!/usr/bin/python3
"""Pine Alt+Tab: switch between windows, with a picture of each window (like Windows).

Runs in the background from sign-in (pine-switcher --daemon), so Alt+Tab answers at once:
the keyboard shortcut only sends it "next" or "prev" over D-Bus (/usr/bin/pine-switcher).

  Alt+Tab             the previous window; keep Alt held and press Tab again for the next ones
  Alt+Shift+Tab       backwards
  arrows, mouse       choose; releasing Alt, Enter or a click switches; Esc cancels
A quick Alt+Tab switches straight away, without showing the switcher.
Minimized windows show their app icon (X has no picture of them). In Game mode every window
shows only its app icon: no pictures are taken, the memory and the CPU stay with the game.
"""
import os
import subprocess
import sys

import gi
gi.require_version("Gtk", "3.0")
gi.require_version("Gdk", "3.0")
gi.require_version("GdkX11", "3.0")
gi.require_version("GdkPixbuf", "2.0")
from gi.repository import GLib  # noqa: E402
GLib.set_prgname("pine-switcher")
from gi.repository import Gdk, GdkPixbuf, GdkX11, Gio, Gtk, Pango  # noqa: E402

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(1, "/usr/lib/pine-settings")
import x11  # noqa: E402
import game  # noqa: E402  (Game mode: icons only)

import gettext  # noqa: E402
_ = gettext.translation("pine", fallback=True).gettext

THUMB_W, THUMB_H = 216, 136
ICON_W, ICON_H = 132, 84  # Game mode: app icons only, smaller cards
SHOW_DELAY = 130          # ms: a quicker Alt+Tab switches without showing anything

CSS = b"""
#pine-switcher { background-color: alpha(@theme_bg_color, 0.97); border: 1px solid alpha(@theme_fg_color, 0.10);
  border-radius: 5px; }
#pine-switcher .card { padding: 8px; border-radius: 5px; border: 2px solid transparent; }
#pine-switcher .card:hover { background-color: alpha(@theme_fg_color, 0.05); }
#pine-switcher .card.selected { background-color: alpha(@theme_selected_bg_color, 0.16);
  border-color: @theme_selected_bg_color; }
#pine-switcher .thumb { background-color: alpha(@theme_fg_color, 0.05); border-radius: 5px; }
#pine-switcher .name { font-weight: 600; }
#pine-switcher .empty { opacity: 0.7; padding: 18px 28px; }
"""


def thumbnail(xid, minimized):
    """A picture of the window scaled into THUMB_W x THUMB_H, or None (minimized, gone)."""
    if minimized:
        return None
    try:
        gw = GdkX11.X11Window.foreign_new_for_display(Gdk.Display.get_default(), xid)
    except (TypeError, GLib.Error):
        return None
    if gw is None:
        return None
    w, h = gw.get_width(), gw.get_height()
    if w < 2 or h < 2:
        return None
    pb = Gdk.pixbuf_get_from_window(gw, 0, 0, w, h)
    if pb is None:
        return None
    scale = min(THUMB_W / w, THUMB_H / h)
    return pb.scale_simple(max(1, round(w * scale)), max(1, round(h * scale)), GdkPixbuf.InterpType.BILINEAR)


def desktop_info(desktop_id):
    try:
        return Gio.DesktopAppInfo.new(desktop_id)
    except TypeError:                               # no such .desktop file
        return None


def app_icon(xid, size):
    """The app's icon from its .desktop file (matching WM_CLASS), else the window's own."""
    inst, cls = x11.wm_class(xid)
    theme = Gtk.IconTheme.get_default()
    for name in (cls, inst, cls.lower(), inst.lower()):
        if not name:
            continue
        info = desktop_info(name + ".desktop")
        if info is None:
            for hit in Gio.DesktopAppInfo.search(name)[:1]:
                info = desktop_info(hit[0]) if hit else None
        gicon = info.get_icon() if info else None
        if gicon:
            ii = theme.lookup_by_gicon(gicon, size, Gtk.IconLookupFlags.FORCE_SIZE)
            if ii:
                try:
                    return ii.load_icon()
                except GLib.Error:
                    pass
    pb = x11.icon(xid, size)
    if pb:
        return pb
    try:
        return theme.load_icon("application-x-executable", size, Gtk.IconLookupFlags.FORCE_SIZE)
    except GLib.Error:
        return None


class Card(Gtk.EventBox):
    def __init__(self, sw, index, xid, pictures=True):
        w, h = (THUMB_W, THUMB_H) if pictures else (ICON_W, ICON_H)
        super().__init__()
        self.xid = xid
        self.get_style_context().add_class("card")
        box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=8)
        head = Gtk.Box(spacing=8)
        ic = app_icon(xid, 16)
        if ic:
            head.pack_start(Gtk.Image.new_from_pixbuf(ic), False, False, 0)
        name = Gtk.Label(label=x11.title(xid) or x11.wm_class(xid)[1], xalign=0)
        name.set_ellipsize(Pango.EllipsizeMode.END)
        name.set_max_width_chars(1)
        name.set_hexpand(True)
        name.get_style_context().add_class("name")
        head.pack_start(name, True, True, 0)
        box.pack_start(head, False, False, 0)
        area = Gtk.Box()
        area.get_style_context().add_class("thumb")
        area.set_size_request(w, h)
        pic = thumbnail(xid, x11.minimized(xid)) if pictures else None
        img = Gtk.Image.new_from_pixbuf(pic if pic else app_icon(xid, 64 if pictures else 48))
        img.set_hexpand(True)
        img.set_vexpand(True)
        area.pack_start(img, True, True, 0)
        box.pack_start(area, False, False, 0)
        box.set_size_request(w, -1)
        self.add(box)
        self.add_events(Gdk.EventMask.POINTER_MOTION_MASK)
        # only a real mouse move selects (not the card that happens to be under the pointer)
        self.connect("motion-notify-event", lambda _w, ev: sw.mouse_moved(ev) and sw.select(index))
        self.connect("button-release-event", lambda *a: (sw.select(index), sw.finish(True)))


class Switcher(Gtk.Application):
    def __init__(self):
        super().__init__(application_id="org.pineos.Switcher", flags=Gio.ApplicationFlags.HANDLES_COMMAND_LINE)
        self.win = None
        self.windows, self.cards, self.sel = [], [], 0
        self.active = False
        self.show_id = 0
        self.start_pointer = None
        for name, step in (("next", 1), ("prev", -1)):
            a = Gio.SimpleAction.new(name, None)
            a.connect("activate", lambda _a, _p, step=step: self.step(step))
            self.add_action(a)

    def do_startup(self):
        Gtk.Application.do_startup(self)
        prov = Gtk.CssProvider()
        prov.load_from_data(CSS)
        Gtk.StyleContext.add_provider_for_screen(Gdk.Screen.get_default(), prov,
                                                 Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION)
        self.hold()                                 # stay in the background between uses

    def do_command_line(self, cmd):
        args = cmd.get_arguments()[1:]
        if "next" in args:
            self.step(1)
        elif "prev" in args:
            self.step(-1)
        return 0

    # ---- the switcher
    def step(self, delta):
        if self.active:
            self.select((self.sel + delta) % max(1, len(self.windows)))
            return
        self.windows = x11.app_windows()
        if not self.windows:
            return
        # Alt+Tab starts on the window used before this one; the current one is first
        current = x11.active_window()
        first_is_current = self.windows[0] == current and not x11.minimized(current)
        if delta > 0:
            self.sel = 1 if first_is_current and len(self.windows) > 1 else 0
        else:
            self.sel = len(self.windows) - 1
        self.active = True
        self.make_window()
        if not self.grab():
            self.finish(True)                       # no keyboard: just switch
            return
        if not self.alt_held():
            self.finish(True)                       # Alt already let go: a quick switch
            return
        self.show_id = GLib.timeout_add(SHOW_DELAY, self.show)

    def make_window(self):
        if self.win:
            self.win.destroy()
        self.win = Gtk.Window(type=Gtk.WindowType.POPUP)
        self.win.set_name("pine-switcher")
        vis = self.win.get_screen().get_rgba_visual()
        if vis:
            self.win.set_visual(vis)
        self.win.connect("key-press-event", self.on_key)
        self.win.connect("key-release-event", self.on_key_release)
        self.win.add_events(Gdk.EventMask.KEY_PRESS_MASK | Gdk.EventMask.KEY_RELEASE_MASK)
        # mapped right away (1 px, off screen) so it can take the keyboard at once
        self.win.move(-100, -100)
        self.win.resize(1, 1)
        self.win.show()

    def grab(self):
        seat = Gdk.Display.get_default().get_default_seat()
        for _try in range(10):                      # the shortcut's own grab may still be ending
            st = seat.grab(self.win.get_window(), Gdk.SeatCapabilities.KEYBOARD, False, None, None, None)
            if st == Gdk.GrabStatus.SUCCESS:
                return True
            GLib.usleep(10000)
        return False

    def alt_held(self):
        keymap = Gdk.Keymap.get_for_display(Gdk.Display.get_default())
        return bool(keymap.get_modifier_state() & Gdk.ModifierType.MOD1_MASK)

    def show(self):
        self.show_id = 0
        if not self.active:
            return False
        mon = Gdk.Display.get_default().get_monitor_at_point(*self.pointer()) \
            or Gdk.Display.get_default().get_primary_monitor()
        wa = mon.get_workarea()
        pictures = not game.active()
        card_w = THUMB_W if pictures else ICON_W
        per_row = max(1, min(len(self.windows), (wa.width - 80) // (card_w + 28)))
        flow = Gtk.FlowBox(selection_mode=Gtk.SelectionMode.NONE, homogeneous=True,
                           max_children_per_line=per_row, min_children_per_line=min(per_row, len(self.windows)),
                           column_spacing=6, row_spacing=6, margin=10)
        flow.set_can_focus(False)
        self.cards = []
        self.start_pointer = None
        for i, xid in enumerate(self.windows):
            card = Card(self, i, xid, pictures)
            self.cards.append(card)
            flow.add(card)
        for child in flow.get_children():
            child.set_can_focus(False)
        self.win.add(flow)
        flow.show_all()
        self.select(self.sel)
        _, nat = self.win.get_preferred_size()
        w, h = min(nat.width, wa.width - 40), min(nat.height, wa.height - 40)
        self.win.resize(w, h)
        self.win.move(wa.x + (wa.width - w) // 2, wa.y + (wa.height - h) // 2)
        return False

    def mouse_moved(self, ev):
        if self.start_pointer is None:
            self.start_pointer = (ev.x_root, ev.y_root)
        sx, sy = self.start_pointer
        return abs(ev.x_root - sx) + abs(ev.y_root - sy) > 6

    def pointer(self):
        _s, x, y = Gdk.Display.get_default().get_default_seat().get_pointer().get_position()[0:3]
        return x, y

    def select(self, i):
        self.sel = i
        for k, c in enumerate(self.cards):
            ctx = c.get_style_context()
            (ctx.add_class if k == i else ctx.remove_class)("selected")

    def on_key(self, _w, ev):
        k = ev.keyval
        shift = ev.state & Gdk.ModifierType.SHIFT_MASK
        if k == Gdk.KEY_Escape:
            self.finish(False)
        elif k in (Gdk.KEY_Return, Gdk.KEY_KP_Enter, Gdk.KEY_space):
            self.finish(True)
        elif k == Gdk.KEY_ISO_Left_Tab or (k == Gdk.KEY_Tab and shift) or k in (Gdk.KEY_Left, Gdk.KEY_Up):
            self.select((self.sel - 1) % len(self.windows))
        elif k in (Gdk.KEY_Tab, Gdk.KEY_Right, Gdk.KEY_Down):
            self.select((self.sel + 1) % len(self.windows))
        return True

    def on_key_release(self, _w, ev):
        if ev.keyval in (Gdk.KEY_Alt_L, Gdk.KEY_Alt_R, Gdk.KEY_Meta_L, Gdk.KEY_Meta_R):
            self.finish(True)
        return True

    def finish(self, switch):
        if not self.active:
            return
        self.active = False
        if self.show_id:
            GLib.source_remove(self.show_id)
            self.show_id = 0
        Gdk.Display.get_default().get_default_seat().ungrab()
        target = self.windows[self.sel] if switch and self.windows else None
        if self.win:
            self.win.destroy()
            self.win = None
        self.cards = []
        if target:
            # wmctrl asks the window manager to switch (and to un-minimize if needed)
            subprocess.Popen(["wmctrl", "-i", "-a", hex(target)])


if __name__ == "__main__":
    sys.exit(Switcher().run(sys.argv))
