"""The person's wallpaper, shared by the login veil and the sign-out / shut-down screen.

Scaled to cover the screen and centred like the desktop shows it: sign-in screen (the same
picture blurred) -> this -> desktop, and back again when signing out, so nothing jumps.
With Pine's own wallpaper it is the boot splash's picture too."""
import html
import json
import os
import re

from gi.repository import GdkPixbuf

WALLPAPER = "/usr/share/backgrounds/pine/pine-wallpaper.png"
FLAT = (6 / 255, 9 / 255, 12 / 255)             # #06090C, the splash colour


def user_wallpaper():
    """The picture the person's desktop shows (Pine Settings' choice, else the desktop's own
    setting), else Pine's. Read from their files: at sign-in the settings service isn't up yet."""
    config = os.environ.get("XDG_CONFIG_HOME") or os.path.expanduser("~/.config")
    paths = []
    try:
        with open(os.path.join(config, "pine", "settings.json"), encoding="utf-8") as f:
            paths.append(json.load(f).get("wallpaper"))
    except (OSError, ValueError, AttributeError):
        pass
    try:
        with open(os.path.join(config, "xfce4", "xfconf", "xfce-perchannel-xml", "xfce4-desktop.xml"),
                  encoding="utf-8") as f:
            paths += [html.unescape(p) for p in re.findall(r'name="last-image" type="string" value="([^"]*)"', f.read())]
    except (OSError, ValueError):
        pass
    return next((p for p in paths if isinstance(p, str) and os.path.isfile(p)), WALLPAPER)


def cover(width, height):
    """The picture scaled to cover width x height (edges cropped), or None."""
    pix = None
    for path in (user_wallpaper(), WALLPAPER):
        try:
            pix = GdkPixbuf.Pixbuf.new_from_file(path)
            pix = pix.apply_embedded_orientation() or pix
            break
        except Exception:
            continue
    if pix is None:
        return None
    s = max(width / pix.get_width(), height / pix.get_height())
    w, h = max(width, int(pix.get_width() * s + 0.5)), max(height, int(pix.get_height() * s + 0.5))
    big = pix.scale_simple(w, h, GdkPixbuf.InterpType.BILINEAR)
    return big.new_subpixbuf((w - width) // 2, (h - height) // 2, width, height)