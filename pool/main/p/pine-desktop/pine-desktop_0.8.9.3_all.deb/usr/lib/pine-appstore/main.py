#!/usr/bin/python3
"""App Store: find, install, open and remove apps (Flatpak / Flathub), in the Pine Settings look.

Usage: pine-appstore [app id | appstream://app.id]     (an id opens the search for it)
Home shows the picks from /etc/bazaar/curated.yaml; every section is also in the sidebar.
Search covers all of Flathub's apps (its catalog is cached on the computer: offline it still
shows what was downloaded last). Install and remove use the system Flatpak (it asks for your
password through Pine's sign-in prompt); nothing else is changed.
"""
import gzip
import os
import re
import sys
import threading
import xml.etree.ElementTree as ET

_HERE = os.path.dirname(os.path.abspath(__file__))
for _p in ("/usr/lib/pine-settings", os.path.join(_HERE, "..", "pine-settings")):
    if os.path.isdir(_p):
        sys.path.insert(0, _p)

import gi  # noqa: E402
gi.require_version("Gtk", "4.0")
gi.require_version("Adw", "1")
gi.require_version("Flatpak", "1.0")            # gir1.2-flatpak-1.0: real download progress
from gi.repository import Adw, Flatpak, Gio, GLib, Gtk  # noqa: E402

import look  # noqa: E402

try:
    from common import _
except Exception:  # pragma: no cover
    def _(t):
        return t

CURATED = ["/etc/bazaar/curated.yaml", os.path.join(_HERE, "..", "..", "..", "etc", "bazaar", "curated.yaml")]
BANNER = "/etc/bazaar/pine-banner.png"
CATALOGS = ["/var/lib/flatpak/appstream/flathub/x86_64/active",
            os.path.expanduser("~/.local/share/flatpak/appstream/flathub/x86_64/active")]
LANG = "{http://www.w3.org/XML/1998/namespace}lang"
ICONS = [("games", "input-gaming-symbolic"), ("office", "x-office-document-symbolic"),
         ("photo", "applications-multimedia-symbolic"), ("phone", "phone-symbolic"),
         ("chat", "chat-message-new-symbolic"), ("browser", "web-browser-symbolic"),
         ("tools", "applications-utilities-symbolic")]


# ---------------------------------------------------------------- data
def load_curated():
    """[{title, ids}] from the Bazaar home-page file (sections only; banner and carousel skipped)."""
    text = ""
    for p in CURATED:
        try:
            with open(p, encoding="utf-8") as f:
                text = f.read()
            break
        except OSError:
            continue
    sections, cur = [], None
    for line in text.splitlines():
        s = line.strip()
        if s.startswith("- section:"):
            cur = {"title": "", "ids": []}
            sections.append(cur)
        elif s.startswith(("- banner:", "- featured-carousel:")):
            cur = None
        elif cur is not None:
            m = re.match(r'title:\s*"?(.*?)"?$', s)
            if m and not cur["title"]:
                cur["title"] = m.group(1)
                continue
            m = re.match(r"-\s+([A-Za-z0-9_\-]+(?:\.[A-Za-z0-9_\-]+)+)\s*$", s)
            if m:
                cur["ids"].append(m.group(1))
    return [s for s in sections if s["title"] and s["ids"]]


def load_catalog():
    """{app id: {name, summary, icon}} from Flatpak's cached Flathub catalog (may be empty)."""
    for d in CATALOGS:
        p = os.path.join(d, "appstream.xml.gz")
        if os.path.exists(p):
            break
    else:
        return {}
    cat = {}
    try:
        with gzip.open(p, "rb") as f:
            for _ev, el in ET.iterparse(f):
                if el.tag != "component":
                    continue
                if el.get("type") == "desktop-application":
                    aid = (el.findtext("id") or "").removesuffix(".desktop")
                    name = next((n.text for n in el.findall("name") if n.get(LANG) is None), None)
                    summ = next((n.text for n in el.findall("summary") if n.get(LANG) is None), "")
                    icon = ""
                    for ic in el.findall("icon"):
                        if ic.get("type") == "cached" and ic.text:
                            icon = os.path.join(d, "icons", f"{ic.get('width', '64')}x{ic.get('height', '64')}", ic.text)
                            if ic.get("width") == "64":
                                break
                    if aid and name:
                        cat[aid] = {"name": name, "summary": summ or "", "icon": icon}
                el.clear()
    except (OSError, ET.ParseError, EOFError):
        pass
    return cat


def flatpak_list(*args):
    try:
        r = Gio.Subprocess.new(["flatpak"] + list(args), Gio.SubprocessFlags.STDOUT_PIPE | Gio.SubprocessFlags.STDERR_SILENCE)
        ok, out, _e = r.communicate_utf8(None, None)
        return [l.strip() for l in (out or "").splitlines() if l.strip()] if ok else []
    except GLib.Error:
        return []


# ---------------------------------------------------------------- installing
def mb(n):
    return f"{n / 1_000_000:.1f} MB" if n < 1_000_000_000 else f"{n / 1_000_000_000:.2f} GB"


def transact(kind, aid, report):
    """Run one Flatpak transaction (system installation; polkit asks for the password).
    kind: "install", "uninstall" or "update" (all apps). report(fraction, text) is called as it goes:
    fraction covers all parts (an app often brings a runtime with it)."""
    inst = Flatpak.Installation.new_system(None)
    tx = Flatpak.Transaction.new_for_installation(inst, None)
    tx.add_default_dependency_sources()
    if kind == "install":
        ref = inst.fetch_remote_ref_sync("flathub", Flatpak.RefKind.APP, aid, Flatpak.get_default_arch(), "stable", None)
        tx.add_install("flathub", ref.format_ref(), None)
    elif kind == "uninstall":
        tx.add_uninstall(inst.get_current_installed_app(aid, None).format_ref())
    else:
        for ref in inst.list_installed_refs_for_update(None):
            tx.add_update(ref.format_ref(), None, None)
    state = {"part": 0, "parts": 1, "done": 0, "total": 1}   # done / total: weight of the parts, by size
    verbs = {Flatpak.TransactionOperationType.UNINSTALL: _("Removing"),
             Flatpak.TransactionOperationType.UPDATE: _("Updating")}

    def weight(op):                       # removing downloads nothing: all parts count the same
        return 1 if op.get_operation_type() == Flatpak.TransactionOperationType.UNINSTALL else max(1, op.get_download_size())

    def ready(t):
        ops = t.get_operations()
        state["parts"] = max(1, len(ops))
        state["total"] = max(1, sum(weight(op) for op in ops))
        return True

    def new_operation(_t, op, progress):
        state["part"] += 1
        part = state["part"]
        total = op.get_download_size()
        before, size = state["done"], weight(op)
        state["done"] += size
        verb = verbs.get(op.get_operation_type(), _("Downloading"))

        def changed(p):
            percent = p.get_progress()
            text = verb + "…"
            done = p.get_bytes_transferred()
            if done and total and op.get_operation_type() != Flatpak.TransactionOperationType.UNINSTALL:
                text += f"  {mb(done)} / {mb(max(total, done))}"
            if state["parts"] > 1:
                text += "  ·  " + _("part %d of %d") % (part, state["parts"])
            report(min(1.0, (before + size * percent / 100) / state["total"]), text)
        progress.set_update_frequency(200)
        progress.connect("changed", changed)
        changed(progress)

    tx.connect("ready", ready)
    tx.connect("new-operation", new_operation)
    tx.run(None)            # raises GLib.Error (also when the password prompt is closed)


# ---------------------------------------------------------------- rows
class AppRow(Adw.ActionRow):
    def __init__(self, win, aid):
        info = win.catalog.get(aid, {})
        super().__init__(title=GLib.markup_escape_text(info.get("name") or aid),
                         subtitle=GLib.markup_escape_text(info.get("summary", "")))
        self.win, self.aid = win, aid
        self.set_subtitle_lines(1)
        img = Gtk.Image(pixel_size=48)
        path = info.get("icon")
        if path and os.path.exists(path):
            img.set_from_file(path)
        else:
            img.set_from_icon_name("application-x-executable")
        self.add_prefix(img)
        box = Gtk.Box(spacing=6, valign=Gtk.Align.CENTER)
        # while installing: a bar with the percentage, and sizes below (like apt)
        self.prog = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=2, valign=Gtk.Align.CENTER)
        self.bar = Gtk.ProgressBar(show_text=True)
        self.bar.set_size_request(220, -1)
        self.detail = Gtk.Label(xalign=1)
        self.detail.add_css_class("caption")
        self.detail.add_css_class("dim-label")
        self.detail.add_css_class("numeric")
        self.prog.append(self.bar)
        self.prog.append(self.detail)
        self.get = Gtk.Button(label=_("Get"))
        self.get.add_css_class("suggested-action")
        self.get.connect("clicked", lambda _b: win.install(aid))
        self.open = Gtk.Button(label=_("Open"))
        self.open.connect("clicked", lambda _b: win.open_app(aid))
        self.remove = Gtk.Button(icon_name="user-trash-symbolic", tooltip_text=_("Uninstall"))
        self.remove.add_css_class("flat")
        self.remove.connect("clicked", lambda _b: win.uninstall(aid))
        for w in (self.prog, self.get, self.open, self.remove):
            box.append(w)
        self.add_suffix(box)
        self.restate()

    def _job(self):
        """The running job this row shows: its own, or "Update all"."""
        return next((k for k in (self.aid, "*updates*") if k in self.win.busy), None)

    def pulse(self):
        job = self._job()
        if job and self.win.progress.get(job, (None, ""))[0] is None:
            self.bar.pulse()

    def restate(self):
        job = self._job()
        busy = job is not None
        have = self.aid in self.win.installed
        self.prog.set_visible(busy)
        if busy:
            fraction, text = self.win.progress.get(job, (None, ""))
            if fraction is None:
                self.bar.set_show_text(False)
            else:
                self.bar.set_show_text(True)
                self.bar.set_fraction(fraction)
                self.bar.set_text(f"{int(fraction * 100)} %")
            self.detail.set_label(text)
        self.get.set_visible(not busy and not have)
        self.open.set_visible(not busy and have)
        self.remove.set_visible(not busy and have)


# ---------------------------------------------------------------- window
class Window(Adw.ApplicationWindow):
    def __init__(self, app, first=None):
        super().__init__(application=app, title=_("App Store"))
        self.set_default_size(1000, 720)
        self.set_size_request(360, 400)
        look.apply()
        self.catalog, self.installed, self.busy, self.rows = {}, set(), set(), []
        self.progress = {}          # job -> (fraction 0..1 or None, text)
        GLib.timeout_add(120, self._pulse)
        self.sections = load_curated()
        self.key = "home"
        self.loaded = False

        self.toasts = Adw.ToastOverlay()
        self.split = Adw.NavigationSplitView()
        self.split.set_min_sidebar_width(260)
        self.split.set_max_sidebar_width(300)
        bp = Adw.Breakpoint.new(Adw.BreakpointCondition.parse("max-width: 640sp"))
        bp.add_setter(self.split, "collapsed", True)
        self.add_breakpoint(bp)
        self.toasts.set_child(self.split)
        self.set_content(self.toasts)

        self.body = Adw.ToolbarView()
        self.body.add_top_bar(Adw.HeaderBar())
        self.content = Adw.NavigationPage(title=_("Home"), child=self.body)
        self.split.set_content(self.content)
        self.split.set_sidebar(self._sidebar())
        self.show("home", loading=True)
        if first:
            self.search.set_text(first)
        threading.Thread(target=self._load, daemon=True).start()

    # ---- sidebar (same structure as Pine Settings)
    def _sidebar(self):
        box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=6, margin_start=10, margin_end=10, margin_bottom=10)
        card = Gtk.Button()
        card.add_css_class("flat")
        card.add_css_class("pine-usercard")
        inner = Gtk.Box(spacing=12)
        badge = Gtk.Image.new_from_icon_name("system-software-install-symbolic")
        badge.set_pixel_size(24)
        badge.add_css_class("pine-badge")
        inner.append(badge)
        texts = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, valign=Gtk.Align.CENTER)
        n = Gtk.Label(label=_("App Store"), xalign=0)
        n.add_css_class("heading")
        texts.append(n)
        self.summary = Gtk.Label(xalign=0)
        self.summary.add_css_class("dim-label")
        self.summary.add_css_class("caption")
        texts.append(self.summary)
        inner.append(texts)
        card.set_child(inner)
        card.connect("clicked", lambda *_a: self.go("home"))
        box.append(card)
        self.search = Gtk.SearchEntry(placeholder_text=_("Search apps"))
        self.search.connect("search-changed", self._search)
        box.append(self.search)
        self.list = Gtk.ListBox()
        self.list.add_css_class("navigation-sidebar")
        self.nav = {}
        entries = [("home", _("Home"), "go-home-symbolic")]
        for i, s in enumerate(self.sections):
            low = s["title"].lower()
            entries.append((f"sec:{i}", s["title"], next((ic for k, ic in ICONS if k in low), "view-app-grid-symbolic")))
        entries += [("installed", _("Installed"), "object-select-symbolic"),
                    ("updates", _("Updates"), "software-update-available-symbolic")]
        for key, label, icon in entries:
            r = Gtk.ListBoxRow()
            hb = Gtk.Box(spacing=12, margin_start=6)
            hb.append(Gtk.Image.new_from_icon_name(icon))
            hb.append(Gtk.Label(label=label, xalign=0, ellipsize=3))
            r.set_child(hb)
            r.key, r.label = key, label
            self.nav[key] = r
            self.list.append(r)
        self.list.connect("row-activated", lambda _l, r: self.go(r.key))
        sc = Gtk.ScrolledWindow(vexpand=True, hscrollbar_policy=Gtk.PolicyType.NEVER, child=self.list)
        box.append(sc)
        tv = Adw.ToolbarView()
        tv.add_top_bar(Adw.HeaderBar())
        tv.set_content(box)
        return Adw.NavigationPage(title=_("App Store"), child=tv)

    def go(self, key):
        if self.search.get_text():
            self.search.set_text("")
        self.show(key)
        self.split.set_show_content(True)

    # ---- data loading (off the main thread)
    def _load(self):
        cat = load_catalog()
        inst = set(flatpak_list("list", "--app", "--columns=application"))
        GLib.idle_add(self._loaded, cat, inst)

    def _loaded(self, cat, inst):
        self.catalog, self.installed, self.loaded = cat, inst, True
        self.summary.set_label(self._count_text())
        self._search(self.search) if self.search.get_text() else self.show(self.key)
        return False

    def _count_text(self):
        n = len(self.installed - {"io.github.kolunmi.Bazaar"})
        return _("1 app installed") if n == 1 else _("%d apps installed") % n

    def reload_installed(self):
        def work():
            inst = set(flatpak_list("list", "--app", "--columns=application"))
            GLib.idle_add(self._installed_now, inst)
        threading.Thread(target=work, daemon=True).start()

    def _installed_now(self, inst):
        self.installed = inst
        self.summary.set_label(self._count_text())
        if self.key == "installed" and not self.search.get_text():
            self.show("installed")
        else:
            for r in self.rows:
                r.restate()
        return False

    # ---- pages
    def _set(self, widget, title):
        self.content.set_title(title)
        self.body.set_content(widget)

    def _status(self, icon, title, text="", spinner=False):
        s = Adw.StatusPage(icon_name=icon, title=title, description=text)
        if spinner:
            sp = Gtk.Spinner(spinning=True, halign=Gtk.Align.CENTER)
            sp.set_size_request(32, 32)
            s.set_child(sp)
        return s

    def _group(self, title, ids, desc=None, limit=None, more=None):
        g = Adw.PreferencesGroup(title=GLib.markup_escape_text(title))
        if desc:
            g.set_description(GLib.markup_escape_text(desc))
        for aid in (ids[:limit] if limit else ids):
            row = AppRow(self, aid)
            self.rows.append(row)
            g.add(row)
        if more and limit and len(ids) > limit:
            b = Gtk.Button(label=_("Show all"))
            b.add_css_class("flat")
            b.connect("clicked", lambda _b: self.go(more))
            g.set_header_suffix(b)
        return g

    def show(self, key, loading=False):
        self.key = key
        self.rows = []
        row = self.nav.get(key)
        if row is not None:
            self.list.select_row(row)
        else:
            self.list.unselect_all()
        title = row.label if row else _("Search")
        if loading or not self.loaded:
            self._set(self._status("system-software-install-symbolic", _("Loading apps…"), spinner=True), title)
            return
        if key == "home":
            page = Adw.PreferencesPage()
            if os.path.exists(BANNER):
                pic = Gtk.Picture.new_for_filename(BANNER)
                pic.set_content_fit(Gtk.ContentFit.COVER)
                pic.set_size_request(-1, 150)
                frame = Gtk.Box()
                frame.add_css_class("card")
                frame.set_overflow(Gtk.Overflow.HIDDEN)
                frame.append(pic)
                pic.set_hexpand(True)
                g = Adw.PreferencesGroup()
                g.add(frame)
                page.add(g)
            if not self.catalog:
                page.add(Adw.PreferencesGroup(title=_("The app list is not on this computer yet"),
                                              description=_("Connect to the internet; the list downloads the first time you open an app store page.")))
            for i, s in enumerate(self.sections):
                page.add(self._group(s["title"], s["ids"], limit=5, more=f"sec:{i}"))
            self._set(page, title)
        elif key.startswith("sec:"):
            s = self.sections[int(key[4:])]
            page = Adw.PreferencesPage()
            page.add(self._group(s["title"], s["ids"]))
            self._set(page, title)
        elif key == "installed":
            ids = sorted(self.installed, key=lambda a: (self.catalog.get(a, {}).get("name") or a).lower())
            ids = [a for a in ids if not a.startswith(("org.freedesktop.", "org.gnome.Platform", "org.kde.Platform"))
                   and a != "io.github.kolunmi.Bazaar"]      # Bazaar is kept as a fallback, not shown
            if not ids:
                self._set(self._status("object-select-symbolic", _("No apps installed from the store yet"),
                                       _("Apps you get here show up in this list.")), title)
                return
            page = Adw.PreferencesPage()
            page.add(self._group(_("Installed apps"), ids))
            self._set(page, title)
        elif key == "updates":
            self._set(self._status("software-update-available-symbolic", _("Looking for updates…"), spinner=True), title)

            def work():
                ids = flatpak_list("remote-ls", "--updates", "--app", "--columns=application")
                GLib.idle_add(self._updates_ready, ids)
            threading.Thread(target=work, daemon=True).start()

    def _updates_ready(self, ids):
        if self.key != "updates":
            return False
        title = self.nav["updates"].label
        if not ids:
            self._set(self._status("object-select-symbolic", _("Your apps are up to date")), title)
            return False
        page = Adw.PreferencesPage()
        g = self._group(_("Updates"), ids)
        b = Gtk.Button(label=_("Update all"))
        b.add_css_class("suggested-action")
        b.connect("clicked", lambda _b: self._update_all())
        g.set_header_suffix(b)
        page.add(g)
        self._set(page, title)
        return False

    def _search(self, entry):
        q = entry.get_text().strip().lower()
        if not q:
            self.show(self.key if self.key != "search" else "home")
            return
        if not self.loaded:
            return
        words = q.replace("appstream://", "").split()
        hits = [a for a, i in self.catalog.items()
                if all(w in f"{i['name']} {i['summary']} {a}".lower() for w in words)]
        hits.sort(key=lambda a: (not self.catalog[a]["name"].lower().startswith(words[0]), self.catalog[a]["name"].lower()))
        self.key = "search"
        self.rows = []
        self.list.unselect_all()
        if not hits:
            self._set(self._status("system-search-symbolic", _("No apps found"),
                                   _("Try a different word, like “music”, “photo” or “game”.")), _("Search"))
            return
        page = Adw.PreferencesPage()
        page.add(self._group(_("Results for “%s”") % entry.get_text().strip(), hits[:60]))
        self._set(page, _("Search"))
        self.split.set_show_content(True)

    # ---- actions
    def toast(self, text):
        t = Adw.Toast.new(text)
        t.set_timeout(4)
        self.toasts.add_toast(t)

    def _run(self, kind, aid, ok_text):
        """Install, uninstall or update in the background (libflatpak, like apt: with progress)."""
        if aid in self.busy:
            return
        self.busy.add(aid)
        self.progress[aid] = (None, _("Preparing…"))
        for r in self.rows:
            r.restate()

        def work():
            try:
                transact(kind, aid, lambda fraction, text: GLib.idle_add(self._progress, aid, fraction, text))
                GLib.idle_add(done, None)
            except GLib.Error as e:
                GLib.idle_add(done, e.message)

        def done(error):
            self.busy.discard(aid)
            self.progress.pop(aid, None)
            self.toast(error or ok_text)
            self.reload_installed()
            for r in self.rows:
                r.restate()
            if self.key == "updates":
                self.show("updates")
            return False
        threading.Thread(target=work, daemon=True).start()

    def _progress(self, aid, fraction, text):
        if aid in self.busy:
            self.progress[aid] = (fraction, text)
            for r in self.rows:
                r.restate()
        return False

    def _pulse(self):
        for r in self.rows:
            r.pulse()
        return True

    def _name(self, aid):
        return self.catalog.get(aid, {}).get("name") or aid

    def install(self, aid):
        self._run("install", aid, _("%s is installed") % self._name(aid))

    def uninstall(self, aid):
        self._run("uninstall", aid, _("%s was removed") % self._name(aid))

    def open_app(self, aid):
        try:
            Gio.Subprocess.new(["flatpak", "run", aid], Gio.SubprocessFlags.NONE)
        except GLib.Error as e:
            self.toast(e.message)

    def _update_all(self):
        self._run("update", "*updates*", _("Your apps are up to date"))


class App(Adw.Application):
    def __init__(self):
        super().__init__(application_id="org.pineos.AppStore", flags=Gio.ApplicationFlags.HANDLES_COMMAND_LINE)
        self.connect("command-line", self._cmd)

    def _cmd(self, _app, cmdline):
        args = [a for a in cmdline.get_arguments()[1:] if not a.startswith("-")]
        first = args[0].replace("appstream://", "") if args else None
        win = self.props.active_window
        if win:
            win.present()
            if first:
                win.search.set_text(first)
        else:
            Window(self, first).present()
        return 0


if __name__ == "__main__":
    sys.exit(App().run(sys.argv))
